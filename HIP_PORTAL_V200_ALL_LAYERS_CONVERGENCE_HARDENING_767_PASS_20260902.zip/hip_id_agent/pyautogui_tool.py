from __future__ import annotations

import asyncio
import os
import platform
from pathlib import Path
from typing import Any, Dict, Optional

from .safe_io import safe_write_json
from .security import mask_sensitive_string


class PyAutoGUIUnavailable(RuntimeError):
    pass


class PyAutoGUIFallbackTool:
    """Last-resort desktop interaction helper for visible HIP controls.

    This tool never discovers a target on its own.  The deterministic browser layer
    must already have resolved a unique, visible Playwright locator and passed the
    normal HIP form/mutation safety policy.  PyAutoGUI is used only when MCP and
    normal Playwright interaction fail against that exact locator.
    """

    def __init__(self, config: Any, run_dir: str | Path):
        self.config = config
        self.run_dir = Path(run_dir)
        self.audit_dir = self.run_dir / "pyautogui"
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        self._module: Any = None
        self._sequence = 0

    @property
    def policy(self) -> Any:
        return getattr(self.config, "pyautogui", None)

    def enabled(self) -> bool:
        cfg = self.policy
        return bool(cfg is not None and getattr(cfg, "enabled", True))

    def _load(self) -> Any:
        if self._module is not None:
            return self._module
        if not self.enabled():
            raise PyAutoGUIUnavailable("PyAutoGUI fallback is disabled by config.")
        if bool(getattr(self.policy, "windows_only", True)) and platform.system().lower() != "windows":
            raise PyAutoGUIUnavailable("PyAutoGUI fallback is enabled only on Windows in this HIP build.")
        if bool(getattr(getattr(self.config, "portal", None), "headless", False)):
            raise PyAutoGUIUnavailable("PyAutoGUI fallback is unavailable in headless browser mode.")
        try:
            import pyautogui  # type: ignore
        except Exception as exc:  # lazy import: headless/Linux test environments stay unaffected
            raise PyAutoGUIUnavailable(f"PyAutoGUI is not available: {exc}") from exc
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = max(0.0, float(getattr(self.policy, "pause_seconds", 0.05)))
        self._module = pyautogui
        return pyautogui

    def status(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "enabled": self.enabled(),
            "mode": "last-resort-visible-control-fallback",
            "windows_only": bool(getattr(self.policy, "windows_only", True)) if self.policy is not None else True,
            "allow_mutation_clicks": bool(getattr(self.policy, "allow_mutation_clicks", False)) if self.policy is not None else False,
            "available": False,
        }
        if not result["enabled"]:
            result["reason"] = "disabled"
            return result
        try:
            module = self._load()
            size = module.size()
            result.update({"available": True, "screen": {"width": int(size.width), "height": int(size.height)}})
        except Exception as exc:
            result["reason"] = mask_sensitive_string(str(exc))
        return result

    def _is_mutating_action(self, action: str) -> bool:
        text = str(action or "").lower()
        safe_exact = {"add", "+ add", "continue", "next", "back", "cancel", "close", "done", "proceed"}
        if text.strip() in safe_exact:
            return False
        return any(word in text for word in ("save", "create", "submit", "delete", "remove", "deploy", "publish", "update", "enable", "disable", "confirm"))

    async def _stable_screen_point(self, page: Any, locator: Any) -> Dict[str, Any]:
        pyautogui = self._load()
        await page.bring_to_front()
        await locator.first.scroll_into_view_if_needed(timeout=int(getattr(self.policy, "locator_timeout_ms", 5000)))
        first = await locator.first.bounding_box(timeout=int(getattr(self.policy, "locator_timeout_ms", 5000)))
        if not first or first.get("width", 0) <= 1 or first.get("height", 0) <= 1:
            raise PyAutoGUIUnavailable("Resolved HIP control does not have a visible bounding box.")
        await asyncio.sleep(max(0.05, float(getattr(self.policy, "stability_wait_ms", 150)) / 1000.0))
        second = await locator.first.bounding_box(timeout=int(getattr(self.policy, "locator_timeout_ms", 5000)))
        if not second:
            raise PyAutoGUIUnavailable("Resolved HIP control disappeared before desktop fallback.")
        tolerance = float(getattr(self.policy, "bbox_stability_tolerance_px", 3.0))
        for key in ("x", "y", "width", "height"):
            if abs(float(first.get(key, 0)) - float(second.get(key, 0))) > tolerance:
                raise PyAutoGUIUnavailable("Resolved HIP control is moving/rerendering; refusing coordinate fallback.")

        metrics = await page.evaluate("""
() => ({
  screenX:Number(window.screenX||0), screenY:Number(window.screenY||0),
  outerWidth:Number(window.outerWidth||window.innerWidth||0), outerHeight:Number(window.outerHeight||window.innerHeight||0),
  innerWidth:Number(window.innerWidth||0), innerHeight:Number(window.innerHeight||0),
  screenWidth:Number(window.screen?.width||0), screenHeight:Number(window.screen?.height||0),
  vvX:Number(window.visualViewport?.offsetLeft||0), vvY:Number(window.visualViewport?.offsetTop||0)
})
""")
        screen = pyautogui.size()
        js_sw = max(1.0, float(metrics.get("screenWidth") or screen.width))
        js_sh = max(1.0, float(metrics.get("screenHeight") or screen.height))
        sx = float(screen.width) / js_sw
        sy = float(screen.height) / js_sh
        border_x = max(0.0, (float(metrics.get("outerWidth") or 0) - float(metrics.get("innerWidth") or 0)) / 2.0)
        chrome_y = max(0.0, float(metrics.get("outerHeight") or 0) - float(metrics.get("innerHeight") or 0) - border_x)
        css_x = float(metrics.get("screenX") or 0) + border_x + float(second["x"]) + float(second["width"]) / 2.0 + float(metrics.get("vvX") or 0)
        css_y = float(metrics.get("screenY") or 0) + chrome_y + float(second["y"]) + float(second["height"]) / 2.0 + float(metrics.get("vvY") or 0)
        x, y = int(round(css_x * sx)), int(round(css_y * sy))
        margin = int(getattr(self.policy, "screen_margin_px", 2))
        if not (margin <= x < int(screen.width) - margin and margin <= y < int(screen.height) - margin):
            raise PyAutoGUIUnavailable(f"Calculated desktop point ({x},{y}) is outside the active screen.")
        return {
            "x": x, "y": y,
            "bbox": {k: float(second[k]) for k in ("x", "y", "width", "height")},
            "screen": {"width": int(screen.width), "height": int(screen.height)},
            "scale": {"x": sx, "y": sy},
        }

    def _write_audit(self, payload: Dict[str, Any]) -> None:
        self._sequence += 1
        safe_write_json(self.audit_dir / f"desktop_action_{self._sequence:05d}.json", payload)

    async def click_locator(self, page: Any, locator: Any, *, action: str, selector: str = "") -> Dict[str, Any]:
        if self._is_mutating_action(action) and not bool(getattr(self.policy, "allow_mutation_clicks", False)):
            raise PyAutoGUIUnavailable("PyAutoGUI is not permitted for final mutating clicks; use governed DOM/MCP execution.")
        pyautogui = self._load()
        point = await self._stable_screen_point(page, locator)
        payload = {"kind": "click", "action": str(action), "selector": str(selector), "point": point, "pass": False}
        try:
            pyautogui.moveTo(point["x"], point["y"], duration=max(0.0, float(getattr(self.policy, "move_duration_seconds", 0.12))))
            pyautogui.click()
            await asyncio.sleep(max(0.05, float(getattr(self.policy, "settle_ms", 300)) / 1000.0))
            payload["pass"] = True
            return payload
        except Exception as exc:
            payload["error"] = mask_sensitive_string(str(exc))
            raise
        finally:
            self._write_audit(payload)

    async def fill_locator(self, page: Any, locator: Any, value: str, *, selector: str = "") -> Dict[str, Any]:
        text = str(value)
        if bool(getattr(self.policy, "ascii_only_text", True)) and any(ord(ch) > 127 for ch in text):
            raise PyAutoGUIUnavailable("PyAutoGUI text fallback is ASCII-only to avoid clipboard leakage and keyboard-layout ambiguity.")
        pyautogui = self._load()
        point = await self._stable_screen_point(page, locator)
        payload = {"kind": "fill", "selector": str(selector), "point": point, "value_length": len(text), "pass": False}
        try:
            pyautogui.moveTo(point["x"], point["y"], duration=max(0.0, float(getattr(self.policy, "move_duration_seconds", 0.12))))
            pyautogui.click()
            pyautogui.hotkey("ctrl", "a")
            pyautogui.write(text, interval=max(0.0, float(getattr(self.policy, "key_interval_seconds", 0.01))))
            await asyncio.sleep(max(0.05, float(getattr(self.policy, "settle_ms", 300)) / 1000.0))
            payload["pass"] = True
            return payload
        except Exception as exc:
            payload["error"] = mask_sensitive_string(str(exc))
            raise
        finally:
            self._write_audit(payload)

    async def press_key(self, page: Any, key: str, *, selector: str = "") -> Dict[str, Any]:
        pyautogui = self._load()
        await page.bring_to_front()
        normalized = str(key or "").strip().lower()
        mapping = {"enter": "enter", "tab": "tab", "escape": "esc", "esc": "esc", "arrowdown": "down", "arrowup": "up", "space": "space"}
        resolved = mapping.get(normalized, normalized)
        payload = {"kind": "press", "selector": str(selector), "key": resolved, "pass": False}
        try:
            pyautogui.press(resolved)
            await asyncio.sleep(max(0.05, float(getattr(self.policy, "settle_ms", 300)) / 1000.0))
            payload["pass"] = True
            return payload
        except Exception as exc:
            payload["error"] = mask_sensitive_string(str(exc))
            raise
        finally:
            self._write_audit(payload)
