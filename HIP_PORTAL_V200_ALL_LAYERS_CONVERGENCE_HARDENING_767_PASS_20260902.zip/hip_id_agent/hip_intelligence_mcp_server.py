from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Any, Dict

from .action_model import HIPActionModel, course_architecture_manifest
from .trajectory_memory import TrajectoryMemory
from .web_representation import build_web_representation, representation_drift


TOOLS = [
    {
        "name": "build_web_representation",
        "description": "Build a value-free semantic embedding of a HIP portal surface from DOM/accessibility controls.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "plan_form_action",
        "description": "Rank one safe field action and bounded recovery candidates using the action model and trajectory priors.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "critique_action_result",
        "description": "Critique a completed field transaction using exact stability, event and mutation evidence.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "retrieve_similar_trajectories",
        "description": "Retrieve value-free successful and failed trajectories for a structurally similar HIP field action.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "record_trajectory_outcome",
        "description": "Record a value-free successful or failed HIP action transition for future planning.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "detect_web_representation_drift",
        "description": "Compare two value-free HIP web representations and detect portal structure drift.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
    {
        "name": "get_course_architecture_manifest",
        "description": "Return the implemented mapping of course web-agent concepts to the HIP runtime.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": True},
    },
]


class Server:
    def __init__(self, memory_dir: Path) -> None:
        self.memory = TrajectoryMemory(memory_dir)
        self.action_model = HIPActionModel()

    def call(self, name: str, args: Dict[str, Any]) -> Any:
        if name == "build_web_representation":
            return build_web_representation(
                phase=str(args.get("phase") or ""),
                url=str(args.get("url") or ""),
                controls=args.get("controls") or [],
                surface_gate=args.get("surface_gate") or {},
                dom_transition=args.get("dom_transition") or {},
                console_signatures=args.get("console_signatures") or [],
                network_signatures=args.get("network_signatures") or [],
            )
        if name == "plan_form_action":
            return self.action_model.plan(
                node=args.get("node") or {},
                representation=args.get("representation") or {},
                binding=args.get("binding") or {},
                surface_gate=args.get("surface_gate") or {},
                memory_matches=args.get("memory_matches") or [],
                interaction_state=args.get("interaction_state") or {},
            )
        if name == "critique_action_result":
            return self.action_model.critique(
                node=args.get("node") or {},
                action_plan=args.get("action_plan") or {},
                outcome=args.get("outcome") or {},
            )
        if name == "retrieve_similar_trajectories":
            return self.memory.retrieve(
                phase=str(args.get("phase") or ""),
                family=str(args.get("family") or ""),
                node=args.get("node") or {},
                representation=args.get("representation") or {},
                limit=int(args.get("limit") or 8),
            )
        if name == "record_trajectory_outcome":
            return self.memory.record(
                phase=str(args.get("phase") or ""),
                family=str(args.get("family") or ""),
                node=args.get("node") or {},
                representation_before=args.get("representation_before") or {},
                action_plan=args.get("action_plan") or {},
                outcome=args.get("outcome") or {},
                representation_after=args.get("representation_after") or {},
            )
        if name == "detect_web_representation_drift":
            return representation_drift(args.get("current") or {}, args.get("previous") or {})
        if name == "get_course_architecture_manifest":
            return course_architecture_manifest()
        raise ValueError(f"Unknown MCP tool: {name}")


def _result(value: Any) -> Dict[str, Any]:
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return {"content": [{"type": "text", "text": text}], "structuredContent": value, "isError": False}


async def serve(memory_dir: Path) -> None:
    server = Server(memory_dir)
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.buffer.readline)
        if not line:
            break
        try:
            request = json.loads(line.decode("utf-8"))
        except Exception:
            continue
        if not isinstance(request, dict):
            continue
        method = request.get("method")
        req_id = request.get("id")
        params = request.get("params") or {}
        if method == "notifications/initialized":
            continue
        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "hip-intelligence-mcp", "version": "1.0.0"},
                }
            elif method == "tools/list":
                result = {"tools": TOOLS}
            elif method == "tools/call":
                result = _result(server.call(str(params.get("name") or ""), params.get("arguments") or {}))
            else:
                raise ValueError(f"Unsupported method: {method}")
            response = {"jsonrpc": "2.0", "id": req_id, "result": result}
        except Exception as exc:
            response = {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32000, "message": str(exc)},
            }
        sys.stdout.write(json.dumps(response, ensure_ascii=False, default=str) + "\n")
        sys.stdout.flush()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--memory-dir", required=True)
    args = parser.parse_args()
    asyncio.run(serve(Path(args.memory_dir)))


if __name__ == "__main__":
    main()
