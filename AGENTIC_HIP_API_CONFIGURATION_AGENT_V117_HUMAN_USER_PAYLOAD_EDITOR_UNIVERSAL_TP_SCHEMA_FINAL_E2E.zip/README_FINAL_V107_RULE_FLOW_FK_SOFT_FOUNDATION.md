# V107 Final — Rule Flow FK + Soft Foundation Gating

**Build ID:** `2026-08-29-agentic-hip-v107-business-final-strict-live-rule-flow-fk-soft-foundation-fix`

## Corrected from the 2026-08-29 LIVE report

1. Mapping Rule no longer submits `flowDefinitionId: 0`. The API attribute is unchanged; V107 resolves a positive value from live/configured evidence, with the approved `flowTemplateId` as the package fallback.
2. `FK_MAC_RULE_FLOW_DEF` is treated as a permanent Rule/backend contract error and is not repeatedly auto-retried.
3. Account/Partner/System create failures caused by a missing PCF route remain external API failures, but they no longer hard-block TP orchestration whose approved request is name-addressed.
4. TP audits still require the corresponding TP create call to succeed; Flow creation still requires Rule + TP audit success. No downstream success is fabricated.
5. Endpoint overrides remain available through `HIP_ACCOUNT_API_URL`, `HIP_PARTNER_API_URL`, and `HIP_SYSTEM_API_URL`. A specific Rule parent can be supplied through `HIP_RULE_FLOW_DEFINITION_ID` if the API team provides one.

No credentialed LIVE HIP mutation is performed by package validation.
