from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import run_agent
from business_demo import prepare_uhal_business_demo
from report_insights import analyze_api_response

ROOT = Path(__file__).resolve().parent


def _ok_result(seq, group, api, attempt, method, url_key, token_kind="HIP"):
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}",
        token_kind, "", 200, "PASS_SUCCESS", True, 1,
        "", "{}", '{"success":true}', {}, "WORKING", "", "WORKING", "", "",
    )


def _flow_existing_result(seq, group, api, attempt, method, url_key, token_kind="HIP"):
    body = '{"success":false,"nameValidationResult":{"isValid":false,"message":"Flow Name already exists."},"failedStep":"STEP_1_VALIDATE_NAME","errorMessage":"Flow name validation failed: Flow Name already exists."}'
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}",
        token_kind, "", 400, "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 1,
        "", "{}", body, {}, "EXPECTED_EXISTING_OBJECT", "Object already exists/configured.",
        "EXPECTED_EXISTING_OBJECT", "Object already exists/configured.", "Keep explicit EXISTING evidence.", "",
    )


def test_v116_flow_existing_analysis_is_pass_existing():
    r = _flow_existing_result(16, "Orchestration", "Flow orchestration create ONLY", "live", "POST", "orch_flow_create")
    a = analyze_api_response(r)
    assert a["verdict"] == "PASS"
    assert a["outcome"] == "EXISTING"


def test_v116_strict_run_executes_deploy_and_history_after_current_flow_existing(monkeypatch):
    prepare_uhal_business_demo(ROOT)
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "2")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    calls = []

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        calls.append(api)
        if api == "Flow orchestration create ONLY":
            return _flow_existing_result(seq, group, api, attempt, method, url_key, str(kwargs.get("token_kind") or "HIP"))
        return _ok_result(seq, group, api, attempt, method, url_key, str(kwargs.get("token_kind") or "HIP"))

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None):
        results = runner.run()

    assert calls.count("Flow orchestration create ONLY") == 1
    assert "Flow orchestration deploy ONLY" in calls
    assert "Flow deployment history" in calls
    flow_create = next(r for r in results if r.api == "Flow orchestration create ONLY")
    assert analyze_api_response(flow_create)["outcome"] == "EXISTING"
    assert runner.final_state["coverageComplete"] is True
    assert "flow_create" not in (runner.final_state.get("unresolvedRequiredSteps") or [])


def test_v116_true_invalid_flow_name_remains_terminal():
    text = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert 'classification, ok = "FLOW_NAME_INVALID", False' in text
    assert 'explicit_existing = any(marker in response_low for marker in existing_name_markers)' in text
    assert 'if (not explicit_existing) and any(marker in response_low for marker in invalid_name_markers)' in text


def test_v116_build_identity():
    value = run_agent.BUILD_ID.lower()
    assert "v117" in value
    assert "strict-live" in value
    assert "no-reuse" in value
