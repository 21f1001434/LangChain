from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import run_agent
from business_demo import prepare_uhal_business_demo
from production_integration_test import FakeResponse

ROOT = Path(__file__).resolve().parent


def response_for(url: str) -> FakeResponse:
    if "validate-unique-interface-detail" in url:
        return FakeResponse(url, 200, {"valid": True})
    if "flows/validate-name" in url:
        return FakeResponse(url, 200, "VALID")
    if "/authz/account" in url:
        return FakeResponse(url, 500, {"message": "backend test response"})
    if "/authz/partner" in url:
        return FakeResponse(url, 409, {"message": "Partner already exists"})
    if "/hip-systems/" in url:
        return FakeResponse(url, 500, {"message": "System backend response"})
    if url.endswith("/api/document-type"):
        return FakeResponse(url, 500, {"message": "Document type exists/backend response"})
    if url.endswith("/api/mac-map"):
        return FakeResponse(url, 500, {"message": "Map backend response"})
    if url.endswith("/api/rule"):
        return FakeResponse(url, 500, {"message": "Rule backend response"})
    if "transport-profiles/orchestration/create" in url:
        return FakeResponse(url, 400, {"message": "TP validation response"})
    if "flows/orchestration/create" in url:
        return FakeResponse(url, 500, {"message": "Flow create response"})
    if "flows/orchestration/deploy" in url:
        return FakeResponse(url, 500, {"message": "Flow deploy response"})
    if "flows/deployment/history" in url:
        return FakeResponse(url, 200, [])
    if "transport-profiles/audits" in url:
        return FakeResponse(url, 200, [{"status": "COMPLETED"}])
    raise AssertionError(url)


def main() -> None:
    prepare_uhal_business_demo(ROOT)
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.full_api_coverage_mode is True
    runner.get_token = lambda token_kind, scope: "offline-token"
    runner.judge.judge = lambda result: {}
    runner.judge.available = lambda: False
    called: list[str] = []

    def mocked_request(method: str, url: str, token_kind: str, scope: str, extra_headers: Any, payload: Any, params: Any):
        called.append(url)
        return response_for(url)

    runner._request_with_retry = mocked_request
    with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(
        runner.adaptive, "record_mapping_graph", return_value={"status": "mocked"}
    ):
        results = runner.run()

    logical = {
        str((r.extracted or {}).get("logicalStepKey") or "")
        for r in results
        if str((r.extracted or {}).get("logicalStepKey") or "")
    }
    assert len(logical) == 18, logical
    assert runner.final_state["coverageComplete"] is True, runner.final_state
    assert runner.final_state["businessSuccess"] is False, runner.final_state
    assert not [r for r in results if str(r.classification).startswith("SKIPPED_")]
    # Map can make one fallback attempt after the primary response; all logical
    # APIs still have at least one live call and nothing is dependency-skipped.
    assert len(called) >= 18, len(called)
    assert any("flows/orchestration/deploy" in u for u in called)
    assert any("flows/deployment/history" in u for u in called)
    assert sum("transport-profiles/audits" in u for u in called) == 2

    output = {
        "status": "PASS",
        "buildId": run_agent.BUILD_ID,
        "logicalApisObserved": len(logical),
        "httpAttempts": len(called),
        "coverageComplete": runner.final_state["coverageComplete"],
        "businessSuccess": runner.final_state["businessSuccess"],
        "skipped": 0,
        "provesContinuationAfterFailures": True,
    }
    path = ROOT / "examples" / "FULL_LIVE_API_COVERAGE_FAILURE_CONTINUATION.json"
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
