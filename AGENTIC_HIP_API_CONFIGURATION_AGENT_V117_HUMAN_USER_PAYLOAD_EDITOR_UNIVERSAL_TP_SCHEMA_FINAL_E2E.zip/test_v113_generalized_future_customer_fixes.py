import json

import run_agent
from hip_naming import compact_hip_flow_name, normalize_input_flow_name, validate_hip_flow_name
from webapp.backend.app.parallel_manager import _primary_attention_diagnostic


def _rule_result(extracted=None):
    return run_agent.Result(
        13, "Rule", "Create mapping rule", "rule", "POST", "https://example/api/rule",
        "HIP", "rule", 500, "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 10, "", "{}",
        json.dumps({
            "error": True,
            "message": "Create failed",
            "detail": "A rule with the same name and version already exists in DEV.",
            "status": 500,
            "data": None,
        }), extracted or {}, "", "", "", "", ""
    )


def test_v113_flow_name_policy_is_generic_and_preserves_business_tokens():
    original = "VERY_LONG_FUTURE_CUSTOMER_NAME_PC_850_PREMIER_MAPPING_INBOUND"
    compact = compact_hip_flow_name(original)
    assert validate_hip_flow_name(compact)["valid"] is True
    assert len(compact) <= 40
    # PREMIER is a business/customer token and must not be rewritten.
    assert "PREMIER" in compact
    # Structural flow tokens may be abbreviated deterministically.
    assert "MAPPING" not in compact
    assert compact == compact_hip_flow_name(original)


def test_v113_all_known_flow_name_aliases_are_reconciled_for_any_customer():
    invalid = "FUTURE_CUSTOMER_WITH_LONG_NAME_PC_850_MAPPING_INBOUND"
    cfg = {
        "profile_name": invalid,
        "flow_name": invalid,
        "objects": {
            "biz_flow": {
                "flow_name": invalid,
                "flow_details": {"business_flow_name": invalid},
            }
        },
    }
    out = normalize_input_flow_name(cfg)
    effective = out["profile_name"]
    assert validate_hip_flow_name(effective)["valid"] is True
    assert out["flow_name"] == effective
    assert out["objects"]["biz_flow"]["flow_name"] == effective
    assert out["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == effective
    assert set(out["_flow_name_normalization"]["changedAliases"]) == {
        "profile_name", "flow_name", "objects.biz_flow.flow_name",
        "objects.biz_flow.flow_details.business_flow_name",
    }


def test_v113_rule_parser_supports_environment_dictionary_shape_for_any_rule():
    runner = run_agent.Runner(llm_enabled=False)
    body = {
        "items": [{
            "ruleName": "FUTURE_CUSTOMER_MAP_RULE",
            "availableEnvironments": {
                "DEV": {"versions": [{"ruleId": 76543, "version": 1.0}]},
                "PROD": {"versions": [{"ruleId": 99999, "version": 1.0}]},
            },
        }]
    }
    ids = runner._exact_rule_ids_from_read_response(
        body, rule_name="FUTURE_CUSTOMER_MAP_RULE", rule_version="1.0",
        environment="DEV", environment_scoped=False,
    )
    assert ids == [76543]


def test_v113_rule_parser_supports_latest_dev_version_shape():
    runner = run_agent.Runner(llm_enabled=False)
    body = {"data": [{
        "name": "FUTURE_RULE",
        "ruleId": 99123,
        "latestDevVersion": 2.0,
        "availableEnvironments": ["DEV"],
    }]}
    ids = runner._exact_rule_ids_from_read_response(
        body, rule_name="FUTURE_RULE", rule_version="2.0", environment="DEV",
        environment_scoped=False,
    )
    assert ids == [99123]


def test_v113_non_json_current_live_rule_listing_can_resolve_exact_identity(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)
    target_name = runner.business["mappingRuleName"]
    target_version = runner.business["mappingRuleVersion"]

    class Resp:
        status_code = 200
        url = "https://developer.dell.com/inaas-gateway/hipService-svc/api/rule/summary"
        headers = {"content-type": "text/html"}
        text = (
            f"<tr><td>{target_name}</td><td>Mapping</td><td>{target_version}</td>"
            f"<td>DEV</td><td>ruleId: 65432</td></tr>"
        )
        def json(self):
            raise ValueError("not json")

    calls = []
    monkeypatch.setattr(runner, "_request_with_retry", lambda **kwargs: calls.append(kwargs) or Resp())
    result = _rule_result()
    assert runner.enforce_live_id_integrity("rule", result, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    assert calls == []
    assert "liveRuleIdResolution" not in result.extracted


def test_v113_rule_post_location_header_is_current_live_identity_not_reuse():
    runner = run_agent.Runner(llm_enabled=False)
    result = _rule_result({"responseLocation": "https://apigtwtst.us.dell.com/hip-config-service/api/rule/81234/details"})
    assert runner.resolve_current_live_rule_id(result) == 81234
    meta = result.extracted["liveRuleIdResolution"]
    assert meta["source"] == "CURRENT_RULE_POST_RESPONSE_LOCATION"
    assert meta["historicalIdUsed"] is False
    assert meta["requestPayloadMutated"] is False


def test_v113_primary_blocker_prefers_dependency_blocked_over_independent_api_fail():
    items = [
        {"api": "Create source account", "verdict": "FAIL", "classification": "API_UPSTREAM_ROUTE_UNAVAILABLE"},
        {"api": "Flow orchestration create ONLY", "verdict": "BLOCKED", "classification": "LIVE_RULE_ID_UNRESOLVED"},
    ]
    primary = _primary_attention_diagnostic(items, {})
    assert primary["api"] == "Flow orchestration create ONLY"
    assert primary["classification"] == "LIVE_RULE_ID_UNRESOLVED"


def test_v113_primary_blocker_uses_canonical_step_not_generic_preflight_when_rows_missing():
    primary = _primary_attention_diagnostic([], {"strictNonPassingLiveSteps": ["rule"]})
    assert primary["api"] == "Canonical API step: rule"
    assert primary["stage"] == "end-to-end-dependency"
    assert "Final pre-LIVE safety gate" not in primary["api"]


def test_v113_mapping_rule_payload_contract_remains_immutable():
    runner = run_agent.Runner(llm_enabled=False)
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "flowDefinitionId" not in payload
    assert "mapId" not in (payload["actions"][0].get("params") or {})
    assert payload["documentTypeName"]
    assert payload["documentTypeVersion"]
    assert payload["actions"][0]["params"]["mapIdentifier"]
    assert payload["actions"][0]["params"]["mapVersion"]


def test_v113_normalization_is_pure_so_stale_alias_repairs_are_persistable():
    source = {
        "profile_name": "FUTURE_PC_850_MAP_IB",
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": ""}}},
    }
    original = json.loads(json.dumps(source))
    out = normalize_input_flow_name(source)
    # Caller snapshot must remain unchanged so queue/preflight/Runner can detect
    # that the canonical result needs to be written back before LIVE execution.
    assert source == original
    assert out != source
    assert out["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == "FUTURE_PC_850_MAP_IB"


def test_v113_html_table_rule_inventory_resolves_only_exact_row_id():
    runner = run_agent.Runner(llm_enabled=False)
    html = (
        '<table>'
        '<tr><td>1</td><td class="name">OTHER_RULE</td><td>111</td><td>1.0</td><td>DEV</td></tr>'
        '<tr><td>2</td><td class="name">FUTURE_EXACT_RULE</td><td>76543</td><td>1.0</td><td>Mapping</td><td>DEV</td></tr>'
        '<tr><td>3</td><td class="name">ANOTHER_RULE</td><td>222</td><td>1.0</td><td>DEV</td></tr>'
        '</table>'
    )
    assert runner._exact_rule_ids_from_read_text(
        html, rule_name="FUTURE_EXACT_RULE", rule_version="1.0", environment="DEV"
    ) == [76543]
