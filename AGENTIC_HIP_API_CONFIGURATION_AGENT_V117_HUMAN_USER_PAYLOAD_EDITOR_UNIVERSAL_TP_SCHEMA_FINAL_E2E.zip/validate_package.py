#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import copy
import json
import os
import py_compile
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent


def check(condition: bool, name: str, details: Any = None) -> Dict[str, Any]:
    return {
        "name": name,
        "passed": bool(condition),
        "details": details,
    }


def load_runner_module():
    module_name = "uhal_final_validation_runner"
    spec = importlib.util.spec_from_file_location(module_name, ROOT / "run_agent.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load run_agent.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    checks: List[Dict[str, Any]] = []
    for filename in [
        "run_agent.py",
        "uhal_mapper.py",
        "api_pdf_ingestion.py",
        "uhal_mcp_server.py",
        "mcp_bridge.py",
        "uhal_app.py",
        "uhal_report.py",
    ]:
        py_compile.compile(str(ROOT / filename), doraise=True)
        checks.append(check(True, f"compile:{filename}"))

    module = load_runner_module()
    previous_cache_setting = os.environ.get("HIP_REUSE_VALIDATED_REQUESTS")
    os.environ["HIP_REUSE_VALIDATED_REQUESTS"] = "false"
    runner = module.Runner(llm_enabled=False)
    expected_config_base = (
        "https://apigtwtst.us.dell.com/hip-config-service"
    )
    config_service_keys = {
        "document_type",
        "rule",
        "map",
        "tp_validate",
        "tp_create",
        "tp_audits",
        "flow_validate",
        "flow_definition",
        "flow_deploy",
        "flow_deploy_history",
        "orch_tp_create",
        "orch_flow_create",
        "orch_flow_deploy",
    }
    checks.append(check(
        runner.hip_config_service_base_url == expected_config_base,
        "HIP Config Service base URL is the new consolidated base",
        runner.hip_config_service_base_url,
    ))
    checks.append(check(
        all(
            runner.urls[key].startswith(expected_config_base + "/api/")
            for key in config_service_keys
        ),
        "All HIP configuration APIs use hip-config-service",
        {key: runner.urls[key] for key in sorted(config_service_keys)},
    ))
    checks.append(check(
        runner.urls["account"].startswith(
            "https://apigtwtst.us.dell.com/hip-partners/api/authz/"
        )
        and runner.urls["partner"].startswith(
            "https://apigtwtst.us.dell.com/hip-partners/api/authz/"
        ),
        "Account and Partner remain on hip-partners",
        {
            "account": runner.urls["account"],
            "partner": runner.urls["partner"],
        },
    ))
    checks.append(check(
        runner.urls["system"].startswith(
            "https://apigtwtst.us.dell.com/hip-systems/api/"
        ),
        "System remains on hip-systems",
        runner.urls["system"],
    ))
    mapper_issues = runner.mapper.validate()
    mapper_errors = [x for x in mapper_issues if x.severity == "ERROR"]
    effective_partner_identifier = runner.partner_identifier_value()
    checks.append(check(
        not mapper_errors,
        "U-HAUL baseline has no mapping errors",
        [x.__dict__ for x in mapper_errors],
    ))
    checks.append(check(
        bool(effective_partner_identifier)
        and runner.partner_payload().get("partnerIdentifierValue") == effective_partner_identifier,
        "U-HAUL Partner Identifier is derived from approved routing evidence without asking for a duplicate value",
        {"effectivePartnerIdentifier": effective_partner_identifier},
    ))
    mcp_input = runner.mcp.validate_uhal_input(
        runner.input,
        runner.ov,
    )
    # Persist non-mutating validation evidence so the validator is self-contained
    # instead of relying on report files from a previous execution.
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)
    (reports / "mcp_uhal_input_validation.json").write_text(
        json.dumps(mcp_input, indent=2, default=str), encoding="utf-8"
    )
    runner.mcp_input_validation = mcp_input
    runner.write_mapping_manifest()
    checks.extend([
        check(runner.mcp.active, "MCP tool layer is active", runner.mcp.status()),
        check(
            bool(mcp_input.get("valid", False))
            and not [x for x in (mcp_input.get("issues") or []) if str((x or {}).get("severity") or "ERROR").upper() == "ERROR"],
            "MCP accepts the U-HAUL baseline because Partner Identifier is derivable from approved routing evidence",
            mcp_input.get("issues"),
        ),
        check(bool(mcp_input.get("lineage")), "MCP returns input-to-payload lineage"),
    ])

    # The approved U-HAUL baseline can derive its external partner identity from
    # the routing condition already present in input.json. Keep the validation
    # non-mutating and prove the full 18-request builder without fabricating a
    # duplicate Partner Identifier value.
    runner.input = copy.deepcopy(runner.input)

    source_doc = runner.doc_payload(runner.source_doc(), "source")
    target_doc = runner.doc_payload(runner.target_doc(), "target")
    map_payload = runner.map_payload(True)
    rule_payload = runner.rule_payload()
    source_tp = runner.tp_orch_payload(runner.source_tp(), "source")
    target_tp = runner.tp_orch_payload(runner.target_tp(), "target")
    flow_payload = runner.flow_orch_payload()
    deploy_payload = runner.deploy_orch_payload()
    flow_inner = json.loads(flow_payload["flowDefinition"])

    checks.extend([
        check(source_doc.get("transactionType") == "INBOUND", "Source Document Type transactionType=INBOUND"),
        check(target_doc.get("transactionType") == "OUTBOUND", "Target Document Type transactionType=OUTBOUND"),
        check(isinstance(source_doc.get("version"), str), "Document Type version is a string"),
        check(source_doc.get("documentIdentifier", {}).get("operator") == "ALL", "Document Type identifier operator=ALL"),
        check(isinstance(source_doc.get("documentIdentifier", {}).get("attributeList"), list), "Document Type identifier attributeList is an array"),
        check("filemask" not in source_doc and "ediDelimiters" not in source_doc, "Document Type omits filemask/ediDelimiters"),
        check(map_payload.get("status") == "1", "MAC Map status is one-character string 1"),
        check(isinstance(map_payload.get("crossReferenceMapList"), list), "MAC Map crossReferenceMapList is non-null array"),
        check("documentTypeId" not in rule_payload, "Rule omits documentTypeId per latest Dev feedback"),
        check("mapId" not in rule_payload.get("actions", [{}])[0].get("params", {}), "Rule actions.params omits mapId per latest Dev feedback"),
    ])

    for label, payload in [("Source", source_tp), ("Target", target_tp)]:
        details = payload["transportProfileDetails"][0]
        interface = details["interfaceDetails"][0]
        parameters = interface["parameters"]
        checks.extend([
            check("domainId" not in payload and "systemId" not in payload, f"{label} TP omits domainId/systemId"),
            check("user" not in payload and "workType" not in payload, f"{label} TP omits user/workType per Dev review"),
            check(details.get("deploymentGroupName") == "hip-automation", f"{label} TP deploymentGroupName=hip-automation"),
            check("interfaceEnvironment" not in interface, f"{label} TP interfaceEnvironment omitted"),
            check(parameters.get("Is Compression Required") == "FALSE", f"{label} TP compression parameter=FALSE"),
            check(parameters.get("Use Existing Folder") == "No", f"{label} TP Use Existing Folder=No"),
        ])

    inner_text = json.dumps(flow_inner)
    flow_rule_details = (
        flow_inner["targetDetails"]["targets"][0]["processSteps"][0]["configuration"]
        ["defaultConfig"]["ruleRefs"]["ruleDetails"]
    )
    checks.extend([
        check(isinstance(flow_payload.get("flowDefinition"), str), "Flow Definition is an escaped JSON string"),
        check('"documentTypeId"' not in inner_text and '"targetDocumentTypeId"' not in inner_text, "Flow Definition contains no Document Type IDs"),
        check("XML_DellAutoASN_10_U-HAUL_ANS_IB" in inner_text, "Flow maps source U-HAUL Document Type"),
        check("XML_SHIPMENT_NOTICE_10_U-HAUL_ANS_OB" in inner_text, "Flow maps target U-HAUL Document Type"),
        check("da-sender-sftphaft-dce-common" in inner_text, "Flow maps Source TP"),
        check("pt-receiver-sftphaft-dce-common" in inner_text, "Flow maps Target TP"),
        check("id" not in flow_rule_details, "Flow Mapping Rule reference omits numeric id per Dev correction"),
        check(flow_rule_details.get("name") == runner.business["mappingRuleName"], "Flow Mapping Rule reference uses exact name"),
        check(str(flow_rule_details.get("version")) == str(runner.business["mappingRuleVersion"]), "Flow Mapping Rule reference uses exact version"),
        check("workType" not in flow_payload, "Flow Create omits workType; HIP derives it internally"),
        check("workType" not in deploy_payload, "Flow Deploy omits workType; HIP derives it internally"),
    ])

    request_contracts = []
    for seq, step_key in enumerate(runner.execution_flow.ordered_steps(), start=1):
        preview = runner.preview_step_request(step_key)
        contract = runner.validate_request_contract(
            seq=seq,
            api_key=preview.get("urlKey") or step_key,
            method=preview.get("method") or "GET",
            url=preview.get("url") or "",
            extra_headers=preview.get("extraHeaders") or {},
            payload=preview.get("payload"),
            params=preview.get("params"),
        )
        request_contracts.append({
            "stepKey": step_key,
            "valid": bool(contract.get("valid")),
            "contract": contract,
        })

    checks.extend([
        check(len(request_contracts) == 18, "Complete 18-step request chain generated", len(request_contracts)),
        check(not [row for row in request_contracts if not row["valid"]], "All 18 request contracts are valid after supplying the required Partner Identifier fixture", [row for row in request_contracts if not row["valid"]]),
        check(
            runner.full_api_coverage_mode,
            "U-HAUL Application Studio full live API coverage mode is enabled",
            {"fullApiCoverageMode": runner.full_api_coverage_mode},
        ),
        check(
            not runner.execution_plan.selected_steps(),
            "No API execution-plan step is skipped for U-HAUL full coverage",
            runner.execution_plan.summary(),
        ),
        check(
            not runner.execution_plan.is_skipped("flow_history"),
            "Flow deployment history remains mandatory",
            runner.execution_plan.summary(),
        ),
        check(
            runner.execution_flow.summary().get("valid"),
            "Execution Flow & Timing is dependency-safe",
            runner.execution_flow.summary(),
        ),
        check((ROOT / "reports" / "uhal_input_to_api_mapping_manifest.json").exists(), "Input-to-API mapping manifest generated"),
        check((ROOT / "reports" / "mcp_uhal_input_validation.json").exists(), "MCP input-validation evidence generated"),
        check(all(bool((row.get("contract") or {}).get("mcpToolValidation")) for row in request_contracts), "Every inspected request contains MCP validation evidence"),
        check(
            runner.mcp.status().get("calls", 0) >= len(request_contracts),
            "MCP tools were invoked for every inspected request",
            {"mcp": runner.mcp.status(), "inspectedRequests": len(request_contracts)},
        ),
    ])

    passed = sum(1 for item in checks if item["passed"])
    failed = [item for item in checks if not item["passed"]]
    output = {
        "status": "PASS" if not failed else "FAIL",
        "passed": passed,
        "failed": len(failed),
        "checks": checks,
        "mcp": runner.mcp.status(),
        "executionPerformed": False,
        "note": "This is a non-mutating package inspection. User-triggered execution paths are live-only and require valid credentials/backend access.",
    }
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)
    path = reports / "package_validation_latest.json"
    path.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
    if previous_cache_setting is None:
        os.environ.pop("HIP_REUSE_VALIDATED_REQUESTS", None)
    else:
        os.environ["HIP_REUSE_VALIDATED_REQUESTS"] = previous_cache_setting
    print(json.dumps({"status": output["status"], "passed": output["passed"], "failed": output["failed"]}, indent=2))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
