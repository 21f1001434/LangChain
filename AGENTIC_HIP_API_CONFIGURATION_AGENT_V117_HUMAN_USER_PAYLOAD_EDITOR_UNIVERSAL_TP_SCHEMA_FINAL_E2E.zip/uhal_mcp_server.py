#!/usr/bin/env python3
"""MCP tools for the U-HAUL HIP configuration agent.

The same tool functions are usable directly as a safe fallback when the MCP
Python SDK is not installed. When the SDK is present, they are registered on an
MCP server and can be called by this runner or any external MCP host.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from api_pdf_ingestion import PdfApiKnowledgeBase
from uhal_mapper import UhalInputMapper
from adaptive_engine import AdaptiveHipEngine
from agentic_interface_orchestrator import (
    AgenticInterfaceOrchestrator,
    impact_analysis,
    recommend_execution_strategy,
)
from api_execution_plan import ApiExecutionPlan
from execution_flow import ExecutionFlowConfig
from interface_registry import registry as interface_registry
from payload_overrides import PayloadOverrideStore
from production_guard import inspect_live_run, redact_sensitive
from transport_interface_react import validate_interface_only_request_override
from runtime_payload_values import is_placeholder, missing_runtime_payload_values, runtime_payload_status

ROOT = Path(__file__).resolve().parent


def _safe_mcp_value(value: Any) -> Any:
    """Redact real secrets while keeping non-secret payload structure visible."""
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            low = str(key).lower()
            if low.endswith("secret env"):
                out[str(key)] = item
            elif any(token in low for token in ("secret", "password", "authorization", "access_token", "accesstoken", "bearer")):
                out[str(key)] = "<REDACTED>"
            else:
                out[str(key)] = _safe_mcp_value(item)
        return out
    if isinstance(value, list):
        return [_safe_mcp_value(item) for item in value]
    return redact_sensitive(value)


def validate_uhal_input_tool(
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """Validate and map U-HAUL input into the canonical HIP execution model."""
    base = Path(root).resolve() if root else ROOT
    mapper = UhalInputMapper(input_data or {}, config or {}, base)
    issues = [item.__dict__ for item in mapper.validate()]
    errors = [item for item in issues if item.get("severity") == "ERROR"]
    return {
        "valid": not errors,
        "normalized": mapper.normalized(),
        "conditions": mapper.conditions(),
        "issues": issues,
        "lineage": mapper.lineage(),
        "executionManifest": mapper.execution_manifest(),
    }


def get_mapping_for_step_tool(
    step_key: str,
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """Return the exact input-to-payload lineage for one HIP execution step."""
    base = Path(root).resolve() if root else ROOT
    mapper = UhalInputMapper(input_data or {}, config or {}, base)
    lineage = mapper.lineage()
    return {
        "stepKey": step_key,
        "mapping": lineage.get(step_key, []),
        "knownSteps": sorted(lineage),
    }


def validate_api_request_tool(
    api_key: str,
    method: str,
    url: str,
    headers: Dict[str, Any],
    payload: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    root: str = "",
) -> Dict[str, Any]:
    """Validate a generated request against Dev-reviewed and PDF contracts."""
    base = Path(root).resolve() if root else ROOT
    kb = PdfApiKnowledgeBase(base)
    return kb.validate_request(
        api_key=api_key,
        method=method,
        url=url,
        headers=headers or {},
        payload=payload,
        params=params,
    )


def resolve_response_ids_tool(response_body: Any) -> Dict[str, Any]:
    """Recursively extract IDs, statuses, work-order and task metadata."""
    out: Dict[str, Any] = {}
    interesting = {
        "id", "documentTypeId", "mapId", "ruleId", "flowId",
        "flowVersion", "workOrderId", "taskId", "taskStatus",
        "success", "failedStep", "errorMessage", "deploymentStatus",
        "status", "operationStatus", "transportProfileName",
    }

    def walk(node: Any, prefix: str = "") -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                path = f"{prefix}.{key}" if prefix else str(key)
                if key in interesting and value not in (None, ""):
                    out.setdefault(key, value)
                    out[path] = value
                if isinstance(value, (dict, list)):
                    walk(value, path)
        elif isinstance(node, list):
            for index, item in enumerate(node):
                walk(item, f"{prefix}[{index}]")

    walk(response_body)
    return out


def suggest_missing_values_tool(
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """Suggest deterministic non-secret values; never invent credentials."""
    base = Path(root).resolve() if root else ROOT
    mapper = UhalInputMapper(input_data or {}, config or {}, base)
    suggestions: List[Dict[str, Any]] = []
    for issue in mapper.validate():
        suggestions.append({
            "field": issue.field,
            "severity": issue.severity,
            "message": issue.message,
            "suggestion": issue.suggestion or "REQUEST_FROM_OWNER",
        })
    return {
        "suggestions": suggestions,
        "normalized": mapper.normalized(),
    }


def analyze_new_input_tool(
    input_data: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """Discover an arbitrary input JSON schema and map it to the canonical HIP model."""
    base = Path(root).resolve() if root else ROOT
    return AdaptiveHipEngine(base).analyze_input(input_data or {})


def prepare_canonical_input_tool(
    input_data: Dict[str, Any],
    apply_safe: bool = True,
    root: str = "",
) -> Dict[str, Any]:
    """Create a canonical HIP input and return unresolved questions."""
    base = Path(root).resolve() if root else ROOT
    return AdaptiveHipEngine(base).prepare_canonical_input(input_data or {}, apply_safe=bool(apply_safe))


def propose_change_patch_tool(
    request_text: str,
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """Translate a user/Dev change request into an approval-gated patch proposal."""
    base = Path(root).resolve() if root else ROOT
    return AdaptiveHipEngine(base).propose_change(request_text or "", input_data or {}, config or {})


def apply_change_patch_tool(
    proposal: Dict[str, Any],
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    approve: bool = False,
    root: str = "",
) -> Dict[str, Any]:
    """Apply an approved change proposal to input/config objects."""
    base = Path(root).resolve() if root else ROOT
    return AdaptiveHipEngine(base).apply_change(proposal or {}, input_data or {}, config or {}, approve=bool(approve))


def query_knowledge_graph_tool(
    text: str = "",
    node_type: str = "",
    limit: int = 100,
    root: str = "",
) -> Dict[str, Any]:
    """Query the persistent HIP mapping/dependency/result knowledge graph."""
    base = Path(root).resolve() if root else ROOT
    engine = AdaptiveHipEngine(base)
    return {"stats": engine.kg.stats(), "results": engine.kg.query(text=text, node_type=node_type, limit=int(limit))}


def agentq_memory_status_tool(
    task_key: str = "",
    root: str = "",
) -> Dict[str, Any]:
    """Return AgentQ-inspired trajectory and ranked patch memory."""
    base = Path(root).resolve() if root else ROOT
    engine = AdaptiveHipEngine(base)
    return {
        "stats": engine.agentq.stats(),
        "trajectories": engine.agentq.recent_trajectories(task_key=task_key, limit=30),
        "rankedCandidates": engine.agentq.ranked_candidates(task_key or "dev_change", limit=10),
    }


def list_interface_profiles_tool(
    root: str = "",
) -> Dict[str, Any]:
    """List built-in/custom interface capabilities without exposing secrets."""
    base = Path(root).resolve() if root else ROOT
    profiles = interface_registry(base)
    rows: List[Dict[str, Any]] = []
    for key, definition in profiles.items():
        rows.append({
            "key": key,
            "displayName": definition.get("displayName") or key,
            "apiInterfaceType": definition.get("apiInterfaceType") or key,
            "family": definition.get("family") or "CUSTOM",
            "deploymentGroup": "hip-automation",
            "sourceSharedProfile": definition.get("sourceSharedProfile") or "",
            "targetSharedProfile": definition.get("targetSharedProfile") or "",
            "requiresDocumentation": bool(definition.get("requiresDocumentation")),
            "sourceRequired": list(definition.get("sourceRequired") or []),
            "targetRequired": list(definition.get("targetRequired") or []),
            "pendingFields": list(definition.get("pendingFields") or []),
            "custom": bool(definition.get("custom")),
        })
    return {
        "count": len(rows),
        "interfaces": rows,
        "keys": [row["key"] for row in rows],
    }


def plan_interface_configuration_tool(
    baseline_input: Dict[str, Any],
    source_interface: str,
    target_interface: str,
    source_parameters: Optional[Dict[str, Any]] = None,
    target_parameters: Optional[Dict[str, Any]] = None,
    source_shared_profile: str = "",
    target_shared_profile: str = "",
    deployment_group: str = "",
    root: str = "",
) -> Dict[str, Any]:
    """Plan/critic-check an interface change and return impact + run strategy."""
    base = Path(root).resolve() if root else ROOT
    kb = PdfApiKnowledgeBase(base)
    agent = AgenticInterfaceOrchestrator(base, baseline_input or {}, pdf_kb=kb)
    proposal = agent.propose(
        source_interface=source_interface,
        target_interface=target_interface,
        source_parameters=source_parameters or {},
        target_parameters=target_parameters or {},
        source_shared_profile=source_shared_profile,
        target_shared_profile=target_shared_profile,
        deployment_group=deployment_group,
    )
    changed = proposal.get("changedPaths") or []
    impact = impact_analysis(changed)
    current_plan = ApiExecutionPlan(base, base / "input.json").summary()
    active_for_strategy = proposal.get("proposal") or baseline_input or {}
    strategy = recommend_execution_strategy(active_for_strategy, current_plan)
    result = {
        **proposal,
        "impact": impact,
        "executionStrategy": strategy,
        "mcpPolicy": {
            "noInventedSecrets": True,
            "contractDrivenUnknownInterfaces": True,
            "criticRequired": True,
        },
    }
    return _safe_mcp_value(result)


def validate_execution_policy_tool(
    root: str = "",
) -> Dict[str, Any]:
    """Validate skip plan, dependency order, payload overrides, docs/run-lock health."""
    base = Path(root).resolve() if root else ROOT
    plan = ApiExecutionPlan(base, base / "input.json").summary()
    flow = ExecutionFlowConfig(base).summary()
    overrides = PayloadOverrideStore(base).summary()
    run_state = inspect_live_run(base)
    plan_valid = not (plan.get("confirmed") and not plan.get("active"))
    flow_valid = bool(flow.get("valid"))
    overrides_valid = bool(overrides.get("valid"))
    run_blocked = bool(run_state.get("active"))
    errors: List[str] = []
    warnings: List[str] = []
    if not plan_valid:
        errors.append("The confirmed API execution plan is stale or invalid for the current input.json.")
    if not flow_valid:
        errors.extend(str(x) for x in (flow.get("errors") or []))
    if not overrides_valid:
        errors.extend(str(x) for x in (overrides.get("errors") or []))
    if run_blocked:
        warnings.append("Another verified HIP run_agent.py process is currently active.")
    warnings.extend(str(x) for x in (flow.get("warnings") or []))
    return {
        "valid": not errors,
        "liveRunBlocked": run_blocked,
        "errors": errors,
        "warnings": warnings,
        "executionPlan": plan,
        "executionFlow": flow,
        "payloadOverrides": overrides,
        "runState": _safe_mcp_value(run_state),
    }


def validate_payload_override_tool(
    step_key: str,
    generated: Dict[str, Any],
    effective: Dict[str, Any],
    interface_only: bool = False,
    root: str = "",
) -> Dict[str, Any]:
    """Critic-check a user payload edit and reject unsafe raw secret values."""
    generated = generated or {}
    effective = effective or {}
    if not isinstance(generated, dict) or not isinstance(effective, dict):
        return {
            "valid": False,
            "errors": ["Generated and effective request values must be JSON objects."],
            "stepKey": step_key,
        }

    secret_violations: List[str] = []
    def walk(node: Any, prefix: str = "") -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                path = f"{prefix}.{key}" if prefix else str(key)
                key_low = str(key).lower()
                if "secret" in key_low:
                    # Saved payload overrides may contain the secure runtime
                    # placeholder because the actual Partner value is injected
                    # only for the live request. Raw secret literals are still
                    # rejected from persisted overrides/reports.
                    if value not in (None, "", "<REDACTED>") and not is_placeholder(value):
                        secret_violations.append(path)
                walk(value, path)
        elif isinstance(node, list):
            for idx, item in enumerate(node):
                walk(item, f"{prefix}[{idx}]")
    walk(effective)

    critic = {
        "valid": True,
        "changedPaths": [],
        "violations": [],
        "allowedPrefixes": [],
        "summary": "No interface-only constraint requested.",
    }
    if interface_only:
        critic = validate_interface_only_request_override(step_key, generated, effective)

    errors = []
    if secret_violations:
        errors.append(
            "Raw secret literals are not allowed in saved payload overrides. "
            "The real Partner value belongs in the live API payload; keep a "
            "{{runtime_payload...}} placeholder in saved configuration and enter "
            "the secure value through the Interface Studio before execution."
        )
    if not critic.get("valid", True):
        errors.append(str(critic.get("summary") or "Interface-only critic rejected the edit."))
    return {
        "valid": not errors,
        "stepKey": step_key,
        "interfaceOnly": bool(interface_only),
        "errors": errors,
        "secretViolations": secret_violations,
        "critic": critic,
        "effectiveRedacted": _safe_mcp_value(effective),
    }


def interpret_api_response_tool(
    api_key: str,
    status_code: Optional[int],
    response_body: Any = None,
    error: str = "",
) -> Dict[str, Any]:
    """Apply semantic HIP response checks, not just HTTP status-code checks."""
    status = int(status_code) if status_code is not None else None
    low = str(error or "").lower()
    body = response_body
    if isinstance(response_body, str):
        try:
            body = json.loads(response_body)
        except Exception:
            body = response_body

    def business_error(node: Any) -> bool:
        if isinstance(node, dict):
            if node.get("success") is False or node.get("error") is True or node.get("errorFlag") is True:
                return True
            if node.get("failedStep") not in (None, "", False):
                return True
            if node.get("errorMessage") not in (None, "", False):
                return True
            return any(business_error(value) for value in node.values() if isinstance(value, (dict, list)))
        if isinstance(node, list):
            return any(business_error(item) for item in node)
        return False

    if error:
        classification = "AUTH_OR_EXECUTION_ERROR" if ("token" in low or "credential" in low) else "EXECUTION_ERROR"
        ok = False
    elif status in (200, 201, 202, 204):
        ok = not business_error(body)
        classification = "PASS_SUCCESS" if ok else "HTTP_SUCCESS_BUT_BUSINESS_ERROR"
    elif status in (400, 409, 415, 422):
        classification, ok = "PAYLOAD_SCHEMA_OR_VALIDATION_ERROR", False
    elif status in (401, 403):
        classification, ok = "AUTH_OR_ENTITLEMENT_ERROR", False
    elif status in (404, 405):
        classification, ok = "PATH_OR_METHOD_ERROR", False
    elif status is not None and status >= 500:
        classification, ok = "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False
    else:
        classification, ok = "UNKNOWN", False

    if ok and api_key == "flow_deploy_history":
        records = body
        if isinstance(body, dict):
            records = body.get("deploymentHistory") or body.get("data") or []
        success_states = {"SUCCESS", "SUCCEEDED", "COMPLETED", "DEPLOYED", "ACTIVE"}
        statuses = {
            str((item or {}).get("deploymentStatus") or (item or {}).get("status") or "").upper()
            for item in records or [] if isinstance(item, dict)
        } if isinstance(records, list) else set()
        if not isinstance(records, list) or not records:
            classification, ok = "DEPLOYMENT_HISTORY_EMPTY", False
        elif not statuses.intersection(success_states):
            classification, ok = "DEPLOYMENT_NOT_SUCCESSFUL", False

    if ok and api_key == "tp_audits":
        records = body.get("data") or body.get("audits") or [] if isinstance(body, dict) else body
        if records is not None and not isinstance(records, list):
            classification, ok = "TP_AUDIT_RESPONSE_INVALID", False

    extracted = resolve_response_ids_tool(body)
    retryable = bool(status in {408, 429, 502, 503, 504})
    return {
        "valid": ok,
        "businessSuccess": ok,
        "classification": classification,
        "retryable": retryable,
        "extracted": extracted,
        "responseRedacted": _safe_mcp_value(body),
    }


def get_api_contract_summary_tool(
    api_key: str,
    root: str = "",
) -> Dict[str, Any]:
    """Return the merged verified/PDF API contract for agent planning."""
    base = Path(root).resolve() if root else ROOT
    kb = PdfApiKnowledgeBase(base)
    return {
        "apiKey": api_key,
        "contract": _safe_mcp_value(kb.merged_contract(api_key)),
        "documents": kb.list_documents(),
        "documentationAvailable": kb.has_documents(),
    }


def assess_execution_readiness_tool(
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    root: str = "",
) -> Dict[str, Any]:
    """MCP supervisor: combine mapping, execution policy and interface readiness."""
    base = Path(root).resolve() if root else ROOT
    mapping = validate_uhal_input_tool(input_data or {}, config or {}, root=str(base))
    policy = validate_execution_policy_tool(root=str(base))
    profiles = interface_registry(base)

    objects = (input_data or {}).get("objects") or {}
    src_type = str((objects.get("source_transport_profile") or {}).get("interface_type") or "").upper()
    tgt_type = str((objects.get("target_transport_profile") or {}).get("interface_type") or "").upper()
    known_types = {str(defn.get("apiInterfaceType") or key).upper(): key for key, defn in profiles.items()}
    interface_errors: List[str] = []
    if src_type and src_type not in known_types:
        interface_errors.append(f"Source interface type {src_type!r} is not registered.")
    if tgt_type and tgt_type not in known_types:
        interface_errors.append(f"Target interface type {tgt_type!r} is not registered.")

    errors = []
    if not mapping.get("valid", True):
        errors.extend(str(item.get("message") or item) for item in mapping.get("issues", []) if item.get("severity") == "ERROR")
    errors.extend(policy.get("errors") or [])
    errors.extend(interface_errors)

    missing_payload_runtime = missing_runtime_payload_values(base, input_data or {})
    if missing_payload_runtime:
        errors.append(
            "Missing Partner/interface runtime payload value(s): "
            + ", ".join(missing_payload_runtime)
        )

    warnings = list(policy.get("warnings") or [])
    return {
        "ready": not errors and not policy.get("liveRunBlocked"),
        "valid": not errors,
        "liveRunBlocked": bool(policy.get("liveRunBlocked")),
        "errors": errors,
        "warnings": warnings,
        "mapping": mapping,
        "executionPolicy": policy,
        "runtimePayloadValues": {
            **runtime_payload_status(base),
            "missing": missing_payload_runtime,
        },
        "interfaces": {
            "sourceType": src_type,
            "sourceKey": known_types.get(src_type),
            "targetType": tgt_type,
            "targetKey": known_types.get(tgt_type),
        },
    }


MCP_SDK_MODE = "unavailable"
mcp = None
try:
    # Stable official Python SDK v1.x. v2 remained pre-release as of this
    # build, so the production package prefers the stable FastMCP API.
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("HIP Agentic Configuration Tools")
    MCP_SDK_MODE = "v1-stable"
except Exception:
    mcp = None


if mcp is not None:
    mcp.tool(name="validate_uhal_input")(validate_uhal_input_tool)
    mcp.tool(name="get_mapping_for_step")(get_mapping_for_step_tool)
    mcp.tool(name="validate_api_request")(validate_api_request_tool)
    mcp.tool(name="resolve_response_ids")(resolve_response_ids_tool)
    mcp.tool(name="suggest_missing_values")(suggest_missing_values_tool)
    mcp.tool(name="analyze_new_input")(analyze_new_input_tool)
    mcp.tool(name="prepare_canonical_input")(prepare_canonical_input_tool)
    mcp.tool(name="propose_change_patch")(propose_change_patch_tool)
    mcp.tool(name="apply_change_patch")(apply_change_patch_tool)
    mcp.tool(name="query_knowledge_graph")(query_knowledge_graph_tool)
    mcp.tool(name="agentq_memory_status")(agentq_memory_status_tool)
    mcp.tool(name="list_interface_profiles")(list_interface_profiles_tool)
    mcp.tool(name="plan_interface_configuration")(plan_interface_configuration_tool)
    mcp.tool(name="validate_execution_policy")(validate_execution_policy_tool)
    mcp.tool(name="validate_payload_override")(validate_payload_override_tool)
    mcp.tool(name="interpret_api_response")(interpret_api_response_tool)
    mcp.tool(name="get_api_contract_summary")(get_api_contract_summary_tool)
    mcp.tool(name="assess_execution_readiness")(assess_execution_readiness_tool)


def main() -> None:
    if mcp is None:
        raise RuntimeError(
            "MCP Python SDK is not installed. Install mcp>=1.28,<2."
        )
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
