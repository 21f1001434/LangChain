from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import run_agent
from report_insights import analyze_api_response
from runtime_id_state import load_runtime_ids, save_runtime_ids

ROOT = Path(__file__).resolve().parent


def _result(seq, group, api, attempt, method, url_key, *, status=200, classification="PASS_SUCCESS", success=True, extracted=None, response='{"success":true}', issue=""):
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}", "HIP", "",
        status, classification, success, 1, "", "{}", response,
        extracted or {}, "WORKING" if success else "API_BACKEND_OR_ERROR_HANDLING", "", "WORKING" if success else "API_BACKEND_OR_ERROR_HANDLING", issue, "",
    )


def test_v104_packaged_historical_dependency_ids_removed_but_approved_map_kept():
    cfg = json.loads((ROOT / "config_overrides.json").read_text(encoding="utf-8"))
    assert "source_document_type_id" not in cfg
    assert "target_document_type_id" not in cfg
    assert "rule_id" not in cfg
    assert "existing_flow_id" not in cfg
    assert cfg["map_id"] == 1670
    assert cfg["source_deployment_group_name"] == "hip-automation"
    assert cfg["target_deployment_group_name"] == "hip-automation"


def test_v104_entity_specific_document_type_id_beats_generic_wrapper_id():
    runner = run_agent.Runner(llm_enabled=False)
    r = _result(1, "Document Type", "Create source document type", "x", "POST", "document_type", extracted={"id": 777, "data": {"documentTypeId": 92011}})
    runner.capture_runtime_state("doctype_source", r)
    assert runner.source_doc_id() == 92011


def test_v104_generic_id_is_not_accepted_as_document_type_id_but_is_not_required_for_progress():
    runner = run_agent.Runner(llm_enabled=False)
    r = _result(1, "Document Type", "Create source document type", "x", "POST", "document_type", extracted={"id": 777})
    runner.capture_runtime_state("doctype_source", r)
    assert runner.source_doc_id() == 0
    # V106: the approved Rule and TP contracts reference Document Type name + version,
    # so a missing documentTypeId must not block downstream processing.
    assert runner.enforce_live_id_integrity("doctype_source", r, require_dependency_ids=True) is True
    assert r.classification == "PASS_SUCCESS"
    verdict = analyze_api_response(r)
    assert verdict["verdict"] == "PASS"
    assert verdict["outcome"] == "SUCCESS"


def test_v104_rule_fk_failure_is_backend_contract_mismatch_and_does_not_mutate_document_type_id():
    runner = run_agent.Runner(llm_enabled=False)
    runner.runtime_state["source_document_type_id"] = 92001
    r = _result(1, "Rule", "Create mapping rule", "x", "POST", "rule", status=500, classification="BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", success=False,
                response='{"error":"ORA-02291: integrity constraint (SHARED.FK_RULE_DOCUMENTTYPE) violated - parent key not found"}',
                issue="RULE_DOCUMENTTYPE parent key not found")
    assert runner.enforce_live_id_integrity("rule", r) is False
    assert runner.source_doc_id() == 92001
    assert r.classification == "API_BACKEND_CONTRACT_MISMATCH"
    assert r.extracted["backendContractMismatch"]["runtimeIdMutationPerformed"] is False
    verdict = analyze_api_response(r)
    assert verdict["verdict"] == "FAIL"
    assert verdict["outcome"] == "API_BACKEND_CONTRACT_MISMATCH"


def test_v104_latest_dev_rule_contract_omits_runtime_document_and_map_ids():
    runner = run_agent.Runner(llm_enabled=False)
    runner.runtime_state["source_document_type_id"] = 92001
    runner.runtime_state["map_id"] = 1670
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "mapId" not in payload["actions"][0]["params"]
    assert payload["documentTypeName"]
    assert payload["actions"][0]["params"]["mapIdentifier"]

def test_v104_standalone_rule_uses_names_versions_not_runtime_ids():
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.map_id() == 0
    assert runner.source_doc_id() == 0
    assert runner.missing_standalone_runtime_requirements("rule") == []
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "mapId" not in payload["actions"][0]["params"]


def test_v104_workspace_runtime_ids_are_bound_to_input_hash(tmp_path: Path):
    (tmp_path / "input.json").write_text('{"customer":"A"}', encoding="utf-8")
    save_runtime_ids(tmp_path, {"source_document_type_id": 123, "map_id": 1670})
    assert load_runtime_ids(tmp_path)["source_document_type_id"] == 123
    (tmp_path / "input.json").write_text('{"customer":"B"}', encoding="utf-8")
    assert load_runtime_ids(tmp_path) == {}
