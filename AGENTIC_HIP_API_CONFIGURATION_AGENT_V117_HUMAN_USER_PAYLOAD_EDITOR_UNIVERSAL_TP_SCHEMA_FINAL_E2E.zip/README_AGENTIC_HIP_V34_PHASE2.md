# Agentic HIP API Configuration Agent — Phase 2 (V34)

Phase 2 extends the Bun/React + FastAPI migration without replacing the proven V32 Python HIP engine.

## Delivered in Phase 2

- Full React Input Builder evidence view:
  - uploaded source/target files
  - physical file format
  - XML/document identifiers
  - file → `input.json` mapping rules
  - artifact warnings/blockers
- Non-mutating **Map to 18 APIs + agent validate** action in React.
- Shared file→`input.json` mapping learner progress and validated-reference teaching.
- Automatic teaching for validated `input.json + customer files` pairs.
- First-class **Parallel Execution Center** in React.
- Global validated queue across multiple customer configurations.
- Bounded 1–8 parallel live agents.
- Per-configuration dependency ordering remains inside the existing Python runner.
- U-HAUL multi-instance parallel demo from one validated U-HAUL configuration.
- Per-job total time and per-step API/wait/total timing display.
- React **Learn** workspace using the existing Python LearnAssistant:
  - PDF
  - HAR / JSON / logs
  - XML / text
  - screenshots with Dell AIA vision when configured
  - sensitive text/network values redacted before persistence
- React **Reports** workspace for configuration-scoped JSON/text runtime evidence.
- Existing API Flow Game, templates, 18 reusable blocks and WebSocket live node execution remain intact.
- `Outbound` is still only a convenience default; the user's Direction selection is authoritative.
- `hip-automation` remains enforced.
- Streamlit remains available during migration until React reaches full feature parity.

## Architecture

```text
Bun + React + TypeScript + React Flow
                 |
          REST + WebSocket
                 |
              FastAPI
                 |
   Phase-2 adapters / parallel manager
                 |
      Existing V32 Python engine
 Input Builder / 18 APIs / Dell AIA /
 OAuth / validation / verdicts / reports
```

## Run

First time:

```powershell
SETUP_AGENTIC_HIP.bat
```

Normal launch:

```powershell
RUN_AGENTIC_HIP.bat
```

Frontend: `http://127.0.0.1:5173`

FastAPI docs: `http://127.0.0.1:8765/docs`

## Parallel workflow

1. Build customer configuration.
2. Resolve only the agent's unresolved values.
3. Click **Map to 18 APIs + agent validate**.
4. Open **Parallel Runs**.
5. Add the validated configuration to the queue.
6. Repeat for other customers, or create 2–8 U-HAUL demo instances.
7. Select jobs and run them LIVE in parallel.
8. Expand each result to see API time, wait time and total step time.

## Safety

There is no dry-run execution path. Validation is non-mutating, but Run/Test/Launch actions use LIVE HIP APIs. Sensitive runtime payload values are kept in ephemeral OS temporary storage and are not persisted in queue manifests or release ZIPs.
