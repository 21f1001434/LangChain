from __future__ import annotations

import json

import run_agent
from report_insights import analyze_api_response


def _rule_existing() -> run_agent.Result:
    return run_agent.Result(
        12, "Rule", "Create mapping rule", "dev-v115", "POST",
        "https://apigtwtst.us.dell.com/hip-config-service/api/rule",
        "HIP", "rule", 500, "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False,
        10, "", "{}",
        json.dumps({
            "error": True,
            "message": "Create failed",
            "detail": "A rule with the same name and version already exists in DEV.",
            "status": 500,
            "data": None,
        }),
        {}, "", "", "", "", "",
    )


def _flow_rule_details(runner: run_agent.Runner):
    flow = runner.flow_inner()
    return flow["targetDetails"]["targets"][0]["processSteps"][0]["configuration"]["defaultConfig"]["ruleRefs"]["ruleDetails"]


def test_v115_flow_rule_reference_uses_name_and_version_only():
    runner = run_agent.Runner(llm_enabled=False)
    details = _flow_rule_details(runner)
    assert set(details) == {"name", "version"}
    assert details["name"] == runner.business["mappingRuleName"]
    assert str(details["version"]) == str(runner.business["mappingRuleVersion"])
    assert "id" not in details


def test_v115_rule_existing_progresses_without_rule_id_or_secondary_lookup(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)
    calls = []
    monkeypatch.setattr(runner, "_request_with_retry", lambda **kwargs: calls.append(kwargs))
    result = _rule_existing()
    assert runner.enforce_live_id_integrity("rule", result, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    assert calls == []
    verdict = analyze_api_response(result)
    assert verdict["verdict"] == "PASS"
    assert verdict["outcome"] == "EXISTING"


def test_v115_flow_create_has_no_standalone_rule_id_requirement():
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.standalone_runtime_requirements("flow_create") == {}
    assert runner.missing_standalone_runtime_requirements("flow_create") == []
    assert runner.step_requires_live_id_for_progress("rule") is False


def test_v115_flow_payload_stays_identical_even_if_rule_id_is_captured_as_evidence():
    runner = run_agent.Runner(llm_enabled=False)
    before = runner.flow_orch_payload()
    runner.runtime_state["rule_id"] = 927
    after = runner.flow_orch_payload()
    assert before == after
    assert '"id":927' not in before["flowDefinition"].replace(" ", "")


def test_v115_mapping_rule_post_contract_is_unchanged_and_id_free():
    runner = run_agent.Runner(llm_enabled=False)
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "flowDefinitionId" not in payload
    assert "mapId" not in (payload["actions"][0].get("params") or {})
    assert payload["documentTypeName"]
    assert payload["documentTypeVersion"]
    assert payload["actions"][0]["params"]["mapIdentifier"]
    assert payload["actions"][0]["params"]["mapVersion"]


def test_v115_account_partner_system_are_not_skipped_by_previous_route_outage():
    runner = run_agent.Runner(llm_enabled=False)
    # Strict no-reuse mode executes these APIs each fresh run. No historical
    # upstream-route failure is a dependency or cached execution decision.
    assert runner.no_reuse_live_mode is True
    for step in ("account_source", "account_target", "partner_target", "system_source"):
        assert runner.execution_plan.is_skipped(step) is False


def test_v115_canonical_schema_omits_flow_rule_id():
    schema = json.loads((run_agent.CODE_ROOT / "schemas" / "uhal_canonical_18_request_shapes.json").read_text(encoding="utf-8"))
    flow = schema["steps"]["flow_create"]["schema"]["keys"]["flowDefinition"]["jsonStringSchema"]
    details = flow["keys"]["targetDetails"]["keys"]["targets"]["items"][0]["keys"]["processSteps"]["items"][0]["keys"]["configuration"]["keys"]["defaultConfig"]["keys"]["ruleRefs"]["keys"]["ruleDetails"]["keys"]
    assert set(details) == {"name", "version"}


def test_v115_build_identity_is_current():
    assert "v117" in run_agent.BUILD_ID.lower()
    assert "strict-live" in run_agent.BUILD_ID.lower()
    assert "no-reuse" in run_agent.BUILD_ID.lower()
