# V73 — U-HAUL Translation Reference + Repeated Parallel Runs

## Final U-HAUL rule

- U-HAUL is exposed only as the validated **Outbound 856 Translation** reference.
- Public template id: `builtin-uhal-outbound-856-translation-approved`.
- The approved U-HAUL template contains all 18 API blocks used by the validated Translation flow.
- U-HAUL Passthrough variants are never exposed as customer templates/sources.
- Old/stale U-HAUL configuration metadata that says Passthrough cannot make Flow Game select a Passthrough template.
- Other customers can still be Translation or Passthrough according to their own validated evidence.

## Same-customer parallel execution

The Execute page now supports repeating any validated source, including `reference:uhal`.

1. Select **Same-customer parallel execution**.
2. Choose U-HAUL Translation, Legrand, or another validated customer.
3. Choose 2–8 instances.
4. Click **Create N parallel instances**.
5. The backend creates N independent immutable queue snapshots with unique job IDs.
6. Each instance is labelled `Instance 1/N`, `Instance 2/N`, etc.
7. Multi-run mode and worker count are prepared automatically.
8. Run the selected instances concurrently.

Duplicate source IDs are intentionally preserved by `/api/parallel/queue-sources`; they are not deduplicated.

## Safety

Each repeated instance still performs its own final contract validation and production pre-LIVE gate before any HIP mutation. The feature duplicates validated execution snapshots, not mutable workspace references.
