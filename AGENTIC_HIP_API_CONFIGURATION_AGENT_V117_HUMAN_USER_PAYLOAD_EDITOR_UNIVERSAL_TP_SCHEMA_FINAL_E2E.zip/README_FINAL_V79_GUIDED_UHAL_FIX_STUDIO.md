# HIP API Agent Studio — V79 Guided U-HAUL Resolution

## What this release implements

V79 keeps the hardened evidence-vs-user-selection conflict gate and adds a beginner-first configuration experience.

### 1. U-HAUL is a first-class configuration
- The approved U-HAUL Outbound 856 Translation reference is automatically materialized into the Configuration Library.
- U-HAUL appears first and is selectable like other customer configurations.
- The managed approved U-HAUL reference cannot be accidentally deleted.
- Users can clone it into an editable customer configuration.
- Home and Build Configuration provide a one-click **Use U-HAUL starter** path.
- Starting a truly new configuration clears the previously active customer values instead of carrying U-HAUL/customer values into the blank form.

### 2. Blockers are click-to-fix
- A blocked or needs-input configuration remains visible instead of becoming a dead end.
- **Fix now** is available in the Configuration Library and Execution Center.
- API Flow Game exposes **Fix configuration** for blocked customer payloads.
- The guided modal loads the exact configuration issue.
- For customer-file vs user-selection conflicts it shows:
  - **CUSTOMER FILE**
  - **USER SELECTION**
  - **ANOTHER VALUE**
- The user chooses one approved value; the agent saves the decision, rebuilds the effective configuration and revalidates automatically.
- If configuration questions are already resolved but an API contract is still blocked, the same popup shows the exact editable API field and revalidates after correction.

### 3. Hard gate remains server-side
Unresolved human decisions cannot be bypassed through direct backend calls. The gate covers validation, API Testing, Flow Game, payload overrides, mapping-learning promotion, parallel queue/instances and LIVE execution.

### 4. User-facing product name
The application is presented as **HIP API Agent Studio**. Home/dashboard React branding has been removed. The browser title, sidebar, loading/fatal screens and visible runtime UI use the Studio name rather than exposing frontend framework terminology.

### 5. Beginner journey
The Home page explains the workflow as:
1. Choose a configuration.
2. Give the agent customer files.
3. Resolve anything that needs attention.
4. Validate all 18 HIP APIs.
5. Review the API flow.
6. Run safely.

## Validation performed for this release
- Application/root automated tests: **252 passed**
- FastAPI webapp tests: **48 passed**
- Total automated tests: **300 passed, 0 failed**
- V79 + hardened conflict focused regression: **14 passed, 0 failed**
- Phase 6 package checker: **38/38 PASS**
- Python source compilation: **PASS**
- Frontend TS/TSX syntax/transpilation: **24/24 PASS**

### Frontend production bundle advisory
The source package intentionally does not include `node_modules`. In the validation sandbox, npm dependencies were not cached, so a complete Vite production bundle was not executed there. All frontend TypeScript/TSX sources were independently transpiled successfully. Run the normal frontend dependency installation/build in the target environment.

## Important behavior
The packaged U-HAUL reference remains an approved reference configuration. **Use U-HAUL starter** creates an editable clone so customer-specific changes do not mutate the approved reference.
