from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import run_agent
from application_studio import (
    customer_metadata,
    customer_options,
    prepare_sftp_uhal_studio,
    request_inventory,
    run_local_request_checks,
)
from production_integration_test import fake_response

ROOT = Path(__file__).resolve().parent


def main() -> None:
    managed = [
        ROOT / "input.json",
        ROOT / "config_overrides.json",
        ROOT / "api_execution_plan.json",
        ROOT / "execution_flow.json",
        ROOT / "payload_overrides.json",
    ]
    backups = {p: p.read_bytes() if p.exists() else None for p in managed}

    try:
        assert customer_options("SFTP")[0] == "U-HAUL"
        meta = customer_metadata("SFTP", "U-HAUL")
        assert meta["deploymentGroup"] == "hip-automation"

        prep = prepare_sftp_uhal_studio(ROOT)
        assert prep["customer"] == "U-HAUL"
        assert prep["interface"] == "SFTP HAFT"
        assert prep["deploymentGroup"] == "hip-automation"
        assert prep["logicalSteps"] == 18
        assert prep["liveSteps"] == 18
        assert prep["reuseSteps"] == 0
        assert prep["executionPlan"]["skipSteps"] == []

        inventory = request_inventory(ROOT)
        assert inventory["total"] == 18
        assert inventory["live"] == 18
        assert inventory["reused"] == 0
        assert all(row["decision"] == "LIVE API" for row in inventory["cards"])
        assert all("effective" in row and "generated" in row for row in inventory["cards"])

        local_checks = run_local_request_checks(ROOT)
        assert local_checks["ok"] is True, local_checks
        assert local_checks["requests"]["total"] == 18
        assert local_checks["requests"]["validCount"] == 18

        runner = run_agent.Runner(llm_enabled=False)
        assert runner.full_api_coverage_mode is True
        runner.get_token = lambda token_kind, scope: "offline-token"
        runner.judge.judge = lambda result: {}
        runner.judge.available = lambda: False
        called_urls: list[str] = []

        def mocked_request(method: str, url: str, token_kind: str, scope: str, extra_headers: Any, payload: Any, params: Any):
            called_urls.append(url)
            return fake_response(method, url, payload, params)

        runner._request_with_retry = mocked_request
        with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(
            runner.adaptive, "record_mapping_graph", return_value={"status": "mocked"}
        ):
            results = runner.run()

        assert len(results) == 18
        assert runner.final_state["coverageComplete"] is True, runner.final_state
        assert not [r for r in results if str(r.classification).startswith("SKIPPED_")]
        assert len(called_urls) == 18, called_urls
        for fragment in [
            "/authz/account", "/authz/partner", "/hip-systems/", "/api/document-type",
            "/api/mac-map", "/api/rule", "/transport-profiles/orchestration/create",
            "/flows/orchestration/create", "/flows/orchestration/deploy",
            "/flows/deployment/history", "/transport-profiles/audits",
        ]:
            assert any(fragment in url for url in called_urls), fragment

        ui_text = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8")
        for token in [
            "HIP Configuration Studio",
            "Full Live API Coverage",
            "Agentic Interface Studio",
            "Run all Agent Checks",
            "Execute Whole U-HAUL Flow",
            "API-by-API request / response summary",
        ]:
            assert token in ui_text, token
        assert "st.page_link(\"pages/10_Agentic_Interface_Studio.py\"" not in ui_text

        evidence = {
            "status": "PASS",
            "buildId": run_agent.BUILD_ID,
            "studio": "Unified SFTP -> U-HAUL full live API coverage",
            "generatedRequests": inventory["total"],
            "requestChecksPassed": local_checks["requests"]["validCount"],
            "logicalStepsProcessed": len(results),
            "liveApiCalls": len(called_urls),
            "existingObjectsReused": 0,
            "skippedCalls": 0,
            "coverageComplete": runner.final_state["coverageComplete"],
            "singleStudio": True,
        }
        path = ROOT / "examples" / "APPLICATION_STUDIO_UHAL_VALIDATION.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
        print(json.dumps(evidence, indent=2))
    finally:
        for path, data in backups.items():
            if data is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(data)


if __name__ == "__main__":
    main()
