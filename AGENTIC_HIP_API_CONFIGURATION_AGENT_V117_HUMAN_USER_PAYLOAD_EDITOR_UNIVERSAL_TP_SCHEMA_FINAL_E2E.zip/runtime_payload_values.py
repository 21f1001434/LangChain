from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

_RUNTIME_TOKEN = re.compile(r"^\{\{runtime_payload\.([A-Za-z0-9_.-]+)\}\}$")


def runtime_payload_path(root: Path) -> Path:
    """Local, transient storage for Partner-supplied payload values.

    This is intentionally outside the project/.env/report folders. Values here
    are request data (for example an HTTPS Receiver Client Secret), not OAuth
    credentials used by the HIP application itself.
    """
    base = Path(tempfile.gettempdir()) / "hip_runtime_payload_values"
    base.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(str(Path(root).resolve()).lower().encode("utf-8")).hexdigest()[:20]
    return base / f"payload_values_{key}.json"


def placeholder(path: str) -> str:
    clean = str(path or "").strip().strip(".")
    if not clean:
        raise ValueError("Runtime payload value path is required.")
    return "{{runtime_payload." + clean + "}}"


def is_placeholder(value: Any) -> bool:
    return bool(isinstance(value, str) and _RUNTIME_TOKEN.match(value.strip()))


def _get_path(data: Dict[str, Any], dotted: str) -> Any:
    node: Any = data
    for part in str(dotted).split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def _set_path(data: Dict[str, Any], dotted: str, value: Any) -> None:
    parts = [part for part in str(dotted).split(".") if part]
    if not parts:
        return
    node = data
    for part in parts[:-1]:
        child = node.get(part)
        if not isinstance(child, dict):
            child = {}
            node[part] = child
        node = child
    node[parts[-1]] = value


def load_runtime_payload_values(root: Path, max_age_seconds: int = 4 * 60 * 60) -> Dict[str, Any]:
    path = runtime_payload_path(root)
    if not path.exists():
        return {}
    try:
        age = max(0.0, time.time() - path.stat().st_mtime)
        if age > max_age_seconds:
            path.unlink(missing_ok=True)
            return {}
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def save_runtime_payload_values(root: Path, values: Dict[str, Any], merge: bool = True) -> Dict[str, Any]:
    path = runtime_payload_path(root)
    current = load_runtime_payload_values(root) if merge else {}
    payload = deepcopy(current)
    for key, value in (values or {}).items():
        if isinstance(value, dict) and isinstance(payload.get(key), dict):
            payload[key].update(deepcopy(value))
        else:
            payload[key] = deepcopy(value)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return runtime_payload_status(root)


def save_runtime_payload_value(root: Path, dotted_path: str, value: Any) -> Dict[str, Any]:
    current = load_runtime_payload_values(root)
    _set_path(current, dotted_path, value)
    return save_runtime_payload_values(root, current, merge=False)


def clear_runtime_payload_values(root: Path) -> None:
    runtime_payload_path(root).unlink(missing_ok=True)


def runtime_payload_status(root: Path) -> Dict[str, Any]:
    values = load_runtime_payload_values(root)
    keys: List[str] = []

    def walk(node: Any, prefix: str = "") -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                path = f"{prefix}.{key}" if prefix else str(key)
                if isinstance(value, dict):
                    walk(value, path)
                else:
                    keys.append(path)
    walk(values)
    return {
        "available": bool(values),
        "keyCount": len(keys),
        "keys": sorted(keys),
        "path": str(runtime_payload_path(root)),
        "valuesRedacted": {key: "<AVAILABLE>" for key in sorted(keys)},
    }


def has_runtime_payload_value(root: Path, dotted_path: str) -> bool:
    value = _get_path(load_runtime_payload_values(root), dotted_path)
    return value not in (None, "")


def collect_placeholders(value: Any) -> List[str]:
    found: List[str] = []
    if isinstance(value, dict):
        for item in value.values():
            found.extend(collect_placeholders(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(collect_placeholders(item))
    elif isinstance(value, str):
        match = _RUNTIME_TOKEN.match(value.strip())
        if match:
            found.append(match.group(1))
    return found


def missing_runtime_payload_values(root: Path, value: Any) -> List[str]:
    data = load_runtime_payload_values(root)
    missing: List[str] = []
    for key in sorted(set(collect_placeholders(value))):
        resolved = _get_path(data, key)
        if resolved in (None, ""):
            missing.append(key)
    return missing


def resolve_runtime_payload_placeholders(root: Path, value: Any, strict: bool = True) -> Any:
    data = load_runtime_payload_values(root)

    def resolve(node: Any) -> Any:
        if isinstance(node, dict):
            return {key: resolve(item) for key, item in node.items()}
        if isinstance(node, list):
            return [resolve(item) for item in node]
        if isinstance(node, str):
            match = _RUNTIME_TOKEN.match(node.strip())
            if match:
                key = match.group(1)
                actual = _get_path(data, key)
                if actual in (None, ""):
                    if strict:
                        raise RuntimeError(
                            f"Missing Partner/runtime payload value for {key}. "
                            "Enter it in the Interface Studio before execution."
                        )
                    return node
                return actual
        return node

    return resolve(value)
