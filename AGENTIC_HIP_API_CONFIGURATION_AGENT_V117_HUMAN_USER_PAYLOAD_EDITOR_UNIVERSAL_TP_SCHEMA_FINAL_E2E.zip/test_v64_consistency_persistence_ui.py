from pathlib import Path

from report_insights import reconcile_execution_analyses, verdict_allows_progress
from webapp.backend.app.flow_engine import apply_edge_mappings

ROOT = Path(__file__).resolve().parent


def test_existing_verdict_is_reusable_dependency_state():
    assert verdict_allows_progress({"verdict": "WARNING", "outcome": "EXISTING"})
    assert verdict_allows_progress({"verdict": "PASS", "outcome": "SUCCESS"})
    assert not verdict_allows_progress({"verdict": "WARNING", "outcome": "NEEDS_VERIFICATION"})


def test_runtime_mapping_preserves_validated_request_fallback_when_existing_response_has_no_id():
    request = {"requestKind": "payload", "payload": {"documentTypeId": 10483}}
    edges = [{"id": "e1", "source": "doc", "target": "rule", "mappings": [{"from": "output.documentTypeId", "to": "payload.documentTypeId"}]}]
    effective, resolved, unresolved = apply_edge_mappings(request, edges, {"doc": {"verdict": "EXISTING"}})
    assert not unresolved
    assert effective["payload"]["documentTypeId"] == 10483
    assert resolved[0]["fallback"] == "validated_effective_request"


def test_downstream_success_does_not_rewrite_prerequisite_failure():
    rows = [
        {"classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", "status_code": 500, "response_preview": "create failed", "extracted": {"logicalStepKey": "account_source"}},
        {"classification": "PASS_SUCCESS", "status_code": 201, "business_success": True, "response_preview": "created", "extracted": {"logicalStepKey": "source_tp"}},
    ]
    analyses = reconcile_execution_analyses(rows)
    assert analyses[0]["verdict"] == "FAIL"
    assert analyses[0]["outcome"] == "API_ERROR"
    assert analyses[1]["verdict"] == "PASS"


def test_builder_new_file_intake_isolated_by_explicit_create_clone_edit_modes():
    text = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    # V83 supersedes implicit fresh-workspace switching with explicit user intent:
    # Create New is isolated, Clone Existing is independent, and Edit Existing
    # mutates only after the confirmation dialog.
    assert "Create New" in text and "Clone Existing" in text and "Edit Existing" in text
    assert "Yes, edit this configuration" in text
    assert "api.cloneConfiguration" in text
    assert "api.createConfiguration" in text
    assert "api.patchConfiguration" in text
    assert "setFiles([])" in text
    assert "active?.updated_at" in text


def test_live_result_metrics_have_non_vertical_labels_and_glass_surface():
    css = (ROOT / "webapp/frontend/src/styles.css").read_text(encoding="utf-8")
    assert ".live-result-section .result-metrics>div{display:flex!important" in css
    assert "white-space:nowrap!important" in css
    assert "backdrop-filter:blur(14px)" in css


def test_api_testing_keeps_transient_request_override_disabled_but_allows_human_persisted_value_edits():
    text = (ROOT / "webapp/frontend/src/pages/ApiTestingPage.tsx").read_text(encoding="utf-8")
    assert "Human Payload Value Editor" in text
    assert "Only you can edit approved values before LIVE" in text
    assert "Save my value edits" in text
    assert "api.apiTestPreflight(active.id,stepKey,{},'merge')" in text
    assert "api.apiTestExecute(active.id,stepKey,{},'merge')" in text

def test_generic_report_uses_reconciled_execution_verdicts_and_glass_surface():
    text = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    assert "reconcile_execution_analyses(raw_rows)" in text
    assert "backdrop-filter:blur(16px)" in text
    assert "no downstream reuse inference is applied" in text
