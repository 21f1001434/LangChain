# Agentic HIP API Configuration Agent — Phase 4 (V36)

Phase 4 adds production execution controls to the Bun/React + FastAPI application while retaining the proven Python HIP engine.

## What Phase 4 adds

### Manual LIVE approval gates per API block
Any API block can require an explicit human approval before the live request is sent. The canvas pauses at that node, shows `AWAITING_APPROVAL`, and continues only after the user approves from the node inspector.

Approval markers are runtime-only and stored under the active configuration workspace. They are not written into `input.json`, templates, or the release ZIP.

### Safe Stop LIVE
A running React graph can be cancelled from the API Flow Game or the Operations workspace. Completed API evidence is retained.

### Resume from checkpoint
BLOCKED, ERROR, or CANCELLED runs can be resumed. Successful previously completed nodes are restored from the prior execution record and are not re-sent. The remaining nodes continue with the restored upstream outputs and runtime edge mappings.

### Operations workspace
The React app now has a first-class **Operations** area with:
- configuration-scoped execution history
- read-only event replay/timeline
- LIVE stop controls
- checkpoint resume
- resume provenance (`resumed from`, restored node count)
- raw execution evidence
- execution-to-execution comparison
- per-node verdict/status comparison
- per-node total timing delta
- total execution timing delta

### Execution evidence
Terminal React graph executions continue to be written into the active configuration Reports workspace.

## Safety model
- LIVE execution still requires explicit user confirmation.
- Configuration agent validation must PASS before a new LIVE run or resume.
- Graph/API-contract preflight still runs before every LIVE start/resume.
- Only successful PASS nodes are restored during resume.
- Approval-gated nodes never call the HIP API before approval is received.
- `hip-automation` remains mandatory.
- Passthrough / Translation applicability rules remain unchanged.

## Run
First setup:

```powershell
SETUP_AGENTIC_HIP.bat
```

Normal launch:

```powershell
RUN_AGENTIC_HIP.bat
```

Frontend: `http://127.0.0.1:5173`

FastAPI docs: `http://127.0.0.1:8765/docs`

Optional approval timeout:

```env
HIP_NODE_APPROVAL_TIMEOUT_SECONDS=3600
```

Streamlit remains packaged as a compatibility/reference path while the React application completes migration.
