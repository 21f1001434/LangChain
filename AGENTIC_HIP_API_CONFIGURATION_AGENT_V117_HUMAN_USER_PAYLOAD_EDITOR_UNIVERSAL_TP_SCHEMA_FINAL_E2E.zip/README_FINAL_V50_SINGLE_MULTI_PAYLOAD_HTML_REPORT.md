# V50 — Single/Multi Customer Execution + Payload Editing + Final HTML Report

## What changed

- Parallel Runs is now a general Execution Center with explicit **Run one customer** and **Run multiple customers** modes.
- Single mode accepts exactly one validated customer (U-HAUL or any customer built/validated in the app) and runs with one worker.
- Multiple mode accepts two or more validated customers and runs them concurrently with 1–8 workers.
- U-HAUL remains the packaged approved reference; newly validated customer configurations appear in the same library.
- API Flow Game **Run LIVE** is now the first toolbar action and the toolbar wraps instead of requiring horizontal dragging.
- Every Flow Game node can load its complete generated/effective payload into the editor and use **replace** mode for full-payload editing.
- API Testing Area can edit a complete payload and **Save for customer**. Saved edits go to that configuration's `payload_overrides.json`, are revalidated immediately, and are included when the customer is snapshotted for single/parallel execution.
- Persistent payload editing changes request body/params only. Method, URL, OAuth selection and protected headers remain runner-controlled.
- React single-flow executions now create `HIP_final_live_execution_<execution-id>.html` plus `HIP_final_live_execution_latest.html`.
- Single/multi-customer batches create `HIP_parallel_final_report_<batch-id>.html` and provide a download button in the result card.
- Legacy `run_agent.py` customer HTML reports are preserved/copied into the source customer's Reports area when run from a queued customer snapshot.
- Reports page renders HTML reports in-app and provides a download action.

## Validation

- Full non-live regression suite: **184/184 passed**.
- Updated Python modules compile successfully.
- Updated TS/TSX files pass TypeScript parser/transpile validation.

## Manual build/run

```powershell
cd webapp\frontend
bun install
bun run build
cd ..\..
.\.venv\Scripts\Activate.ps1
python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765
```

Then open `http://127.0.0.1:8765` and use `Ctrl+Shift+R` once after upgrading from an older build.
