from __future__ import annotations

import json
from pathlib import Path

from run_agent import BUILD_ID, REPORTS, Runner
from production_guard import redact_sensitive


def main() -> int:
    print(f"HIP OAuth diagnostic build: {BUILD_ID}")
    runner = Runner(llm_enabled=False)
    try:
        token = runner.get_token("HIP", runner.hip_scope)
        result = {
            "status": "PASS",
            "buildId": BUILD_ID,
            "tokenReceived": bool(token),
            "tokenSource": runner.token_sources.get("HIP"),
            "tokenUrl": runner.hip_token_url,
            "scopeSent": bool(runner.hip_scope),
            "diagnostic": str(REPORTS / "hip_token_diagnostics_latest.json"),
        }
        print(json.dumps(redact_sensitive(result), indent=2))
        return 0
    except Exception as exc:
        result = {
            "status": "FAILED",
            "buildId": BUILD_ID,
            "tokenUrl": runner.hip_token_url,
            "scopeSent": bool(runner.hip_scope),
            "error": str(exc),
            "diagnostic": str(REPORTS / "hip_token_diagnostics_latest.json"),
        }
        print(json.dumps(redact_sensitive(result), indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
