@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo   Agentic HIP V104 - FULL Business Non-Mutating Release Validation
echo ============================================================
call :run "Quick packaged runtime checks" python FINAL_RELEASE_VALIDATION.py || goto :fail
call :run "Business workflow smoke" python BUSINESS_READINESS_VALIDATION.py || goto :fail
call :run "Full Python regression" python -m pytest -q || goto :fail
call :run "Standard package validator" python validate_package.py || goto :fail
call :run "Adaptive package validator" python validate_adaptive_package.py || goto :fail
call :run "Required final self-check" python final_self_check.py || goto :fail
for %%N in (1 2 3 4 5 6) do call :run "Phase %%N release check" python CHECK_AGENTIC_HIP_PHASE%%N.py || goto :fail
echo.
echo ============================================================
echo FINAL LOCAL/PACKAGE VALIDATION: PASS
echo ============================================================
echo This validation does NOT mutate Dell HIP.
echo Next: open System ^& Connections, verify OAuth/service readiness,
echo then run one approved LIVE smoke configuration on the Dell network.
pause
exit /b 0
:run
echo.
echo --- %~1 ---
shift
%*
if errorlevel 1 exit /b 1
exit /b 0
:fail
echo.
echo ============================================================
echo FINAL LOCAL/PACKAGE VALIDATION: FAIL
echo ============================================================
echo Fix the failing check before LIVE execution.
pause
exit /b 1
