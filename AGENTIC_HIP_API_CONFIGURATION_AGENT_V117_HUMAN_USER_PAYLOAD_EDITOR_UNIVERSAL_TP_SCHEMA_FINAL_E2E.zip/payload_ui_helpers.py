from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from production_guard import redact_sensitive


def safe_request_for_ui(value: Any) -> Any:
    """Return a display-safe copy of a request without exposing secrets."""
    return redact_sensitive(deepcopy(value))


def json_change_paths(before: Any, after: Any, prefix: str = "") -> List[str]:
    """Small human-readable structural diff for payload review screens."""
    paths: List[str] = []

    if isinstance(before, dict) and isinstance(after, dict):
        keys = sorted(set(before) | set(after), key=str)
        for key in keys:
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in before:
                paths.append(f"+ {path}")
            elif key not in after:
                paths.append(f"- {path}")
            else:
                paths.extend(json_change_paths(before[key], after[key], path))
        return paths

    if isinstance(before, list) and isinstance(after, list):
        if before != after:
            paths.append(prefix or "<root list>")
        return paths

    if before != after:
        paths.append(prefix or "<root>")
    return paths


def payload_status_row(
    *,
    step_key: str,
    label: str,
    method: str,
    decision: str,
    override_active: bool,
    request_kind: str,
    changed_paths: List[str],
) -> Dict[str, Any]:
    return {
        "stepKey": step_key,
        "Task": label,
        "Method": method,
        "Decision": decision,
        "Request": request_kind.upper(),
        "Edited": "Yes" if override_active else "No",
        "Changes": len(changed_paths),
    }


# ---------------------------------------------------------------------------
# Scratch easy-payload editor helpers
# ---------------------------------------------------------------------------
# Paths use a familiar JSON-ish notation: `flowDetails.name` and
# `attributes[0].value`.  The helpers are deliberately UI-framework agnostic so
# they can be regression tested without launching Streamlit.
_PATH_TOKEN_RE = re.compile(r"([^.[\]]+)|\[(\d+)\]")


def json_field_paths(value: Any, prefix: str = "") -> List[Dict[str, Any]]:
    """Flatten scalar JSON leaves into rows suitable for a no-code field editor.

    Each row contains path/value/type. Empty dictionaries/lists are represented as
    editable JSON values so a user can still replace them from the quick editor.
    """
    rows: List[Dict[str, Any]] = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            if not node:
                rows.append({"path": path or "<root>", "value": {}, "type": "object"})
                return
            for key, item in node.items():
                child = f"{path}.{key}" if path else str(key)
                walk(item, child)
            return
        if isinstance(node, list):
            if not node:
                rows.append({"path": path or "<root>", "value": [], "type": "array"})
                return
            for index, item in enumerate(node):
                child = f"{path}[{index}]" if path else f"[{index}]"
                walk(item, child)
            return
        rows.append({"path": path or "<root>", "value": deepcopy(node), "type": json_value_type(node)})

    walk(value, prefix)
    return rows


def json_value_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    return "string"


def display_json_value(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def parse_json_value(text: Any, expected_type: str = "string") -> Any:
    """Parse a quick-editor input while preserving the selected field's type."""
    if not isinstance(text, str):
        # Streamlit widgets may already return bool/int/float values.
        if expected_type == "string":
            return str(text)
        return deepcopy(text)

    raw = text.strip()
    kind = str(expected_type or "string").lower()
    if kind == "string":
        return text
    if kind == "null":
        return None if raw.lower() in {"", "null", "none"} else text
    if kind == "boolean":
        if raw.lower() in {"true", "1", "yes", "y", "on"}:
            return True
        if raw.lower() in {"false", "0", "no", "n", "off"}:
            return False
        raise ValueError("Boolean value must be true or false.")
    if kind == "integer":
        return int(raw)
    if kind == "number":
        return float(raw)
    if kind in {"object", "array"}:
        value = json.loads(raw or ("{}" if kind == "object" else "[]"))
        if kind == "object" and not isinstance(value, dict):
            raise ValueError("Expected a JSON object.")
        if kind == "array" and not isinstance(value, list):
            raise ValueError("Expected a JSON array.")
        return value
    # Fallback for unknown types: JSON when possible, otherwise text.
    try:
        return json.loads(raw)
    except Exception:
        return text


def _path_tokens(path: str) -> List[Any]:
    if path in {"", "<root>"}:
        return []
    tokens: List[Any] = []
    for match in _PATH_TOKEN_RE.finditer(str(path)):
        key, index = match.groups()
        tokens.append(int(index) if index is not None else key)
    return tokens


def get_json_path(value: Any, path: str) -> Any:
    node = value
    for token in _path_tokens(path):
        if isinstance(token, int):
            if not isinstance(node, list) or token >= len(node):
                raise KeyError(path)
            node = node[token]
        else:
            if not isinstance(node, dict) or token not in node:
                raise KeyError(path)
            node = node[token]
    return deepcopy(node)


def set_json_path(value: Any, path: str, new_value: Any) -> Any:
    """Return a deep copy with one existing/new nested JSON path changed."""
    tokens = _path_tokens(path)
    if not tokens:
        return deepcopy(new_value)
    out = deepcopy(value)
    node = out
    for position, token in enumerate(tokens[:-1]):
        next_token = tokens[position + 1]
        if isinstance(token, int):
            if not isinstance(node, list):
                raise KeyError(path)
            while len(node) <= token:
                node.append({} if isinstance(next_token, str) else [])
            if node[token] is None:
                node[token] = {} if isinstance(next_token, str) else []
            node = node[token]
        else:
            if not isinstance(node, dict):
                raise KeyError(path)
            if token not in node or node[token] is None:
                node[token] = {} if isinstance(next_token, str) else []
            node = node[token]
    last = tokens[-1]
    if isinstance(last, int):
        if not isinstance(node, list):
            raise KeyError(path)
        while len(node) <= last:
            node.append(None)
        node[last] = deepcopy(new_value)
    else:
        if not isinstance(node, dict):
            raise KeyError(path)
        node[last] = deepcopy(new_value)
    return out


def apply_quick_field_change(effective_request: Dict[str, Any], path: str, new_value: Any) -> Dict[str, Any]:
    """Apply a no-code field change to a full effective payload/params object.

    Scratch stores the result as a full replace override. That is intentional:
    changing `attributes[0].name` must not accidentally replace the whole list
    with a one-item merge patch.
    """
    if not isinstance(effective_request, dict):
        raise ValueError("Effective request must be a JSON object.")
    updated = set_json_path(effective_request, path, new_value)
    if not isinstance(updated, dict):
        raise ValueError("A HIP request must remain a JSON object.")
    return updated


def copy_request_override(source_component: Dict[str, Any]) -> Dict[str, Any]:
    """Return an independent deep copy of another Scratch block's override."""
    value = source_component.get("requestOverride") if isinstance(source_component, dict) else {}
    return deepcopy(value) if isinstance(value, dict) else {}
