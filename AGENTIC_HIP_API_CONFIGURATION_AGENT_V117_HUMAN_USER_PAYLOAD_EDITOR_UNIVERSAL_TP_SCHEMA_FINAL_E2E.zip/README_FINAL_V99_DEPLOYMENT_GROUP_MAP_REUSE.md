# V99 — hip-automation deployment group + existing MAC Map reuse

The latest LIVE report proved that `dce-shared` does not exist for the current environment. V99 locks the canonical deployment group to `hip-automation` across Input Builder, packaged U-HAUL reference data, React/FastAPI summaries, TP orchestration payloads, validators and reports.

The same report returned HTTP 500 with `Map identifier should be unique in an Environment. Please select other.` V99 treats that exact HIP response as explicit EXISTING evidence, reuses the configured/live U-HAUL map ID (`1670`), and continues Mapping Rule and Flow dependencies. Strict LIVE still calls and captures the MAC Map API; no skip assumption is introduced.
