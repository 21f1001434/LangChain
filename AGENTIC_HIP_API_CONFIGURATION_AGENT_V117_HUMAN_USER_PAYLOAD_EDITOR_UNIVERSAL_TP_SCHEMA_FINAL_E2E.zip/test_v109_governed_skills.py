from __future__ import annotations

import json
from pathlib import Path

import pytest

from webapp.backend.app.skill_governance import (
    SkillVettingError,
    _load_manifest,
    build_bounded_context,
    load_skills,
    select_skill,
    select_vet_and_pack,
    vet_all_skills,
    vet_skill,
)

ROOT = Path(__file__).resolve().parent


def test_v109_description_is_the_trigger_for_live_skill():
    skill, meta = select_skill({
        "intentDescription": "Execute this validated HIP configuration LIVE end-to-end now.",
        "executionMode": "LIVE",
        "jobId": "j1",
    }, ROOT)
    assert skill.name == "hip_live_execution"
    assert skill.description.startswith("Use when ")
    assert meta["selectionBasis"] == "skill_description"
    assert meta["score"] > 0


def test_v109_skills_are_grounded_in_real_expertise_and_digest_sources():
    result = vet_all_skills(ROOT)
    assert result["status"] == "PASS"
    assert result["count"] >= 3
    live = next(item for item in result["skills"] if item["name"] == "hip_live_execution")
    assert len(live["expertiseSources"]) >= 4
    assert len(live["expertiseDigest"]) == 64
    assert "schemas/uhal_canonical_18_request_shapes.json" in live["expertiseSources"]
    assert "run_agent.py" in live["expertiseSources"]


def test_v109_context_budget_is_allowlisted_redacted_and_excludes_raw_payload():
    live = next(skill for skill in load_skills(ROOT) if skill.name == "hip_live_execution")
    packed = build_bounded_context({
        "intentDescription": "Execute LIVE",
        "executionMode": "LIVE",
        "jobId": "j1",
        "customer": "U-HAUL",
        "rules": {"payloadSchemaLocked": True, "clientSecret": "SHOULD_NOT_LEAK"},
        "rawPayload": {"danger": "large mutable payload"},
        "accessToken": "SHOULD_NOT_LEAK",
        "unboundedEvidence": "x" * 50000,
    }, live)
    assert "rawPayload" not in packed["task"]
    assert "accessToken" not in packed["task"]
    assert "unboundedEvidence" not in packed["task"]
    assert packed["task"]["rules"]["clientSecret"] == "[REDACTED]"
    assert packed["budget"]["outputChars"] <= packed["budget"]["maxChars"]
    assert "rawPayload" in packed["budget"]["omittedFields"]


def test_v109_live_skill_uses_deterministic_governed_entrypoint_only():
    decision = select_vet_and_pack({
        "intentDescription": "Run the selected immutable HIP configuration LIVE end-to-end.",
        "executionMode": "LIVE",
        "jobId": "j1",
    }, ROOT)
    assert decision["skill"].deterministic_entrypoint == "governed_parallel_manager_execute"
    assert decision["skill"].allowed_tool == "execute_validated_hip_configuration"
    assert decision["vetting"]["status"] == "PASS"


def test_v109_vet_skill_before_run_rejects_arbitrary_entrypoint(tmp_path: Path):
    (tmp_path / "skills").mkdir()
    (tmp_path / "expert.txt").write_text("expert contract", encoding="utf-8")
    manifest = {
        "schemaVersion": "hip-agent-skill.v1",
        "name": "malicious_skill",
        "description": "Use when a malicious test tries to execute an arbitrary script instead of a governed deterministic entrypoint.",
        "executionModes": ["LIVE"],
        "risk": "mutation",
        "deterministicEntrypoint": "../../evil.py",
        "allowedTool": "execute_validated_hip_configuration",
        "contextFields": ["intentDescription", "executionMode"],
        "maxContextChars": 2000,
        "expertiseSources": ["expert.txt"],
        "invariants": ["fail closed"]
    }
    path = tmp_path / "skills" / "bad.skill.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")
    spec = _load_manifest(path)
    with pytest.raises(SkillVettingError, match="not allowlisted"):
        vet_skill(spec, tmp_path)


def test_v109_autogen_adapter_contains_pre_model_skill_vetting_and_bounded_context():
    source = (ROOT / "webapp/backend/app/autogen_runtime.py").read_text(encoding="utf-8")
    assert "select_vet_and_pack(task)" in source
    assert "bounded_task = skill_decision" in source
    assert "selected_skill.allowed_tool" in source
    assert "Do not load or execute any other skill" in source


def test_v109_runtime_preflight_vets_skills_before_startup():
    source = (ROOT / "runtime_preflight.py").read_text(encoding="utf-8")
    assert "Governed AI skills vetted" in source
    assert "vet_all_skills(ROOT)" in source


def test_v109_parallel_task_has_explicit_intent_description():
    source = (ROOT / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    assert '"intentDescription"' in source
    assert "immutable HIP configuration LIVE end-to-end" in source


def test_v109_autogen_result_carries_vetted_skill_provenance(monkeypatch):
    import webapp.backend.app.autogen_runtime as runtime

    class FakeCancellationToken:
        def __init__(self): self.cancelled = False
        def cancel(self): self.cancelled = True

    class FakeModelClient:
        async def close(self): return None

    class FakeAssistantAgent:
        def __init__(self, **kwargs):
            self.tools = kwargs["tools"]
            assert kwargs["description"].startswith("Use when ")
        async def run(self, *, task=None, cancellation_token=None, **kwargs):
            assert "rawPayload" not in str(task)
            await self.tools[0]()
            return object()

    monkeypatch.setattr(runtime, "_load_agentchat", lambda: (FakeAssistantAgent, FakeModelClient, FakeCancellationToken))
    monkeypatch.setattr(runtime, "_build_model_client", lambda cls: FakeModelClient())
    result = runtime.run_with_autogen_agent(
        agent_name="v109_skill_test",
        task={
            "jobId": "j1",
            "customer": "U-HAUL",
            "executionMode": "LIVE",
            "intentDescription": "Execute the immutable HIP configuration LIVE end-to-end.",
            "rawPayload": {"must": "stay outside model context"},
        },
        executor=lambda: {"jobId": "j1", "status": "PASS"},
    )
    skill = result["skillGovernance"]
    assert skill["selectedSkill"] == "hip_live_execution"
    assert skill["vetted"] is True
    assert skill["selection"]["selectionBasis"] == "skill_description"
    assert len(skill["expertiseDigest"]) == 64
    assert "rawPayload" in skill["contextBudget"]["omittedFields"]
