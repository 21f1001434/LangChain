@echo off
cd /d "%~dp0"
echo Starting LIVE U-HAUL HIP execution with mandatory Dell AIA...
python run_agent.py
if errorlevel 1 exit /b %errorlevel%
echo Execution completed. Reports are under reports.
