from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"name": name, "ok": bool(ok), "detail": detail})

manifest = json.loads((ROOT / "AGENTIC_HIP_PHASE4_MANIFEST.json").read_text(encoding="utf-8"))
main = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
worker = (ROOT / "webapp/backend/app/legacy_worker.py").read_text(encoding="utf-8")
manager = (ROOT / "webapp/backend/app/execution_manager.py").read_text(encoding="utf-8")
models = (ROOT / "webapp/backend/app/models.py").read_text(encoding="utf-8")
flow_ui = (ROOT / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
ops_ui = (ROOT / "webapp/frontend/src/pages/OperationsPage.tsx").read_text(encoding="utf-8")
node_ui = (ROOT / "webapp/frontend/src/components/NodeInspector.tsx").read_text(encoding="utf-8")
sidebar = (ROOT / "webapp/frontend/src/components/Sidebar.tsx").read_text(encoding="utf-8")

check("Phase 4 manifest", manifest.get("phase") == 4 and manifest.get("release") == "V36")
check("LIVE-only preserved", manifest.get("liveOnlyExecution") is True)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
check("Current deployment group is hip-automation", DEFAULT_DEPLOYMENT_GROUP == "hip-automation")
check("18 API block declaration", manifest.get("apiBlocks") == 18)
check("FastAPI phase 4+ bootstrap", ('"phase": 4' in main or '"phase": 5' in main or '"phase": 6' in main))
check("Node approval model", "approval_required" in models and "approval_message" in models)
check("Approval route", '/nodes/{node_id}/approve' in main)
check("Approval wait happens before runner.call", worker.find('node.awaiting_approval') < worker.find('runner.call('))
check("Approval received event", "node.approval_received" in worker)
check("Approval timeout configurable", "HIP_NODE_APPROVAL_TIMEOUT_SECONDS" in worker)
check("Cancel LIVE route", '/cancel' in main and "def cancel" in manager)
check("Resume LIVE route", '/resume' in main and "resume_from_execution" in manager)
check("Resume restores PASS outputs only", "_resume_state" in manager and "verdict" in manager and "completedNodeIds" in manager)
check("Worker skips restored nodes", "node.resumed" in worker and "resumed_nodes" in worker)
check("Execution comparison route", '/compare/{left_id}/{right_id}' in main)
check("Execution comparison engine", "def compare" in manager and "totalMsDelta" in manager)
check("React Operations workspace", "Execution Control Center" in ops_ui)
check("React resume control", "Resume from checkpoint" in ops_ui)
check("React run comparison", "Compare verdicts and timing" in ops_ui)
check("React Stop LIVE", "Stop LIVE" in flow_ui)
check("React approval status", "AWAITING_APPROVAL" in flow_ui)
check("Node approval setting", "Manual approval before LIVE API" in node_ui)
check("Operations navigation", "label:'Operations'" in sidebar and ("Phase 4" in sidebar or "Phase 5" in sidebar or "Phase 6" in sidebar))
check("Approval timeout documented", "HIP_NODE_APPROVAL_TIMEOUT_SECONDS" in (ROOT / ".env.example").read_text(encoding="utf-8"))

try:
    from webapp.backend.app.legacy_adapter import api_catalog, transaction_metadata
    check("Exactly 18 reusable APIs at runtime", len(api_catalog()) == 18 and all(x.get("reusable") for x in api_catalog()))
    meta = transaction_metadata()
    check("Direction remains editable", meta.get("editable_direction") is True and meta.get("default_direction") == "Outbound")
except Exception as exc:
    check("Phase 4 Python imports", False, str(exc))

failed = [row for row in checks if not row["ok"]]
summary = {"status": "PASS" if not failed else "FAIL", "passed": len(checks)-len(failed), "failed": len(failed), "checks": checks}
print(json.dumps(summary, indent=2))
raise SystemExit(1 if failed else 0)
