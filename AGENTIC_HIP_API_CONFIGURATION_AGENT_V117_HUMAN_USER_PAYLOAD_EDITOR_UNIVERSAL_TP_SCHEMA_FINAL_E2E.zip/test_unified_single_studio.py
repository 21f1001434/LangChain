from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    studio = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    adaptive = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8")
    views = (ROOT / "unified_studio_views.py").read_text(encoding="utf-8")

    assert not (ROOT / "pages").exists(), "Streamlit pages/ directory should not auto-create separate apps"
    assert "✨ Easy Mode" in studio
    assert "🧪 API Testing Area" in studio
    assert "render_easy_studio" in studio
    assert "🤖 Agentic Interface Studio" in studio
    assert "🛠️ Payload / MCP / Advanced" in studio
    assert "render_agentic_interface_studio" in studio
    assert "render_advanced_tools" in studio
    assert "st.page_link(\"pages/10_Agentic_Interface_Studio.py\"" not in studio
    assert "st.page_link(\"pages/90_Advanced_Technical_Workspace.py\"" not in studio
    assert "Observe → Plan → Validate → Critic" in views
    assert "MCP interface-plan evidence" in views
    assert "Full Live API Coverage" in adaptive

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-glass-easy-studio-v14",
        "easyModeDefault": True,
        "responsiveGlassUi": True,
        "singleStreamlitStudio": True,
        "legacyPagesNotAutoRegistered": True,
        "agenticInterfaceIntegrated": True,
        "advancedMcpToolsIntegrated": True,
        "pageLinkErrorRemoved": True,
    }
    path = ROOT / "examples" / "UNIFIED_SINGLE_STUDIO_VALIDATION.json"
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
