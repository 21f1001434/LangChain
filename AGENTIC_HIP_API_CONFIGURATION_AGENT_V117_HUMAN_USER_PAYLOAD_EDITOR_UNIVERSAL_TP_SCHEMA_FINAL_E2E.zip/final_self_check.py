from __future__ import annotations

import compileall
import io
import zipfile
import importlib.util
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from business_demo import agent_response_verdict
from api_contract_policy import API_REQUEST_MUTATION_ALLOWED, POLICY_NAME, immutable_flow_graph
from execution_flow import STEP_DEFINITIONS
from learn_assistant import LearnAssistant
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from input_builder_core import (
    combine_existing_input_with_artifact_evidence, build_from_raw_files,
    build_from_config_manual_and_raw_files, normalize_input_json,
)
from input_builder_artifacts import build_profile_runner_manual_bytes
from input_builder_integration import apply_user_request_hints
from input_mapping_learner import load_mapping_knowledge, mapping_learning_summary, record_mapping_example
from input_bundle import (
    backup_active_state, extract_input_zip, inspect_input_zip, inspect_individual_files,
    replace_input_files_from_pairs, restore_active_state,
)
from payload_ui_helpers import apply_quick_field_change, get_json_path
from parallel_configurations import snapshot_validated_configuration, snapshot_validated_configuration_instances, list_queued_configurations, _load_step_timings
from run_agent import AIAJudge, DEFAULT_HIP_TOKEN_USER_AGENT, Runner
from scratch_flow import (
    drag_palette_item,
    component_request,
    new_component,
    parse_drag_item,
    reconcile_drag_canvas,
)

ROOT = Path(__file__).resolve().parent


def check(name: str, ok: bool, detail: Any = "") -> Dict[str, Any]:
    return {"name": name, "ok": bool(ok), "detail": detail}


def main() -> int:
    checks: List[Dict[str, Any]] = []

    checks.append(check("Python source compilation", compileall.compile_dir(str(ROOT), quiet=1)))

    keys = list(STEP_DEFINITIONS)
    checks.append(check("Exactly 18 HIP API definitions", len(keys) == 18, {"count": len(keys), "keys": keys}))

    runner = Runner(llm_enabled=False)
    baseline_errors = [x for x in runner.mapper.validate() if x.severity == "ERROR"]
    effective_partner_identifier = runner.partner_identifier_value()
    checks.append(check(
        "U-HAUL baseline derives Partner Identifier from approved routing evidence",
        not baseline_errors
        and bool(effective_partner_identifier)
        and runner.partner_payload().get("partnerIdentifierValue") == effective_partner_identifier,
        {"mapperErrors": [x.__dict__ for x in baseline_errors], "effectivePartnerIdentifier": effective_partner_identifier},
    ))
    # Contract inspection remains non-mutating; no fabricated Partner Identifier
    # fixture is required because the approved routing condition is authoritative.
    runner.input = json.loads(json.dumps(runner.input))
    previews = []
    for seq, key in enumerate(keys, start=1):
        request = runner.preview_step_request(key)
        contract = runner.validate_request_contract(
            seq=seq,
            api_key=request.get("urlKey") or key,
            method=request.get("method") or "GET",
            url=request.get("url") or "",
            extra_headers=request.get("extraHeaders") or {},
            payload=request.get("payload"),
            params=request.get("params"),
        )
        previews.append({
            "stepKey": key,
            "method": request.get("method"),
            "urlKey": request.get("urlKey"),
            "requestKind": request.get("requestKind"),
            "contractValid": contract.get("valid"),
        })
    all_preview_ok = all(
        row["contractValid"] is True
        and row["method"] in {"GET", "POST", "PUT", "PATCH", "DELETE"}
        and row["urlKey"]
        for row in previews
    )
    checks.append(check("All 18 APIs build and pass non-mutating contract inspection", all_preview_ok, previews))

    flow = {
        "name": "Final self-check all 18",
        "components": [new_component(key, stop_on_blocked=False) for key in keys],
    }
    rendered = [component_request(runner, component, {}) for component in flow["components"]]
    scratch_ok = (
        len(rendered) == 18
        and [row.get("stepKey") for row in rendered] == keys
        and all(row.get("method") and row.get("urlKey") for row in rendered)
    )
    checks.append(check(
        "All 18 APIs build through Scratch in visual order",
        scratch_ok,
        [{"stepKey": row.get("stepKey"), "method": row.get("method"), "urlKey": row.get("urlKey")} for row in rendered],
    ))

    doc_token = drag_palette_item("doctype_source")
    four_docs, four_change = reconcile_drag_canvas({"name": "Four docs", "components": []}, [doc_token] * 4)
    checks.append(check(
        "Reusable drag/drop can create Document Type four times",
        len(four_docs.get("components") or []) == 4
        and len({row.get("instanceId") for row in four_docs.get("components") or []}) == 4
        and len(four_change.get("addedInstanceIds") or []) == 4,
    ))

    drag_ok = True
    for key in keys:
        kind, parsed = parse_drag_item(drag_palette_item(key))
        drag_ok = drag_ok and kind == "template" and parsed == key
    checks.append(check("All 18 APIs are draggable reusable palette blocks", drag_ok))

    default_input, default_cfg = with_default_deployment_group({"objects": {}}, {})
    source_tp_preview = component_request(runner, new_component("source_tp"), {})
    target_tp_preview = component_request(runner, new_component("target_tp"), {})
    deployment_ok = (
        DEFAULT_DEPLOYMENT_GROUP == "hip-automation"
        and default_input["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
        and default_input["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
        and default_cfg["source_deployment_group_name"] == "hip-automation"
        and default_cfg["target_deployment_group_name"] == "hip-automation"
        and source_tp_preview["payload"]["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"
        and target_tp_preview["payload"]["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"
    )
    checks.append(check("hip-automation is the deployment-group default across active TP interactions", deployment_ok))

    alias_input, alias_cfg = with_default_deployment_group({"objects": {
        "source_transport_profile": {"deployment-group": "wrong", "deploymentGroupName": "wrong"},
        "target_transport_profile": {"deploymentgroupname": "wrong"},
    }}, {"deployment-group": "wrong", "deploymentgroupname": "wrong"})
    alias_ok = (
        alias_input["objects"]["source_transport_profile"]["deployment-group"] == "hip-automation"
        and alias_input["objects"]["source_transport_profile"]["deploymentGroupName"] == "hip-automation"
        and alias_input["objects"]["target_transport_profile"]["deploymentgroupname"] == "hip-automation"
        and alias_cfg["deployment-group"] == "hip-automation"
        and alias_cfg["deploymentgroupname"] == "hip-automation"
    )
    checks.append(check("deployment-group/deploymentGroupName aliases normalize to hip-automation", alias_ok))

    immutable_graph = immutable_flow_graph({"nodes": [{"id": "n", "request_override": {"bad": 1}, "override_mode": "replace"}], "edges": []})
    immutable_ok = (
        API_REQUEST_MUTATION_ALLOWED is False
        and POLICY_NAME == "IMMUTABLE_DEVELOPER_APPROVED_18_API_CONTRACT_HUMAN_USER_VALUE_EDIT_ONLY"
        and immutable_graph["nodes"][0]["request_override"] == {}
        and immutable_graph["nodes"][0]["override_mode"] == "merge"
    )
    checks.append(check("Approved 18-API structure mutation is disabled while human value editing is governed", immutable_ok))

    with tempfile.TemporaryDirectory() as td:
        bundle_buffer = io.BytesIO()
        with zipfile.ZipFile(bundle_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("maps/Transform.jar", b"jar")
            zf.writestr("schemas/source.xml", b"<Source/>")
            zf.writestr("schemas/output.xml", b"<Output/>")
        bundle_bytes = bundle_buffer.getvalue()
        bundle_info = inspect_input_zip(bundle_bytes)
        destination = Path(td) / "input_files"
        extract_input_zip(bundle_bytes, destination)
        bundle_ok = (
            bundle_info.get("fileCount") == 3
            and (destination / "Transform.jar").exists()
            and (destination / "source.xml").exists()
            and (destination / "output.xml").exists()
        )
        checks.append(check("UHAL-style ZIP input bundle validates and extracts safely", bundle_ok, bundle_info))

    with tempfile.TemporaryDirectory() as td:
        pairs = [("map.xbm", b"<transformMap logicalName=\"MAP_A\"/>"), ("Transform_MAP_A.jar", b"jar"), ("source.xml", b"<Source/>")]
        direct_info = inspect_individual_files(pairs)
        direct_dest = Path(td) / "input_files"
        replace_input_files_from_pairs(pairs, direct_dest)
        existing = {
            "customer": "SELF_CHECK", "direction": "Inbound", "flow_type": "translation", "requires_data_map": True,
            "objects": {"data_map": {"map_name": "MAP_A", "map_data_file": ""}},
        }
        evidence = {
            "customer": "SELF_CHECK", "direction": "Inbound", "flow_type": "translation", "requires_data_map": True,
            "objects": {"data_map": {"map_name": "MAP_A", "map_data_file": "Transform_MAP_A.jar"}},
        }
        combined = combine_existing_input_with_artifact_evidence(existing, evidence, manifest=[x[0] for x in pairs])
        direct_ok = (
            direct_info.get("fileCount") == 3
            and (direct_dest / "Transform_MAP_A.jar").exists()
            and combined.get("objects", {}).get("data_map", {}).get("map_data_file") == "Transform_MAP_A.jar"
            and not (combined.get("_artifact_validation") or {}).get("blockers")
        )
        checks.append(check("Existing input.json can ingest individual supporting artifacts", direct_ok, combined.get("_artifact_validation")))

    scratch_ui = (ROOT / "scratch_flow_ui.py").read_text(encoding="utf-8")
    app_ui = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    builder_ui = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    game_bundle_ok = all(marker in scratch_ui for marker in ("HIP Flow Arcade", "MISSION TRACK", "LAUNCH MISSION LIVE")) \
        and "🧭 Build New Configuration" in app_ui \
        and all(marker in builder_ui for marker in (
            "Select interface", "Upload customer artifacts",
            "Agent ingest + generate input.json",
            "Agent asks only for values it cannot determine",
            "Map input.json to the 18 HIP APIs + validate",
            "Existing input.json + supporting artifacts",
            "ZIP bundle", "Individual files",
            "RUN FULL CONFIGURATION LIVE",
        ))
    checks.append(check("Game board + full New Configuration Builder are packaged", game_bundle_ok))

    payload = {"name": "DOC_A", "attributes": [{"value": "OLD", "usage": ["Identifier", "Display"]}], "other": {"keep": True}}
    changed = apply_quick_field_change(payload, "attributes[0].value", "NEW")
    checks.append(check(
        "Easy payload editor changes one nested field without losing siblings",
        get_json_path(changed, "attributes[0].value") == "NEW"
        and changed["attributes"][0]["usage"] == ["Identifier", "Display"]
        and changed["other"] == {"keep": True}
        and payload["attributes"][0]["value"] == "OLD",
    ))

    existing = agent_response_verdict({
        "api": "Create System", "status_code": 409, "business_success": False,
        "response_preview": "AIC-DCE is already exists. Please Update",
    })
    blocked = agent_response_verdict({
        "api": "Source TP orchestration create ONLY", "status_code": 400, "business_success": False,
        "response_preview": "not able to find system AIC-DCE",
    })
    checks.append(check(
        "Response analyst distinguishes PASS/EXISTING from BLOCKED",
        existing.get("verdict") == "PASS" and existing.get("outcome") == "EXISTING" and blocked.get("verdict") == "BLOCKED",
        {"existing": existing, "blocked": blocked},
    ))

    nav_files = [ROOT / "pages" / "10_Agentic_Interface_Studio.py", ROOT / "pages" / "90_Advanced_Technical_Workspace.py"]
    nav_ok = all(path.exists() for path in nav_files) and all(
        'st.page_link("hip_application_studio.py"' not in path.read_text(encoding="utf-8") for path in nav_files
    )
    checks.append(check("Compatibility navigation avoids hard-coded root page_link", nav_ok))

    with tempfile.TemporaryDirectory() as td:
        temp_root = Path(td)
        har = {
            "log": {"entries": [{
                "request": {
                    "method": "POST", "url": "https://example/api",
                    "headers": [
                        {"name": "Authorization", "value": "Bearer SELF_CHECK_TOKEN"},
                        {"name": "Cookie", "value": "SESSION=SELF_CHECK_COOKIE"},
                    ],
                    "postData": {"text": '{"client_secret":"SELF_CHECK_SECRET"}'},
                },
                "response": {"status": 400, "content": {"text": "not able to find"}},
            }]}
        }
        record = LearnAssistant(temp_root).ingest("selfcheck.har", json.dumps(har).encode("utf-8"), "application/json")
        stored = Path(record["storedPath"]).read_text(encoding="utf-8")
        redaction_ok = record.get("storedRedacted") is True and all(
            secret not in stored for secret in ("SELF_CHECK_TOKEN", "SELF_CHECK_COOKIE", "SELF_CHECK_SECRET")
        )
        checks.append(check("Learn persists HAR/network evidence in redacted form", redaction_ok))

    vision = [x.lower() for x in AIAJudge({}, enabled=False).vision_candidates()]
    checks.append(check(
        "Vision routing excludes text gpt-oss-120b and retains reviewed multimodal candidates",
        "gpt-oss-120b" not in vision and "gemma-3-27b-it" in vision and "pixtral-12b-2409" in vision,
        vision,
    ))

    real_env = ROOT / ".env"
    checks.append(check("Release ZIP does not require embedded credentials", True, {"localEnvPresent": real_env.exists(), "template": ".env.example"}))

    checks.append(check(
        "HIP Application Studio primary launchers are packaged",
        (ROOT / "RUN_HIP_STUDIO.bat").exists() and (ROOT / "RUN_HIP_STUDIO.ps1").exists()
        and "RUN_AGENTIC_HIP.bat" in (ROOT / "RUN_HIP_STUDIO.bat").read_text(encoding="utf-8")
        and "SETUP_AGENTIC_HIP.bat" in (ROOT / "SETUP_AND_RUN.bat").read_text(encoding="utf-8"),
    ))

    requirements_text = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    legacy_requirements_text = (ROOT / "requirements_legacy_streamlit.txt").read_text(encoding="utf-8") if (ROOT / "requirements_legacy_streamlit.txt").exists() else ""
    checks.append(check(
        "Phase 6 primary runtime is React/FastAPI and legacy Streamlit is optional",
        "fastapi>=0.128,<1" in requirements_text
        and "streamlit>=" not in requirements_text
        and "streamlit>=1.50,<2.0" in legacy_requirements_text
        and (ROOT / "runtime_preflight.py").exists(),
    ))

    build_values = []
    for filename in ("hip_application_studio.py", "run_agent.py"):
        text = (ROOT / filename).read_text(encoding="utf-8")
        import re
        match = re.search(r'^BUILD_ID\s*=\s*["\']([^"\']+)', text, flags=re.M)
        build_values.append(match.group(1) if match else "")
    manifest = json.loads((ROOT / "LIVE_ONLY_RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    checks.append(check(
        "Release build IDs are internally consistent",
        len(set(build_values + [str(manifest.get("buildId") or "")])) == 1 and bool(build_values[0]),
        {"pythonBuildIds": build_values, "manifestBuildId": manifest.get("buildId")},
    ))

    lightweight_runner = Runner.__new__(Runner)
    lightweight_runner.__dict__.pop("hip_token_user_agent", None)
    lightweight_runner.__dict__.pop("token_sources", None)
    lightweight_runner._ensure_token_runtime_state()
    oauth_user_agent = lightweight_runner._resolved_hip_token_user_agent()
    checks.append(check(
        "HIP OAuth lightweight Runner has safe User-Agent/token-state fallback",
        oauth_user_agent == DEFAULT_HIP_TOKEN_USER_AGENT
        and isinstance(lightweight_runner.token_sources, dict),
        {"userAgent": oauth_user_agent, "tokenSourcesInitialized": isinstance(lightweight_runner.token_sources, dict)},
    ))

    typo_existing = agent_response_verdict({"response_preview": "AIC-DCE is already exits . Please Update"})
    checks.append(check(
        "Response analyst accepts the observed already-exits wording as EXISTING",
        typo_existing.get("verdict") == "PASS" and typo_existing.get("outcome") == "EXISTING",
        typo_existing,
    ))

    with tempfile.TemporaryDirectory() as td:
        state_root = Path(td) / "state"
        state_root.mkdir()
        (state_root / "input_files").mkdir()
        (state_root / "input_files" / "old.xml").write_text("old", encoding="utf-8")
        (state_root / "input.json").write_text('{"old":true}', encoding="utf-8")
        backup_root = Path(td) / "backup"
        backup_active_state(state_root, backup_root)
        (state_root / "input_files" / "old.xml").unlink()
        (state_root / "input_files" / "new.xml").write_text("new", encoding="utf-8")
        (state_root / "input.json").write_text('{"new":true}', encoding="utf-8")
        restore_active_state(state_root, backup_root)
        rollback_ok = (state_root / "input_files" / "old.xml").read_text(encoding="utf-8") == "old" \
            and not (state_root / "input_files" / "new.xml").exists() \
            and json.loads((state_root / "input.json").read_text(encoding="utf-8")) == {"old": True}
        checks.append(check("Input Bundle activation has rollback protection", rollback_ok))

    builder_modules = [
        ROOT / "input_builder_core.py", ROOT / "input_builder_integration.py",
        ROOT / "input_builder_aia_adapter.py", ROOT / "input_builder_artifacts.py",
        ROOT / "input_builder_ui.py",
    ]
    checks.append(check("Standalone Dell AIA Input Builder is integrated into the main solution", all(p.exists() for p in builder_modules), [p.name for p in builder_modules]))

    runtime_sources = "\n".join(
        p.read_text(encoding="utf-8", errors="replace")
        for p in ROOT.glob("*.py")
        if not p.name.startswith(("test_", "validate_")) and p.name != "final_self_check.py"
    )
    legacy_groups = [x for x in ("dce-shared-sender", "dce-shared-receiver", "dce-default-sender", "dce-default-receiver") if x in runtime_sources]
    checks.append(check("No legacy deployment-group literal remains in runtime Python", not legacy_groups, legacy_groups))
    checks.append(check("Runtime does not fabricate the old sample Partner/DUNS value", '123456789' not in runtime_sources))

    from adaptive_engine import AdaptiveHipEngine
    engine = AdaptiveHipEngine(Path(tempfile.mkdtemp(prefix="hip_v25_selfcheck_")))
    proposal = engine.propose_change("Use deployment group wrong-group and DUNS is DUNS-SELF-CHECK", runner.input, {}, use_aia=False)
    applied = engine.apply_change(proposal, runner.input, {}, approve=True)
    checks.append(check(
        "Free-text changes cannot override hip-automation and can capture a real Partner Identifier",
        applied["input"].get("partner_identifier_value") == "DUNS-SELF-CHECK"
        and applied["input"]["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
        and applied["input"]["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation",
    ))

    # V28 multi-source + flow-applicability acceptance checks.
    with tempfile.TemporaryDirectory(prefix="hip_v28_multisource_") as td:
        td_path = Path(td)
        source_xml = td_path / "source.xml"
        source_xml.write_text("<cXML><Receiver>CUSTOMER</Receiver><Sender>DELL</Sender><OrderId>1</OrderId></cXML>", encoding="utf-8")

        passthrough = build_from_raw_files(
            [source_xml], customer="ATEA_NORWAY", direction="Inbound",
            flow_type="passthrough", use_dell_aia=False,
        )
        pt_steps = (passthrough.get("objects", {}).get("biz_flow", {}) or {}).get("process_steps", []) or []
        strict_pt_ok = (
            passthrough.get("flow_type") == "passthrough"
            and passthrough.get("requires_data_map") is False
            and not str((passthrough.get("objects", {}).get("target_document_type", {}) or {}).get("name") or "").strip()
            and not str((passthrough.get("objects", {}).get("data_map", {}) or {}).get("map_identifier") or "").strip()
            and str((passthrough.get("objects", {}).get("rule", {}) or {}).get("name") or "").upper() == "NA"
            and not any(str(x.get("step_type") or "").lower() == "mapping transformer" for x in pt_steps if isinstance(x, dict))
        )
        checks.append(check("V28 Passthrough defaults to one Document Type and direct routing", strict_pt_ok))

        mapping_jar = td_path / "Transform_MAP850.jar"
        with zipfile.ZipFile(mapping_jar, "w") as zf:
            zf.writestr("com/dell/Transform_MAP850.class", b"class")
        translation = build_from_raw_files(
            [source_xml, mapping_jar], customer="LEGRAND", direction="Inbound",
            flow_type="", use_dell_aia=False,
        )
        checks.append(check(
            "V28 mapping artifacts keep incomplete flows in Translation",
            translation.get("flow_type") == "translation" and translation.get("requires_data_map") is True,
            {"flowType": translation.get("flow_type"), "mapFile": (translation.get("objects", {}).get("data_map", {}) or {}).get("map_data_file")},
        ))

        manual_bytes = build_profile_runner_manual_bytes(passthrough)
        manual_path = td_path / "Configuration_Manual.xlsx"
        manual_path.write_bytes(manual_bytes)
        cm_plus_files = build_from_config_manual_and_raw_files(
            manual_path, [source_xml, mapping_jar], customer="LEGRAND", direction="Inbound",
            flow_type="", use_dell_aia=False, manual_primary=True,
        )
        checks.append(check(
            "V28 Configuration Manual + customer files converge to one canonical input.json",
            cm_plus_files.get("_source") == "Configuration Manual + customer artifacts"
            and cm_plus_files.get("flow_type") == "translation",
            {"source": cm_plus_files.get("_source"), "flowType": cm_plus_files.get("flow_type")},
        ))

        request_base = normalize_input_json({
            "customer": "REQUEST_CUSTOMER", "direction": "Outbound", "flow_type": "translation", "requires_data_map": True,
            "objects": {
                "source_document_type": {"name": "SRC", "version": "1.0"},
                "target_document_type": {"name": "TGT", "version": "1.0"},
                "data_map": {"map_identifier": "MAP", "map_data_file": "Transform_MAP.jar"},
                "rule": {"name": "MAP_RULE"},
                "source_transport_profile": {"profile_name": "SRC_TP"},
                "target_transport_profile": {"profile_name": "TGT_TP"},
                "biz_flow": {"process_steps": [{"step_type": "Mapping Transformer"}]},
            },
        })
        learned, learned_audit = apply_user_request_hints(
            td_path, request_base,
            "This is an inbound passthrough flow. DUNS is 99887766. Target account is TGT_ACC. No separate target document type.",
            use_aia=False,
        )
        checks.append(check(
            "V28 explicit user request can safely teach input.json without inventing values",
            learned.get("flow_type") == "passthrough"
            and learned.get("partner_identifier_value") == "99887766"
            and (learned.get("objects", {}).get("target_transport_profile", {}) or {}).get("existing_account_name") == "TGT_ACC"
            and not str((learned.get("objects", {}).get("target_document_type", {}) or {}).get("name") or "").strip()
            and bool(learned_audit.get("applied")),
            learned_audit.get("applied"),
        ))

    ui_text = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    checks.append(check(
        "V28 Builder exposes files-only, CM+files, existing-input+files and user-request modes",
        all(token in ui_text for token in (
            "Customer files only — agent creates input.json",
            "Configuration Manual + customer files — agent creates input.json",
            "Existing input.json + supporting artifacts",
            "User request / business instructions for input.json",
        )),
    ))

    # V29 Windows/Linux artifact portability guards.
    v27_test_text = (ROOT / "test_v27_input_json_plus_artifacts.py").read_text(encoding="utf-8")
    checks.append(check(
        "V29 artifact regression tests have no machine-specific /mnt/data dependency",
        "/mnt/data/" not in v27_test_text and "\\mnt\\data" not in v27_test_text,
    ))

    with tempfile.TemporaryDirectory(prefix="hip_v29_manifest_") as td:
        td_path = Path(td)
        jar = td_path / "Transform_PORTABLE_MAP.jar"
        with zipfile.ZipFile(jar, "w") as zf:
            zf.writestr("Transform_PORTABLE_MAP.class", b"fixture")
        xbm = td_path / "PORTABLE_MAP.xbm"
        xbm.write_text('<transformMap logicalName="PORTABLE_MAP" analystVersionLastSaved="1.0"></transformMap>', encoding="utf-8")
        src = td_path / "source.xml"
        src.write_text('<Source/>', encoding="utf-8")
        evidence = build_from_raw_files([xbm, jar, src], customer="PORTABLE", direction="Inbound", flow_type="translation", use_dell_aia=False)
        existing = json.loads(json.dumps(evidence))
        existing["objects"]["data_map"]["map_data_file"] = ""
        evidence["objects"]["data_map"]["map_data_file"] = ""
        merged = combine_existing_input_with_artifact_evidence(existing, evidence, manifest=[xbm.name, jar.name, src.name])
        checks.append(check(
            "V29 blank map_data_file is recovered from the current uploaded JAR manifest",
            (merged.get("objects", {}).get("data_map", {}) or {}).get("map_data_file") == jar.name
            and not (merged.get("_artifact_validation", {}) or {}).get("blockers"),
            (merged.get("objects", {}).get("data_map", {}) or {}).get("map_data_file"),
        ))

    # V30 parallel-agent + latency acceptance checks.
    with tempfile.TemporaryDirectory(prefix="hip_v30_parallel_") as td:
        td_path = Path(td)
        (td_path / "input_files").mkdir()
        (td_path / "input_files" / "sample.xml").write_text("<Root/>", encoding="utf-8")
        (td_path / "input.json").write_text(json.dumps({
            "customer": "V30_CUSTOMER", "profile_name": "V30_FLOW",
            "direction": "Outbound", "flow_type": "passthrough",
            "objects": {"biz_flow": {"flow_details": {"business_flow_name": "V30_FLOW"}}},
        }), encoding="utf-8")
        (td_path / "config_overrides.json").write_text("{}", encoding="utf-8")
        (td_path / "request_validation_cache.json").write_text(json.dumps({"fixture": {"valid": True}}), encoding="utf-8")
        validation = {
            "ok": True, "generatedAt": "self-check", "mapper": {"ok": True},
            "mcpSupervisor": {"valid": True},
            "requests": {"ok": True, "validCount": 18, "total": 18, "items": [{"valid": True}] * 18},
        }
        queued = snapshot_validated_configuration(td_path, validation)
        listed = list_queued_configurations(td_path)
        workspace = Path(queued.get("workspace") or "")
        checks.append(check(
            "V30 validated configurations can be frozen into isolated parallel-agent snapshots",
            bool(listed and listed[0].get("ready"))
            and (workspace / "input.json").exists()
            and (workspace / "input_files" / "sample.xml").exists()
            and (workspace / "request_validation_cache.json").exists(),
            {"jobId": queued.get("jobId"), "ready": listed[0].get("ready") if listed else False},
        ))

    runner_source = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    parallel_source = (ROOT / "parallel_configurations.py").read_text(encoding="utf-8")
    parallel_ui_source = (ROOT / "parallel_config_ui.py").read_text(encoding="utf-8")
    studio_source = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    checks.append(check(
        "V30 parallel live execution is isolated per configuration and dependency-safe within each agent",
        "ThreadPoolExecutor" in parallel_source
        and "HIP_WORKSPACE_ROOT" in parallel_source
        and "run_agent.py" in parallel_source
        and "⚡ Parallel Configurations" in studio_source
        and "RUN SELECTED CONFIGURATIONS IN PARALLEL LIVE" in parallel_ui_source,
    ))
    checks.append(check(
        "V30 backend latency optimizations are enabled without a UI redesign",
        "HTTPAdapter" in runner_source
        and "HIP_HTTP_POOL_SIZE" in runner_source
        and "HIP_REUSE_VALIDATED_REQUESTS" in runner_source
        and "request_validation_cache.json" in runner_source,
    ))

    # V31 per-step timing + U-HAUL multi-instance parallel demo acceptance checks.
    with tempfile.TemporaryDirectory(prefix="hip_v31_uhal_instances_") as td:
        td_path = Path(td)
        (td_path / "input_files").mkdir()
        (td_path / "input_files" / "source.xml").write_text("<DellAutoASN/>", encoding="utf-8")
        (td_path / "input.json").write_text(json.dumps({
            "customer": "U-HAUL", "profile_name": "UHAL_V31_DEMO",
            "direction": "Outbound", "flow_type": "translation",
            "objects": {"biz_flow": {"flow_details": {"business_flow_name": "UHAL_V31_DEMO"}}},
        }), encoding="utf-8")
        validation = {
            "ok": True, "generatedAt": "self-check", "mapper": {"ok": True},
            "mcpSupervisor": {"valid": True},
            "requests": {"ok": True, "validCount": 18, "total": 18, "items": [{"valid": True}] * 18},
        }
        instances = snapshot_validated_configuration_instances(td_path, validation, 3, label_prefix="U-HAUL Parallel Demo")
        checks.append(check(
            "V31 one validated U-HAUL configuration can be cloned into multiple isolated parallel instances",
            len(instances) == 3
            and len({row.get("jobId") for row in instances}) == 3
            and [row.get("demoInstance") for row in instances] == [1, 2, 3],
            [row.get("jobId") for row in instances],
        ))

        timing_root = td_path / "timing_fixture"
        (timing_root / "reports").mkdir(parents=True)
        (timing_root / "reports" / "execution_timing_latest.json").write_text(json.dumps({
            "events": [{
                "stepKey": "doctype_source", "label": "Source Document Type", "sequence": 8,
                "resultClassification": "PASS", "apiElapsedMs": 850, "apiElapsedSeconds": 0.85,
                "actualWaitSeconds": 0.15, "totalStepSeconds": 1.0,
            }]
        }), encoding="utf-8")
        timing_rows = _load_step_timings(timing_root)
        checks.append(check(
            "V31 execution timing captures API, wait and total time for each step",
            bool(timing_rows)
            and timing_rows[0].get("apiElapsedSeconds") == 0.85
            and timing_rows[0].get("waitSeconds") == 0.15
            and timing_rows[0].get("totalStepSeconds") == 1.0,
            timing_rows,
        ))

    checks.append(check(
        "V31 Parallel execution is a first-class Application Studio workspace with U-HAUL demo controls",
        "⚡ Parallel LIVE" in studio_source
        and "U-HAUL parallel capability demo" in parallel_ui_source
        and "Total step time" in parallel_ui_source
        and "snapshot_validated_configuration_instances" in parallel_source,
    ))

    # V32 uploaded-file truth + multi-reference input.json mapping learner checks.
    with tempfile.TemporaryDirectory(prefix="hip_v32_file_mapping_") as td:
        td_path = Path(td)
        src = td_path / "SRC_850.xml"
        tgt = td_path / "TGT_850.xml"
        jar = td_path / "Transform_V32.jar"
        src.write_text('<?xml version="1.0"?><PurchaseOrderCollection><OrderHeader/></PurchaseOrderCollection>', encoding="utf-8")
        tgt.write_text('<?xml version="1.0"?><PurchaseOrder><OrderHeader/></PurchaseOrder>', encoding="utf-8")
        with zipfile.ZipFile(jar, "w") as zf:
            zf.writestr("Transform_V32.class", b"CAFEBABE")
        built = build_from_raw_files([src, tgt, jar], customer="V32", direction="Inbound", flow_type="translation", use_dell_aia=False)
        src_dt = ((built.get("objects") or {}).get("source_document_type") or {})
        tgt_dt = ((built.get("objects") or {}).get("target_document_type") or {})
        fm = built.get("_file_mapping") or {}
        checks.append(check(
            "V32 physical uploaded XML controls Source/Target Document Type format instead of EDI transaction heuristics",
            src_dt.get("data_format_type") == "XML"
            and tgt_dt.get("data_format_type") == "XML"
            and built.get("tx_standard") == "XML"
            and ((src_dt.get("document_identifier") or {}).get("rows") or [{}])[0].get("value") == "PurchaseOrderCollection"
            and ((tgt_dt.get("document_identifier") or {}).get("rows") or [{}])[0].get("value") == "PurchaseOrder"
            and (fm.get("source") or {}).get("filename") == "SRC_850.xml",
            {"txStandard": built.get("tx_standard"), "source": fm.get("source"), "target": fm.get("target")},
        ))

        def ref(customer: str, src_name: str, tgt_name: str) -> Dict[str, Any]:
            return {"customer": customer, "_file_mapping": {
                "source": {"filename": src_name, "data_format_type": "XML"},
                "target": {"filename": tgt_name, "data_format_type": "XML"},
                "fieldMappings": [
                    {"path": "objects.source_document_type.data_format_type", "rule": "physical source payload content sniff"},
                    {"path": "objects.target_document_type.data_format_type", "rule": "physical target payload content sniff"},
                ],
            }}
        record_mapping_example(td_path, ref("A", "ORIGIN_A.xml", "DEST_A.xml"), ["ORIGIN_A.xml", "DEST_A.xml"])
        record_mapping_example(td_path, ref("B", "ORIGIN_B.xml", "DEST_B.xml"), ["ORIGIN_B.xml", "DEST_B.xml"])
        record_mapping_example(td_path, ref("C", "ORIGIN_C.xml", "DEST_C.xml"), ["ORIGIN_C.xml", "DEST_C.xml"])
        learned = load_mapping_knowledge(td_path)
        summary = mapping_learning_summary(learned)
        checks.append(check(
            "V32 three input.json + customer-file reference pairs build reusable file-to-input mapping knowledge",
            summary.get("example_count") == 3
            and "ORIGIN" in (summary.get("source_tokens") or [])
            and "DEST" in (summary.get("target_tokens") or []),
            summary,
        ))

    ib_ui_source = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    checks.append(check(
        "V32 Input Builder visibly explains uploaded file to input.json mappings and 3-reference learning",
        "File → input.json mapping learner" in ib_ui_source
        and "How uploaded files mapped into input.json" in ib_ui_source
        and "Reference pairs learned" in ib_ui_source,
    ))

    ui_modules = {name: importlib.util.find_spec(name) is not None for name in ("fastapi", "uvicorn")}
    ui_modules["bun"] = bool(shutil.which("bun"))
    ui_modules["streamlitRequired"] = False
    checks.append(check(
        "Phase 6 React/FastAPI UI toolchain available in current environment (advisory)",
        bool(ui_modules.get("fastapi") and ui_modules.get("uvicorn") and ui_modules.get("bun")),
        ui_modules,
    ))

    required_failures = [row for row in checks if not row["ok"] and "(advisory)" not in row["name"]]
    payload = {
        "status": "PASS" if not required_failures else "FAIL",
        "requiredChecksPassed": len(checks) - len(required_failures) - sum(1 for row in checks if "(advisory)" in row["name"]),
        "requiredChecksFailed": len(required_failures),
        "checks": checks,
    }
    print(json.dumps(payload, indent=2, default=str))
    return 0 if not required_failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
