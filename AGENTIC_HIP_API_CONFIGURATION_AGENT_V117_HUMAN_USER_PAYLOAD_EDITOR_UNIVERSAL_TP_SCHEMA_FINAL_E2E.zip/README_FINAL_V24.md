# HIP Application Studio — Final V24 Full Solution

## What this release does

V24 combines the HIP live API runner, all 18 HIP API blocks, the Scratch-style game builder, API Testing Area, Dell AIA Learn workspace, and the standalone Dell AIA Input Builder into one application.

### End-to-end new-customer flow

1. Open **Build New Configuration**.
2. Select Source and Target interface: SFTP, FTP, HTTPS, HTTPS-AS2, or an approved custom interface.
3. Upload a customer ZIP or individual XML/EDI/TXT/CSV/JSON/XBM/JAR/XLSX files. A Configuration Manual is optional.
4. The deterministic Input Builder inventories files, detects Translation/Passthrough, extracts document/map/routing signals and builds one canonical configuration.
5. Dell AIA may fill metadata gaps, but cannot invent secrets, accounts, partner names, IDs, routing constants or internal entitlements.
6. The agent asks only for unresolved/approval values.
7. The same canonical model generates `input.json`, the Configuration Manual workbook, field-source audit and all 18 API request previews.
8. The agent validates mapping, dependencies, interface prerequisites and API contracts.
9. After validation, run the full configuration LIVE, test an individual API LIVE, or arrange reusable API blocks in the Flow Game and launch LIVE.

## Mandatory deployment-group policy

For **every automation interface and interaction**, Source and Target Transport Profile orchestration use:

```text
hip-automation
```

This is enforced in the input normalizer, interface registry, guided editor, free-text change agent, configuration derivation and runtime request builder. Legacy/uploaded/user/LLM deployment-group values cannot override it.

## Human-required live business values

The agent does not fabricate business values. In particular, a real **Partner Identifier / DUNS** must be supplied when the customer artifacts do not prove it. The approved U-HAUL baseline intentionally does not ship with a fake DUNS; the UI asks for the real Dev-approved value before Partner Create can run.

For HTTPS and HTTPS-AS2, the external-partner side also requires the approved **partner SSL certificate ID/reference** when it cannot be derived. The certificate must already exist in HIP before Transport Profile creation.

## Translation vs Passthrough

- Translation: mapping artifacts (XBM/JAR or explicit mapping configuration) activate Target Document Type, Data Map and Mapping Rule steps.
- Passthrough: Data Map and Mapping Rule are marked **Not Applicable**; the runner does not send invalid Map/Rule creates.

## Live-only execution

There is no dry-run execution mode. Request preview/contract validation is non-mutating inspection only. All Run/Test/Launch controls use the live HIP request path and require valid Dell credentials/network.

## Installation

Recommended Windows first run:

```text
SETUP_AND_RUN.bat
```

Manual:

```powershell
python -m pip install -r requirements.txt
python runtime_preflight.py
python -m streamlit run hip_application_studio.py --server.port 8503
```

## Final validation

- Pytest: 66 passed
- Standard package validator: 57/57 PASS
- Adaptive package validator: 60/60 PASS
- Final required self-check: 25/25 PASS
- Standalone Input Builder smoke tests: PASS
- Live Dell HIP calls during packaging: NOT EXECUTED (credentials/network unavailable in packaging environment)

Run locally at any time:

```powershell
python final_self_check.py
python validate_package.py
python validate_adaptive_package.py
```
