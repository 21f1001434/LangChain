# API PDF Ingestion and Validation Guide

The runner can ingest the searchable PDF exported from the HIP API portal.

## What the agent does with the PDF

1. Saves the PDF locally under `knowledge/api_pdf/uploads/`.
2. Extracts searchable text page by page.
3. Detects sections for:
   - Document Type
   - MAC Map
   - Rule
   - Transport Profile validation and audits
   - TP Orchestration
   - Flow validation
   - Flow Orchestration Create
   - Flow Orchestration Deploy
   - Flow deployment history
   - Account, Partner and System
4. Uses Dell AIA `gpt-oss-120b` to convert the relevant PDF sections into
   structured API contracts.
5. Combines those contracts with the Dev-reviewed and previously successful
   request rules already built into the runner.
6. Validates each request before the API call.
7. In strict mode, blocks only the affected API step when the generated request
   conflicts with the contract.
8. Stores untruncated validation evidence in the final report.

## Searchable PDF requirement

The PDF should contain selectable/searchable text. If it is image-only, the
agent warns that the API portal should be exported again as a searchable PDF.

## UI workflow

```powershell
python -m streamlit run uhal_app.py
```

Then:

1. Open `Credentials`.
2. Save HIP API and Dell AIA credentials.
3. Verify both connections.
4. Open `API PDF Validation`.
5. Upload the API portal PDF.
6. Enable `Strict PDF validation`.
7. Click `Ingest PDFs and build API contracts`.
8. Review the detected APIs and extracted contracts.
9. Open `Missing Value Assistant`.
10. Review or apply safe non-secret suggestions.
11. Open `Review & Execute`.
12. Execute the live U-HAUL flow.

## CLI workflow

Ingest one PDF:

```powershell
python run_agent.py --ingest-pdf "C:\path\HIP_API_Portal.pdf"
```

Ingest multiple PDFs:

```powershell
python run_agent.py `
  --ingest-pdf "C:\path\Document_Types.pdf" `
  --ingest-pdf "C:\path\Flow_Orchestration.pdf"
```

List ingested documents:

```powershell
python run_agent.py --list-pdf-docs
```

Rebuild contracts after credential/model changes:

```powershell
python run_agent.py --refresh-pdf-contracts
```

Run live:

```powershell
python run_agent.py
```

## Validation priority

The final contract is merged in this order:

1. Confirmed Dev-team payload changes and successful-run rules.
2. Built-in API schema validation.
3. Contract details extracted from the uploaded PDF.
4. Dell AIA semantic comparison against the PDF.

The PDF supplements confirmed working behavior. It does not silently reverse
a Dev-team correction.

## Security

PDFs and extracted text stay local. Credentials are not included in PDF
prompts, payload evidence or reports. Authorization headers are represented
only as `<REDACTED>` or `<PRESENT>`.
