# V58 - HIP-derived workType.type

## Change
`workType.type` and `workType.description` are HIP-internal metadata and are no longer hard-coded, stored as customer/template values, requested from users, or sent in Flow Orchestration Create/Deploy requests.

The agent keeps only the stable numeric `workType.id` in the request object. HIP derives the internal work-type text. This avoids coupling the agent to internal labels that may change later.

## Validation
- Flow Create payload: `workType` contains ID only.
- Flow Deploy payload: `workType` contains ID only.
- Deterministic contract validation no longer requires `workType.type`.
- Production readiness no longer requires `workType.type`.
- Legacy config values for type/description are ignored and stripped by hydration.
- The user is never asked to supply `workType.type`.
