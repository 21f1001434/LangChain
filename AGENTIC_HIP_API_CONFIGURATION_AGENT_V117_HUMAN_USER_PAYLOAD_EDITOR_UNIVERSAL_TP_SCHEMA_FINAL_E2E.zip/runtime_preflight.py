from __future__ import annotations

import argparse
import importlib.util
import json
import shutil
import sys
from importlib import metadata
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
MIN_PYTHON = (3, 11)
MIN_STREAMLIT = (1, 50)


def _version_tuple(value: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for token in str(value).split('.'):
        digits = ''.join(ch for ch in token if ch.isdigit())
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def _package_version(distribution: str) -> str:
    try:
        return metadata.version(distribution)
    except Exception:
        return ''


def run_preflight(*, ui_only: bool = False, legacy_streamlit: bool = False, production: bool = False) -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []

    def add(name: str, ok: bool, detail: str = '', fix: str = '', required: bool = True) -> None:
        checks.append({'name': name, 'ok': bool(ok), 'detail': detail, 'fix': fix if not ok else '', 'required': required})

    add('Python >= 3.11', sys.version_info[:2] >= MIN_PYTHON,
        f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}', 'Install/use Python 3.11 or newer.')

    # Phase 6 primary runtime: HIP API Agent Studio Web UI + FastAPI/Python. Streamlit is optional archive-only.
    required_modules = [
        ('fastapi', 'fastapi'), ('uvicorn', 'uvicorn'), ('pydantic', 'pydantic'),
        ('requests', 'requests'), ('dotenv', 'python-dotenv'), ('psutil', 'psutil'),
        ('openpyxl', 'openpyxl'), ('pypdf', 'pypdf'), ('fitz', 'PyMuPDF'),
    ]
    if not ui_only:
        required_modules += [('networkx', 'networkx'), ('reportlab', 'reportlab')]

    # Strict V97 parallel LIVE execution requires the modern Microsoft AutoGen AgentChat
    # 0.7.5 stack explicitly requested for this project.  Do not accept legacy
    # pyautogen/ConversableAgent as a substitute.
    if not ui_only:
        autogen_distributions = (
            ('autogen_agentchat', 'autogen-agentchat'),
            ('autogen_core', 'autogen-core'),
            ('autogen_ext', 'autogen-ext'),
        )
        for module, distribution in autogen_distributions:
            present = importlib.util.find_spec(module) is not None
            version = _package_version(distribution) if present else ''
            exact = bool(present and version == '0.7.5')
            add(
                f'Microsoft AutoGen {distribution} == 0.7.5',
                exact,
                version or 'not installed',
                f'Install the exact strict-LIVE dependency from requirements.txt: {distribution}==0.7.5.',
            )
    optional_modules = [
        ('mcp', 'mcp', 'Local MCP-function fallback remains available when MCP_REQUIRED=false.'),
        ('neo4j', 'neo4j', 'SQLite/local structures remain available when Neo4j is not configured.'),
    ]
    for module, distribution in required_modules:
        present = importlib.util.find_spec(module) is not None
        add(f'Import {module}', present, _package_version(distribution) if present else 'not installed', f'Install {distribution} from requirements.txt.')
    for module, distribution, note in optional_modules:
        present = importlib.util.find_spec(module) is not None
        add(f'Optional import {module}', True, _package_version(distribution) if present else f'not installed; {note}', required=False)

    bun = shutil.which('bun')
    dist_index = ROOT / 'webapp' / 'frontend' / 'dist' / 'index.html'
    # Bun is needed to build/update the frontend. An already-built dist can run without Bun.
    bun_ok = bool(bun) or (production and dist_index.is_file())
    add('Bun frontend toolchain', bun_ok, bun or ('compiled frontend already present' if dist_index.is_file() else 'not found'),
        'Install Bun for Windows, reopen the terminal, then rerun SETUP_AGENTIC_HIP.bat.')

    required_files = (
        'requirements.txt', 'webapp/backend/app/main.py', 'webapp/frontend/package.json',
        'webapp/frontend/src/App.tsx', 'input.json', 'config_overrides.json',
    )
    for filename in required_files:
        exists = (ROOT / filename).is_file()
        add(f'Required file {filename}', exists, str(ROOT / filename), 'Re-extract the complete Phase 6 release ZIP into a fresh folder.')

    # V109 deterministic skill gate. Every declarative skill is structurally
    # vetted against an allowlist and its expert-source files before startup.
    try:
        from webapp.backend.app.skill_governance import vet_all_skills
        skill_vetting = vet_all_skills(ROOT)
        add('Governed AI skills vetted', skill_vetting.get('status') == 'PASS',
            f"{skill_vetting.get('count', 0)} skill manifest(s) passed description/provenance/entrypoint checks",
            'Restore the shipped skills/*.skill.json manifests and their referenced expert sources.')
    except Exception as exc:
        add('Governed AI skills vetted', False, f'{type(exc).__name__}: {exc}',
            'Fix/remove the invalid skill manifest; arbitrary or unvetted skills cannot run.')

    if production:
        add('Compiled React frontend', dist_index.is_file(), str(dist_index), 'Run SETUP_AGENTIC_HIP.bat or build with: cd webapp\\frontend && bun run build')

    if legacy_streamlit:
        streamlit_present = importlib.util.find_spec('streamlit') is not None
        sortable_present = importlib.util.find_spec('streamlit_sortables') is not None
        streamlit_version = _package_version('streamlit')
        streamlit_ok = streamlit_present and _version_tuple(streamlit_version) >= MIN_STREAMLIT
        add('Legacy Streamlit >= 1.50', streamlit_ok, streamlit_version or 'not installed', 'Install: python -m pip install -r requirements_legacy_streamlit.txt')
        add('Legacy streamlit-sortables', sortable_present, _package_version('streamlit-sortables') if sortable_present else 'not installed', 'Install: python -m pip install -r requirements_legacy_streamlit.txt')
        add('Legacy UI source', (ROOT / 'hip_application_studio.py').is_file(), str(ROOT / 'hip_application_studio.py'), 'Legacy source is missing from this release.')
    else:
        add('Streamlit not required', True, 'Phase 6 primary UI is HIP API Agent Studio Web UI; legacy Streamlit dependencies are optional.', required=False)

    failed = [row for row in checks if not row['ok'] and row.get('required', True)]
    return {
        'status': 'PASS' if not failed else 'FAIL', 'phase': 6, 'primaryUi': 'HIP API Agent Studio Web UI',
        'streamlitRequired': False, 'root': str(ROOT), 'checksPassed': len(checks)-len(failed),
        'checksFailed': len(failed), 'checks': checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='Agentic HIP Phase 6 React/FastAPI runtime preflight.')
    parser.add_argument('--ui-only', action='store_true', help='Check the core React/FastAPI launch dependencies.')
    parser.add_argument('--production', action='store_true', help='Also require a compiled React dist/index.html.')
    parser.add_argument('--legacy-streamlit', action='store_true', help='Additionally check optional archived Streamlit UI dependencies.')
    parser.add_argument('--json', action='store_true', help='Print machine-readable JSON.')
    args = parser.parse_args()
    result = run_preflight(ui_only=args.ui_only, legacy_streamlit=args.legacy_streamlit, production=args.production)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print('\n=== AGENTIC HIP PHASE 6 RUNTIME PREFLIGHT ===')
        for row in result['checks']:
            mark = 'PASS' if row['ok'] else ('INFO' if not row.get('required', True) else 'FAIL')
            print(f"[{mark}] {row['name']}: {row['detail']}")
            if not row['ok'] and row.get('fix'):
                print(f"       Fix: {row['fix']}")
        print(f"\nResult: {result['status']} ({result['checksPassed']} passed / {result['checksFailed']} failed)")
    return 0 if result['status'] == 'PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())
