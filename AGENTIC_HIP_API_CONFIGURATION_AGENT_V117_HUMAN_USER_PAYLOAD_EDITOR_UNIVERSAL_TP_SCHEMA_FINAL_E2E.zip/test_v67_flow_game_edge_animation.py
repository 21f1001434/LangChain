from pathlib import Path

ROOT = Path(__file__).resolve().parent
FLOW = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
CSS = (ROOT / 'webapp/frontend/src/styles.css').read_text(encoding='utf-8')

def test_template_and_manual_edges_are_directionally_animated():
    assert "animated:true" in FLOW
    assert "MarkerType.ArrowClosed" in FLOW
    assert "hip-flow-edge hip-flow-edge-idle" in FLOW

def test_edge_animation_tracks_execution_state():
    assert "hip-flow-edge-${state}" in FLOW
    assert "activeEdge" in FLOW
    assert "completed" in FLOW
    assert "blocked?'blocked':activeEdge?'active':completed?'complete':'idle'" in FLOW

def test_visible_motion_and_reduced_motion_fallback_exist():
    assert "@keyframes hip-flow-edge-travel" in CSS
    assert ".hip-flow-edge-active" in CSS
    assert "animation-duration: .58s" in CSS
    assert "prefers-reduced-motion: reduce" in CSS
