from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import streamlit as st
from dotenv import dotenv_values, load_dotenv, set_key

from api_pdf_ingestion import PdfApiKnowledgeBase
from uhal_mapper import UhalInputMapper

ROOT = Path(__file__).resolve().parent
INPUT_PATH = ROOT / "input.json"
CONFIG_PATH = ROOT / "config_overrides.json"
ENV_PATH = ROOT / ".env"
GITIGNORE_PATH = ROOT / ".gitignore"
REPORTS = ROOT / "reports"
PDF_INBOX = ROOT / "knowledge" / "api_pdf" / "inbox"
PDF_INBOX.mkdir(parents=True, exist_ok=True)
PDF_KB = PdfApiKnowledgeBase(ROOT)

load_dotenv(ENV_PATH, override=True)


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Dict[str, Any]) -> None:
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def read_env() -> Dict[str, str]:
    if not ENV_PATH.exists():
        return {}
    return {
        str(k): str(v or "")
        for k, v in dotenv_values(ENV_PATH).items()
    }


def save_env(updates: Dict[str, Any]) -> None:
    ENV_PATH.touch(exist_ok=True)
    for key, value in updates.items():
        if value is None:
            continue
        set_key(
            str(ENV_PATH),
            key,
            str(value),
            quote_mode="always",
        )
    load_dotenv(ENV_PATH, override=True)


def ensure_gitignore() -> None:
    required = [
        ".env",
        "Test.py",
        "__pycache__/",
        "*.pyc",
        "reports/",
        "payloads/",
        "knowledge/api_pdf/uploads/",
        "knowledge/api_pdf/inbox/",
    ]
    existing = (
        GITIGNORE_PATH.read_text(encoding="utf-8").splitlines()
        if GITIGNORE_PATH.exists()
        else []
    )
    merged = list(existing)
    for item in required:
        if item not in merged:
            merged.append(item)
    GITIGNORE_PATH.write_text(
        "\n".join(merged).strip() + "\n",
        encoding="utf-8",
    )


def latest_report() -> Path | None:
    reports = sorted(
        REPORTS.glob("UHAL_final_end_to_end_report_*.html")
    )
    return reports[-1] if reports else None


def configured(env: Dict[str, str], key: str) -> bool:
    value = env.get(key) or os.getenv(key) or ""
    return bool(value and not value.startswith("REPLACE_"))


def secret_status(env: Dict[str, str], key: str) -> str:
    return "Configured" if configured(env, key) else "Missing"


def parse_json_editor(
    label: str,
    raw: str,
    fallback: Any,
) -> Tuple[Any, str | None]:
    try:
        return json.loads(raw), None
    except Exception as exc:
        return fallback, f"{label}: {exc}"


def validate_files(input_data: Dict[str, Any]) -> List[str]:
    required = [
        ROOT / "input_files" / "Transform_DELLCoXMLASNXX08C.jar",
        ROOT / "input_files" / "DELLCoXMLASNXX08C.xbm",
        ROOT / "input_files" / "source_DellAutoASN.xml",
        ROOT / "input_files" / "output_u-haul_ASN.xml",
    ]
    issues = [
        f"Missing required input file: {p.name}"
        for p in required
        if not p.exists()
    ]
    if not input_data.get("profile_name"):
        issues.append("Business Flow Name is missing.")
    return issues


def validate_credentials(env: Dict[str, str]) -> List[str]:
    required = [
        "HIP_TOKEN_URL",
        "HIP_CLIENT_ID",
        "HIP_CLIENT_SECRET",
        "DELL_AIA_BASE_URL",
        "DELL_AIA_MODEL",
        "DELL_AIA_CLIENT_ID",
        "DELL_AIA_CLIENT_SECRET",
    ]
    return [
        f"Missing credential/configuration: {key}"
        for key in required
        if not configured(env, key)
    ]


def validate_pdf_documentation(env: Dict[str, str]) -> List[str]:
    require_pdf = (
        env.get("PDF_REQUIRE_DOCUMENTATION", "false")
        .lower()
        in {"true", "1", "yes", "y"}
    )
    if require_pdf and not PDF_KB.has_documents():
        return [
            "API PDF documentation is required but no PDF has been ingested."
        ]
    return []


def pdf_contract_summary() -> Dict[str, Any]:
    contract_path = (
        ROOT
        / "knowledge"
        / "api_pdf"
        / "contracts"
        / "pdf_contracts_latest.json"
    )
    if not contract_path.exists():
        return {}
    try:
        return load_json(contract_path)
    except Exception:
        return {}


def deterministic_missing_suggestions(
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    env: Dict[str, str],
) -> List[Dict[str, Any]]:
    objects = input_data.get("objects") or {}
    src = objects.get("source_document_type") or {}
    tgt = objects.get("target_document_type") or {}

    suggestions: List[Dict[str, Any]] = []

    def add(
        field: str,
        current: Any,
        suggestion: Any,
        reason: str,
        secret: bool = False,
    ) -> None:
        if current not in (None, "", [], {}):
            return
        suggestions.append({
            "field": field,
            "suggestedValue": suggestion,
            "reason": reason,
            "secret": secret,
        })

    add(
        "HIP_TOKEN_URL",
        env.get("HIP_TOKEN_URL"),
        "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token",
        "New HIP API token endpoint supplied by the Dev team.",
    )
    add(
        "HIP_CLIENT_ID",
        env.get("HIP_CLIENT_ID"),
        "REQUEST_FROM_API_OWNER",
        "Client IDs must be supplied by the API subscription owner.",
        True,
    )
    add(
        "HIP_CLIENT_SECRET",
        env.get("HIP_CLIENT_SECRET"),
        "REQUEST_ROTATED_SECRET_FROM_API_OWNER",
        "Secrets must not be inferred or copied into reports.",
        True,
    )
    add(
        "DELL_AIA_BASE_URL",
        env.get("DELL_AIA_BASE_URL"),
        "https://aia.gateway.dell.com/genai/dev/v1",
        "Dell AIA development gateway.",
    )
    add(
        "DELL_AIA_MODEL",
        env.get("DELL_AIA_MODEL"),
        "gpt-oss-120b",
        "Confirmed Dell AIA text model.",
    )
    add(
        "DELL_AIA_CLIENT_ID",
        env.get("DELL_AIA_CLIENT_ID"),
        "REQUEST_FROM_DELL_AIA_OWNER",
        "Dell AIA service-account client ID.",
        True,
    )
    add(
        "DELL_AIA_CLIENT_SECRET",
        env.get("DELL_AIA_CLIENT_SECRET"),
        "REQUEST_ROTATED_SECRET_FROM_DELL_AIA_OWNER",
        "Dell AIA service-account secret.",
        True,
    )
    add(
        "source_document_type.api_transaction_type",
        src.get("api_transaction_type"),
        "INBOUND",
        "Source Document Type has IB semantics.",
    )
    add(
        "target_document_type.api_transaction_type",
        tgt.get("api_transaction_type"),
        "OUTBOUND",
        "Target Document Type has OB semantics.",
    )
    add(
        "source_document_type.api_document_identifier",
        src.get("api_document_identifier"),
        {
            "operator": "ALL",
            "attributeList": [{
                "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
                "value": "DellAutoASN",
            }],
        },
        "Dev POST payload shape with U-HAUL source root.",
    )
    add(
        "target_document_type.api_document_identifier",
        tgt.get("api_document_identifier"),
        {
            "operator": "ALL",
            "attributeList": [{
                "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
                "value": "SHIPMENT_NOTICE",
            }],
        },
        "Dev POST payload shape with U-HAUL target root.",
    )
    add(
        "source_haft_account",
        config.get("source_haft_account"),
        "haftatap10251594",
        "Dev-provided Source HAFT account.",
    )
    add(
        "target_haft_account",
        config.get("target_haft_account"),
        "haftatap10251593",
        "Dev-provided Target HAFT account.",
    )
    add(
        "source_deployment_group_name",
        config.get("source_deployment_group_name"),
        "hip-automation",
        "Final deployment group for both Source and Target.",
    )
    return suggestions


def apply_safe_suggestions(
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    env: Dict[str, str],
) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, str]]:
    updated_input = json.loads(json.dumps(input_data))
    updated_config = json.loads(json.dumps(config))
    updated_env: Dict[str, str] = {}

    objects = updated_input.setdefault("objects", {})
    src = objects.setdefault("source_document_type", {})
    tgt = objects.setdefault("target_document_type", {})

    src.setdefault("api_transaction_type", "INBOUND")
    tgt.setdefault("api_transaction_type", "OUTBOUND")
    src.setdefault("api_document_identifier", {
        "operator": "ALL",
        "attributeList": [{
            "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
            "value": "DellAutoASN",
        }],
    })
    tgt.setdefault("api_document_identifier", {
        "operator": "ALL",
        "attributeList": [{
            "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
            "value": "SHIPMENT_NOTICE",
        }],
    })

    updated_config.setdefault(
        "source_haft_account",
        "haftatap10251594",
    )
    updated_config.setdefault(
        "target_haft_account",
        "haftatap10251593",
    )
    updated_config.setdefault(
        "source_deployment_group_name",
        "hip-automation",
    )
    updated_config.setdefault(
        "target_deployment_group_name",
        "hip-automation",
    )

    defaults = {
        "HIP_TOKEN_URL":
            "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token",
        "DELL_AIA_BASE_URL":
            "https://aia.gateway.dell.com/genai/dev/v1",
        "DELL_AIA_MODEL": "gpt-oss-120b",
        "DELL_AIA_TEMPERATURE": "0.2",
        "USE_DELL_SSO": "true",
        "DELL_AUTH_MODE": "auto",
    }
    for key, value in defaults.items():
        if not env.get(key):
            updated_env[key] = value

    return updated_input, updated_config, updated_env


st.set_page_config(
    page_title="U-HAUL HIP Live Runner",
    page_icon="🔗",
    layout="wide",
)

st.markdown(
    """
<style>
.stApp {background:linear-gradient(180deg,#f4f8fc,#edf3f9)}
.block-container{max-width:1550px;padding-top:1.2rem}
.hero{background:radial-gradient(circle at 90% 10%,rgba(34,189,193,.58),transparent 28%),linear-gradient(135deg,#051a34,#084f89 64%,#087f8f);color:white;padding:29px 33px;border-radius:22px;box-shadow:0 17px 44px rgba(9,48,84,.18);margin-bottom:20px}
.hero h1{margin:0;font-size:2rem}.hero p{color:#dceeff;margin:.45rem 0 0}

.safe{background:#ecfdf3;border-left:6px solid #148447;padding:14px;border-radius:12px;margin:12px 0}
</style>
<div class="hero">
<h1>U-HAUL HIP Live End-to-End Runner</h1>
<p>Credentials → missing-value assistance → master data → MAC Map → Rule → TP Orchestration → Flow Create → Flow Deploy → audits.</p>
</div>
""",
    unsafe_allow_html=True,
)

input_data = load_json(INPUT_PATH)
config = load_json(CONFIG_PATH)
env_values = read_env()
objects = input_data["objects"]

with st.sidebar:
    st.header("Runtime Status")
    st.success("Live API execution: ON")
    st.success("Dell AIA judge: REQUIRED")
    if env_values.get("MCP_ENABLED", "true").lower() in {"true", "1", "yes", "y"}:
        st.success("MCP tools: ENABLED")
    else:
        st.warning("MCP tools: DISABLED")
    st.write("**HIP API credentials**")
    st.write("Client ID:", secret_status(env_values, "HIP_CLIENT_ID"))
    st.write("Client Secret:", secret_status(env_values, "HIP_CLIENT_SECRET"))
    st.write("**Dell AIA credentials**")
    st.write("Client ID:", secret_status(env_values, "DELL_AIA_CLIENT_ID"))
    st.write(
        "Client Secret:",
        secret_status(env_values, "DELL_AIA_CLIENT_SECRET"),
    )
    st.caption(
        "Credentials are saved only to the local .env file and are excluded "
        "from reports and source packages."
    )

tabs = st.tabs([
    "Credentials",
    "Business Flow",
    "Document Types",
    "Map & Rule",
    "Transport Profiles",
    "Flow & Workflow",
    "API PDF Validation",
    "MCP Tools",
    "Missing Value Assistant",
    "U-HAUL Mapping",
    "Review & Execute",
])

with tabs[0]:
    st.header("Credential Update")
    st.caption("Credentials are stored only in the local .env and excluded from reports.")

    st.subheader("HIP API credentials supplied by Som")
    hip_config_service_base = st.text_input(
        "HIP Config Service base URL",
        value=env_values.get(
            "HIP_CONFIG_SERVICE_BASE_URL",
            "https://apigtwtst.us.dell.com/hip-config-service",
        ),
        help=(
            "Used for Document Type, MAC Map, Rule, TP validation/audit/"
            "orchestration, Flow validation/orchestration and Flow history. "
            "Account/Partner and System remain on separate services."
        ),
    )
    st.caption(
        "Active consolidated base: "
        "https://apigtwtst.us.dell.com/hip-config-service"
    )
    c1, c2 = st.columns(2)
    hip_token_url = c1.text_input(
        "HIP token URL",
        value=env_values.get(
            "HIP_TOKEN_URL",
            "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token",
        ),
    )
    hip_scope = c2.text_input(
        "HIP scope — optional",
        value=env_values.get("HIP_SCOPE", ""),
    )
    c3, c4 = st.columns(2)
    hip_client_id = c3.text_input(
        "HIP client ID",
        value=env_values.get("HIP_CLIENT_ID", ""),
    )
    hip_client_secret = c4.text_input(
        "HIP client secret",
        type="password",
        placeholder=(
            "Configured — leave blank to keep"
            if configured(env_values, "HIP_CLIENT_SECRET")
            else "Paste rotated secret"
        ),
    )

    st.info(
        "The HIP client ID and secret are automatically reused for MAC Map "
        "and every HIP Config Service endpoint."
    )

    st.divider()
    st.subheader("Dell AIA model credentials")
    c9, c10 = st.columns(2)
    aia_base_url = c9.text_input(
        "Dell AIA Base URL",
        value=env_values.get(
            "DELL_AIA_BASE_URL",
            "https://aia.gateway.dell.com/genai/dev/v1",
        ),
    )
    aia_model = c10.text_input(
        "Dell AIA model",
        value=env_values.get(
            "DELL_AIA_MODEL",
            "gpt-oss-120b",
        ),
    )
    c11, c12 = st.columns(2)
    aia_client_id = c11.text_input(
        "Dell AIA client ID",
        value=env_values.get("DELL_AIA_CLIENT_ID", ""),
    )
    aia_client_secret = c12.text_input(
        "Dell AIA client secret",
        type="password",
        placeholder=(
            "Configured — leave blank to keep"
            if configured(env_values, "DELL_AIA_CLIENT_SECRET")
            else "Paste rotated secret"
        ),
    )
    c13, c14, c15 = st.columns(3)
    aia_auth_mode = c13.selectbox(
        "Dell AIA auth mode",
        ["auto", "client_credentials", "sso"],
        index=(
            ["auto", "client_credentials", "sso"].index(
                env_values.get("DELL_AUTH_MODE", "auto")
            )
            if env_values.get("DELL_AUTH_MODE", "auto")
            in ["auto", "client_credentials", "sso"]
            else 0
        ),
    )
    use_dell_sso = c14.checkbox(
        "Allow Dell SSO fallback",
        value=env_values.get(
            "USE_DELL_SSO",
            "true",
        ).lower() in {"true", "1", "yes"},
    )
    aia_temperature = c15.number_input(
        "Temperature",
        min_value=0.0,
        max_value=2.0,
        value=float(env_values.get("DELL_AIA_TEMPERATURE", "0.2")),
        step=0.1,
    )

    if st.button(
        "Save credentials to local .env",
        type="primary",
        use_container_width=True,
    ):
        current = read_env()
        updates: Dict[str, Any] = {
            "HIP_CONFIG_SERVICE_BASE_URL": hip_config_service_base.rstrip("/"),
            "HIP_TOKEN_URL": hip_token_url,
            "HIP_CLIENT_ID": hip_client_id,
            "HIP_SCOPE": hip_scope,
            "DELL_AIA_BASE_URL": aia_base_url,
            "DELL_AIA_MODEL": aia_model,
            "DELL_AIA_CLIENT_ID": aia_client_id,
            "DELL_AUTH_MODE": aia_auth_mode,
            "USE_DELL_SSO": str(use_dell_sso).lower(),
            "DELL_AIA_TEMPERATURE": str(aia_temperature),
            "HIP_REQUESTED_BY": config.get(
                "requestedBy",
                "adheesh.srivastava@dellteam.com",
            ),
            "HIP_USER_ID": str(
                (config.get("user") or {}).get("userId", 16679)
            ),
            "HIP_ENVIRONMENT": config.get("hipEnvironment", "DEV"),
        }

        if hip_client_secret:
            updates["HIP_CLIENT_SECRET"] = hip_client_secret
        elif current.get("HIP_CLIENT_SECRET"):
            updates["HIP_CLIENT_SECRET"] = current["HIP_CLIENT_SECRET"]


        if aia_client_secret:
            updates["DELL_AIA_CLIENT_SECRET"] = aia_client_secret
        elif current.get("DELL_AIA_CLIENT_SECRET"):
            updates["DELL_AIA_CLIENT_SECRET"] = current[
                "DELL_AIA_CLIENT_SECRET"
            ]

        save_env(updates)
        ensure_gitignore()
        st.success(
            "Credentials saved locally. They are not written to reports."
        )

    if st.button(
        "Check HIP API and Dell AIA connections",
        use_container_width=True,
    ):
        proc = subprocess.run(
            [
                sys.executable,
                str(ROOT / "run_agent.py"),
                "--check-connections",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
        )
        if proc.returncode == 0:
            st.success("HIP API OAuth and Dell AIA model verified.")
            st.code(proc.stdout)
        else:
            st.error("Connection check failed.")
            st.code(proc.stdout + "\n" + proc.stderr)

with tabs[1]:
    c1, c2, c3 = st.columns(3)
    profile_name = c1.text_input(
        "Business Flow Name",
        input_data.get("profile_name", ""),
    )
    customer = c2.text_input(
        "Customer",
        input_data.get("customer", "U-HAUL"),
    )
    direction = c3.selectbox(
        "Direction",
        ["Outbound", "Inbound"],
        index=(
            0 if input_data.get("direction") == "Outbound" else 1
        ),
    )
    c4, c5, c6 = st.columns(3)
    source_system = c4.text_input(
        "Source System / Application",
        config.get("source_system_name", "AIC - DCE"),
    )
    target_partner = c5.text_input(
        "External Partner / Application",
        config.get("target_system_name", ""),
        help="Use the Dev-approved external partner/application name. The app will not invent one for live execution.",
    )
    deployment_group = c6.text_input(
        "Deployment Group — fixed by Dev team",
        "hip-automation",
        disabled=True,
    )
    partner_identifier_value = st.text_input(
        "Partner Identifier / DUNS value",
        value=str(input_data.get("partner_identifier_value") or config.get("partner_identifier_value") or ""),
        help="Required by the live Partner Create API. Enter the Dev-approved value; it is never fabricated by the agent.",
    )

with tabs[2]:
    src = objects["source_document_type"]
    tgt = objects["target_document_type"]
    c1, c2 = st.columns(2)

    with c1:
        st.subheader("Source Document Type")
        src_name = st.text_input("Source name", src.get("name", ""))
        src_version = st.text_input(
            "Source API version",
            str(src.get("version", "1")),
        )
        src_transaction_type = st.selectbox(
            "Source transactionType",
            ["INBOUND", "OUTBOUND"],
            index=(
                0
                if src.get("api_transaction_type", "INBOUND")
                == "INBOUND"
                else 1
            ),
        )
        src_validation = st.text_input(
            "Source validationType",
            src.get("validation_type", "Structure"),
        )
        src_identifier_raw = st.text_area(
            "Source documentIdentifier JSON",
            value=json.dumps(
                src.get("api_document_identifier")
                or src.get("document_identifier")
                or {},
                indent=2,
            ),
            height=250,
        )
        src_attrs_raw = st.text_area(
            "Source attributes JSON",
            value=json.dumps(
                src.get("attributes_to_configure") or [],
                indent=2,
            ),
            height=360,
        )

    with c2:
        st.subheader("Target Document Type")
        tgt_name = st.text_input("Target name", tgt.get("name", ""))
        tgt_version = st.text_input(
            "Target API version",
            str(tgt.get("version", "1")),
        )
        tgt_transaction_type = st.selectbox(
            "Target transactionType",
            ["INBOUND", "OUTBOUND"],
            index=(
                1
                if tgt.get("api_transaction_type", "OUTBOUND")
                == "OUTBOUND"
                else 0
            ),
        )
        tgt_validation = st.text_input(
            "Target validationType",
            tgt.get("validation_type", "Structure"),
        )
        tgt_identifier_raw = st.text_area(
            "Target documentIdentifier JSON",
            value=json.dumps(
                tgt.get("api_document_identifier")
                or tgt.get("document_identifier")
                or {},
                indent=2,
            ),
            height=250,
        )
        tgt_attrs_raw = st.text_area(
            "Target attributes JSON",
            value=json.dumps(
                tgt.get("attributes_to_configure") or [],
                indent=2,
            ),
            height=360,
        )

    st.info(
        "Dev payload match: statusDisabled is included; filemask and "
        "ediDelimiters are omitted; version is sent as a string; "
        "documentIdentifier uses operator + attributeList; "
        "lastModifiedBy is sent as an empty string."
    )

with tabs[3]:
    data_map = objects["data_map"]
    rule = objects["rule"]
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("MAC Map")
        map_name = st.text_input(
            "Map name",
            data_map.get("map_name", ""),
        )
        map_identifier = st.text_input(
            "Map identifier",
            data_map.get("map_identifier", ""),
        )
        map_version = st.text_input(
            "Map version",
            str(data_map.get("map_identifier_version", "1")),
        )
        st.caption(
            "MAC Map uses the same Som API credential when selected "
            "on the Credentials tab."
        )
    with c2:
        st.subheader("Mapping Rule")
        rule_name = st.text_input(
            "Rule name",
            rule.get("name", ""),
        )
        rule_version = st.text_input(
            "Rule version",
            str(rule.get("version", "1")),
        )
        st.dataframe(
            (rule.get("conditions") or {}).get("rows", []),
            use_container_width=True,
        )
        st.json(rule.get("actions", {}))

with tabs[4]:
    source_tp = objects["source_transport_profile"]
    target_tp = objects["target_transport_profile"]
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Source TP")
        source_tp_create_name = st.text_input(
            "Source TP orchestration name",
            source_tp.get("profile_name", ""),
        )
        source_tp_flow_name = st.text_input(
            "Source TP referenced by Flow",
            config.get("source_transport_profile_name", ""),
        )
        source_account = st.text_input(
            "Source HAFT account",
            config.get(
                "source_haft_account",
                "haftatap10251594",
            ),
        )
        source_folder = st.text_input(
            "Source subscription folder",
            source_tp.get("subscription_folder", ""),
        )
    with c2:
        st.subheader("Target TP")
        target_tp_create_name = st.text_input(
            "Target TP orchestration name",
            target_tp.get("profile_name", ""),
        )
        target_tp_flow_name = st.text_input(
            "Target TP referenced by Flow",
            config.get("target_transport_profile_name", ""),
        )
        target_account = st.text_input(
            "Target HAFT account",
            config.get(
                "target_haft_account",
                "haftatap10251593",
            ),
        )
        target_folder = st.text_input(
            "Target subscription folder",
            target_tp.get("subscription_folder", ""),
        )

with tabs[5]:
    c1, c2, c3 = st.columns(3)
    user_id = c1.number_input(
        "Workflow userId",
        min_value=0,
        value=int(
            (config.get("user") or {}).get("userId")
            or 16679
        ),
    )
    requester = c2.text_input(
        "Requester / emailId",
        config.get(
            "requestedBy",
            "adheesh.srivastava@dellteam.com",
        ),
    )
    environment = c3.text_input(
        "HIP environment",
        config.get("hipEnvironment", "DEV"),
    )

with tabs[6]:
    st.header("API PDF Validation")
    st.write(
        "Upload the searchable PDF exported from the API portal. "
        "The agent extracts its text, identifies API sections, builds "
        "structured contracts with Dell AIA, and validates each request "
        "before it is sent."
    )

    uploaded_pdfs = st.file_uploader(
        "API documentation PDF",
        type=["pdf"],
        accept_multiple_files=True,
        help=(
            "Use a searchable/text PDF. Image-only scans may not provide "
            "enough text for strict contract validation."
        ),
    )

    c1, c2, c3 = st.columns(3)
    strict_pdf = c1.checkbox(
        "Strict PDF validation",
        value=env_values.get(
            "PDF_CONTRACT_VALIDATION_MODE",
            "auto",
        ).lower() == "strict",
        help=(
            "When enabled, a Dell AIA/PDF mismatch blocks the affected "
            "API call before it is sent."
        ),
    )
    require_pdf = c2.checkbox(
        "Require PDF before live run",
        value=env_values.get(
            "PDF_REQUIRE_DOCUMENTATION",
            "false",
        ).lower() in {"true", "1", "yes", "y"},
    )
    aia_each_request = c3.checkbox(
        "Dell AIA validates every request",
        value=env_values.get(
            "PDF_AIA_VALIDATE_EACH_REQUEST",
            "true",
        ).lower() in {"true", "1", "yes", "y"},
    )

    if st.button(
        "Save PDF validation settings",
        use_container_width=True,
    ):
        save_env({
            "PDF_CONTRACT_VALIDATION_MODE": (
                "strict" if strict_pdf else "auto"
            ),
            "PDF_REQUIRE_DOCUMENTATION": str(require_pdf).lower(),
            "PDF_AIA_VALIDATE_EACH_REQUEST": str(
                aia_each_request
            ).lower(),
        })
        st.success("PDF validation settings saved.")

    if st.button(
        "Ingest PDFs and build API contracts",
        type="primary",
        disabled=not bool(uploaded_pdfs),
        use_container_width=True,
    ):
        paths: List[Path] = []
        for uploaded in uploaded_pdfs or []:
            safe_name = Path(uploaded.name).name
            target = PDF_INBOX / safe_name
            target.write_bytes(uploaded.getvalue())
            paths.append(target)

        cmd = [sys.executable, str(ROOT / "run_agent.py")]
        for path in paths:
            cmd.extend(["--ingest-pdf", str(path)])

        with st.status(
            "Extracting PDF text and building contracts with Dell AIA...",
            expanded=True,
        ) as status:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                text=True,
                capture_output=True,
            )
            st.code(proc.stdout or "(no stdout)")
            if proc.stderr:
                st.code(proc.stderr)
            if proc.returncode == 0:
                status.update(
                    label="PDF contracts created",
                    state="complete",
                )
            else:
                status.update(
                    label="PDF ingestion failed",
                    state="error",
                )

    documents = PDF_KB.list_documents()
    if documents:
        st.subheader("Ingested PDF documents")
        document_rows = [
            {
                "filename": item.get("filename"),
                "pages": item.get("pages"),
                "characters": item.get("characters"),
                "extractionMethod": item.get("extractionMethod"),
                "detectedApis": ", ".join(
                    item.get("detectedApis") or []
                ),
                "warnings": " | ".join(
                    item.get("warnings") or []
                ),
            }
            for item in documents
        ]
        st.dataframe(document_rows, use_container_width=True)

        contracts = pdf_contract_summary()
        contract_map = contracts.get("contracts") or {}
        st.metric("Structured API contracts", len(contract_map))
        with st.expander("Extracted PDF contracts"):
            st.json(contracts)
    else:
        st.info(
            "No API PDF has been ingested. Verified built-in contracts "
            "and Dev-reviewed payload rules remain active."
        )

    if st.button(
        "Rebuild contracts from ingested PDFs",
        disabled=not PDF_KB.has_documents(),
        use_container_width=True,
    ):
        proc = subprocess.run(
            [
                sys.executable,
                str(ROOT / "run_agent.py"),
                "--refresh-pdf-contracts",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
        )
        if proc.returncode == 0:
            st.success("PDF contracts rebuilt.")
            st.code(proc.stdout)
        else:
            st.error("PDF contract rebuild failed.")
            st.code(proc.stdout + "\n" + proc.stderr)


with tabs[7]:
    st.header("MCP Tools")
    st.write(
        "The agent uses MCP tools for U-HAUL input mapping, request-contract "
        "validation and response-ID resolution before dependent API calls."
    )

    mcp_enabled = st.checkbox(
        "Enable MCP tool layer",
        value=env_values.get("MCP_ENABLED", "true").lower()
        in {"true", "1", "yes", "y"},
    )
    mcp_required = st.checkbox(
        "Require the official MCP SDK",
        value=env_values.get("MCP_REQUIRED", "false").lower()
        in {"true", "1", "yes", "y"},
        help=(
            "When enabled, execution stops if the MCP SDK or tool call is "
            "unavailable. Leave disabled to permit the exact local tool "
            "fallback in restricted Dell environments."
        ),
    )
    mcp_validate_each = st.checkbox(
        "Validate every API request through MCP",
        value=env_values.get(
            "MCP_VALIDATE_EACH_REQUEST", "true"
        ).lower() in {"true", "1", "yes", "y"},
    )

    if st.button("Save MCP settings", use_container_width=True):
        save_env({
            "MCP_ENABLED": str(mcp_enabled).lower(),
            "MCP_REQUIRED": str(mcp_required).lower(),
            "MCP_VALIDATE_EACH_REQUEST": str(
                mcp_validate_each
            ).lower(),
        })
        st.success("MCP settings saved to the local .env.")

    if st.button(
        "Test MCP tools and U-HAUL mapping",
        type="primary",
        use_container_width=True,
    ):
        proc = subprocess.run(
            [
                sys.executable,
                str(ROOT / "run_agent.py"),
                "--mcp-status",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
        )
        if proc.returncode == 0:
            st.success("MCP tool validation completed.")
            try:
                st.json(json.loads(proc.stdout))
            except Exception:
                st.code(proc.stdout)
        else:
            st.error("MCP tool validation failed.")
            st.code(proc.stdout + "\n" + proc.stderr)

    st.subheader("Exposed MCP tools")
    st.code(
        """validate_uhal_input
get_mapping_for_step
validate_api_request
resolve_response_ids
suggest_missing_values"""
    )
    st.caption(
        "The server can also be exposed to an external MCP host with "
        "python uhal_mcp_server.py."
    )


with tabs[8]:
    st.header("Missing Value Assistant")
    deterministic = deterministic_missing_suggestions(
        input_data,
        config,
        env_values,
    )
    if deterministic:
        st.dataframe(deterministic, use_container_width=True)
    else:
        st.success("No deterministic missing values were detected.")

    if st.button(
        "Apply safe non-secret defaults",
        use_container_width=True,
    ):
        new_input, new_config, new_env = apply_safe_suggestions(
            input_data,
            config,
            env_values,
        )
        save_json(INPUT_PATH, new_input)
        save_json(CONFIG_PATH, new_config)
        if new_env:
            save_env(new_env)
        st.success("Safe defaults applied. Secret fields were not changed.")
        st.rerun()

    if st.button(
        "Ask Dell AIA to suggest missing values",
        type="primary",
        use_container_width=True,
    ):
        proc = subprocess.run(
            [
                sys.executable,
                str(ROOT / "run_agent.py"),
                "--suggest-missing",
            ],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
        )
        if proc.returncode != 0:
            st.error("Dell AIA suggestion request failed.")
            st.code(proc.stdout + "\n" + proc.stderr)
        else:
            suggestion_path = (
                REPORTS / "missing_value_suggestions_latest.json"
            )
            if suggestion_path.exists():
                st.success("Dell AIA suggestions received.")
                st.json(load_json(suggestion_path))
            else:
                st.warning(
                    "Suggestion command completed but no result file was found."
                )
                st.code(proc.stdout)

with tabs[9]:
    st.header("U-HAUL Input → API Payload Mapping")
    mapper = UhalInputMapper(input_data, config, ROOT)
    manifest = mapper.execution_manifest()
    issues = manifest.get("validationIssues") or []
    if any(item.get("severity") == "ERROR" for item in issues):
        st.error("The U-HAUL input contains mapping errors.")
        st.dataframe(issues, use_container_width=True)
    else:
        st.success("U-HAUL input is complete for the verified API contracts.")

    st.subheader("Normalized business context")
    st.json(manifest.get("businessContext") or {})

    rows = []
    for api_key, fields in (manifest.get("lineage") or {}).items():
        for item in fields:
            rows.append({
                "API": api_key,
                "Payload Field": item.get("payloadField"),
                "Input / Runtime Source": item.get("inputPath"),
                "Mapped Value": json.dumps(item.get("value"), default=str)
                if isinstance(item.get("value"), (dict, list))
                else item.get("value"),
            })
    st.subheader("Field lineage")
    st.dataframe(rows, use_container_width=True)

    st.subheader("Dependency manifest")
    st.dataframe(manifest.get("sequence") or [], use_container_width=True)
    st.download_button(
        "Download mapping manifest",
        json.dumps(manifest, indent=2, default=str).encode("utf-8"),
        file_name="uhal_input_to_api_mapping_manifest.json",
        mime="application/json",
        use_container_width=True,
    )


with tabs[10]:
    updated_input = json.loads(json.dumps(input_data))
    updated_config = json.loads(json.dumps(config))

    src_identifier, src_identifier_error = parse_json_editor(
        "Source documentIdentifier",
        src_identifier_raw,
        src.get("api_document_identifier") or {},
    )
    tgt_identifier, tgt_identifier_error = parse_json_editor(
        "Target documentIdentifier",
        tgt_identifier_raw,
        tgt.get("api_document_identifier") or {},
    )
    src_attrs, src_attrs_error = parse_json_editor(
        "Source attributes",
        src_attrs_raw,
        src.get("attributes_to_configure") or [],
    )
    tgt_attrs, tgt_attrs_error = parse_json_editor(
        "Target attributes",
        tgt_attrs_raw,
        tgt.get("attributes_to_configure") or [],
    )

    updated_input["profile_name"] = profile_name
    updated_input["customer"] = customer
    updated_input["direction"] = direction
    updated_input["partner_identifier_value"] = partner_identifier_value.strip()
    updated_input["objects"]["source_document_type"].update({
        "name": src_name,
        "version": src_version,
        "validation_type": src_validation,
        "api_transaction_type": src_transaction_type,
        "api_document_identifier": src_identifier,
        "attributes_to_configure": src_attrs,
        "last_modified_by": "",
    })
    updated_input["objects"]["target_document_type"].update({
        "name": tgt_name,
        "version": tgt_version,
        "validation_type": tgt_validation,
        "api_transaction_type": tgt_transaction_type,
        "api_document_identifier": tgt_identifier,
        "attributes_to_configure": tgt_attrs,
        "last_modified_by": "",
    })
    updated_input["objects"]["data_map"].update({
        "map_name": map_name,
        "map_identifier": map_identifier,
        "map_identifier_version": map_version,
    })
    updated_input["objects"]["rule"].update({
        "name": rule_name,
        "version": rule_version,
    })
    updated_input["objects"]["source_transport_profile"].update({
        "profile_name": source_tp_create_name,
        "existing_account_name": source_account,
        "deployment_group": deployment_group,
        "subscription_folder": source_folder,
        "partner_name": source_system,
    })
    updated_input["objects"]["target_transport_profile"].update({
        "profile_name": target_tp_create_name,
        "existing_account_name": target_account,
        "deployment_group": deployment_group,
        "subscription_folder": target_folder,
        "partner_name": target_partner,
    })
    updated_input["objects"]["biz_flow"]["configure_source"][
        "source_transport_profile"
    ] = source_tp_flow_name
    updated_input["objects"]["biz_flow"]["configure_targets"][
        "target_transport_profile"
    ] = target_tp_flow_name
    updated_input["objects"]["biz_flow"]["configure_routing"][
        "actions"
    ]["target"] = target_tp_flow_name

    updated_config.update({
        "requestedBy": requester,
        "hipEnvironment": environment,
        "source_system_name": source_system,
        "target_system_name": target_partner,
        "partner_identifier_value": partner_identifier_value.strip(),
        "source_haft_account": source_account,
        "target_haft_account": target_account,
        "source_deployment_group_name": deployment_group,
        "target_deployment_group_name": deployment_group,
        "source_transport_profile_name": source_tp_flow_name,
        "target_transport_profile_name": target_tp_flow_name,
    })
    updated_config.setdefault("user", {})["userId"] = int(user_id)
    updated_config["user"]["emailId"] = requester

    issues = validate_files(updated_input)
    current_env = read_env()
    issues.extend(validate_credentials(current_env))
    issues.extend(validate_pdf_documentation(current_env))
    mapping_validator = UhalInputMapper(updated_input, updated_config, ROOT)
    issues.extend(
        f"U-HAUL mapping: {item.field}: {item.message}"
        for item in mapping_validator.validate()
        if item.severity == "ERROR"
    )
    for error in [
        src_identifier_error,
        tgt_identifier_error,
        src_attrs_error,
        tgt_attrs_error,
    ]:
        if error:
            issues.append(error)

    left, right = st.columns([2, 1])
    with left:
        st.subheader("Live dependency plan")
        st.code(
            """1. Verify HIP OAuth and Dell AIA gpt-oss-120b
2. Load built-in + ingested PDF API contracts
3. Validate each request before sending
4. Validate source/target TP interface + flow name
5. Source/target account, partner and system
6. Source/target Document Types
7. MAC Map
8. Mapping Rule
9. Source/target TP Orchestration
10. Flow Orchestration Create
11. Flow Orchestration Deploy
12. Flow deployment history + TP audits"""
        )
    with right:
        st.subheader("Preflight")
        if not issues:
            st.success("Ready for live execution")
        else:
            for issue in issues:
                st.error(issue)

    with st.expander("Final input.json preview"):
        st.json(updated_input)
    with st.expander("Final config_overrides.json preview"):
        st.json(updated_config)

    if st.button(
        "Save form values",
        use_container_width=True,
    ):
        save_json(INPUT_PATH, updated_input)
        save_json(CONFIG_PATH, updated_config)
        ensure_gitignore()
        st.success("Input and configuration saved.")

    st.caption("Execution begins only after all preflight validations pass.")
    if st.button(
        "Execute Live U-HAUL End-to-End",
        type="primary",
        disabled=bool(issues),
        use_container_width=True,
    ):
        save_json(INPUT_PATH, updated_input)
        save_json(CONFIG_PATH, updated_config)
        ensure_gitignore()

        cmd = [sys.executable, str(ROOT / "run_agent.py")]
        with st.status(
            "Executing live dependency-aware U-HAUL flow...",
            expanded=True,
        ) as status:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                text=True,
                capture_output=True,
            )
            st.code(proc.stdout or "(no stdout)")
            if proc.stderr:
                st.code(proc.stderr)
            if proc.returncode == 0:
                status.update(
                    label="Live run completed",
                    state="complete",
                )
            else:
                status.update(
                    label=(
                        "Live run failed with code "
                        f"{proc.returncode}"
                    ),
                    state="error",
                )

        report = latest_report()
        if report and report.exists():
            st.success(f"Final report generated: {report.name}")
            st.components.v1.html(
                report.read_text(encoding="utf-8"),
                height=900,
                scrolling=True,
            )
            st.download_button(
                "Download final HTML report",
                report.read_bytes(),
                file_name=report.name,
                mime="text/html",
                use_container_width=True,
            )
