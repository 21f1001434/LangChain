# HIP API Agent Studio V91
## Microsoft AutoGen AgentChat 0.7.5 · Four-Agent LIVE Orchestration

Build ID: `2026-08-25-agentic-hip-v91-autogen-agentchat-075-4-agent-live`

## 1. Why V91 exists

V90 used the legacy `pyautogen` / `ConversableAgent` API. V91 migrates the parallel LIVE execution layer to the modern Microsoft AutoGen **AgentChat 0.7.5** API requested for this project.

The implementation now follows the AgentChat architecture:

- `autogen-agentchat==0.7.5`
- `autogen-core==0.7.5`
- `autogen-ext[openai]==0.7.5`
- `autogen_agentchat.agents.AssistantAgent`
- `autogen_ext.models.openai.OpenAIChatCompletionClient`
- `autogen_core.CancellationToken`
- `AssistantAgent.run(...)`
- a governed Python tool exposed to each AgentChat agent

Reference quickstart:
`https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/quickstart.html`

## 2. Final LIVE execution architecture

The Execution Center uses a single **RUN LIVE EXECUTION** action.

It supports:

- one customer once;
- the same customer multiple times;
- multiple different customers;
- a mixed set of validated customer/instance snapshots.

For every active customer/instance V91 creates a **fresh AssistantAgent**. Agent objects are not shared across concurrent jobs.

Observed concurrency envelope supplied for this environment:

| Parallel AgentChat agents | Result |
|---:|---|
| 1 | Stable |
| 2 | Stable |
| 3 | Stable |
| 4 | 100% stable |
| 5 | Unstable - HTTP 429 |

V91 therefore enforces a server-side maximum of **4 concurrent AgentChat agents**. Selecting more than four jobs is allowed: the queue is drained in waves with no more than four active agents at a time. Five concurrent AgentChat model calls are never deliberately scheduled.

Example: selecting 10 customer/instance snapshots runs as `4 + 4 + 2`.

## 3. What each AutoGen agent actually does

`webapp/backend/app/autogen_runtime.py` creates a fresh `AssistantAgent` for one immutable selected snapshot.

The agent uses Dell AIA `gpt-oss-120b` through Dell's OpenAI-compatible chat-completions endpoint via `OpenAIChatCompletionClient`.

The agent receives only one governed execution tool:

`execute_validated_hip_configuration`

That tool invokes the existing HIP runner, which remains responsible for:

1. immutable snapshot verification;
2. unresolved human-decision hard gate;
3. 18-contract validation;
4. production preflight;
5. OAuth / endpoint checks;
6. dependency-aware HIP API scheduling;
7. actual LIVE API calls;
8. cancellation;
9. response classification;
10. evidence/report creation.

The LLM is not allowed to invent, add, remove or rename payload fields. The 18 developer-approved request structures remain locked.

## 4. Dell AIA model client

Default V91 settings:

- base URL: `https://aia.gateway.dell.com/genai/dev/v1`
- chat path: `/chat/completions`
- model: `gpt-oss-120b`
- function/tool calling: enabled
- parallel model tool calls: disabled
- one governed tool iteration per AgentChat run
- OAuth token is reused through a thread-safe token cache

The following environment aliases are supported for the existing Dell AIA credentials:

- `DELL_AIA_CLIENT_ID` / `AIA_CLIENT_ID`
- `DELL_AIA_CLIENT_SECRET` / `AIA_CLIENT_SECRET`
- `DELL_AIA_TOKEN_URL` / `AIA_TOKEN_URL`
- static short-lived bearer-token aliases already supported by the project
- `AIA_EXTRA_HEADERS_JSON` for Dell gateway-specific headers

No credentials are embedded in the release.

## 5. API parallelism inside every AgentChat agent

The four-agent ceiling applies to **AgentChat agents**, not to the HIP API operations inside an agent.

Inside each customer execution `run_agent.py` computes the API dependency graph. All dependency-ready HIP API operations may fan out concurrently through the API executor; dependent operations wait until prerequisites are satisfied.

Therefore the architecture is:

`N selected snapshots -> waves of <=4 AssistantAgents -> each agent -> dependency-ready HIP APIs in parallel`

This preserves dependency correctness while allowing many API calls to be in flight across the four active customer/instance agents.

## 6. Stop Batch / Stop Instance

V91 passes an AutoGen `CancellationToken` to `AssistantAgent.run()`.

- **Stop Instance** cancels that AgentChat job and its governed HIP runner.
- **Stop Batch** cancels all active jobs and prevents queued jobs from starting.
- Cancellation can interrupt the Dell AIA model phase rather than waiting until after the model call has returned.
- Cancelled jobs are reported as `CANCELLED`, not `BLOCKED`.

## 7. Immediate multi-instance deletion

Deleting a repeated instance updates the UI immediately.

Frontend behavior:

1. remove the row optimistically;
2. clear its selection;
3. add a deletion tombstone so stale refresh/events cannot resurrect it;
4. call the backend deletion endpoint;
5. release the tombstone after the server confirms deletion;
6. roll back immediately if server deletion fails.

V91 retains **Delete selected** for bulk deletion.

For a grouped repeated run, the backend reindexes the remaining queue metadata. Example:

`1/3, 2/3, 3/3` -> delete `2/3` -> `1/2, 2/2`

This reindexing changes queue metadata only. It does not mutate the validated payload snapshot.

## 8. Builder and configuration lifecycle retained

Build Configuration continues to support:

- **Create New**
- **Clone Existing**
- **Edit Existing** with an explicit confirmation popup

U-HAUL remains a protected developer-approved reference:

- DEV APPROVED
- TEST READY
- 18/18
- immutable
- clonable
- not editable or deletable

Customer-file vs user-selection conflicts remain a backend hard gate and must be explicitly resolved before downstream API work.

## 9. Pipeline execution retained

Saved pipelines retain the all-stage safety gate:

1. validate every stage;
2. production-preflight every stage;
3. do not perform the first LIVE mutation unless all stages pass;
4. execute stages in saved order;
5. stop after the first non-passing runtime stage;
6. allow dependency-ready APIs within the current stage to run concurrently.

## 10. Exact dependency installation

Use a fresh extracted directory.

### Standard setup

Run:

`SETUP_AGENTIC_HIP.bat`

It installs `requirements.txt`, installs/builds the frontend with Bun, runs runtime preflight, and starts the Studio.

### Manual Python setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python runtime_preflight.py --json
```

The preflight deliberately requires the exact AutoGen 0.7.5 distributions for the LIVE agent runtime. A legacy `pyautogen` installation does not satisfy V91.

## 11. Validation performed for V91

Executed against the clean V91 source tree:

- application/root pytest: **295/295 PASS**
- FastAPI/backend pytest: **48/48 PASS**
- total automated pytest: **343/343 PASS**
- V90/V91 targeted modern AgentChat tests: **11/11 PASS**
- package Phase 6 checks: **38/38 PASS**
- final release validation: **16/16 PASS**
- package validation: **57/57 PASS**
- required self-checks: **43/43 PASS**
- adaptive compatibility checks: **60/60 PASS**
- frontend TS/TSX dependency-independent transpilation: **24/24 PASS**
- Python compileall: **PASS**
- ZIP integrity: recorded in `V91_VALIDATION_RESULT.json`

### External-package limitation of the packaging sandbox

The packaging sandbox does not have the AutoGen 0.7.5 distributions installed and cannot reach PyPI. The V91 runtime preflight correctly reports the three missing AutoGen distributions here instead of silently falling back to the legacy API. The AgentChat integration is tested with compatible injected `AssistantAgent`, model-client and `CancellationToken` test doubles; this proves the V91 orchestration path invokes the governed HIP execution tool and handles cancellation.

On the target machine, `SETUP_AGENTIC_HIP.bat` / `pip install -r requirements.txt` must successfully install the exact AutoGen 0.7.5 packages before RUN LIVE EXECUTION is used.

## 12. Meaning of PASS

A LIVE job is PASS only after the governed HIP runner actually executes and response analysis classifies the execution as successful (including approved existing-resource semantics where applicable). A successful AgentChat model call alone is never treated as a successful HIP execution.
