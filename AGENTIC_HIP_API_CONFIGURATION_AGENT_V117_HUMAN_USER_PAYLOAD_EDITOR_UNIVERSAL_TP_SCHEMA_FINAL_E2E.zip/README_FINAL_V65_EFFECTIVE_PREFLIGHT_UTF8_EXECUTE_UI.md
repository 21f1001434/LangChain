# V65 — Effective Preflight, UTF-8 Windows I/O, Execute UI Fix

## Fixes
- Final production preflight validates Source/Target Document Type direction from the exact effective persisted requests used by API Testing/Flow Game/Execute, instead of stale raw `input.json` helper fields.
- Windows child processes are forced to UTF-8 (`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`, explicit subprocess encoding) across API validation, preflight, Flow Game, single execution and parallel execution paths.
- Execute LIVE RESULT metrics now use a dedicated responsive layout, eliminating vertical/broken labels caused by shared API Testing metric CSS.
- Final pre-LIVE gates remain mandatory; no mutating call is made when a true effective-request validation fails.

## Verification
- Focused V65 tests cover effective transaction direction precedence, Unicode child-process round trip, and Execute metric isolation.
- Full pytest suite and release/self-check scripts pass.
