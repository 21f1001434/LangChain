from __future__ import annotations

import json
import tempfile
from pathlib import Path

from payload_overrides import PayloadOverrideStore, save_override
from payload_ui_helpers import json_change_paths


ROOT = Path(__file__).resolve().parent


def main() -> None:
    guided = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8")
    advanced = (ROOT / "legacy_pages" / "90_Advanced_Technical_Workspace.py").read_text(encoding="utf-8")
    runner = (ROOT / "run_agent.py").read_text(encoding="utf-8")

    guided_tokens = [
        "Review what the agent will send",
        "Review or edit a generated request",
        "What will be sent",
        "Original generated",
        "Edit request",
        "Check my edit",
        "Ask agent to review",
        "Save this edit",
        "Restore agent-generated",
    ]
    for token in guided_tokens:
        assert token in guided, token

    advanced_tokens = [
        "Filter by API area",
        "Show edited only",
        "Show executable only",
        "Effective request",
        "Generated baseline",
        "Change summary",
        "Save request edit",
        "Restore generated",
        "Ask Dell AIA to review/fix",
    ]
    for token in advanced_tokens:
        assert token in advanced, token

    assert "redact_sensitive(payload)" in runner
    assert "call_factory.get(\"payload\") is not None" in runner
    assert "_resolve_runtime_payload_values" in runner

    changes = json_change_paths(
        {"a": 1, "nested": {"x": 1}},
        {"a": 2, "nested": {"x": 1, "y": 3}},
    )
    assert "a" in " ".join(changes)
    assert "nested.y" in " ".join(changes)

    with tempfile.TemporaryDirectory() as tmp:
        temp_root = Path(tmp)
        save_override(
            temp_root,
            "rule",
            {
                "documentTypeId": "{{runtime.source_document_type_id}}",
                "custom": "edited",
            },
            request_kind="payload",
            mode="merge",
            note="user edit",
            edit_origin="USER",
        )
        store = PayloadOverrideStore(temp_root)
        factory, meta = store.apply(
            "rule",
            {"payload": {"documentTypeId": 1, "keep": True}},
            {"runtime": {"source_document_type_id": 92001}},
        )
        assert meta["applied"] is True
        assert factory["payload"]["documentTypeId"] == 92001
        assert factory["payload"]["custom"] == "edited"
        assert factory["payload"]["keep"] is True

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "guidedPayloadEditor": True,
        "advancedPayloadStudioImproved": True,
        "generatedVsEffectiveComparison": True,
        "editValidationAndAgentReview": True,
        "runtimePlaceholderSupport": True,
        "secretSafePreviewAndEvidence": True,
    }
    path = ROOT / "examples" / "DUAL_PAYLOAD_EDIT_UI_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
