import json
from types import SimpleNamespace

import run_agent
from hip_naming import compact_hip_flow_name, normalize_input_flow_name, validate_hip_flow_name


def _result(response, *, success=False, classification="BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", status=500):
    return run_agent.Result(
        13, "Rule", "Create mapping rule", "rule", "POST", "https://example/api/rule",
        "HIP", "rule", status, classification, success, 10, "", "{}", response, {},
        "", "", "", "", ""
    )


def test_v110_legrand_flow_name_is_compacted_before_live_payload_materialization():
    original = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    assert len(original) == 43
    compact = compact_hip_flow_name(original)
    assert compact == "LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB"
    assert validate_hip_flow_name(compact)["valid"] is True
    cfg = {
        "profile_name": original,
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": original}}},
    }
    normalized = normalize_input_flow_name(cfg)
    assert normalized["profile_name"] == compact
    assert normalized["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == compact
    assert normalized["_flow_name_normalization"]["stage"].startswith("canonical input")


def test_v110_flow_name_validation_rejects_live_screenshot_name():
    check = validate_hip_flow_name("LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB")
    assert check["valid"] is False
    assert check["length"] == 43
    assert any("at most 40" in msg for msg in check["errors"])


def test_v110_tp_audit_uses_create_history_not_newer_failed_edits():
    runner = run_agent.Runner(llm_enabled=False)
    body = [
        {"operation": "edit", "status": "FAILED", "updatedAt": "2026-08-30T20:00:00Z"},
        {"operation": "edit", "status": "FAILED", "updatedAt": "2026-08-30T19:00:00Z"},
        {"operation": "create", "status": "SUCCESS", "comments": "Created TP successfully", "updatedAt": "2026-08-20T10:00:00Z"},
    ]
    classification, ok = runner.validate_step_business_result("tp_audits", body, "PASS_SUCCESS", True)
    assert (classification, ok) == ("PASS_SUCCESS", True)


def test_v110_rule_duplicate_resolves_exact_current_dev_rule_id_read_only(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)
    target_name = runner.business["mappingRuleName"]
    target_version = runner.business["mappingRuleVersion"]
    calls = []

    class Resp:
        def __init__(self, status, body):
            self.status_code = status
            self._body = body
        def json(self):
            return self._body

    def fake_request(**kwargs):
        calls.append(kwargs)
        if kwargs["url"].endswith("/details"):
            return Resp(404, {"error": "not found"})
        return Resp(200, {
            "data": [
                {
                    "ruleName": target_name,
                    "environments": [
                        {"hipEnvironment": "DEV", "versions": [{"ruleId": 43210, "version": float(target_version)}]},
                        {"hipEnvironment": "PROD", "versions": [{"ruleId": 99999, "version": float(target_version)}]},
                    ],
                },
                {"ruleName": "OTHER_RULE", "hipEnvironment": "DEV", "ruleId": 88888, "version": float(target_version)},
            ]
        })

    monkeypatch.setattr(runner, "_request_with_retry", fake_request)
    duplicate = _result(json.dumps({
        "error": True,
        "message": "Create failed",
        "detail": "A rule with the same name and version already exists in DEV.",
        "status": 500,
        "data": None,
    }))
    # V115 supersedes the V110 workaround: Dev confirmed Flow uses Rule
    # name + version, so canonical execution must not resolve a numeric ID.
    assert runner.enforce_live_id_integrity("rule", duplicate, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    assert calls == []
    assert "liveRuleIdResolution" not in duplicate.extracted


def test_v110_ambiguous_or_missing_rule_read_is_terminal_and_not_retried(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)

    class Resp:
        status_code = 200
        def json(self):
            return {"data": []}

    monkeypatch.setattr(runner, "_request_with_retry", lambda **kwargs: Resp())
    duplicate = _result('{"detail":"A rule with the same name and version already exists in DEV."}')
    assert runner.enforce_live_id_integrity("rule", duplicate, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    # V115: missing Rule ID is no longer an error because Flow uses name+version.
    assert duplicate.classification != "LIVE_RULE_ID_UNRESOLVED"


def test_v110_invalid_flow_name_classification_is_terminal():
    assert run_agent.Runner.is_non_retryable_completion_reason("FLOW_NAME_INVALID") is True


def test_v110_flow_name_can_never_be_renamed_after_http_response():
    runner = run_agent.Runner(llm_enabled=False)
    original = runner.flow_name()
    try:
        runner.allocate_unique_flow_name()
    except RuntimeError as exc:
        assert "IMMUTABLE_FLOW_NAME" in str(exc)
    else:
        raise AssertionError("V110 must prohibit post-response Flow renaming")
    assert runner.flow_name() == original
