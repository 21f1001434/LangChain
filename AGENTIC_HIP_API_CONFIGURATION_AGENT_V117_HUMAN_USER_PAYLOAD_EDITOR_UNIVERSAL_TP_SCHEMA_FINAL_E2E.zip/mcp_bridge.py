#!/usr/bin/env python3
"""Synchronous bridge to the official MCP Python SDK.

MCP v2 uses an in-memory transport for low latency. MCP v1 uses stdio. If the
SDK is absent and MCP_REQUIRED is false, the exact same registered tool
functions run locally and the report marks the fallback explicitly.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import datetime as dt
from pathlib import Path
from typing import Any, Dict, Optional

from uhal_mcp_server import (
    MCP_SDK_MODE,
    get_mapping_for_step_tool,
    mcp as local_mcp_server,
    resolve_response_ids_tool,
    suggest_missing_values_tool,
    validate_api_request_tool,
    validate_uhal_input_tool,
    analyze_new_input_tool,
    prepare_canonical_input_tool,
    propose_change_patch_tool,
    apply_change_patch_tool,
    query_knowledge_graph_tool,
    agentq_memory_status_tool,
    list_interface_profiles_tool,
    plan_interface_configuration_tool,
    validate_execution_policy_tool,
    validate_payload_override_tool,
    interpret_api_response_tool,
    get_api_contract_summary_tool,
    assess_execution_readiness_tool,
)

MCP_TOOL_NAMES = [
    "validate_uhal_input",
    "get_mapping_for_step",
    "validate_api_request",
    "resolve_response_ids",
    "suggest_missing_values",
    "analyze_new_input",
    "prepare_canonical_input",
    "propose_change_patch",
    "apply_change_patch",
    "query_knowledge_graph",
    "agentq_memory_status",
    "list_interface_profiles",
    "plan_interface_configuration",
    "validate_execution_policy",
    "validate_payload_override",
    "interpret_api_response",
    "get_api_contract_summary",
    "assess_execution_readiness",
]



class MCPBridge:
    def __init__(
        self,
        root: Path,
        enabled: bool = True,
        required: bool = False,
    ) -> None:
        self.root = Path(root).resolve()
        self.enabled = bool(enabled)
        self.required = bool(required)
        self.sdk_mode = MCP_SDK_MODE
        self.calls = 0
        self.failures = 0
        self.fallback_calls = 0
        self.tool_call_counts: Dict[str, int] = {}
        self.trace_path = self.root / "reports" / "mcp_tool_trace_latest.jsonl"
        if self.required and not self.sdk_available:
            raise RuntimeError(
                "MCP_REQUIRED=true but the MCP Python SDK is unavailable. "
                "Install mcp>=1.28,<2."
            )

    @property
    def sdk_available(self) -> bool:
        return self.sdk_mode in {"v1", "v1-stable", "v2"} and local_mcp_server is not None

    @property
    def active(self) -> bool:
        return self.enabled and (self.sdk_available or not self.required)

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled,
            "required": self.required,
            "active": self.active,
            "sdkAvailable": self.sdk_available,
            "sdkMode": self.sdk_mode,
            "calls": self.calls,
            "failures": self.failures,
            "fallbackCalls": self.fallback_calls,
            "toolCallCounts": dict(sorted(self.tool_call_counts.items())),
            "tracePath": str(self.trace_path),
            "transport": (
                "in-memory" if self.sdk_mode == "v2"
                else "stdio" if self.sdk_mode in {"v1", "v1-stable"}
                else "local-function-fallback"
            ),
            "toolCount": len(MCP_TOOL_NAMES),
            "toolNames": list(MCP_TOOL_NAMES),
            "toolCoverage": {
                "mapping": True,
                "interfacePlanning": True,
                "contractValidation": True,
                "executionPolicy": True,
                "payloadCritic": True,
                "responseInterpretation": True,
                "runtimeIdResolution": True,
                "knowledgeGraph": True,
                "agentqMemory": True,
            },
        }

    def _record_trace(
        self,
        *,
        tool: str,
        started: float,
        transport: str,
        success: bool,
        arguments: Dict[str, Any],
        result: Optional[Dict[str, Any]] = None,
        error: str = "",
    ) -> None:
        """Write secret-free MCP observability evidence.

        We intentionally record only argument/result *keys*, never values, so
        OAuth/client-secret material cannot leak through tool tracing.
        """
        record = {
            "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
            "tool": tool,
            "transport": transport,
            "success": bool(success),
            "durationMs": round((time.perf_counter() - started) * 1000.0, 3),
            "argumentKeys": sorted(str(key) for key in (arguments or {}).keys()),
            "resultKeys": sorted(str(key) for key in (result or {}).keys()),
            "errorType": str(error or "")[:240],
        }
        try:
            self.trace_path.parent.mkdir(parents=True, exist_ok=True)
            with self.trace_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            # Tool tracing must never block HIP execution.
            pass

    @staticmethod
    def _unwrap_result(result: Any) -> Dict[str, Any]:
        structured = getattr(result, "structured_content", None)
        if isinstance(structured, dict):
            if set(structured) == {"result"} and isinstance(
                structured.get("result"), dict
            ):
                return structured["result"]
            return structured

        for block in getattr(result, "content", []) or []:
            text = getattr(block, "text", None)
            if not text:
                continue
            try:
                parsed = json.loads(text)
                if isinstance(parsed, dict):
                    return parsed.get("result", parsed)
            except Exception:
                continue
        if getattr(result, "is_error", False):
            raise RuntimeError("MCP tool returned an error result.")
        return {}

    async def _call_v2(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        from mcp import Client

        async with Client(local_mcp_server) as client:
            result = await client.call_tool(name, arguments)
            if getattr(result, "is_error", False):
                raise RuntimeError(f"MCP tool {name!r} failed: {result.content}")
            return self._unwrap_result(result)

    async def _call_v1(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        params = StdioServerParameters(
            command=sys.executable,
            args=[str(self.root / "uhal_mcp_server.py")],
            cwd=str(self.root),
        )
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(name, arguments)
                if getattr(result, "isError", False) or getattr(
                    result, "is_error", False
                ):
                    raise RuntimeError(f"MCP tool {name!r} failed.")
                return self._unwrap_result(result)

    def _direct_fallback(
        self,
        name: str,
        arguments: Dict[str, Any],
    ) -> Dict[str, Any]:
        functions = {
            "validate_uhal_input": validate_uhal_input_tool,
            "get_mapping_for_step": get_mapping_for_step_tool,
            "validate_api_request": validate_api_request_tool,
            "resolve_response_ids": resolve_response_ids_tool,
            "suggest_missing_values": suggest_missing_values_tool,
            "analyze_new_input": analyze_new_input_tool,
            "prepare_canonical_input": prepare_canonical_input_tool,
            "propose_change_patch": propose_change_patch_tool,
            "apply_change_patch": apply_change_patch_tool,
            "query_knowledge_graph": query_knowledge_graph_tool,
            "agentq_memory_status": agentq_memory_status_tool,
            "list_interface_profiles": list_interface_profiles_tool,
            "plan_interface_configuration": plan_interface_configuration_tool,
            "validate_execution_policy": validate_execution_policy_tool,
            "validate_payload_override": validate_payload_override_tool,
            "interpret_api_response": interpret_api_response_tool,
            "get_api_contract_summary": get_api_contract_summary_tool,
            "assess_execution_readiness": assess_execution_readiness_tool,
        }
        if name not in functions:
            raise KeyError(f"Unknown local MCP tool: {name}")
        self.fallback_calls += 1
        return functions[name](**arguments)

    def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any],
    ) -> Dict[str, Any]:
        started = time.perf_counter()
        self.tool_call_counts[name] = self.tool_call_counts.get(name, 0) + 1

        if not self.enabled:
            result = {
                "mcpUsed": False,
                "disabled": True,
                "tool": name,
            }
            self._record_trace(
                tool=name, started=started, transport="disabled", success=True,
                arguments=arguments, result=result,
            )
            return result

        self.calls += 1
        attempted_transport = "unknown"
        try:
            if self.sdk_mode == "v2":
                attempted_transport = "in-memory"
                result = asyncio.run(self._call_v2(name, arguments))
                result.setdefault("mcpUsed", True)
                result.setdefault("mcpTransport", "in-memory")
            elif self.sdk_mode in {"v1", "v1-stable"}:
                attempted_transport = "stdio"
                result = asyncio.run(self._call_v1(name, arguments))
                result.setdefault("mcpUsed", True)
                result.setdefault("mcpTransport", "stdio")
            elif self.required:
                attempted_transport = "required-unavailable"
                raise RuntimeError("MCP SDK unavailable and MCP is required.")
            else:
                attempted_transport = "local-function-fallback"
                result = self._direct_fallback(name, arguments)
                result.setdefault("mcpUsed", False)
                result.setdefault("mcpTransport", "local-function-fallback")
                result.setdefault(
                    "warning",
                    "Install mcp>=1.28,<2 to use the stable protocol transport.",
                )

            self._record_trace(
                tool=name, started=started,
                transport=str(result.get("mcpTransport") or attempted_transport),
                success=True, arguments=arguments, result=result,
            )
            return result
        except Exception as exc:
            self.failures += 1
            if self.required:
                self._record_trace(
                    tool=name, started=started, transport=attempted_transport,
                    success=False, arguments=arguments, error=type(exc).__name__,
                )
                raise

            result = self._direct_fallback(name, arguments)
            result.setdefault("mcpUsed", False)
            result.setdefault("mcpTransport", "local-function-fallback")
            result.setdefault("warning", "MCP call failed; local tool used.")
            result.setdefault("protocolFailure", type(exc).__name__)
            self._record_trace(
                tool=name, started=started, transport="local-function-fallback",
                success=True, arguments=arguments, result=result,
                error=type(exc).__name__,
            )
            return result

    def validate_uhal_input(
        self,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.call_tool(
            "validate_uhal_input",
            {
                "input_data": input_data,
                "config": config,
                "root": str(self.root),
            },
        )

    def mapping_for_step(
        self,
        step_key: str,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.call_tool(
            "get_mapping_for_step",
            {
                "step_key": step_key,
                "input_data": input_data,
                "config": config,
                "root": str(self.root),
            },
        )

    def validate_api_request(self, **kwargs: Any) -> Dict[str, Any]:
        arguments = dict(kwargs)
        arguments["root"] = str(self.root)
        return self.call_tool("validate_api_request", arguments)

    def resolve_response_ids(self, response_body: Any) -> Dict[str, Any]:
        return self.call_tool(
            "resolve_response_ids",
            {"response_body": response_body},
        )

    def suggest_missing_values(
        self,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.call_tool(
            "suggest_missing_values",
            {
                "input_data": input_data,
                "config": config,
                "root": str(self.root),
            },
        )

    def analyze_new_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        return self.call_tool("analyze_new_input", {"input_data": input_data, "root": str(self.root)})

    def prepare_canonical_input(self, input_data: Dict[str, Any], apply_safe: bool = True) -> Dict[str, Any]:
        return self.call_tool("prepare_canonical_input", {"input_data": input_data, "apply_safe": apply_safe, "root": str(self.root)})

    def propose_change_patch(self, request_text: str, input_data: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        return self.call_tool("propose_change_patch", {"request_text": request_text, "input_data": input_data, "config": config, "root": str(self.root)})

    def apply_change_patch(self, proposal: Dict[str, Any], input_data: Dict[str, Any], config: Dict[str, Any], approve: bool) -> Dict[str, Any]:
        return self.call_tool("apply_change_patch", {"proposal": proposal, "input_data": input_data, "config": config, "approve": approve, "root": str(self.root)})

    def query_knowledge_graph(self, text: str = "", node_type: str = "", limit: int = 100) -> Dict[str, Any]:
        return self.call_tool("query_knowledge_graph", {"text": text, "node_type": node_type, "limit": limit, "root": str(self.root)})

    def agentq_memory_status(self, task_key: str = "") -> Dict[str, Any]:
        return self.call_tool("agentq_memory_status", {"task_key": task_key, "root": str(self.root)})

    def list_interface_profiles(self) -> Dict[str, Any]:
        return self.call_tool("list_interface_profiles", {"root": str(self.root)})

    def plan_interface_configuration(
        self,
        baseline_input: Dict[str, Any],
        source_interface: str,
        target_interface: str,
        source_parameters: Optional[Dict[str, Any]] = None,
        target_parameters: Optional[Dict[str, Any]] = None,
        source_shared_profile: str = "",
        target_shared_profile: str = "",
        deployment_group: str = "",
    ) -> Dict[str, Any]:
        return self.call_tool(
            "plan_interface_configuration",
            {
                "baseline_input": baseline_input or {},
                "source_interface": source_interface,
                "target_interface": target_interface,
                "source_parameters": source_parameters or {},
                "target_parameters": target_parameters or {},
                "source_shared_profile": source_shared_profile,
                "target_shared_profile": target_shared_profile,
                "deployment_group": deployment_group,
                "root": str(self.root),
            },
        )

    def validate_execution_policy(self) -> Dict[str, Any]:
        return self.call_tool("validate_execution_policy", {"root": str(self.root)})

    def validate_payload_override(
        self,
        step_key: str,
        generated: Dict[str, Any],
        effective: Dict[str, Any],
        interface_only: bool = False,
    ) -> Dict[str, Any]:
        return self.call_tool(
            "validate_payload_override",
            {
                "step_key": step_key,
                "generated": generated or {},
                "effective": effective or {},
                "interface_only": bool(interface_only),
                "root": str(self.root),
            },
        )

    def interpret_api_response(
        self,
        api_key: str,
        status_code: Optional[int],
        response_body: Any = None,
        error: str = "",
    ) -> Dict[str, Any]:
        return self.call_tool(
            "interpret_api_response",
            {
                "api_key": api_key,
                "status_code": status_code,
                "response_body": response_body,
                "error": error,
            },
        )

    def get_api_contract_summary(self, api_key: str) -> Dict[str, Any]:
        return self.call_tool(
            "get_api_contract_summary",
            {"api_key": api_key, "root": str(self.root)},
        )

    def assess_execution_readiness(
        self,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.call_tool(
            "assess_execution_readiness",
            {
                "input_data": input_data or {},
                "config": config or {},
                "root": str(self.root),
            },
        )

