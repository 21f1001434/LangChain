# HIP Application Studio V26 — Readiness / Connection Check Fix

V26 retains the complete V25 solution and fixes the false preflight failure shown in the live UI.

## Fixed

- Secure connection health is now separated from payload/configuration readiness.
- Missing Partner Identifier / DUNS no longer makes a working OAuth/MCP connection appear broken.
- UhalInputMapper and the live Runner now resolve Partner Identifier from the same locations, including legacy `partnerCreate.partnerIdentifierValue`.
- Easy Studio shows the real first blocker and provides a direct Partner Identifier / DUNS input when that is the missing value.
- Account / Partner / System OAuth credentials can again be loaded from the user's legacy `Test.py`, as well as `.env` / environment variables.
- V25 OAuth User-Agent / lightweight Runner hardening is retained.

## Expected check behavior

If connections are healthy but Partner DUNS is missing:

- Secure connections: PASS
- All API requests: NEEDS INPUT
- MCP safety/readiness: NEEDS INPUT
- Final preflight: NEEDS INPUT
- Agent message: connections are working; provide Partner Identifier / DUNS

After the real Dev-approved value is entered and re-checked, request/preflight readiness can pass.

## Verification

- pytest: 71 passed
- validate_package.py: 57/57 PASS
- validate_adaptive_package.py: 60/60 PASS
- final_self_check.py: 26/26 required PASS

All existing V25 features remain: integrated Input Builder, all 18 HIP APIs, `hip-automation`, Scratch/API Flow Game, interactive graphs, Easy Payload Editor, API Testing Area, Learn text/vision/network-log support, Translation/Passthrough handling, inbound/outbound mapping, live-only execution, and response PASS/EXISTING/BLOCKED analysis.
