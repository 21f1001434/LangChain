@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   OPTIONAL LEGACY STREAMLIT REFERENCE UI
 echo   Phase 6 normal operation does NOT require this UI.
 echo ============================================================
python runtime_preflight.py --legacy-streamlit
if errorlevel 1 (
  echo Install optional archive dependencies with:
  echo   python -m pip install -r requirements_legacy_streamlit.txt
  exit /b 2
)
python -m streamlit run hip_application_studio.py --server.port 8503
exit /b %errorlevel%
