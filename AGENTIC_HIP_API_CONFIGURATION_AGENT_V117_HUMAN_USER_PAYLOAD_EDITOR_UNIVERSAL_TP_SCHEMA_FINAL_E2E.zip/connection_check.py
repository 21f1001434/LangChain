from __future__ import annotations

import datetime as dt
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parent
WORKSPACE_ROOT = Path(os.getenv("HIP_WORKSPACE_ROOT") or ROOT).expanduser().resolve()
REPORTS = WORKSPACE_ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT))

from production_guard import atomic_write_json, redact_sensitive
from run_agent import BUILD_ID, Runner


def result(status: str, **kwargs: Any) -> Dict[str, Any]:
    return {"status": status, **kwargs}


def _secure_connections_ok(components: Dict[str, Any], mandatory: list[str]) -> bool:
    """Return only transport/OAuth health; payload readiness is evaluated elsewhere."""
    return all(components.get(key, {}).get("status") == "OK" for key in mandatory)


def main() -> None:
    output: Dict[str, Any] = {
        "generatedAt": dt.datetime.now().isoformat(),
        "overall": "FAILED",
        "buildId": BUILD_ID,
        "credentialModel": {
            "hipConfig": "Dedicated HIP Config OAuth credential; shared with MAC Map",
            "account": "Dedicated Account OAuth credential when Account API executes",
            "partner": "Dedicated Partner OAuth credential when Partner API executes",
            "system": "Dedicated System OAuth credential when System API executes",
            "dellAia": "Separate Dell AIA OAuth credential",
        },
        "components": {},
    }

    try:
        runner = Runner(llm_enabled=True)
    except Exception as exc:
        output["components"]["initialization"] = result("FAILED", error=str(exc))
        atomic_write_json(
            REPORTS / "connection_check_latest.json",
            redact_sensitive(output),
        )
        print(json.dumps(redact_sensitive(output), indent=2, default=str))
        raise SystemExit(1)

    plan = runner.execution_plan.summary()
    output["apiExecutionPlan"] = plan
    output["executionFlow"] = runner.execution_flow.summary()

    try:
        aia = runner.judge.verify_connection()
        output["components"]["dellAia"] = result("OK", details=aia)
    except Exception as exc:
        output["components"]["dellAia"] = result("FAILED", error=str(exc))

    # Connectivity and configuration readiness are intentionally separated.
    # A missing business payload value (for example Partner DUNS) must not make
    # the UI claim that the MCP/secure connection itself is broken.
    try:
        mcp_status = runner.mcp.status()
        mcp_interfaces = runner.mcp.list_interface_profiles()
        output["components"]["mcp"] = result(
            "OK",
            transport=mcp_status,
            interfaceCatalog={
                "count": mcp_interfaces.get("count", 0),
                "keys": mcp_interfaces.get("keys", []),
            },
        )
    except Exception as exc:
        output["components"]["mcp"] = result("FAILED", error=str(exc))

    try:
        mcp_validation = runner.mcp.validate_uhal_input(runner.input, runner.ov)
        mcp_readiness = runner.mcp.assess_execution_readiness(runner.input, runner.ov)
        configuration_ready = bool(
            mcp_validation.get("valid", True)
            and mcp_readiness.get("valid", True)
            and not mcp_readiness.get("liveRunBlocked")
        )
        output["configurationReadiness"] = {
            "status": "READY" if configuration_ready else "NEEDS_INPUT",
            "ready": configuration_ready,
            "inputValidation": mcp_validation,
            "readiness": mcp_readiness,
        }
    except Exception as exc:
        output["configurationReadiness"] = {
            "status": "FAILED",
            "ready": False,
            "error": str(exc),
        }

    def token_component(
        component_key: str,
        token_kind: str,
        token_url: str,
        scope: str,
        *,
        required: bool,
    ) -> None:
        if not required:
            output["components"][component_key] = result(
                "NOT_REQUIRED",
                reason="Corresponding API is skipped as an existing object.",
            )
            return
        try:
            token = runner.get_token(token_kind, scope)
            output["components"][component_key] = result(
                "OK",
                tokenReceived=bool(token),
                tokenUrl=token_url,
                tokenSource=runner.token_sources.get(token_kind),
                authMode="oauth2-client-credentials-basic-auth",
                scopeSent=bool(scope),
            )
        except Exception as exc:
            output["components"][component_key] = result(
                "FAILED",
                tokenUrl=token_url,
                scopeSent=bool(scope),
                error=str(exc),
            )

    token_component(
        "hipOAuth", "HIP", runner.hip_token_url, runner.hip_scope, required=True
    )
    output["components"]["macMap"] = (
        result("OK", authentication="uses-shared-hip-bearer-token")
        if output["components"]["hipOAuth"].get("status") == "OK"
        else result("BLOCKED", error="Blocked because HIP Config OAuth failed.")
    )

    account_required = not (
        runner.execution_plan.is_skipped("account_source")
        and runner.execution_plan.is_skipped("account_target")
    )
    partner_required = not runner.execution_plan.is_skipped("partner_target")
    system_required = not runner.execution_plan.is_skipped("system_source")

    token_component(
        "accountOAuth",
        "ACCOUNT",
        runner.account_token_url,
        runner.account_scope,
        required=account_required,
    )
    token_component(
        "partnerOAuth",
        "PARTNER",
        runner.partner_token_url,
        runner.partner_scope,
        required=partner_required,
    )
    token_component(
        "systemOAuth",
        "SYSTEM",
        runner.system_token_url,
        runner.system_scope,
        required=system_required,
    )

    mandatory = ["dellAia", "mcp", "hipOAuth"]
    if account_required:
        mandatory.append("accountOAuth")
    if partner_required:
        mandatory.append("partnerOAuth")
    if system_required:
        mandatory.append("systemOAuth")

    # `overall` is secure connectivity only. Execution-flow/payload readiness is
    # reported separately so one unresolved business field cannot turn a working
    # OAuth connection into a false connection failure.
    secure_connections_ok = _secure_connections_ok(output["components"], mandatory)
    output["secureConnectionsOk"] = secure_connections_ok
    output["overall"] = "OK" if secure_connections_ok else "FAILED"
    output["flowConfigurationValid"] = bool(output["executionFlow"].get("valid"))

    safe_output = redact_sensitive(output)
    atomic_write_json(REPORTS / "connection_check_latest.json", safe_output)
    print(json.dumps(safe_output, indent=2, default=str))
    raise SystemExit(0 if output["overall"] == "OK" else 1)


if __name__ == "__main__":
    main()
