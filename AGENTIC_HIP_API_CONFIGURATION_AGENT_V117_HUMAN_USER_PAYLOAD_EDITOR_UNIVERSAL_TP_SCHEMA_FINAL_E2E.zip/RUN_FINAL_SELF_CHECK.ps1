$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
python .\final_self_check.py
exit $LASTEXITCODE
