$ErrorActionPreference = 'Stop'
& "$PSScriptRoot/SETUP_AGENTIC_HIP.ps1"
