from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import run_agent
from production_integration_test import fake_response
from execution_flow import (
    DEFAULT_ORDER,
    ExecutionFlowConfig,
    save_execution_flow,
)

ROOT = Path(__file__).resolve().parent
FLOW_PATH = ROOT / "execution_flow.json"


def main() -> None:
    original = FLOW_PATH.read_text(encoding="utf-8") if FLOW_PATH.exists() else None
    try:
        custom_order = [
            "doctype_source",
            "doctype_target",
            "validate_source",
            "validate_target",
            "validate_flow",
            "account_source",
            "account_target",
            "system_source",
            "partner_target",
            "map",
            "rule",
            "source_tp",
            "target_tp",
            "source_tp_audit",
            "target_tp_audit",
            "flow_create",
            "flow_deploy",
            "flow_history",
        ]
        rows = [
            {
                "stepKey": key,
                "order": index + 1,
                "waitAfterSeconds": 7.0 if key == "doctype_source" else 0.0,
            }
            for index, key in enumerate(custom_order)
        ]
        saved = save_execution_flow(ROOT, rows)
        assert saved["valid"] is True, saved
        assert saved["orderedSteps"] == custom_order, saved

        runner = run_agent.Runner(llm_enabled=False)
        runner.get_token = lambda token_kind, scope: "offline-token"
        runner.judge.judge = lambda result: {}
        runner.judge.available = lambda: False
        runner._request_with_retry = lambda method, url, token_kind, scope, extra_headers, payload, params: fake_response(method, url, payload, params)
        with patch.object(
            runner.adaptive,
            "record_api_result",
            return_value=None,
        ), patch.object(
            runner.adaptive,
            "record_mapping_graph",
            return_value={"status": "mocked"},
        ), patch("run_agent.time.sleep", return_value=None):
            results = runner.run()

        event_keys = [item["stepKey"] for item in runner.execution_timing_events]
        assert event_keys == custom_order, event_keys
        source_doc_event = next(
            item for item in runner.execution_timing_events
            if item["stepKey"] == "doctype_source"
        )
        assert source_doc_event["configuredWaitAfterSeconds"] == 7.0
        assert source_doc_event["actualWaitSeconds"] >= 0.0
        assert source_doc_event["waitStatus"] == "WAITED"

        # Dependency protection: Flow Deploy before Flow Create must be rejected.
        invalid = list(rows)
        flow_create_row = next(row for row in invalid if row["stepKey"] == "flow_create")
        flow_deploy_row = next(row for row in invalid if row["stepKey"] == "flow_deploy")
        flow_create_row["order"], flow_deploy_row["order"] = (
            flow_deploy_row["order"], flow_create_row["order"]
        )
        rejected = False
        try:
            save_execution_flow(ROOT, invalid)
        except ValueError:
            rejected = True
        assert rejected is True

        output = {
            "status": "PASS",
            "buildId": run_agent.BUILD_ID,
            "customOrderApplied": event_keys,
            "configuredWaitAfterSeconds": source_doc_event["configuredWaitAfterSeconds"],
            "livePacingActualWaitSeconds": source_doc_event["actualWaitSeconds"],
            "dependencyViolationRejected": rejected,
            "steps": len(results),
        }
        path = ROOT / "examples" / "EXECUTION_FLOW_TIMING_TEST.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(output, indent=2), encoding="utf-8")
        print(json.dumps(output, indent=2))
    finally:
        if original is None:
            FLOW_PATH.unlink(missing_ok=True)
        else:
            FLOW_PATH.write_text(original, encoding="utf-8")


if __name__ == "__main__":
    main()
