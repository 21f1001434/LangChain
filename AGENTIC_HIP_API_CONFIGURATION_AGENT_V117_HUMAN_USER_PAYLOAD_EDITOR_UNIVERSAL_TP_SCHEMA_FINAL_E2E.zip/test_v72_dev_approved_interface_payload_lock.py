from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

import run_agent
from canonical_payload_contract import (
    interface_shape_summary,
    lock_request_value,
    validate_override_structure,
)
from payload_overrides import PayloadOverrideStore, save_override

ROOT = Path(__file__).resolve().parent

FILE_KEYS = {
    "Interface Environment", "File Filtering Pattern", "Post Transfer Action",
    "Is Compression Required", "Use Existing Folder", "Existing Account",
    "Subscription Folder", "Existing Account Name",
}
HTTPS_SOURCE_KEYS = {
    "Protocol", "HIP URL", "Proxy URI", "Request Method", "Request Format",
    "Sender Authentication Type", "Are Input Files Compressed?", "Sender Grant Type",
}
HTTPS_TARGET_KEYS = {
    "Protocol", "Partner URL", "Request Method", "Request Format",
    "Receiver Authentication Type", "Gateway URL",
    "Are Input Files Compressed?",
    "Receiver Grant Type", "Receiver Token Endpoint", "Receiver Client Id",
    "Receiver Client Secret",
}
AS2_SOURCE_KEYS = {
    "Partner Verification Certificate", "AS2 URL",
    "Partner Verification Certificate Id", "Dell Identifier",
    "Interface Environment", "Partner Identifier", "Request Method",
    "Are SSL and Partner Verification Certificates identical?",
    "Partner Verification Certificate CN – Expiry",
}
AS2_TARGET_KEYS = {
    "Encryption Certificate", "Asynchronous MDN Required",
    "Encryption Certificate CN – Expiry", "Signing Algorithm", "Dell Identifier",
    "Interface Environment", "Encryption Certificate Id", "Partner URL",
    "Partner Identifier", "Is Compression Required", "Request Method",
    "Encryption Algorithm",
}


def _runner() -> run_agent.Runner:
    return run_agent.Runner(llm_enabled=False)


def test_v72_interface_catalog_is_exact_and_separate_by_family():
    fam = interface_shape_summary()["families"]
    assert set(fam) == {"FILE", "HTTPS", "HTTPS_AS2"}
    assert set(fam["FILE"]["sourceKeys"]) == FILE_KEYS
    assert set(fam["FILE"]["targetKeys"]) == FILE_KEYS
    assert set(fam["HTTPS"]["sourceKeys"]) == HTTPS_SOURCE_KEYS
    assert set(fam["HTTPS"]["targetKeys"]) == HTTPS_TARGET_KEYS
    assert set(fam["HTTPS_AS2"]["sourceKeys"]) == AS2_SOURCE_KEYS
    assert set(fam["HTTPS_AS2"]["targetKeys"]) == AS2_TARGET_KEYS


def test_v72_https_sender_uses_exact_dev_team_attribute_names_only():
    tp = {
        "profile_usage": "Sender", "interface_type": "HTTPS",
        "interface_parameters": {
            "Protocol": "REST", "HIP URL": "https://hip.example", "Proxy URI": "dce-common-sv1",
            "Request Method": "POST", "Request Format": "Request Body",
            "Sender Authentication Type": "OAuth2", "Are Input Files Compressed?": "False",
            "Sender Grant Type": "client_credentials", "WRONG NEW FIELD": "must-drop",
        },
    }
    p = _runner().tp_parameters(tp, "source")
    assert set(p) == HTTPS_SOURCE_KEYS
    assert p["HIP URL"] == "https://hip.example"
    assert p["Proxy URI"] == "dce-common-sv1"
    assert "WRONG NEW FIELD" not in p


def test_v72_https_receiver_uses_exact_dev_team_attribute_names_only():
    tp = {
        "profile_usage": "Receiver", "interface_type": "HTTPS",
        "interface_parameters": {
            "Protocol": "REST", "Partner URL": "https://partner.example", "Request Method": "POST",
            "Request Format": "Request Body", "Receiver Authentication Type": "OAuth2",
            "Gateway URL": "pending", "SSL Certificate": "partner.crt",
            "Are Input Files Compressed?": "False", "SSL Certificate CN - Expiry": "CN - 2030-01-01",
            "Receiver Grant Type": "client_credentials", "Receiver Token Endpoint": "https://token.example",
            "Receiver Client Id": "client-id", "Receiver Client Secret": "{{runtime_payload.target.receiver_client_secret}}",
            "SSL Certificate Id": "cert-id", "WRONG NEW FIELD": "must-drop",
        },
    }
    p = _runner().tp_parameters(tp, "target")
    assert set(p) == HTTPS_TARGET_KEYS
    assert p["Partner URL"] == "https://partner.example"
    assert p["Receiver Client Id"] == "client-id"
    assert "WRONG NEW FIELD" not in p


def test_v72_sftp_and_ftp_stay_on_final_file_shape_only():
    runner = _runner()
    base = {
        "profile_usage": "Sender", "interface_environment": "UAT", "existing_account": "Yes",
        "existing_account_name": "acct", "subscription_folder": "/Inbound/ASN",
        "interface_parameters": {"WRONG NEW FIELD": "must-drop"},
    }
    for interface in ("SFTP", "FTP"):
        tp = {**base, "interface_type": interface}
        p = runner.tp_parameters(tp, "source")
        assert set(p) == FILE_KEYS
        assert p["Existing Account Name"] == "acct"
        assert p["Subscription Folder"] == "/Inbound/ASN"


def test_v72_as2_source_and_target_have_fixed_distinct_shapes_and_alias_values():
    runner = _runner()
    src = runner.tp_parameters({
        "profile_usage": "Sender", "interface_type": "HTTPS-AS2",
        "interface_parameters": {
            "Partner Public Certificate (for verification at Dell)": "verify.crt",
            "Dell AS2 URL": "https://dell.example/as2",
            "Dell Identifier (AS2 ID)": "HIP_AS2", "Partner Identifier (AS2 ID)": "PARTNER_AS2",
            "Certificate CN - Expiry": "partner.example - 2030-01-01",
            "WRONG NEW FIELD": "drop",
        },
    }, "source")
    assert set(src) == AS2_SOURCE_KEYS
    assert src["Partner Verification Certificate"] == "verify.crt"
    assert src["AS2 URL"] == "https://dell.example/as2"
    assert src["Dell Identifier"] == "HIP_AS2"
    assert src["Partner Identifier"] == "PARTNER_AS2"

    tgt = runner.tp_parameters({
        "profile_usage": "Receiver", "interface_type": "HTTPS-AS2",
        "interface_parameters": {
            "Partner AS2 URL": "https://partner.example/as2", "Partner AS2 ID": "PARTNER_AS2",
            "Dell AS2 ID": "HIP_AS2", "Signing Algorithm": "SHA256",
            "Encryption Algorithm": "AES256", "Is Compression Required": "False",
            "Asynchronous MDN Required": "False", "WRONG NEW FIELD": "drop",
        },
    }, "target")
    assert set(tgt) == AS2_TARGET_KEYS
    assert tgt["Partner URL"] == "https://partner.example/as2"
    assert tgt["Partner Identifier"] == "PARTNER_AS2"
    assert tgt["Dell Identifier"] == "HIP_AS2"
    assert "WRONG NEW FIELD" not in tgt


def test_v72_dynamic_canonical_lock_rejects_https_extra_and_does_not_add_file_keys():
    body = {
        "interfaceType": "HTTPS",
        "propertyMap": {key: "x" for key in HTTPS_SOURCE_KEYS},
        "transportProfileName": "HTTPS_ACME_SRC",
        "hipEnvironment": "DEV",
    }
    body["propertyMap"]["Existing Account Name"] = "WRONG-FILE-KEY"
    body["propertyMap"]["invented"] = "bad"
    locked, meta = lock_request_value("validate_source", "payload", body, strict_unknown=False)
    assert set(locked["propertyMap"]) == HTTPS_SOURCE_KEYS
    assert "Existing Account Name" not in locked["propertyMap"]
    assert any("Existing Account Name" in x for x in meta["droppedPaths"])
    check = validate_override_structure("validate_source", "payload", body, interface_family="HTTPS")
    assert check["valid"] is False


def test_v72_https_workspace_override_migrates_wrong_keys_with_https_family(tmp_path: Path):
    inp = json.loads((ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8"))
    src = inp["objects"]["source_transport_profile"]
    src["interface_type"] = "HTTPS"
    src["profile_usage"] = "Sender"
    src["interface_parameters"] = {"Protocol": "REST", "Proxy URI": "acme/in"}
    (tmp_path / "input.json").write_text(json.dumps(inp, indent=2), encoding="utf-8")
    old = {
        "version": 1,
        "overrides": {
            "source_tp": {
                "enabled": True, "requestKind": "payload", "mode": "merge",
                "value": {
                    "transportProfileDetails": [{
                        "interfaceDetails": [{
                            "interfaceType": "HTTPS", "interfaceRole": "Primary",
                            "parameters": {"Protocol": "REST", "Proxy URI": "acme/in", "Existing Account Name": "WRONG", "invented": "BAD"},
                        }]
                    }]
                },
            }
        },
    }
    (tmp_path / "payload_overrides.json").write_text(json.dumps(old, indent=2), encoding="utf-8")
    store = PayloadOverrideStore(tmp_path)
    row = store.get("source_tp") or {}
    params = row["value"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
    assert params == {"Protocol": "REST", "Proxy URI": "acme/in"}
    assert row["structureMigration"]["interfaceFamily"] == "HTTPS"


def test_v72_https_save_override_rejects_new_attribute_but_accepts_value_change(tmp_path: Path):
    inp = json.loads((ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8"))
    inp["objects"]["source_transport_profile"]["interface_type"] = "HTTPS"
    (tmp_path / "input.json").write_text(json.dumps(inp), encoding="utf-8")
    bad = {"transportProfileDetails": [{"interfaceDetails": [{"parameters": {"invented": "BAD"}}]}]}
    with pytest.raises(ValueError, match="CANONICAL_PAYLOAD_STRUCTURE_LOCK"):
        save_override(tmp_path, "source_tp", bad, request_kind="payload", mode="merge", edit_origin="USER")
    good = {"transportProfileDetails": [{"interfaceDetails": [{"parameters": {"Proxy URI": "legrand/in"}}]}]}
    summary = save_override(tmp_path, "source_tp", good, request_kind="payload", mode="merge", edit_origin="USER")
    assert summary["valid"] is True
    stored = PayloadOverrideStore(tmp_path).get("source_tp")
    assert stored["value"]["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"] == {"Proxy URI": "legrand/in"}
    assert stored["interfaceFamily"] == "HTTPS"

def test_v72_https_changes_only_interface_details_inside_tp_create_structure():
    runner = _runner()
    for kind, expected in (("source", HTTPS_SOURCE_KEYS), ("target", HTTPS_TARGET_KEYS)):
        base_tp = deepcopy(runner.source_tp() if kind == "source" else runner.target_tp())
        file_payload = runner.tp_orch_payload(deepcopy(base_tp), kind)
        https_tp = deepcopy(base_tp)
        https_tp["interface_type"] = "HTTPS"
        https_tp["profile_usage"] = "Sender" if kind == "source" else "Receiver"
        https_tp["interface_parameters"] = {
            "Protocol": "REST",
            "HIP URL": "pending" if kind == "source" else "ignored",
            "Proxy URI": "customer/in",
            "Partner URL": "https://partner.example",
            "Gateway URL": "pending",
            "Request Method": "POST",
            "Request Format": "Request Body",
        }
        https_payload = runner.tp_orch_payload(https_tp, kind)
        file_copy = deepcopy(file_payload)
        https_copy = deepcopy(https_payload)
        file_if = file_copy["transportProfileDetails"][0].pop("interfaceDetails")
        https_if = https_copy["transportProfileDetails"][0].pop("interfaceDetails")
        # Exact outer body stays unchanged. Only interfaceDetails is protocol-specific.
        assert https_copy == file_copy
        assert set(https_if[0]["parameters"]) == expected
        assert https_if[0]["interfaceType"] == "HTTPS"
        assert file_if[0]["interfaceType"] in {"SFTP HAFT", "FTP"}
