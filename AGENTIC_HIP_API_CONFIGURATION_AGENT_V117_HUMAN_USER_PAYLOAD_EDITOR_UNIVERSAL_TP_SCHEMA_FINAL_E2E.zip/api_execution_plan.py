from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set


STEP_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "validate_source": {
        "label": "Validate Source TP",
        "group": "Validation",
        "skippable": True,
    },
    "validate_target": {
        "label": "Validate Target TP",
        "group": "Validation",
        "skippable": True,
    },
    "validate_flow": {
        "label": "Validate Flow Name",
        "group": "Validation",
        "skippable": True,
    },
    "account_source": {
        "label": "Source Account",
        "group": "Foundation",
        "skippable": True,
    },
    "account_target": {
        "label": "Target Account",
        "group": "Foundation",
        "skippable": True,
    },
    "partner_target": {
        "label": "Target Partner",
        "group": "Foundation",
        "skippable": True,
    },
    "system_source": {
        "label": "Source System",
        "group": "Foundation",
        "skippable": True,
    },
    "doctype_source": {
        "label": "Source Document Type",
        "group": "Configuration",
        "skippable": True,
        "existing_id_key": "source_document_type_id",
    },
    "doctype_target": {
        "label": "Target Document Type",
        "group": "Configuration",
        "skippable": True,
        "existing_id_key": "target_document_type_id",
    },
    "map": {
        "label": "MAC Map",
        "group": "Configuration",
        "skippable": True,
        "existing_id_key": "map_id",
    },
    "rule": {
        "label": "Mapping Rule",
        "group": "Configuration",
        "skippable": True,
        "existing_id_key": "rule_id",
    },
    "source_tp": {
        "label": "Source TP Orchestration",
        "group": "Orchestration",
        "skippable": True,
    },
    "target_tp": {
        "label": "Target TP Orchestration",
        "group": "Orchestration",
        "skippable": True,
    },
    "source_tp_audit": {
        "label": "Source TP Audit",
        "group": "Verification",
        "skippable": True,
    },
    "target_tp_audit": {
        "label": "Target TP Audit",
        "group": "Verification",
        "skippable": True,
    },
    "flow_create": {
        "label": "Flow Orchestration Create",
        "group": "Orchestration",
        "skippable": True,
        "existing_id_key": "flow_id",
    },
    "flow_deploy": {
        "label": "Flow Orchestration Deploy",
        "group": "Orchestration",
        "skippable": True,
    },
    "flow_history": {
        "label": "Flow Deployment History",
        "group": "Verification",
        "skippable": False,
        "always_verify": True,
    },
}

UHAL_EXISTING_FOUNDATION_PRESET = {
    "account_source",
    "account_target",
    "partner_target",
    "system_source",
}

KEY_ALIASES = {
    "map_primary": "map",
    "map_fallback": "map",
    "source_tp_direct": "source_tp",
    "target_tp_direct": "target_tp",
}

RUNTIME_ID_FIELDS = {
    "source_document_type_id",
    "target_document_type_id",
    "map_id",
    "rule_id",
    "flow_id",
}


def canonical_step_key(step_key: str) -> str:
    value = str(step_key or "").strip()
    return KEY_ALIASES.get(value, value)


def input_sha256(path: Path) -> str:
    if not path.exists():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _positive_int(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, float) and value.is_integer():
        return int(value) if value > 0 else None
    text = str(value or "").strip()
    if text.isdigit():
        parsed = int(text)
        return parsed if parsed > 0 else None
    return None


class ApiExecutionPlan:
    """
    Persisted execution policy for intentionally skipping create/validation APIs
    when the corresponding HIP object is confirmed to already exist.

    Safety properties:
    - The plan is bound to the SHA-256 of the active input.json.
    - Flow deployment history is never skippable.
    - Steps that need numeric IDs for downstream payloads require those IDs.
    - A skipped step is explicitly reported as SKIPPED_BY_USER_EXISTING_OBJECT;
      it is never confused with an HTTP success response.
    """

    def __init__(self, root: Path, input_path: Path):
        self.root = Path(root)
        self.input_path = Path(input_path)
        self.path = self.root / "api_execution_plan.json"
        self._data = self._load()
        self.current_input_sha256 = input_sha256(self.input_path)
        self.errors, self.warnings = self._validate()

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {
                "version": 1,
                "confirmed": False,
                "inputSha256": "",
                "skipSteps": [],
                "existingIds": {},
                "reason": "",
            }
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {
                "version": 1,
                "confirmed": False,
                "inputSha256": "",
                "skipSteps": [],
                "existingIds": {},
                "reason": "",
            }
        return data if isinstance(data, dict) else {}

    def _validate(self) -> tuple[List[str], List[str]]:
        errors: List[str] = []
        warnings: List[str] = []

        selected = self.selected_steps_raw()
        unknown = sorted(step for step in selected if step not in STEP_DEFINITIONS)
        if unknown:
            errors.append("Unknown execution-plan step(s): " + ", ".join(unknown))

        forbidden = sorted(
            step for step in selected
            if step in STEP_DEFINITIONS
            and not STEP_DEFINITIONS[step].get("skippable", False)
        )
        if forbidden:
            errors.append(
                "These verification steps cannot be skipped: "
                + ", ".join(STEP_DEFINITIONS[x]["label"] for x in forbidden)
            )

        configured_hash = str(self._data.get("inputSha256") or "").strip()
        if selected and not configured_hash:
            errors.append(
                "The skip plan is not bound to input.json. Re-save it from the UI."
            )
        elif (
            selected
            and configured_hash
            and self.current_input_sha256
            and configured_hash != self.current_input_sha256
        ):
            warnings.append(
                "The saved API skip plan belongs to a different input.json and is inactive."
            )

        existing = self.existing_ids()
        for step in sorted(selected):
            meta = STEP_DEFINITIONS.get(step) or {}
            id_key = meta.get("existing_id_key")
            if id_key and _positive_int(existing.get(id_key)) is None:
                errors.append(
                    f"{meta.get('label', step)} is selected to skip but "
                    f"existingIds.{id_key} is missing or invalid."
                )

        return errors, warnings

    def selected_steps_raw(self) -> Set[str]:
        values = self._data.get("skipSteps") or []
        if not isinstance(values, list):
            return set()
        return {
            canonical_step_key(str(item))
            for item in values
            if str(item or "").strip()
        }

    def existing_ids(self) -> Dict[str, Any]:
        value = self._data.get("existingIds") or {}
        return value if isinstance(value, dict) else {}

    def is_hash_current(self) -> bool:
        saved = str(self._data.get("inputSha256") or "").strip()
        return bool(saved and self.current_input_sha256 and saved == self.current_input_sha256)

    def active(self) -> bool:
        return (
            bool(self._data.get("confirmed"))
            and self.is_hash_current()
            and not self.errors
        )

    def selected_steps(self) -> Set[str]:
        return self.selected_steps_raw() if self.active() else set()

    def is_skipped(self, step_key: str) -> bool:
        return canonical_step_key(step_key) in self.selected_steps()

    def label(self, step_key: str) -> str:
        key = canonical_step_key(step_key)
        return str((STEP_DEFINITIONS.get(key) or {}).get("label") or key)

    def existing_runtime_id(self, step_key: str) -> Optional[tuple[str, int]]:
        key = canonical_step_key(step_key)
        meta = STEP_DEFINITIONS.get(key) or {}
        id_key = meta.get("existing_id_key")
        if not id_key:
            return None
        value = _positive_int(self.existing_ids().get(id_key))
        if value is None:
            return None
        return id_key, value

    def synthetic_extracted(self, step_key: str) -> Dict[str, Any]:
        key = canonical_step_key(step_key)
        extracted: Dict[str, Any] = {
            "skippedByUser": True,
            "existingObject": True,
            "executionDecision": "SKIP_EXISTING",
            "stepKey": key,
            "stepLabel": self.label(key),
        }

        existing = self.existing_runtime_id(key)
        if existing:
            id_key, value = existing
            extracted["existingIdKey"] = id_key
            extracted["existingId"] = value
            if key == "doctype_source" or key == "doctype_target":
                extracted["documentTypeId"] = value
                extracted["id"] = value
            elif key == "map":
                extracted["mapId"] = value
                extracted["id"] = value
            elif key == "rule":
                extracted["ruleId"] = value
                extracted["id"] = value
            elif key == "flow_create":
                extracted["flowId"] = value
                extracted["id"] = value
                extracted["flowVersion"] = str(
                    self._data.get("existingFlowVersion") or "1.0"
                )

        return extracted

    def apply_existing_runtime_id(
        self,
        step_key: str,
        runtime_state: Dict[str, Any],
    ) -> None:
        existing = self.existing_runtime_id(step_key)
        if not existing:
            return
        id_key, value = existing
        runtime_state[id_key] = value
        if canonical_step_key(step_key) == "flow_create":
            runtime_state["flow_version"] = str(
                self._data.get("existingFlowVersion") or runtime_state.get("flow_version") or "1.0"
            )

    def summary(self) -> Dict[str, Any]:
        selected = self.selected_steps_raw()
        return {
            "version": self._data.get("version", 1),
            "path": str(self.path),
            "confirmed": bool(self._data.get("confirmed")),
            "active": self.active(),
            "inputSha256": str(self._data.get("inputSha256") or ""),
            "currentInputSha256": self.current_input_sha256,
            "inputMatches": self.is_hash_current(),
            "skipSteps": sorted(selected),
            "skipLabels": [self.label(x) for x in sorted(selected)],
            "executeSteps": [
                key for key, meta in STEP_DEFINITIONS.items()
                if meta.get("skippable") and key not in selected
            ],
            "alwaysVerify": [
                key for key, meta in STEP_DEFINITIONS.items()
                if meta.get("always_verify")
            ],
            "existingIds": self.existing_ids(),
            "existingFlowVersion": str(self._data.get("existingFlowVersion") or "1.0"),
            "reason": str(self._data.get("reason") or ""),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


def save_execution_plan(
    root: Path,
    input_path: Path,
    skip_steps: Iterable[str],
    existing_ids: Optional[Dict[str, Any]] = None,
    *,
    confirmed: bool,
    reason: str = "",
    existing_flow_version: str = "1.0",
) -> Dict[str, Any]:
    root = Path(root)
    input_path = Path(input_path)

    normalized: List[str] = []
    for raw in skip_steps:
        key = canonical_step_key(str(raw))
        if not key or key in normalized:
            continue
        meta = STEP_DEFINITIONS.get(key)
        if not meta:
            raise ValueError(f"Unknown API execution-plan step: {key}")
        if not meta.get("skippable", False):
            raise ValueError(f"{meta.get('label', key)} cannot be skipped.")
        normalized.append(key)

    cleaned_ids: Dict[str, int] = {}
    for key, value in (existing_ids or {}).items():
        if key not in RUNTIME_ID_FIELDS:
            continue
        parsed = _positive_int(value)
        if parsed is not None:
            cleaned_ids[key] = parsed

    if normalized and not confirmed:
        raise ValueError(
            "Confirm that the selected HIP objects already exist before saving the skip plan."
        )

    for step in normalized:
        id_key = (STEP_DEFINITIONS.get(step) or {}).get("existing_id_key")
        if id_key and id_key not in cleaned_ids:
            raise ValueError(
                f"{STEP_DEFINITIONS[step]['label']} requires an existing numeric ID "
                f"({id_key}) before it can be skipped."
            )

    data = {
        "version": 1,
        "savedAt": dt.datetime.now().isoformat(),
        "confirmed": bool(normalized and confirmed),
        "inputSha256": input_sha256(input_path) if normalized else "",
        "skipSteps": normalized,
        "existingIds": cleaned_ids,
        "existingFlowVersion": str(existing_flow_version or "1.0"),
        "reason": str(reason or "").strip(),
    }

    path = root / "api_execution_plan.json"
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return ApiExecutionPlan(root, input_path).summary()


def clear_execution_plan(root: Path, input_path: Path) -> Dict[str, Any]:
    return save_execution_plan(
        root,
        input_path,
        [],
        {},
        confirmed=False,
        reason="",
    )
