# Compatibility launcher. RUN_HIP_STUDIO.ps1 performs runtime_preflight.py before opening Streamlit.
& "$PSScriptRoot\RUN_HIP_STUDIO.ps1"
exit $LASTEXITCODE
