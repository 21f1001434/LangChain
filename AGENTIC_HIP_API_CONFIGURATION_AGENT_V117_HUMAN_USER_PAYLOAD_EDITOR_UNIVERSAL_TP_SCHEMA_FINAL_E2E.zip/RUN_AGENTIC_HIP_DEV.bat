@echo off
setlocal
cd /d "%~dp0"
where bun >nul 2>nul
if errorlevel 1 (
  echo Bun is required for development mode. Run SETUP_AGENTIC_HIP.bat first.
  exit /b 1
)

echo ============================================================
echo   Agentic HIP API Configuration Agent - DEV
if /I "%HIP_BACKEND_HOT_RELOAD%"=="1" (
  echo   Backend: SAFE hot reload ^(webapp\backend\app only^)
  set "BACKEND_RELOAD=--reload --reload-dir webapp\backend\app"
) else (
  echo   Backend: stable mode ^(hot reload disabled^)
  echo   Frontend: Bun/Vite hot reload enabled
  echo   To opt into backend reload: set HIP_BACKEND_HOT_RELOAD=1
  set "BACKEND_RELOAD="
)
echo ============================================================

start "Agentic HIP Backend DEV" cmd /k "python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765 %BACKEND_RELOAD%"
timeout /t 2 /nobreak >nul
pushd webapp\frontend
start "Agentic HIP Frontend DEV" cmd /k "bun run dev"
popd
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:5173
exit /b 0
