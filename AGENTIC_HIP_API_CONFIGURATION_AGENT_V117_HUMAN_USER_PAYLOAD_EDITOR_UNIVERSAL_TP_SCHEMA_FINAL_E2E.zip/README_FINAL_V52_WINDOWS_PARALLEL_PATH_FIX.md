# V52 — Windows Parallel Path / U-HAUL LIVE Execution Fix

V52 fixes the U-HAUL single/parallel LIVE failure reported on Windows where a validated queued snapshot became BLOCKED before the first API step with `[Errno 2] No such file or directory` while copying an `input_files` XML file.

## Root cause

The source queue path was valid, but the old execution layout appended `parallel_runs/<batch>/jobs/<job>/...`. In a deep OneDrive project path this pushed the destination over the classic Windows path-length boundary. The observed U-HAUL example is approximately 244 characters in the queue and about 267 characters in the old run workspace. Windows can report this as a misleading file-not-found error.

## Fix

- LIVE parallel jobs now stage into a short isolated physical workspace under the OS temp directory (`%TEMP%\hip_exec\<project>\<batch>\<job>` on Windows).
- Logical batch/job IDs, UI status, customer identity and report metadata remain unchanged.
- `HIP_PARALLEL_EXEC_ROOT` can override the short execution base when required by operations.
- New queue job IDs are compact opaque IDs to reduce queue-path depth as well.
- Before `run_agent.py` starts, the runner hashes every execution-critical snapshot file and verifies the staged copy is byte-for-byte complete. Missing/changed files block before any LIVE API call with an actionable staging-integrity error.
- U-HAUL XML/JAR/XBM/customer evidence files are copied into each execution workspace; execution never relies on the original project file path.
- Each job HTML report is copied back into the persistent batch report area so reports remain available even though the execution workspace is intentionally short/temp-based.
- The legacy parallel configuration runner uses the same short-workspace strategy.

## Regression coverage

V52 adds a deep OneDrive/Windows-style path regression, an exact shipped U-HAUL evidence-file staging regression for `UHAUL_4506868691_69D_ASN_VSHIP_20260410124029.xml`, and a staging-integrity/report persistence guard.

Non-LIVE validation confirms the shipped U-HAUL source is 18/18 valid, all 19 execution-critical snapshot files stage successfully, the short execution path is 46 characters in the packaging environment, the U-HAUL XML is present, and the staged copy remains 18/18 valid.

No LIVE Dell/HIP mutating API calls are executed during packaging.
