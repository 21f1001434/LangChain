from __future__ import annotations

import hashlib
import io
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None


API_ALIASES: Dict[str, Dict[str, Any]] = {
    "tp_validate": {
        "title": "Transport Profile Validate Unique Interface",
        "keywords": [
            "validate-unique-interface-detail",
            "validate unique interface",
            "transport profile validation",
        ],
    },
    "flow_validate": {
        "title": "Flow Validate Name",
        "keywords": [
            "/api/flows/validate-name",
            "validate flow name",
            "flow name is unique",
        ],
    },
    "account": {
        "title": "Account Create",
        "keywords": [
            "/api/authz/account",
            "create account",
            "account create",
        ],
    },
    "partner": {
        "title": "Partner Create",
        "keywords": [
            "/api/authz/partner",
            "create partner",
            "partner create",
            "x-account-name",
        ],
    },
    "system": {
        "title": "System Create",
        "keywords": [
            "domain-systems",
            "create system",
            "system create",
        ],
    },
    "document_type": {
        "title": "Document Type Create",
        "keywords": [
            "/api/document-type",
            "document type",
            "macdocumenttypecreaterequest",
        ],
    },
    "map": {
        "title": "MAC Map Create",
        "keywords": [
            "/api/mac-map",
            "mac map",
            "mapdatadto",
            "crossreferencemaplist",
        ],
    },
    "rule": {
        "title": "Rule Create",
        "keywords": [
            "/api/rule",
            "macruledto",
            "ruleconditions",
            "executeactionwhen",
        ],
    },
    "orch_tp_create": {
        "title": "Transport Profile Orchestration Create",
        "keywords": [
            "transport-profiles/orchestration/create",
            "tp orchestration",
            "transport profile orchestration",
        ],
    },
    "orch_flow_create": {
        "title": "Flow Orchestration Create",
        "keywords": [
            "flows/orchestration/create",
            "flow orchestration create",
            "flowdefinition",
        ],
    },
    "orch_flow_deploy": {
        "title": "Flow Orchestration Deploy",
        "keywords": [
            "flows/orchestration/deploy",
            "flow orchestration deploy",
            "deployment orchestration",
        ],
    },
    "flow_deploy_history": {
        "title": "Flow Deployment History",
        "keywords": [
            "flows/deployment/history",
            "deployment history",
            "deploymentstatus",
        ],
    },
    "tp_audits": {
        "title": "Transport Profile Audits",
        "keywords": [
            "transport-profiles/audits",
            "transport profile audits",
            "workorderid",
        ],
    },
}


BUILTIN_CONTRACTS: Dict[str, Dict[str, Any]] = {
    "tp_validate": {
        "method": "POST",
        "pathContains": "validate-unique-interface-detail",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "interfaceType",
            "propertyMap",
            "transportProfileName",
            "hipEnvironment",
        ],
        "fieldTypes": {
            "interfaceType": "string",
            "propertyMap": "object",
            "transportProfileName": "string",
            "hipEnvironment": "string",
        },
    },
    "flow_validate": {
        "method": "GET",
        "pathContains": "flows/validate-name",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": ["flowName"],
        "source": "query",
    },
    "account": {
        "method": "POST",
        "pathContains": "/account",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": ["accountName", "domains"],
        "fieldTypes": {
            "accountName": "string",
            "domains": "array",
        },
    },
    "partner": {
        "method": "POST",
        "pathContains": "/partner",
        "requiredHeaders": ["x-requester-id", "x-account-name"],
        "requiredFields": [
            "name",
            "partnerIdentifier",
            "partnerIdentifierValue",
            "primaryDomain",
        ],
    },
    "system": {
        "method": "POST",
        "pathContains": "/system",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "systemName",
            "businessContactName",
            "supportContactName",
            "businessContactNumber",
            "supportContactNumber",
            "businessContactEmail",
            "supportContactEmail",
        ],
        "forbiddenFields": ["domainId"],
    },
    "document_type": {
        "method": "POST",
        "pathContains": "document-type",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "name",
            "dataFormatType",
            "transactionType",
            "version",
            "statusDisabled",
            "description",
            "validationType",
            "schemaFileName",
            "schemaFileContent",
            "hipEnvironment",
            "documentIdentifier",
            "lastModifiedBy",
            "attributes",
            "createdBy",
        ],
        "forbiddenFields": ["filemask", "ediDelimiters"],
        "fieldTypes": {
            "name": "string",
            "dataFormatType": "string",
            "transactionType": "string",
            "version": "string",
            "statusDisabled": "boolean",
            "documentIdentifier": "object",
            "attributes": "array",
        },
        "allowedValues": {
            "transactionType": ["INBOUND", "OUTBOUND"],
        },
        "nestedRequiredFields": [
            "documentIdentifier.operator",
            "documentIdentifier.attributeList",
        ],
        "allowEmptyFields": [
            "schemaFileName",
            "schemaFileContent",
            "lastModifiedBy",
        ],
    },
    "map": {
        "method": "POST",
        "pathContains": "mac-map",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "mapName",
            "hipEnvironment",
            "mapIdentifier",
            "mapIdentifierVersion",
            "requestedBy",
            "status",
            "mapClassName",
            "mapFileName",
            "mapData",
            "crossReferenceMapList",
        ],
        "fieldTypes": {
            "mapName": "string",
            "mapIdentifier": "string",
            "mapData": "string",
            "crossReferenceMapList": "array",
        },
        "allowEmptyFields": ["crossReferenceMapList"],
    },
    "rule": {
        "method": "POST",
        "pathContains": "/rule",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "name",
            "hipEnvironment",
            "ruleType",
            "documentTypeName",
            "documentTypeVersion",
            "version",
            "createdBy",
            "ruleConditions",
            "actions",
        ],
        "fieldTypes": {
            "ruleConditions": "array",
            "actions": "array",
        },
    },
    "orch_tp_create": {
        "method": "POST",
        "pathContains": "transport-profiles/orchestration/create",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "operation",
            "systemName",
            "systemType",
            "requestedBy",
            "hipEnvironment",
            "transportProfileDetails",
        ],
        "forbiddenFields": [
            "domainId",
            "systemId",
            "user",
            "workType",
        ],
        "nestedRequiredFields": [
            "transportProfileDetails.0.transportProfileName",
            "transportProfileDetails.0.transportProfileUsage",
            "transportProfileDetails.0.transportProfileOperation",
            "transportProfileDetails.0.deploymentGroupName",
            "transportProfileDetails.0.interfaceDetails",
            "transportProfileDetails.0.documentTypeDetails",
        ],
    },
    "orch_flow_create": {
        "method": "POST",
        "pathContains": "flows/orchestration/create",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "flowName",
            "flowDescription",
            "flowTemplateName",
            "flowType",
            "operation",
            "flowDefinition",
            "flowVersion",
            "user",
        ],
        "fieldTypes": {
            "flowDefinition": "string",
            "user": "object",
        },
        "nestedRequiredFields": [
            "user.userId",
            "user.emailId",
        ],
        "forbiddenFields": ["workType"],
        "notes": ["workType is HIP-derived; omit it (preferred) or send null. Never send a non-null workType object."],
    },
    "orch_flow_deploy": {
        "method": "POST",
        "pathContains": "flows/orchestration/deploy",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "flowName",
            "flowVersion",
            "environment",
            "user",
        ],
        "nestedRequiredFields": [
            "user.userId",
            "user.emailId",
        ],
        "forbiddenFields": ["workType"],
        "notes": ["workType is HIP-derived; omit it (preferred) or send null. Never send a non-null workType object."],
    },
    "flow_deploy_history": {
        "method": "GET",
        "pathContains": "flows/deployment/history",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "flowName",
            "flowVersion",
            "environment",
        ],
        "source": "query",
    },
    "tp_audits": {
        "method": "GET",
        "pathContains": "transport-profiles/audits",
        "requiredHeaders": ["x-requester-id"],
        "requiredFields": [
            "transportProfileName",
            "hipEnvironment",
        ],
        "source": "query",
    },
}


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _redact_sensitive(text: str) -> str:
    value = text or ""
    patterns = [
        (
            r'(?i)(authorization\s*[:=]\s*bearer\s+)'
            r'[A-Za-z0-9._~+\-/=]+',
            r'\1<REDACTED>',
        ),
        (
            r'(?i)(client[_ -]?secret\s*["\']?\s*[:=]\s*["\']?)'
            r'[^"\'\s,}]+',
            r'\1<REDACTED>',
        ),
        (
            r'(?i)(access[_ -]?token\s*["\']?\s*[:=]\s*["\']?)'
            r'[^"\'\s,}]+',
            r'\1<REDACTED>',
        ),
    ]
    for pattern, replacement in patterns:
        value = re.sub(pattern, replacement, value)
    return value


def _compact_for_aia(
    value: Any,
    key: str = "",
    max_string: int = 6000,
) -> Any:
    if isinstance(value, dict):
        return {
            str(k): _compact_for_aia(v, str(k), max_string)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [
            _compact_for_aia(v, key, max_string)
            for v in value
        ]
    if isinstance(value, str):
        lower_key = key.lower()
        if lower_key in {
            "mapdata",
            "crossreferencemapdata",
            "schemafilecontent",
            "inputschema",
            "outputschema",
        }:
            return f"<LONG_CONTENT length={len(value)}>"
        if len(value) > max_string:
            return (
                value[:max_string]
                + f"...<TRUNCATED length={len(value)}>"
            )
    return value


def _checksum(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_filename(name: str) -> str:
    base = Path(name).name
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", base)


def _path_exists(data: Any, dotted_path: str) -> bool:
    current = data
    for part in dotted_path.split("."):
        if isinstance(current, list):
            try:
                index = int(part)
            except Exception:
                return False
            if index < 0 or index >= len(current):
                return False
            current = current[index]
        elif isinstance(current, dict):
            if part not in current:
                return False
            current = current[part]
        else:
            return False
    return True


def _path_value(data: Any, dotted_path: str) -> Any:
    current = data
    for part in dotted_path.split("."):
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except Exception:
                return None
        elif isinstance(current, dict):
            if part not in current:
                return None
            current = current[part]
        else:
            return None
    return current


def _type_ok(value: Any, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "boolean":
        return isinstance(value, bool)
    return True


@dataclass
class PdfIngestionResult:
    filename: str
    checksum: str
    pages: int
    characters: int
    extraction_method: str
    detected_apis: List[str]
    warnings: List[str]
    text_path: str
    index_path: str


class PdfApiKnowledgeBase:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.knowledge_dir = self.root / "knowledge" / "api_pdf"
        self.upload_dir = self.knowledge_dir / "uploads"
        self.text_dir = self.knowledge_dir / "text"
        self.index_dir = self.knowledge_dir / "indexes"
        self.contract_dir = self.knowledge_dir / "contracts"
        for directory in [
            self.upload_dir,
            self.text_dir,
            self.index_dir,
            self.contract_dir,
        ]:
            directory.mkdir(parents=True, exist_ok=True)

    def has_documents(self) -> bool:
        return any(self.index_dir.glob("*.json"))

    def list_documents(self) -> List[Dict[str, Any]]:
        documents: List[Dict[str, Any]] = []
        for path in sorted(self.index_dir.glob("*.json")):
            try:
                documents.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                continue
        return documents

    def _extract_with_pypdf(
        self,
        data: bytes,
    ) -> Tuple[List[str], List[str]]:
        if PdfReader is None:
            return [], ["pypdf is not installed."]
        warnings: List[str] = []
        pages: List[str] = []
        reader = PdfReader(io.BytesIO(data))
        for index, page in enumerate(reader.pages, start=1):
            try:
                page_text = page.extract_text() or ""
            except Exception as exc:
                page_text = ""
                warnings.append(
                    f"pypdf page {index} extraction failed: {exc}"
                )
            pages.append(page_text)
        return pages, warnings

    def _extract_with_pymupdf(
        self,
        data: bytes,
    ) -> Tuple[List[str], List[str]]:
        if fitz is None:
            return [], ["PyMuPDF is not installed."]
        warnings: List[str] = []
        pages: List[str] = []
        doc = fitz.open(stream=data, filetype="pdf")
        try:
            for index, page in enumerate(doc, start=1):
                try:
                    pages.append(page.get_text("text") or "")
                except Exception as exc:
                    pages.append("")
                    warnings.append(
                        f"PyMuPDF page {index} extraction failed: {exc}"
                    )
        finally:
            doc.close()
        return pages, warnings

    def extract_pdf(
        self,
        data: bytes,
    ) -> Tuple[List[str], str, List[str]]:
        pages, warnings = self._extract_with_pypdf(data)
        total = sum(len(_normalise(page)) for page in pages)
        method = "pypdf"

        if total < 500:
            fallback_pages, fallback_warnings = (
                self._extract_with_pymupdf(data)
            )
            fallback_total = sum(
                len(_normalise(page))
                for page in fallback_pages
            )
            warnings.extend(fallback_warnings)
            if fallback_total > total:
                pages = fallback_pages
                total = fallback_total
                method = "pymupdf"

        if total < 200:
            warnings.append(
                "Very little searchable text was extracted. "
                "The PDF may be scanned/image-only. Export a searchable PDF "
                "from the API portal before strict validation."
            )
        return pages, method, warnings

    def _detect_api_pages(
        self,
        pages: List[str],
    ) -> Dict[str, List[int]]:
        detected: Dict[str, List[int]] = {}
        for page_no, text in enumerate(pages, start=1):
            lower = text.lower()
            for api_key, spec in API_ALIASES.items():
                if any(
                    keyword.lower() in lower
                    for keyword in spec["keywords"]
                ):
                    detected.setdefault(api_key, []).append(page_no)
        return detected

    def ingest_bytes(
        self,
        filename: str,
        data: bytes,
    ) -> PdfIngestionResult:
        if not data.startswith(b"%PDF"):
            raise ValueError(
                f"{filename} does not appear to be a PDF file."
            )

        safe_name = _safe_filename(filename)
        digest = _checksum(data)
        stem = f"{Path(safe_name).stem}_{digest[:12]}"

        upload_path = self.upload_dir / f"{stem}.pdf"
        text_path = self.text_dir / f"{stem}.txt"
        index_path = self.index_dir / f"{stem}.json"

        upload_path.write_bytes(data)
        pages, method, warnings = self.extract_pdf(data)

        combined_parts: List[str] = []
        for page_no, page_text in enumerate(pages, start=1):
            combined_parts.append(
                f"\n===== PAGE {page_no} =====\n{page_text}\n"
            )
        combined = "".join(combined_parts)
        text_path.write_text(combined, encoding="utf-8")

        detected_pages = self._detect_api_pages(pages)
        index = {
            "filename": safe_name,
            "storedPdf": str(upload_path),
            "checksum": digest,
            "pages": len(pages),
            "characters": len(_normalise(combined)),
            "extractionMethod": method,
            "warnings": warnings,
            "detectedApis": sorted(detected_pages),
            "apiPages": detected_pages,
            "textPath": str(text_path),
        }
        index_path.write_text(
            json.dumps(index, indent=2),
            encoding="utf-8",
        )

        return PdfIngestionResult(
            filename=safe_name,
            checksum=digest,
            pages=len(pages),
            characters=index["characters"],
            extraction_method=method,
            detected_apis=sorted(detected_pages),
            warnings=warnings,
            text_path=str(text_path),
            index_path=str(index_path),
        )

    def _relevant_text(
        self,
        api_key: str,
        max_chars: int = 18000,
    ) -> str:
        parts: List[str] = []
        remaining = max_chars
        for index in self.list_documents():
            pages = index.get("apiPages", {}).get(api_key) or []
            if not pages:
                continue
            text_path = Path(index["textPath"])
            if not text_path.exists():
                continue
            full_text = text_path.read_text(
                encoding="utf-8",
                errors="ignore",
            )
            for page_no in pages:
                marker = f"===== PAGE {page_no} ====="
                next_marker = f"===== PAGE {page_no + 1} ====="
                start = full_text.find(marker)
                if start < 0:
                    continue
                end = full_text.find(next_marker, start)
                if end < 0:
                    end = len(full_text)
                piece = full_text[start:end]
                if len(piece) > remaining:
                    piece = piece[:remaining]
                parts.append(piece)
                remaining -= len(piece)
                if remaining <= 0:
                    return _redact_sensitive("\n".join(parts))
        return _redact_sensitive("\n".join(parts))

    def extract_contracts_with_aia(
        self,
        judge: Any,
    ) -> Dict[str, Any]:
        extracted: Dict[str, Any] = {}
        for api_key, alias in API_ALIASES.items():
            source_text = self._relevant_text(api_key)
            if not source_text.strip():
                continue

            system = (
                "You extract Dell HIP API contracts from user-provided API "
                "documentation. Use only the supplied PDF text. Do not fill "
                "gaps from general knowledge. Return JSON only with keys: "
                "apiKey, title, method, endpoint, requiredHeaders, "
                "requiredFields, optionalFields, fieldTypes, allowedValues, "
                "forbiddenFields, successHttpStatuses, businessSuccessRules, "
                "notes, evidencePages, confidence. If a detail is absent, "
                "use an empty value and explain it in notes."
            )
            user = json.dumps({
                "apiKey": api_key,
                "title": alias["title"],
                "pdfText": source_text,
            }, indent=2)

            contract = judge.complete_json(
                system=system,
                user=user,
                temperature=0,
            )
            contract["apiKey"] = api_key
            extracted[api_key] = contract

        output = {
            "generatedAt": __import__("datetime").datetime.now().isoformat(),
            "contracts": extracted,
        }
        path = self.contract_dir / "pdf_contracts_latest.json"
        path.write_text(
            json.dumps(output, indent=2, default=str),
            encoding="utf-8",
        )
        return output

    def load_pdf_contracts(self) -> Dict[str, Dict[str, Any]]:
        path = self.contract_dir / "pdf_contracts_latest.json"
        if not path.exists():
            return {}
        try:
            return (
                json.loads(path.read_text(encoding="utf-8"))
                .get("contracts", {})
            )
        except Exception:
            return {}

    def merged_contract(
        self,
        api_key: str,
    ) -> Dict[str, Any]:
        built_in = json.loads(
            json.dumps(BUILTIN_CONTRACTS.get(api_key, {}))
        )
        pdf_contract = self.load_pdf_contracts().get(api_key) or {}

        # PDF values supplement the verified built-in contract. Confirmed
        # Dev corrections and successful-run rules remain authoritative.
        for key, value in pdf_contract.items():
            if value in (None, "", [], {}):
                continue

            if key in {"requiredFields", "requiredHeaders"}:
                # Preserve the verified required set. Keep the PDF extraction
                # as evidence instead of turning a generic Swagger field into
                # a new blocker.
                built_in[f"pdfExtracted{key[0].upper()}{key[1:]}"] = (
                    value if isinstance(value, list) else [value]
                )
                continue

            if key in {
                "optionalFields",
                "businessSuccessRules",
                "notes",
                "evidencePages",
            }:
                existing = built_in.get(key) or []
                incoming = value if isinstance(value, list) else [value]
                built_in[key] = list(dict.fromkeys(
                    [str(x) for x in existing + incoming]
                ))
                continue

            if key == "forbiddenFields":
                existing = built_in.get(key) or []
                incoming = value if isinstance(value, list) else [value]
                built_in[key] = list(dict.fromkeys(
                    [str(x) for x in existing + incoming]
                ))
                continue

            if key in {"fieldTypes", "allowedValues"}:
                merged = dict(built_in.get(key) or {})
                if isinstance(value, dict):
                    for field, field_value in value.items():
                        merged.setdefault(field, field_value)
                built_in[key] = merged
                continue

            if key in {"method", "pathContains", "source"}:
                if not built_in.get(key):
                    built_in[key] = value
                continue

            # Keep all other PDF metadata under a namespaced key.
            built_in.setdefault("pdfMetadata", {})[key] = value

        return built_in

    def validate_request(
        self,
        api_key: str,
        method: str,
        url: str,
        headers: Dict[str, Any],
        payload: Any = None,
        params: Any = None,
    ) -> Dict[str, Any]:
        contract = self.merged_contract(api_key)
        issues: List[Dict[str, str]] = []

        def issue(
            severity: str,
            field: str,
            message: str,
            source: str = "verified-contract",
        ) -> None:
            issues.append({
                "severity": severity,
                "field": field,
                "message": message,
                "source": source,
            })

        expected_method = str(contract.get("method") or "").upper()
        if expected_method and method.upper() != expected_method:
            issue(
                "ERROR",
                "method",
                f"Expected {expected_method}, received {method.upper()}.",
            )

        path_contains = str(contract.get("pathContains") or "")
        if path_contains and path_contains.lower() not in url.lower():
            issue(
                "ERROR",
                "url",
                f"URL does not contain expected path '{path_contains}'.",
            )

        lower_headers = {
            str(k).lower(): v for k, v in (headers or {}).items()
        }
        for required_header in contract.get("requiredHeaders") or []:
            if not lower_headers.get(str(required_header).lower()):
                issue(
                    "ERROR",
                    f"header.{required_header}",
                    f"Required header '{required_header}' is missing.",
                )

        data = (
            params
            if contract.get("source") == "query"
            else payload
        )
        if not isinstance(data, dict):
            issue(
                "ERROR",
                "request",
                "The request body/query parameters must be a JSON object.",
            )
            data = {}

        allow_empty = {
            str(field)
            for field in contract.get("allowEmptyFields") or []
        }
        for field in contract.get("requiredFields") or []:
            field = str(field)
            value = _path_value(data, field)
            if field in allow_empty:
                missing = not _path_exists(data, field)
            else:
                missing = value in (None, "", [], {})
            if missing:
                issue(
                    "ERROR",
                    field,
                    f"Required field '{field}' is missing or empty.",
                )

        for field in contract.get("nestedRequiredFields") or []:
            value = _path_value(data, str(field))
            if value in (None, "", [], {}):
                issue(
                    "ERROR",
                    str(field),
                    f"Required nested field '{field}' is missing or empty.",
                )

        for field in contract.get("forbiddenFields") or []:
            value = _path_value(data, str(field))
            if value is not None:
                issue(
                    "ERROR",
                    str(field),
                    f"Field '{field}' is not allowed by the Dev-reviewed "
                    "contract for this request.",
                )

        for field, expected_type in (
            contract.get("fieldTypes") or {}
        ).items():
            value = _path_value(data, str(field))
            if value is not None and not _type_ok(
                value,
                str(expected_type),
            ):
                issue(
                    "ERROR",
                    str(field),
                    f"Expected type {expected_type}; received "
                    f"{type(value).__name__}.",
                )

        for field, allowed_values in (
            contract.get("allowedValues") or {}
        ).items():
            value = _path_value(data, str(field))
            if (
                value is not None
                and allowed_values
                and value not in allowed_values
            ):
                issue(
                    "ERROR",
                    str(field),
                    f"Value {value!r} is not in allowed values "
                    f"{allowed_values!r}.",
                )

        # API-specific semantic checks.
        if api_key == "document_type":
            identifier = data.get("documentIdentifier") or {}
            if not isinstance(identifier.get("attributeList"), list):
                issue(
                    "ERROR",
                    "documentIdentifier.attributeList",
                    "attributeList must be an array.",
                )
            for index, item in enumerate(
                identifier.get("attributeList") or []
            ):
                if not isinstance(item, dict) or not item.get(
                    "derivedFrom"
                ):
                    issue(
                        "ERROR",
                        f"documentIdentifier.attributeList.{index}",
                        "Each identifier row requires derivedFrom.",
                    )

        if api_key == "map":
            if data.get("crossReferenceMapList") is None:
                issue(
                    "ERROR",
                    "crossReferenceMapList",
                    "crossReferenceMapList must never be null.",
                )

        if api_key == "rule":
            if "documentTypeId" in data:
                issue(
                    "ERROR",
                    "documentTypeId",
                    "Dev feedback 2026-08-28: remove documentTypeId from the Mapping Rule payload.",
                )
            actions = data.get("actions") if isinstance(data.get("actions"), list) else []
            for index, action in enumerate(actions):
                params = action.get("params") if isinstance(action, dict) and isinstance(action.get("params"), dict) else {}
                if "mapId" in params:
                    issue(
                        "ERROR",
                        f"actions.{index}.params.mapId",
                        "Dev feedback 2026-08-28: remove mapId from Rule actions.params.",
                    )

        if api_key == "orch_flow_create":
            definition = data.get("flowDefinition")
            if isinstance(definition, str):
                try:
                    inner = json.loads(definition)
                    inner_text = json.dumps(inner)
                    if '"documentTypeId"' in inner_text:
                        issue(
                            "ERROR",
                            "flowDefinition",
                            "Dev correction requires Document Type names and "
                            "versions instead of documentTypeId fields.",
                        )
                    if '"targetDocumentTypeId"' in inner_text:
                        issue(
                            "ERROR",
                            "flowDefinition",
                            "targetDocumentTypeId must be replaced by target "
                            "Document Type name/version.",
                        )
                except Exception as exc:
                    issue(
                        "ERROR",
                        "flowDefinition",
                        f"flowDefinition is not valid escaped JSON: {exc}",
                    )

        errors = [
            item for item in issues
            if item["severity"] == "ERROR"
        ]
        warnings = [
            item for item in issues
            if item["severity"] != "ERROR"
        ]
        return {
            "apiKey": api_key,
            "valid": not errors,
            "contract": contract,
            "errors": errors,
            "warnings": warnings,
            "pdfDocumentsAvailable": self.has_documents(),
        }

    def aia_validate_request(
        self,
        judge: Any,
        api_key: str,
        method: str,
        url: str,
        headers: Dict[str, Any],
        payload: Any = None,
        params: Any = None,
    ) -> Dict[str, Any]:
        source_text = self._relevant_text(api_key, max_chars=12000)
        if not source_text.strip():
            return {
                "performed": False,
                "valid": True,
                "errors": [],
                "warnings": [
                    "No matching API section was found in the ingested PDF."
                ],
            }

        safe_headers = {
            key: ("<PRESENT>" if value else "<MISSING>")
            for key, value in headers.items()
            if key.lower() != "authorization"
        }

        system = (
            "You are a strict Dell HIP API request validator. Compare the "
            "request only against the supplied user PDF text. Also respect "
            "the confirmed Dev corrections listed in the request context. "
            "Do not invent missing contract details. Return JSON only with "
            "keys valid, errors, warnings, evidence. errors and warnings are "
            "arrays of concise strings."
        )
        user = json.dumps({
            "apiKey": api_key,
            "method": method,
            "url": url,
            "headers": safe_headers,
            "payload": _compact_for_aia(payload),
            "params": _compact_for_aia(params),
            "confirmedDevCorrections": BUILTIN_CONTRACTS.get(
                api_key, {}
            ),
            "pdfText": source_text,
        }, indent=2, default=str)[:24000]

        result = judge.complete_json(
            system=system,
            user=user,
            temperature=0,
        )
        return {
            "performed": True,
            "valid": bool(result.get("valid", False)),
            "errors": result.get("errors") or [],
            "warnings": result.get("warnings") or [],
            "evidence": result.get("evidence") or [],
        }
