from __future__ import annotations

from pathlib import Path

from report_insights import analyze_api_response, format_duration_ms, format_duration_seconds
from webapp.backend.app.report_renderer import render_parallel_batch_html, render_react_execution_html

ROOT = Path(__file__).resolve().parent


def test_human_duration_switches_to_minutes_and_hours():
    assert format_duration_seconds(59.5).endswith("s")
    assert format_duration_seconds(61) == "1m 01s"
    assert format_duration_seconds(3661) == "1h 01m 01s"
    assert format_duration_ms(125000) == "2m 05s"


def test_agent_response_judge_reads_business_body_not_only_http():
    passed = analyze_api_response({"status_code": 201, "classification": "PASS_SUCCESS", "business_success": True, "response_preview": {"status": "created"}})
    existing = analyze_api_response({"status_code": 409, "classification": "PAYLOAD_SCHEMA_OR_VALIDATION_ERROR", "response_preview": "Transport profile already exists"})
    business_fail = analyze_api_response({"status_code": 200, "classification": "HTTP_SUCCESS_BUT_BUSINESS_ERROR", "response_preview": {"success": False, "message": "validation error"}})
    ambiguous = analyze_api_response({"status_code": 200, "classification": "UNKNOWN", "response_preview": {"id": 1}})
    assert passed["verdict"] == "PASS"
    assert existing["verdict"] == "PASS" and existing["outcome"] == "EXISTING"
    assert business_fail["verdict"] == "FAIL"
    assert ambiguous["verdict"] == "WARNING"


def test_react_report_is_summary_first_and_raw_evidence_collapsed():
    record = {
        "id": "e1", "status": "PASS", "elapsedMs": 125000,
        "flow": {"nodes": [{"id": "n1", "api_key": "partner_target", "label": "Partner"}], "edges": []},
        "events": [
            {"type": "node.request", "nodeId": "n1", "request": {"payload": {"partnerIdentifierValue": "12345666"}}},
            {"type": "node.completed", "nodeId": "n1", "result": {"status_code": 409, "classification": "PAYLOAD_SCHEMA_OR_VALIDATION_ERROR", "response_preview": "Partner already exists"}, "verdict": {"verdict": "PASS", "outcome": "EXISTING"}, "timing": {"apiMs": 62000, "totalMs": 62000}},
        ],
    }
    text = render_react_execution_html(record, {"customer": "U-HAUL", "direction": "Outbound", "transaction_code": "856"})
    assert "Agent final assessment" in text
    assert "PASS" in text and "EXISTING" in text
    assert "2m 05s" in text
    assert "Effective request" in text and "Response / verdict" in text
    assert '<details class="evidence">' in text


def test_parallel_report_has_four_business_outcomes_and_human_time():
    text = render_parallel_batch_html({
        "batchId": "b1", "parallelWorkers": 2, "configurationCount": 2,
        "passCount": 1, "warningCount": 1, "failCount": 0, "blockedCount": 0,
        "overallVerdict": "WARNING", "elapsedSeconds": 3661,
        "results": [
            {"jobId": "j1", "customer": "U-HAUL", "status": "WARNING", "elapsedSeconds": 62, "agentSummary": {"reason": "Existing partner reused."}},
            {"jobId": "j2", "customer": "LEGRAND", "status": "PASS", "elapsedSeconds": 7},
        ],
    })
    assert "1h 01m 01s" in text
    assert "WARNING" in text and "FAIL" in text and "BLOCKED" in text and "PASS" in text
    assert "Existing partner reused" in text


def test_parallel_ui_uses_human_duration_and_warning_status():
    page = (ROOT / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    styles = (ROOT / "webapp/frontend/src/styles.css").read_text(encoding="utf-8")
    assert "formatDuration" in page
    assert "warningCount" in page and "failCount" in page
    assert "Agent conclusion" in page
    assert "warning-pill" in styles
