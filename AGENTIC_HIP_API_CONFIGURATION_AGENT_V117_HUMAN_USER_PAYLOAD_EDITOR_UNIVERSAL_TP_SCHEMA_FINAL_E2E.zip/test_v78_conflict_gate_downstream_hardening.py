from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.legacy_adapter import apply_configuration_answers
from webapp.backend.app.main import STORE, app


def _unresolved_interface_input() -> dict:
    return {
        "customer": "ACME",
        "direction": "Inbound",
        "tx_code": "850",
        "tx_name": "Purchase Order",
        "flow_type": "passthrough",
        "requires_data_map": False,
        "objects": {
            "source_document_type": {"name": "SRC", "data_format_type": "XML", "version": "1.0"},
            "target_document_type": {"name": "TGT", "data_format_type": "XML", "version": "1.0"},
            "rule": {"name": "RULE"},
            # This mirrors the unresolved built state after the operator selected
            # SFTP but customer/approved evidence says HTTPS.
            "source_transport_profile": {"interface_type": "SFTP HAFT", "profile_name": "SRC_TP"},
            "target_transport_profile": {"interface_type": "SFTP HAFT", "profile_name": "TGT_TP"},
            "biz_flow": {"flow_details": {"business_flow_name": "FLOW"}, "configure_source": {}, "configure_targets": {}, "configure_routing": {}},
        },
        "_selection_conflicts": [{
            "id": "selection_conflict_objects_source_transport_profile_interface_type",
            "path": "objects.source_transport_profile.interface_type",
            "label": "source interface",
            "selectedField": "source_interface",
            "selectedValue": "SFTP",
            "fileValues": ["HTTPS"],
            "fileSources": ["approved_customer.json"],
            "fileEvidence": [{"value": "HTTPS", "sourceFile": "approved_customer.json", "confidence": "confirmed", "rule": "approved customer configuration/manual value"}],
            "fileConfidence": "confirmed",
            "status": "UNRESOLVED",
        }],
    }


def test_interface_conflict_resolution_recomputes_effective_registry_before_enrichment(tmp_path: Path):
    canonical = _unresolved_interface_input()
    (tmp_path / "input.json").write_text(json.dumps(canonical), encoding="utf-8")
    result = apply_configuration_answers(
        tmp_path,
        {"source_interface": "SFTP", "target_interface": "SFTP"},
        {"selection_conflict_objects_source_transport_profile_interface_type": "HTTPS"},
    )
    source = result["input"]["objects"]["source_transport_profile"]
    assert result["effective_source_interface"] == "HTTPS"
    assert source["interface_type"] == "HTTPS"
    # Stale SFTP enrichment must not inject the shared file-transfer account into HTTPS.
    assert not source.get("existing_account_name")
    assert not result["input"].get("_selection_conflicts")


def test_api_testing_requests_are_server_side_blocked_until_conflict_is_resolved():
    client = TestClient(app)
    created = client.post("/api/configurations", json={"name": "V78 conflict gate test"})
    assert created.status_code == 200
    cid = created.json()["id"]
    try:
        record = STORE.get_configuration(cid)
        workspace = Path(record["workspace"])
        (workspace / "input.json").write_text(json.dumps(_unresolved_interface_input()), encoding="utf-8")
        conflict_question = {
            "id": "selection_conflict_objects_source_transport_profile_interface_type",
            "path": "objects.source_transport_profile.interface_type",
            "label": "source interface",
            "type": "conflict",
            "informational": False,
            "conflict": {
                "fileValues": ["HTTPS"],
                "fileSources": ["approved_customer.json"],
                "selectedValue": "SFTP",
                "selectedField": "source_interface",
            },
        }
        STORE.update_configuration(cid, {"questions": [conflict_question], "status": "NEEDS_INPUT"})
        response = client.get(f"/api/configurations/{cid}/api-requests")
        assert response.status_code == 400
        detail = response.json()["detail"]
        assert detail["blockerCount"] == 1
        assert detail["conflictCount"] == 1
        assert detail["conflicts"][0]["fileValues"] == ["HTTPS"]
        assert detail["conflicts"][0]["selectedValue"] == "SFTP"
        assert "Build Configuration" in detail["nextAction"]
    finally:
        STORE.delete_configuration(cid)



def test_parallel_queue_cannot_revalidate_around_an_unresolved_conflict():
    client = TestClient(app)
    created = client.post("/api/configurations", json={"name": "V78 parallel conflict gate"})
    assert created.status_code == 200
    cid = created.json()["id"]
    try:
        record = STORE.get_configuration(cid)
        workspace = Path(record["workspace"])
        (workspace / "input.json").write_text(json.dumps(_unresolved_interface_input()), encoding="utf-8")
        STORE.update_configuration(cid, {
            "questions": [{
                "id": "selection_conflict_objects_source_transport_profile_interface_type",
                "path": "objects.source_transport_profile.interface_type",
                "label": "source interface",
                "type": "conflict",
                "informational": False,
                "conflict": {"fileValues": ["HTTPS"], "fileSources": ["approved_customer.json"], "selectedValue": "SFTP", "selectedField": "source_interface"},
            }],
            "status": "NEEDS_INPUT",
            # Even a stale prior PASS must not let the queue bypass the decision gate.
            "validation": {"ok": True, "requests": {"validCount": 18, "total": 18}},
        })
        response = client.post("/api/parallel/queue", json={"configuration_id": cid, "label": "must block"})
        assert response.status_code == 400
        assert "required Build Configuration decision" in response.json()["detail"]
    finally:
        STORE.delete_configuration(cid)

def test_frontend_blocks_flow_navigation_while_required_decisions_remain():
    root = Path(__file__).resolve().parent
    page = (root / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    assert "disabled={!active||questions.length>0}" in page
    assert "Resolve required values/conflicts before opening API Flow Game." in page
    assert "fileEvidence?.[i]" in page
