from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, List


def scalar_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if is_dataclass(value):
        value = asdict(value)
    if isinstance(value, (dict, list, tuple, set)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def safe_table_rows(data: Any) -> List[Dict[str, Any]]:
    if data is None:
        return []
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, (list, tuple)):
        data = [data]

    rows: List[Dict[str, Any]] = []
    for item in data:
        if is_dataclass(item):
            item = asdict(item)
        if isinstance(item, dict):
            rows.append({str(k): scalar_value(v) for k, v in item.items()})
        else:
            rows.append({"value": scalar_value(item)})
    return rows
