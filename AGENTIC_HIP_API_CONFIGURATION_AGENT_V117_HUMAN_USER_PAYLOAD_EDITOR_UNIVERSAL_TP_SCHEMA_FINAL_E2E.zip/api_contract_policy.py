from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

# V117 policy:
# - developer-approved method / URL / request kind / attribute structure remain immutable;
# - only an explicit HUMAN USER action may edit VALUES of existing canonical payload/parameter fields before LIVE;
# - the AI/agent may inspect, validate, or explain payloads but has zero value-edit authority;
# - persisted edits are contract-validated and applied before the first LIVE fingerprint;
# - ad-hoc graph/request structure mutation remains forbidden.
API_REQUEST_MUTATION_ALLOWED = False  # structural/ad-hoc mutation remains forbidden
API_REQUEST_VALUE_EDIT_ALLOWED = True
POLICY_NAME = "IMMUTABLE_DEVELOPER_APPROVED_18_API_CONTRACT_HUMAN_USER_VALUE_EDIT_ONLY"


def has_request_override(value: Any) -> bool:
    return isinstance(value, dict) and bool(value)


def assert_no_request_override(value: Any, *, context: str = "API request") -> None:
    """Reject one-off request overrides that bypass the persisted value editor.

    API Testing/Flow nodes may not smuggle a transient request body into LIVE.
    User edits must first be saved through the schema-locked Payload Value Editor,
    where they are validated, audited, and visible in generated/effective previews.
    """
    if has_request_override(value):
        raise ValueError(
            f"{POLICY_NAME}: {context} ad-hoc request override is disabled. "
            "Save the value edit through Payload Value Editor first. API method, URL, "
            "request kind, attribute names, nesting and protected headers are immutable."
        )


def immutable_flow_graph(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Remove transient Flow-graph request overrides while preserving edge mappings."""
    value = deepcopy(graph if isinstance(graph, dict) else {})
    for node in value.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        node["request_override"] = {}
        node["override_mode"] = "merge"
    return value


def immutable_override_meta(step_key: str, *, persisted_count: int = 0) -> Dict[str, Any]:
    """Compatibility metadata when no persisted value edit is applied."""
    return {
        "applied": False,
        "stepKey": str(step_key or ""),
        "policy": POLICY_NAME,
        "structureMutationAllowed": False,
        "valueEditAllowed": True,
        "persistedOverrideIgnored": False,
        "persistedValueEditCount": int(persisted_count or 0),
        "note": (
            "Developer-approved request structure is immutable. Only a human user may edit approved values "
            "through the persisted schema-locked editor before LIVE materialization; the AI/agent cannot edit values."
        ),
    }
