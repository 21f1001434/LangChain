from run_agent import Runner
from api_pdf_ingestion import BUILTIN_CONTRACTS


def test_flow_create_and_deploy_do_not_send_worktype_at_all():
    runner = Runner(llm_enabled=False)
    for step in ("flow_create", "flow_deploy"):
        request = runner.preview_step_request(step)
        assert "workType" not in (request.get("payload") or {})


def test_contracts_do_not_require_any_worktype_field():
    for key in ("orch_flow_create", "orch_flow_deploy"):
        c = BUILTIN_CONTRACTS[key]
        assert "workType" not in (c.get("requiredFields") or [])
        assert not any(str(x).startswith("workType") for x in (c.get("nestedRequiredFields") or []))
        assert "workType" in (c.get("forbiddenFields") or [])


def test_missing_values_never_ask_user_for_worktype():
    runner = Runner(llm_enabled=False)
    fields = [str(item.get("field") or "") for item in runner.collect_missing_values()]
    assert not any("worktype" in field.casefold() for field in fields)
