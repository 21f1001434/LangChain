from pathlib import Path
import zipfile

from input_builder_core import build_from_raw_files, combine_existing_input_with_artifact_evidence
from input_mapping_learner import load_mapping_knowledge, record_mapping_example, mapping_learning_summary


def _xml(path: Path, root: str, body: str = "") -> Path:
    path.write_text(f'<?xml version="1.0" encoding="UTF-8"?><{root}>{body}</{root}>', encoding="utf-8")
    return path


def _jar(path: Path, cls: str = "Transform_TEST") -> Path:
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr(cls + ".class", b"CAFEBABE")
    return path


def _edi(path: Path, code: str = "850") -> Path:
    # Minimal X12 shape sufficient for deterministic sniff/ST extraction.
    text = "ISA*00*          *00*          *ZZ*SENDER         *ZZ*RECEIVER       *260101*1200*U*00401*000000001*0*T*>~GS*PO*S*R*20260101*1200*1*X*004010~ST*%s*0001~SE*2*0001~" % code
    path.write_text(text, encoding="utf-8")
    return path


def test_xml_source_never_becomes_edi_from_850_transaction(tmp_path):
    src = _xml(tmp_path / "SRC_customer_850.xml", "PurchaseOrderCollection")
    tgt = _xml(tmp_path / "TGT_customer_850.xml", "PurchaseOrder")
    jar = _jar(tmp_path / "Transform_CUSTOMER850.jar", "Transform_CUSTOMER850")
    cfg = build_from_raw_files([src, tgt, jar], customer="CUSTOMER", direction="Inbound", flow_type="translation", use_dell_aia=False)
    assert cfg["objects"]["source_document_type"]["data_format_type"] == "XML"
    assert cfg["objects"]["target_document_type"]["data_format_type"] == "XML"
    assert cfg["tx_standard"] == "XML"
    assert cfg["objects"]["source_document_type"]["document_identifier"]["rows"][0]["value"] == "PurchaseOrderCollection"
    assert cfg["objects"]["target_document_type"]["document_identifier"]["rows"][0]["value"] == "PurchaseOrder"


def test_source_xml_target_edi_uses_uploaded_physical_formats(tmp_path):
    src = _xml(tmp_path / "SRC_order.xml", "DellPOA")
    tgt = _edi(tmp_path / "TGT_order.edi", "850")
    jar = _jar(tmp_path / "Transform_ORDER.jar", "Transform_ORDER")
    cfg = build_from_raw_files([src, tgt, jar], customer="CUSTOMER", direction="Outbound", flow_type="translation", use_dell_aia=False)
    assert cfg["objects"]["source_document_type"]["data_format_type"] == "XML"
    assert cfg["objects"]["target_document_type"]["data_format_type"] == "EDIX12"
    assert cfg["tx_standard"] == "XML"


def test_source_edi_target_xml_uses_uploaded_physical_formats(tmp_path):
    src = _edi(tmp_path / "SRC_order.edi", "850")
    tgt = _xml(tmp_path / "TGT_order.xml", "PurchaseOrder")
    jar = _jar(tmp_path / "Transform_ORDER.jar", "Transform_ORDER")
    cfg = build_from_raw_files([src, tgt, jar], customer="CUSTOMER", direction="Inbound", flow_type="translation", use_dell_aia=False)
    assert cfg["objects"]["source_document_type"]["data_format_type"] == "EDIX12"
    assert cfg["objects"]["target_document_type"]["data_format_type"] == "XML"
    assert cfg["tx_standard"] == "X12"


def test_existing_input_format_conflict_is_blocker(tmp_path):
    src = _xml(tmp_path / "SRC_order.xml", "PurchaseOrderCollection")
    tgt = _xml(tmp_path / "TGT_order.xml", "PurchaseOrder")
    jar = _jar(tmp_path / "Transform_ORDER.jar", "Transform_ORDER")
    evidence = build_from_raw_files([src, tgt, jar], customer="C", direction="Inbound", flow_type="translation", use_dell_aia=False)
    existing = {
        "customer": "C", "direction": "Inbound", "flow_type": "translation", "requires_data_map": True,
        "objects": {
            "source_document_type": {"name": "SRC", "data_format_type": "EDIX12", "document_identifier": {"rows": [{"derived_from":"ELEMENT_IN_PAYLOAD","expression":"ST*01","value":"850"}]}},
            "target_document_type": {"name": "TGT", "data_format_type": "XML", "document_identifier": {"rows": [{"derived_from":"TRANSACTION_ROOT_ELEMENT","value":"PurchaseOrder"}]}},
            "data_map": {"map_data_file": "Transform_ORDER.jar"},
        },
    }
    combined = combine_existing_input_with_artifact_evidence(existing, evidence, manifest=[p.name for p in (src,tgt,jar)], flow_type="translation")
    blockers = (combined.get("_artifact_validation") or {}).get("blockers") or []
    assert any(x.get("path") == "objects.source_document_type.data_format_type" for x in blockers)


def _reference(customer: str, source_file: str, target_file: str):
    return {
        "customer": customer,
        "_file_mapping": {
            "source": {"filename": source_file, "data_format_type": "XML"},
            "target": {"filename": target_file, "data_format_type": "XML"},
            "fieldMappings": [
                {"path": "objects.source_document_type.data_format_type", "rule": "physical source payload content sniff"},
                {"path": "objects.target_document_type.data_format_type", "rule": "physical target payload content sniff"},
            ],
        },
    }


def test_three_reference_pairs_are_learned_and_reused_for_role_hints(tmp_path):
    # Two examples teach non-standard ORIGIN/DEST filename vocabulary.
    record_mapping_example(tmp_path, _reference("A", "ORIGIN_A.xml", "DEST_A.xml"), ["ORIGIN_A.xml", "DEST_A.xml"])
    record_mapping_example(tmp_path, _reference("B", "ORIGIN_B.xml", "DEST_B.xml"), ["ORIGIN_B.xml", "DEST_B.xml"])
    # Third pair is also recorded, matching the user's intended 3-customer teaching set.
    record_mapping_example(tmp_path, _reference("C", "ORIGIN_C.xml", "DEST_C.xml"), ["ORIGIN_C.xml", "DEST_C.xml"])
    knowledge = load_mapping_knowledge(tmp_path)
    summary = mapping_learning_summary(knowledge)
    assert summary["example_count"] == 3
    assert "ORIGIN" in summary["source_tokens"]
    assert "DEST" in summary["target_tokens"]

    src = _xml(tmp_path / "ORIGIN_NEW.xml", "SourceRoot")
    tgt = _xml(tmp_path / "DEST_NEW.xml", "TargetRoot")
    jar = _jar(tmp_path / "Transform_NEW.jar", "Transform_NEW")
    cfg = build_from_raw_files([src, tgt, jar], customer="NEW", direction="Inbound", flow_type="translation", use_dell_aia=False, mapping_knowledge=knowledge)
    assert cfg["_file_mapping"]["source"]["filename"] == "ORIGIN_NEW.xml"
    assert cfg["_file_mapping"]["target"]["filename"] == "DEST_NEW.xml"
    assert cfg["objects"]["source_document_type"]["data_format_type"] == "XML"
