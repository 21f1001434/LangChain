# V68 - Lightweight Motion & UX Enhancement

V68 extends V67 Flow Game edge animation across the whole React application while preserving execution performance.

## Motion principles
- No animation library.
- No extra HTTP/WebSocket requests.
- No new polling or JavaScript animation timers.
- Transform/opacity are preferred for compositor-friendly motion.
- Infinite animation is limited to an operation that is actively RUNNING/WORKING.
- `prefers-reduced-motion` disables nonessential motion.

## Added UX motion
- Page/title/content one-shot entrance transitions.
- Active customer context transition when switching customers.
- Full-row navigation selection sweep and tactile button press feedback.
- Busy buttons and global API activity glint using CSS-only transforms.
- Validation PASS/BLOCKED feedback animation.
- File upload/evidence arrival feedback.
- API Testing selected/result feedback.
- Execute CHECKING/RUNNING job progress strips and result arrival transitions.
- Report selection/content transitions.
- Flow Game node RUNNING/PASS/EXISTING/BLOCKED animation in addition to V67 animated directional edges.
- Dashboard hero micro-motion on initial page entry.

All existing V67/V66 validation, persistence, payload, pre-LIVE, report and execution behavior is preserved.
