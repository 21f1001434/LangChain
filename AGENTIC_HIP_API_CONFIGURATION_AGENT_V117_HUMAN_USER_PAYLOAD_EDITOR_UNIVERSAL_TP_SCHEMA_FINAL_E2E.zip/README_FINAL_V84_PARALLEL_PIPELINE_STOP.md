# HIP API Agent Studio — V84 Final

V84 fixes the real parallel-execution failures observed on managed Windows and adds a separate ordered Pipeline Execution workflow.

## 1. Parallel Capacity / Limit Test

The same-customer parallel area is explicitly for capacity/limit testing of one already validated customer configuration.

- 2–8 isolated instances can run concurrently through a bounded worker pool.
- Each instance has an immutable queued snapshot and short physical execution path.
- In-memory batch state is authoritative while LIVE work is running.
- Report/telemetry persistence can no longer block or change the HIP business verdict.
- JSON report writes use unique temporary files and retry transient Windows/endpoint-security locks.
- Report persistence problems are warnings, not customer BLOCKED results.

## 2. Execution stop controls

- **STOP BATCH** cancels the whole batch, terminates active child processes, and prevents queued instances from continuing.
- **Stop instance** cancels only one selected instance and leaves sibling workers running.
- User-stopped work is reported as **CANCELLED**, not BLOCKED.

## 3. Pipeline Execution

Pipeline Execution is separate from capacity testing. It is for an ordered business run.

A user can create a named pipeline, add validated configurations, reorder stages, save it, validate the complete pipeline, and run it LIVE.

Safety behavior:

1. Every stage is validated before LIVE execution.
2. Every stage is production-preflighted before the first LIVE HIP mutation.
3. If any stage fails the all-stage gate, no pipeline stage starts LIVE.
4. If the entire gate passes, stages run sequentially in the saved order.
5. If a runtime stage fails, later stages are marked SKIPPED and the pipeline stops.

## Existing behavior preserved

- U-HAUL remains the immutable developer-approved Outbound 856 Translation test reference.
- U-HAUL remains DEV APPROVED / TEST READY / 18 of 18.
- Build Configuration supports Create New, Clone Existing, and confirmed Edit Existing.
- U-HAUL can be cloned but cannot be edited.
- Global customer selection remains available across Studio pages.
- File-vs-user conflicts retain guided side-by-side resolution and a backend hard gate.
- The 18 developer-approved API payload structures stay locked; only approved customer-specific values can change.
- Windows runtime/path hardening and sidebar overflow fixes remain in place.

## Validation

- Root/application automated tests: **278 passed, 0 failed**
- FastAPI/backend tests: **48 passed, 0 failed**
- Total automated tests: **326 passed, 0 failed**
- Focused V84 + affected historical regression: **55 passed, 0 failed**
- Phase 6 checks: **38/38 PASS**
- Final release checks: **16/16 PASS**
- Package validation: **57/57 PASS**
- Adaptive package validation: **60/60 PASS**
- Frontend TypeScript/TSX transpilation: **24/24 PASS**

A fresh Vite production bundle was not regenerated in this sandbox because `node_modules` is intentionally not packaged. The 24 TypeScript/TSX source files passed dependency-independent transpilation.

## Recommended use

Extract V84 into a fresh folder rather than overwriting an actively running older release.

- Use **Parallel Capacity / Limit Test** for concurrency testing.
- Use **Pipeline Execution** for a real ordered business workflow.
