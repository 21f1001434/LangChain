from __future__ import annotations

import argparse
import json
from pathlib import Path

from production_guard import redact_sensitive
from run_agent import Runner
from scratch_flow import execute_scratch_flow, load_scratch_flow

ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description="Execute the user-defined HIP Scratch Flow.")
    args = parser.parse_args()

    # Scratch execution is production/live only. There is intentionally no
    # simulation or non-live execution mode.
    runner = Runner(llm_enabled=True)
    preflight = runner.production_preflight()
    if not preflight.get("ready", False):
        print(json.dumps({"status": "PREFLIGHT_FAILED", "preflight": redact_sensitive(preflight)}, indent=2, default=str))
        raise SystemExit(4)
    runner.validate_live_configuration()
    runner.validate_pdf_readiness()
    runner.judge.verify_connection()

    flow = load_scratch_flow(ROOT)

    def progress(index: int, total: int, component: dict) -> None:
        print(f"[SCRATCH {index}/{total}] {component.get('label') or component.get('stepKey')} ({component.get('instanceId')})", flush=True)

    report = execute_scratch_flow(ROOT, runner, flow, progress_callback=progress)
    print(json.dumps({
        "status": "SUCCESS" if report.get("completed") else "BLOCKED_OR_PARTIAL",
        "flowName": report.get("flowName"),
        "componentCount": report.get("componentCount"),
        "executedCount": report.get("executedCount"),
        "passCount": report.get("passCount"),
        "blockedCount": report.get("blockedCount"),
        "reportJson": str(ROOT / "reports" / "scratch_flow_report_latest.json"),
        "reportHtml": str(ROOT / "reports" / "scratch_flow_report_latest.html"),
    }, indent=2))
    if not report.get("completed"):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
