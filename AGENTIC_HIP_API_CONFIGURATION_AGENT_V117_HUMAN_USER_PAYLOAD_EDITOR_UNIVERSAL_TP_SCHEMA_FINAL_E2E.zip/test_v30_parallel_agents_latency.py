from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import parallel_configurations as pc
from runtime_payload_values import save_runtime_payload_values, load_runtime_payload_values


def _write_active(root: Path, customer: str, flow: str) -> None:
    (root / "input_files").mkdir(parents=True, exist_ok=True)
    (root / "input_files" / f"{customer}.xml").write_text("<Root/>", encoding="utf-8")
    (root / "input.json").write_text(json.dumps({
        "customer": customer,
        "profile_name": flow,
        "direction": "Outbound",
        "flow_type": "passthrough",
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": flow}}},
    }), encoding="utf-8")
    (root / "config_overrides.json").write_text("{}", encoding="utf-8")
    (root / "request_validation_cache.json").write_text(json.dumps({"fingerprint": {"valid": True}}), encoding="utf-8")


def _validation() -> dict:
    return {
        "ok": True,
        "generatedAt": "2026-08-17T00:00:00Z",
        "mapper": {"ok": True},
        "mcpSupervisor": {"valid": True},
        "requests": {"ok": True, "validCount": 18, "total": 18, "items": [{"valid": True}] * 18},
    }


def test_validated_configuration_snapshot_is_isolated_and_carries_validation_cache(tmp_path: Path):
    _write_active(tmp_path, "CUSTOMER_A", "FLOW_A")
    queued = pc.snapshot_validated_configuration(tmp_path, _validation())
    workspace = Path(queued["workspace"])
    assert queued["validated"] is True
    assert (workspace / "input.json").exists()
    assert (workspace / "input_files" / "CUSTOMER_A.xml").exists()
    assert (workspace / "request_validation_cache.json").exists()
    assert queued["requestCount"] == 18

    # Mutating the active configuration after queueing must not mutate the snapshot.
    _write_active(tmp_path, "CUSTOMER_B", "FLOW_B")
    snap = json.loads((workspace / "input.json").read_text(encoding="utf-8"))
    assert snap["customer"] == "CUSTOMER_A"


def test_parallel_runner_executes_multiple_configuration_agents_concurrently(tmp_path: Path, monkeypatch):
    jobs = []
    for customer in ("A", "B", "C"):
        _write_active(tmp_path, customer, f"FLOW_{customer}")
        jobs.append(pc.snapshot_validated_configuration(tmp_path, _validation()))

    active = 0
    max_active = 0
    lock = threading.Lock()

    def fake_run_one(root, code_root, job, batch_id, progress_callback=None):
        nonlocal active, max_active
        with lock:
            active += 1
            max_active = max(max_active, active)
        time.sleep(0.15)
        with lock:
            active -= 1
        return {
            "jobId": job["jobId"], "customer": job["customer"], "flow": job["flow"],
            "status": "PASS", "returnCode": 0, "elapsedSeconds": 0.15,
        }

    monkeypatch.setattr(pc, "_run_one", fake_run_one)
    started = time.perf_counter()
    summary = pc.run_parallel_configurations(tmp_path, [j["jobId"] for j in jobs], max_workers=3)
    elapsed = time.perf_counter() - started
    assert summary["passCount"] == 3
    assert summary["parallelWorkers"] == 3
    assert max_active >= 2
    assert elapsed < 0.40  # serial would be about 0.45s plus overhead




def test_parallel_snapshot_carries_runtime_payload_values_ephemerally(tmp_path: Path):
    _write_active(tmp_path, "HTTPS_CUSTOMER", "HTTPS_FLOW")
    save_runtime_payload_values(tmp_path, {"target": {"Receiver Client Secret": "secret-value"}}, merge=False)
    queued = pc.snapshot_validated_configuration(tmp_path, _validation())
    assert queued["runtimeValuesEphemeral"] is True
    listed = pc.list_queued_configurations(tmp_path)
    assert listed[0]["runtimeValuesReady"] is True
    workspace = pc._prepare_run_workspace(tmp_path, listed[0], "batch_fixture")
    hydrated = load_runtime_payload_values(workspace)
    assert hydrated["target"]["Receiver Client Secret"] == "secret-value"
    # Secret value is not persisted in the queue manifest/project snapshot.
    manifest_text = (Path(queued["workspace"]) / "queue_manifest.json").read_text(encoding="utf-8")
    assert "secret-value" not in manifest_text

def test_parallel_and_latency_features_are_wired_into_final_application():
    root = Path(__file__).resolve().parent
    runner = (root / "run_agent.py").read_text(encoding="utf-8")
    studio = (root / "hip_application_studio.py").read_text(encoding="utf-8")
    builder = (root / "input_builder_ui.py").read_text(encoding="utf-8")
    parallel_ui = (root / "parallel_config_ui.py").read_text(encoding="utf-8")

    assert "HIP_WORKSPACE_ROOT" in runner
    assert "HTTPAdapter" in runner and "HIP_HTTP_POOL_SIZE" in runner
    assert "HIP_REUSE_VALIDATED_REQUESTS" in runner
    assert "request_validation_cache.json" in runner
    assert "⚡ Parallel Configurations" in studio
    assert "snapshot_validated_configuration" in builder
    assert "RUN SELECTED CONFIGURATIONS IN PARALLEL LIVE" in parallel_ui
