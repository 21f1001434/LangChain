from __future__ import annotations

import json
from pathlib import Path

from agentic_interface_orchestrator import AgenticInterfaceOrchestrator
from api_pdf_ingestion import PdfApiKnowledgeBase
from interface_registry import get_interface
from mcp_bridge import MCPBridge
from run_agent import Runner
from runtime_payload_values import (
    clear_runtime_payload_values,
    placeholder,
    save_runtime_payload_values,
)

ROOT = Path(__file__).resolve().parent


def main() -> None:
    env_example = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert "TP_SOURCE_INTERFACE_CLIENT_SECRET" not in env_example
    assert "TP_TARGET_INTERFACE_CLIENT_SECRET" not in env_example

    https = get_interface(ROOT, "HTTPS")
    assert "Receiver Client Secret" in https.get("targetRequired", [])
    assert "Receiver Client Secret Env" not in https.get("targetRequired", [])

    baseline = json.loads(
        (ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8")
    )
    agent = AgenticInterfaceOrchestrator(ROOT, baseline, pdf_kb=PdfApiKnowledgeBase(ROOT))

    params = {
        "Protocol": "REST",
        "Partner URL": "https://partner.example",
        "Request Method": "POST",
        "Request Format": "Request Body",
        "Receiver Authentication Type": "OAuth2",
        "Gateway URL": "URL will be shared later after API Publish is successful.",
        "Are Input Files Compressed?": "False",
        "Receiver Grant Type": "partner-grant",
        "Receiver Token Endpoint": "https://partner.example/oauth/token",
        "Receiver Client Id": "partner-client",
        "Receiver Client Secret": placeholder("target.receiver_client_secret"),
    }
    proposal = agent.propose(
        source_interface="SFTP",
        target_interface="HTTPS",
        target_parameters=params,
    )
    assert proposal["valid"] is True, proposal
    stored = proposal["proposal"]
    secret_field = stored["objects"]["target_transport_profile"]["interface_parameters"]["Receiver Client Secret"]
    assert secret_field == placeholder("target.receiver_client_secret")
    assert "partner-secret-value" not in json.dumps(stored)

    original = (ROOT / "input.json").read_text(encoding="utf-8")
    try:
        (ROOT / "input.json").write_text(json.dumps(stored, indent=2), encoding="utf-8")
        request_builder = Runner(llm_enabled=False)
        preview = request_builder.preview_step_request("target_tp")["payload"]
        interface_params = preview["transportProfileDetails"][0]["interfaceDetails"][0]["parameters"]
        assert interface_params["Receiver Client Secret"] == placeholder("target.receiver_client_secret")

        clear_runtime_payload_values(ROOT)
        mcp = MCPBridge(ROOT, enabled=True, required=False)
        readiness_missing = mcp.assess_execution_readiness(stored, json.loads((ROOT / "config_overrides.json").read_text()))
        assert readiness_missing["valid"] is False
        assert any("runtime payload" in str(err).lower() for err in readiness_missing.get("errors", []))

        save_runtime_payload_values(
            ROOT,
            {"target": {"receiver_client_secret": "partner-secret-value"}},
            merge=False,
        )
        live_runner = Runner(llm_enabled=False)
        resolved = live_runner._resolve_runtime_payload_values(
            {"Receiver Client Secret": placeholder("target.receiver_client_secret")}
        )
        assert resolved == {"Receiver Client Secret": "partner-secret-value"}

        critic = mcp.validate_payload_override(
            "target_tp",
            {
                "transportProfileDetails": [
                    {
                        "interfaceDetails": [
                            {"interfaceType": "HTTPS", "parameters": {}}
                        ]
                    }
                ]
            },
            {
                "transportProfileDetails": [
                    {
                        "interfaceDetails": [
                            {
                                "interfaceType": "HTTPS",
                                "parameters": {
                                    "Receiver Client Secret": placeholder("target.receiver_client_secret")
                                },
                            }
                        ]
                    }
                ]
            },
            interface_only=True,
        )
        assert critic.get("valid") is True, critic
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")
        clear_runtime_payload_values(ROOT)

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "noTpSecretsInEnv": True,
        "partnerSecretIsPayloadField": True,
        "storedConfigurationUsesRuntimePayloadPlaceholder": True,
        "mcpBlocksWhenRuntimePayloadValueMissing": True,
        "mcpAllowsSecureRuntimePayloadPlaceholder": True,
        "liveRunnerInjectsPayloadSecretImmediatelyBeforeSend": True,
    }
    path = ROOT / "examples" / "PARTNER_PAYLOAD_VALUES_V12_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
