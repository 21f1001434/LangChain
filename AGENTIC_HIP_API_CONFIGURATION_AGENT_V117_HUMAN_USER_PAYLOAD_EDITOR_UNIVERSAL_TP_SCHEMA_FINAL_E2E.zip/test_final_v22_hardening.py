from pathlib import Path
import tempfile

from business_demo import agent_response_verdict
from input_bundle import backup_active_state, restore_active_state
from runtime_preflight import MIN_STREAMLIT

ROOT = Path(__file__).resolve().parent


def test_streamlit_minimum_matches_width_api_usage():
    req = (ROOT / 'requirements_legacy_streamlit.txt').read_text(encoding='utf-8')
    assert 'streamlit>=1.50,<2.0' in req
    assert MIN_STREAMLIT >= (1, 48)


def test_existing_typo_response_is_still_pass_existing():
    verdict = agent_response_verdict({'response_preview': 'AIC-DCE is already exits . Please Update'})
    assert verdict['verdict'] == 'PASS'
    assert verdict['outcome'] == 'EXISTING'


def test_input_bundle_backup_restore_is_transactional(tmp_path: Path):
    root = tmp_path / 'app'
    root.mkdir()
    (root / 'input_files').mkdir()
    (root / 'input_files' / 'old.xml').write_text('old', encoding='utf-8')
    (root / 'input.json').write_text('{"old": true}', encoding='utf-8')
    (root / 'config_overrides.json').write_text('{"group": "old"}', encoding='utf-8')
    backup = tmp_path / 'backup'
    backup_active_state(root, backup)

    (root / 'input_files' / 'old.xml').unlink()
    (root / 'input_files' / 'new.xml').write_text('new', encoding='utf-8')
    (root / 'input.json').write_text('{"new": true}', encoding='utf-8')
    (root / 'scratch_flow.json').write_text('{"new": true}', encoding='utf-8')

    restore_active_state(root, backup)
    assert (root / 'input_files' / 'old.xml').read_text(encoding='utf-8') == 'old'
    assert not (root / 'input_files' / 'new.xml').exists()
    assert (root / 'input.json').read_text(encoding='utf-8') == '{"old": true}'
    assert not (root / 'scratch_flow.json').exists()


def test_release_launchers_use_runtime_preflight():
    assert 'runtime_preflight.py' in (ROOT / 'run_uhal_ui.bat').read_text(encoding='utf-8')
    assert 'runtime_preflight.py' in (ROOT / 'run_uhal_ui.ps1').read_text(encoding='utf-8')
    assert (ROOT / 'SETUP_AND_RUN.bat').exists()
    assert (ROOT / 'SETUP_AND_RUN.ps1').exists()
