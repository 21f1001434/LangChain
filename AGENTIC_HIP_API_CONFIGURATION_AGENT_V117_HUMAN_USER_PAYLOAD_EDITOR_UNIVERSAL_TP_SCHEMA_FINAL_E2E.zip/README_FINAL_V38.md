# HIP Application Studio / Agentic HIP — Final V38

See `README_START_HERE.md` and `README_AGENTIC_HIP_V38_PHASE6.md`. Phase 6 makes React/Bun + FastAPI/Python the primary runtime and keeps Streamlit only as an optional archive/reference UI.
