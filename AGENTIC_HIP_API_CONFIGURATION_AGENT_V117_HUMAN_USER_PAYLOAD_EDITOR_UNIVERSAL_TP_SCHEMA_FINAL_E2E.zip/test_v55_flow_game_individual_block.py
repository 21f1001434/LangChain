from pathlib import Path

from webapp.backend.app.main import _flow_node_agent_check
from webapp.backend.app.models import FlowDefinition

ROOT = Path(__file__).resolve().parent


def _workspace(tmp_path: Path) -> Path:
    ws = tmp_path / 'ws'
    ws.mkdir()
    (ws / 'input.json').write_bytes((ROOT / 'input.json').read_bytes())
    return ws


def test_individual_block_agent_check_passes_for_standalone_valid_request(tmp_path: Path):
    ws = _workspace(tmp_path)
    config = {'workspace': str(ws), 'validation': {'ok': True}}
    flow = FlowDefinition(nodes=[{'id': 'source-check', 'api_key': 'validate_source', 'label': 'Validate Source TP'}], edges=[])
    result = _flow_node_agent_check(config, 'source-check', flow)
    assert result['readyForLive'] is True
    assert result['agentCheck']['verdict'] == 'PASS'
    assert all(row['status'] == 'PASS' for row in result['agentCheck']['checks'])
    assert result['contractValidation']['valid'] is True


def test_individual_block_agent_check_blocks_runtime_mapped_dependency(tmp_path: Path):
    ws = _workspace(tmp_path)
    config = {'workspace': str(ws), 'validation': {'ok': True}}
    flow = FlowDefinition(
        nodes=[
            {'id': 'upstream', 'api_key': 'validate_source', 'label': 'Upstream'},
            {'id': 'selected', 'api_key': 'validate_source', 'label': 'Selected'},
        ],
        edges=[{'id': 'mapped', 'source': 'upstream', 'target': 'selected', 'mappings': [{'from': 'output.id', 'to': 'payload.id'}]}],
    )
    result = _flow_node_agent_check(config, 'selected', flow)
    assert result['readyForLive'] is False
    runtime = next(row for row in result['agentCheck']['checks'] if row['key'] == 'runtime_dependencies')
    assert runtime['status'] == 'BLOCKED'
    assert 'upstream' in runtime['reason'].lower()


def test_individual_block_agent_check_requires_latest_configuration_validation(tmp_path: Path):
    ws = _workspace(tmp_path)
    config = {'workspace': str(ws), 'validation': {'ok': False}}
    flow = FlowDefinition(nodes=[{'id': 'source-check', 'api_key': 'validate_source'}], edges=[])
    result = _flow_node_agent_check(config, 'source-check', flow)
    assert result['readyForLive'] is False
    validation = next(row for row in result['agentCheck']['checks'] if row['key'] == 'configuration_validation')
    assert validation['status'] == 'BLOCKED'


def test_flow_game_ui_exposes_agent_check_and_individual_live_run():
    flow = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    inspector = (ROOT / 'webapp/frontend/src/components/NodeInspector.tsx').read_text(encoding='utf-8')
    api = (ROOT / 'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    main = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    assert 'checkIndividualBlock' in flow
    assert 'runIndividualBlock' in flow
    assert 'Check & run this block LIVE' in inspector
    assert 'Agent check' in inspector
    assert 'preflightFlowNode' in api and 'executeFlowNode' in api
    assert '/flow/nodes/{node_id}/preflight' in main
    assert '/flow/nodes/{node_id}/execute' in main


def test_flow_game_live_paths_repeat_final_production_gate_server_side():
    main = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    adapter = (ROOT / 'webapp/backend/app/legacy_adapter.py').read_text(encoding='utf-8')
    assert 'def production_preflight' in adapter
    assert 'flow_node_final_pre_live_checks_latest.json' in main
    assert 'flow_final_pre_live_checks_latest.json' in main
    assert 'No LIVE API call was made.' in main
    assert 'No LIVE HIP API call was made.' in main
