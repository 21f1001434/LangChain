from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Iterable


def _get(item: Any, *names: str, default: Any = None) -> Any:
    if is_dataclass(item):
        item = asdict(item)
    if isinstance(item, dict):
        for name in names:
            if name in item and item.get(name) is not None:
                return item.get(name)
        return default
    for name in names:
        value = getattr(item, name, None)
        if value is not None:
            return value
    return default


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except Exception:
            return str(value)
    return str(value)


def format_duration_seconds(value: Any) -> str:
    """Human duration used in UI/reporting.

    < 1 second -> ms
    < 60 seconds -> seconds
    < 1 hour -> minutes + seconds
    >= 1 hour -> hours + minutes + seconds
    """
    try:
        seconds = max(0.0, float(value or 0.0))
    except Exception:
        return "—"
    if seconds < 1:
        return f"{seconds * 1000:.0f} ms"
    if seconds < 60:
        return f"{seconds:.2f} s" if seconds < 10 else f"{seconds:.1f} s"
    total = int(round(seconds))
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {secs:02d}s"
    return f"{minutes}m {secs:02d}s"


def format_duration_ms(value: Any) -> str:
    try:
        return format_duration_seconds(float(value or 0.0) / 1000.0)
    except Exception:
        return "—"


_EXISTING = (
    "already exists", "already exist", "already exits", "already present",
    "already configured", "already available", "existing object", "object exists",
    "record exists", "record already exists", "pre-existing", "preexisting",
    "already created", "unique constraint", "duplicate", "duplicate entry",
    "duplicate key", "duplicate value", "transport profile already exists",
    "map identifier should be unique in an environment", "map identifier should be unique",
)
_WARNING = (
    "warning", "partial", "partially", "pending", "queued", "accepted",
    "in progress", "processing", "eventual consistency", "retry recommended",
)
_FAILURE = (
    "failed", "failure", "business error", "validation error", "invalid payload",
    "invalid request", "unable to create", "could not create", "cannot create",
    "not successful", "exception", "internal server error", "bad request",
)
_BLOCKED = (
    "missing required", "mandatory parameter", "dependency failure", "skipped_dependency",
    "not validated", "preflight", "credential missing", "invalid_scope", "unauthorized",
    "forbidden", "not able to find", "unable to find", "could not find", "cannot find",
)
_SUCCESS = (
    "success", "successful", "created", "updated", "deployed", "completed",
    "validated", "active", "enabled",
)


def analyze_api_response(item: Any) -> Dict[str, Any]:
    """Business-facing response judge for final reports.

    This intentionally reads more than HTTP status. It combines the final response,
    runner classification, business-success flag, and the existing Dell-AIA/owner
    diagnosis when available. It never upgrades an ambiguous response to PASS.
    """
    status_code = _get(item, "status_code", "statusCode")
    try:
        http = int(status_code) if status_code not in (None, "") else None
    except Exception:
        http = None
    classification = str(_get(item, "classification", default="") or "").upper()
    owner = str(_get(item, "final_owner", "finalOwner", "owner", default="") or "").upper()
    business_success = bool(_get(item, "business_success", "businessSuccess", default=False))
    response = _text(_get(item, "response_preview", "responsePreview", "response", default=""))
    error = _text(_get(item, "error", default=""))
    issue = _text(_get(item, "issue", default=""))
    action = _text(_get(item, "action_required", "actionRequired", "action", default=""))
    existing_verdict = _get(item, "agentVerdict", "verdict", default={})
    if not isinstance(existing_verdict, dict):
        existing_verdict = {}
    combined = " ".join((response, error, classification, owner, issue, _text(existing_verdict))).lower()

    if classification in {"NOT_APPLICABLE", "SKIPPED_NOT_APPLICABLE"}:
        return {"verdict": "SKIPPED", "outcome": "NOT_APPLICABLE", "reason": "This API does not apply to this configuration.", "nextAction": "No action required.", "httpStatus": http}
    if classification == "LIVE_ID_UNRESOLVED":
        return {"verdict": "BLOCKED", "outcome": "LIVE_ID_UNRESOLVED", "reason": issue or "HIP did not provide the current-environment entity ID required by downstream APIs.", "nextAction": action or "Resolve the entity-specific LIVE ID and retry; never use a historical packaged ID.", "httpStatus": http}
    if classification == "API_UPSTREAM_ROUTE_UNAVAILABLE":
        return {"verdict": "FAIL", "outcome": "API_UPSTREAM_ROUTE_UNAVAILABLE", "reason": issue or "The Dell gateway was reached but its configured upstream PCF service route does not exist/is not deployed.", "nextAction": action or "API/platform team should restore the upstream route or provide the replacement endpoint; do not mutate the approved payload.", "httpStatus": http}
    if classification == "API_BACKEND_CONTRACT_MISMATCH":
        return {"verdict": "FAIL", "outcome": "API_BACKEND_CONTRACT_MISMATCH", "reason": issue or "HIP backend behavior conflicts with the developer-approved request contract.", "nextAction": action or "Keep the approved request unchanged and have the API/backend team align its persistence/validation contract.", "httpStatus": http}
    if classification.startswith("SKIPPED_") and classification != "SKIPPED_BY_USER_EXISTING_OBJECT":
        reason = issue or "The API was not executed because an earlier gate or dependency prevented it."
        return {"verdict": "BLOCKED", "outcome": "NOT_EXECUTED", "reason": reason, "nextAction": action or "Resolve the blocking dependency and run validation again.", "httpStatus": http}

    if owner in {"EXPECTED_EXISTING_OBJECT", "EXPECTED_DUPLICATE_FROM_RETEST"} or any(marker in combined for marker in _EXISTING):
        return {"verdict": "PASS", "outcome": "EXISTING", "reason": "This API was executed and HIP itself reports that the requested object already exists. No API call was skipped and no later dependent result is being used to infer success.", "nextAction": action or "Keep the API response as explicit EXISTING evidence. If a brand-new object is required, change the approved business identity in canonical input rather than mutating the runtime request.", "httpStatus": http}
    if owner == "USER_APPROVED_SKIP" or classification == "SKIPPED_BY_USER_EXISTING_OBJECT":
        return {"verdict": "BLOCKED", "outcome": "NOT_EXECUTED", "reason": "The create API was skipped by an old execution plan. V109 LIVE no-reuse mode does not accept this as execution evidence.", "nextAction": "Execute the API and use its own LIVE response as evidence.", "httpStatus": http}

    owner_blocked = owner in {"MISSING_REQUIRED_ID_OR_CONFIG", "EXPECTED_DEPENDENCY_FAILURE", "AUTH_OR_ENTITLEMENT"}
    if owner_blocked:
        verdict = "FAIL" if http is not None else "BLOCKED"
        return {"verdict": verdict, "outcome": "BLOCKER" if verdict == "BLOCKED" else "API_ERROR", "reason": issue or error or "The agent diagnosis identifies a missing dependency, authorization, or required configuration.", "nextAction": action or "Correct the blocking condition and retest.", "httpStatus": http}

    explicit_business_error = classification in {
        "HTTP_SUCCESS_BUT_BUSINESS_ERROR", "PAYLOAD_SCHEMA_OR_VALIDATION_ERROR",
        "AUTH_OR_ENTITLEMENT_ERROR", "PATH_OR_METHOD_ERROR", "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD",
        "API_UPSTREAM_ROUTE_UNAVAILABLE", "API_BACKEND_CONTRACT_MISMATCH",
        "EXECUTION_ERROR", "AUTH_OR_EXECUTION_ERROR", "DEPLOYMENT_NOT_SUCCESSFUL",
        "TP_AUDIT_RESPONSE_INVALID",
    }
    if explicit_business_error or (http is not None and http >= 400):
        return {"verdict": "FAIL", "outcome": "API_ERROR", "reason": issue or error or f"The API response indicates failure{f' (HTTP {http})' if http is not None else ''}.", "nextAction": action or "Review the response, correct the request/dependency, and retry.", "httpStatus": http}

    # Successful business result from the runner/AIA is strongest positive evidence.
    # This is evaluated before free-text markers so harmless fields such as failedCount=0
    # cannot downgrade an explicitly successful business result.
    if business_success or owner == "WORKING" or classification in {"PASS", "PASS_SUCCESS", "SUCCESS"}:
        if any(marker in combined for marker in _WARNING) or http == 202:
            return {"verdict": "WARNING", "outcome": "ACCEPTED_OR_PENDING", "reason": "The API accepted the request, but the final response indicates a pending/partial condition that should be verified.", "nextAction": action or "Verify the final state/audit before considering the workflow fully complete.", "httpStatus": http}
        return {"verdict": "PASS", "outcome": "SUCCESS", "reason": "The final response and agent analysis indicate the API completed successfully.", "nextAction": "No corrective action required.", "httpStatus": http}

    if any(marker in combined for marker in _BLOCKED):
        verdict = "FAIL" if http is not None else "BLOCKED"
        return {"verdict": verdict, "outcome": "BLOCKER" if verdict == "BLOCKED" else "API_ERROR", "reason": issue or error or "The response shows a missing dependency, authorization, or required configuration.", "nextAction": action or "Correct the blocking condition and retest.", "httpStatus": http}

    if any(marker in combined for marker in _FAILURE):
        return {"verdict": "FAIL", "outcome": "API_ERROR", "reason": issue or error or "The response body indicates a business or execution failure.", "nextAction": action or "Review the response, correct the request/dependency, and retry.", "httpStatus": http}

    if http is not None and 200 <= http < 300:
        if any(marker in combined for marker in _SUCCESS) and not any(marker in combined for marker in _FAILURE):
            return {"verdict": "PASS", "outcome": "SUCCESS", "reason": "The HTTP response and response body indicate a successful result.", "nextAction": "No corrective action required.", "httpStatus": http}
        return {"verdict": "WARNING", "outcome": "NEEDS_VERIFICATION", "reason": "The HTTP call succeeded, but the response does not clearly prove the final business state.", "nextAction": action or "Verify the resulting object/audit state before relying on it.", "httpStatus": http}

    if http is not None and 300 <= http < 400:
        return {"verdict": "WARNING", "outcome": "REDIRECT_OR_INTERMEDIATE", "reason": f"The API returned HTTP {http}; the final business state should be verified.", "nextAction": action or "Verify the target endpoint and final state.", "httpStatus": http}

    if error:
        return {"verdict": "FAIL", "outcome": "EXECUTION_ERROR", "reason": issue or error, "nextAction": action or "Resolve the execution error and retry.", "httpStatus": http}

    return {"verdict": "WARNING", "outcome": "NEEDS_REVIEW", "reason": issue or "The agent received a result but cannot prove a clean success or failure from the available evidence.", "nextAction": action or "Review the final response and verification/audit evidence.", "httpStatus": http}


def verdict_allows_progress(verdict: Any) -> bool:
    """True when downstream execution may safely continue.

    PASS is reusable, including PASS/EXISTING.  WARNING/EXISTING is retained
    as backward-compatible input for older persisted reports, but new analysis
    emits PASS for an explicitly proven existing object. Other warnings remain
    review-only and do not automatically unblock dependencies.
    """
    value = verdict if isinstance(verdict, dict) else {}
    status = str(value.get("verdict") or "").upper()
    outcome = str(value.get("outcome") or "").upper()
    return status == "PASS" or outcome == "EXISTING"


def reconcile_execution_analyses(items: Iterable[Any]) -> list[Dict[str, Any]]:
    """Reconcile only an actual retry of the *same* logical API step.

    V109 preserves the V108 rule that removes cross-step reuse inference. A successful dependent
    API can never rewrite an earlier Account/Partner/System/Rule failure into
    EXISTING_REUSED, and validation failures are never hidden by later success.
    Every row keeps the verdict earned by its own HTTP response. The only allowed
    softening is when the exact same logical API is actually executed again and
    that later retry succeeds.
    """
    rows = list(items)
    analyses = [analyze_api_response(item) for item in rows]
    step_keys: list[str] = []
    for item in rows:
        extracted = _get(item, "extracted", default={}) or {}
        key = ""
        if isinstance(extracted, dict):
            key = str(extracted.get("logicalStepKey") or extracted.get("stepKey") or "")
        step_keys.append(key)

    def proof_allows_progress(analysis: Dict[str, Any]) -> bool:
        verdict = str(analysis.get("verdict") or "").upper()
        outcome = str(analysis.get("outcome") or "").upper()
        return verdict == "PASS" or outcome in {"EXISTING", "RETRIED_SUCCESS"}

    later_success_index: Dict[str, int] = {}
    for idx, (key, analysis) in enumerate(zip(step_keys, analyses)):
        if key and proof_allows_progress(analysis):
            later_success_index[key] = idx

    for idx, (key, analysis) in enumerate(zip(step_keys, analyses)):
        if not key or later_success_index.get(key, -1) <= idx:
            continue
        verdict = str(analysis.get("verdict") or "").upper()
        if verdict in {"FAIL", "BLOCKED"}:
            analyses[idx] = {
                **analysis,
                "verdict": "WARNING",
                "outcome": "RETRIED_SUCCESS",
                "reason": "This API attempt failed, but the same logical API was actually executed again later and the retry passed. No dependent API was used as substitute evidence.",
                "nextAction": "Use the later successful response from this same API step as the final evidence.",
            }
    return analyses


def summarize_analyses(items: Iterable[Any]) -> Dict[str, Any]:
    analyses = reconcile_execution_analyses(list(items))
    counts = {key: 0 for key in ("PASS", "WARNING", "FAIL", "BLOCKED", "SKIPPED")}
    for analysis in analyses:
        verdict = str(analysis.get("verdict") or "WARNING").upper()
        counts[verdict] = counts.get(verdict, 0) + 1
    if counts.get("FAIL"):
        overall = "FAIL"
    elif counts.get("BLOCKED"):
        overall = "BLOCKED"
    elif counts.get("WARNING"):
        overall = "WARNING"
    else:
        overall = "PASS"
    return {"overallVerdict": overall, "counts": counts, "analyses": analyses}
