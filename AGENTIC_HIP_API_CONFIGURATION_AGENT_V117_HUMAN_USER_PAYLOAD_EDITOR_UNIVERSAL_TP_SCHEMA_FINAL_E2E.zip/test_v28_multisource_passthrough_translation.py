from __future__ import annotations

import gzip
import tempfile
import zipfile
from pathlib import Path

from input_builder_artifacts import build_profile_runner_manual_bytes
from input_builder_core import (
    build_from_config_manual_and_raw_files,
    build_from_raw_files,
    normalize_input_json,
)
from input_builder_integration import apply_user_request_hints, unresolved_questions
from run_agent import Runner
from uhal_mapper import UhalInputMapper

ROOT = Path(__file__).resolve().parent


def _xml(path: Path, root: str = "PurchaseOrder") -> Path:
    path.write_text(
        f"<{root}><Receiver>CUSTOMER</Receiver><Sender>DELL</Sender><OrderId>123</OrderId></{root}>",
        encoding="utf-8",
    )
    return path


def _mapping_files(root: Path, include_jar: bool = True):
    xbm_text = (
        '<transformMap logicalName="MAP850" analystVersionLastSaved="6.7.2">'
        '<sources><schemaRoot logicalName="PurchaseOrder"/></sources>'
        '<targets><schemaRoot logicalName="DellPO"/></targets></transformMap>'
    )
    xbm = root / "MAP850.xbm"
    xbm.write_bytes(gzip.compress(xbm_text.encode("utf-8")))
    files = [xbm]
    if include_jar:
        jar = root / "Transform_MAP850.jar"
        with zipfile.ZipFile(jar, "w") as zf:
            zf.writestr("com/dell/Transform_MAP850.class", b"class")
        files.append(jar)
    return files


def _base_passthrough() -> dict:
    return {
        "customer": "ATEA_NORWAY",
        "direction": "Inbound",
        "flow_type": "passthrough",
        "requires_data_map": False,
        "profile_name": "ATEA_FLOW",
        "objects": {
            "source_document_type": {
                "name": "CXML_850_ATEA_P", "version": "1", "data_format_type": "XML",
                "api_transaction_type": "INBOUND",
                "document_identifier": {"operation": "ALL", "rows": [{"value": "cXML"}]},
                "attributes_to_configure": [{"attribute_name": "Receiver", "value": "ATEA"}],
            },
            "target_document_type": {
                "name": "SHOULD_BE_REMOVED", "version": "1", "data_format_type": "XML",
                "document_identifier": {"rows": [{"value": "cXML"}]},
            },
            "data_map": {"map_identifier": "OLD_MAP", "map_name": "OLD_MAP", "map_data_file": "old.jar"},
            "rule": {"name": "OLD_RULE"},
            "source_transport_profile": {"profile_name": "SRC_TP", "partner_name": "CUSTOMER", "document_type": "CXML_850_ATEA_P(1.0)"},
            "target_transport_profile": {"profile_name": "TGT_TP", "partner_name": "AIC - DCE", "document_type": "SHOULD_BE_REMOVED(1.0)"},
            "biz_flow": {
                "configure_targets": {"target_transport_profile": "TGT_TP", "document_type_name_version": "SHOULD_BE_REMOVED(1.0)"},
                "process_steps": [
                    {"step_type": "Mapping Transformer"},
                ],
                "configure_routing": {},
            },
        },
    }


def test_passthrough_strictly_uses_one_document_type_and_no_mapping_objects():
    data = normalize_input_json(_base_passthrough())
    src = data["objects"]["source_document_type"]
    tgt = data["objects"]["target_document_type"]
    assert data["flow_type"] == "passthrough"
    assert data["requires_data_map"] is False
    assert tgt.get("name") == ""
    assert tgt.get("_passthrough") is True
    assert data["objects"]["data_map"]["map_identifier"] == ""
    assert data["objects"]["rule"]["name"] == "NA"
    assert data["objects"]["biz_flow"]["process_steps"] == []
    assert data["objects"]["target_transport_profile"]["document_type"].startswith(src["name"])
    assert data["objects"]["biz_flow"]["configure_targets"]["document_type_name_version"].startswith(src["name"])


def test_passthrough_target_document_type_is_not_applicable_by_default():
    data = normalize_input_json(_base_passthrough())
    runner = Runner.__new__(Runner)
    runner.mapper = UhalInputMapper(data, {}, ROOT)
    assert runner.step_applicable("doctype_target") is False
    assert runner.step_applicable("map") is False
    assert runner.step_applicable("rule") is False
    assert "reuse" in runner.applicability_reason("doctype_target").lower()


def test_passthrough_explicit_separate_target_exception_is_supported():
    raw = _base_passthrough()
    raw["passthrough_target_document_type_required"] = True
    raw["objects"]["data_map"] = {}
    raw["objects"]["rule"] = {}
    data = normalize_input_json(raw)
    assert data["objects"]["target_document_type"]["name"] == "SHOULD_BE_REMOVED"
    runner = Runner.__new__(Runner)
    runner.mapper = UhalInputMapper(data, {}, ROOT)
    assert runner.step_applicable("doctype_target") is True
    assert runner.step_applicable("map") is False
    assert runner.step_applicable("rule") is False


def test_raw_files_only_create_passthrough_input_without_target_doc(tmp_path):
    sample = _xml(tmp_path / "sample.xml")
    data = build_from_raw_files(
        [sample], customer="ATEA_NORWAY", direction="Inbound",
        flow_type="passthrough", use_dell_aia=False,
    )
    assert data["flow_type"] == "passthrough"
    assert data["objects"]["target_document_type"].get("name") == ""
    assert data["objects"]["data_map"].get("map_identifier") == ""
    assert data["objects"]["rule"].get("name") == "NA"
    assert not any(
        str(step.get("step_type") or "").lower() == "mapping transformer"
        for step in data["objects"]["biz_flow"].get("process_steps", [])
        if isinstance(step, dict)
    )


def test_xbm_without_jar_is_translation_and_agent_asks_for_missing_jar(tmp_path):
    sample = _xml(tmp_path / "sample.xml")
    xbm = _mapping_files(tmp_path, include_jar=False)[0]
    data = build_from_raw_files(
        [sample, xbm], customer="LEGRAND", direction="Inbound",
        use_dell_aia=False,
    )
    assert data["flow_type"] == "translation"
    assert data["requires_data_map"] is True
    questions = unresolved_questions(ROOT, data, "SFTP", "SFTP")
    assert any("mapping jar" in str(q.get("label") or "").lower() for q in questions)


def test_explicit_passthrough_choice_wins_even_when_mapping_artifacts_exist(tmp_path):
    sample = _xml(tmp_path / "sample.xml")
    files = [sample] + _mapping_files(tmp_path, include_jar=True)
    data = build_from_raw_files(
        files, customer="CUSTOMER", direction="Inbound",
        flow_type="passthrough", use_dell_aia=False,
    )
    assert data["flow_type"] == "passthrough"
    assert data["objects"]["target_document_type"].get("name") == ""
    assert data["objects"]["data_map"].get("map_identifier") == ""


def test_configuration_manual_plus_customer_files_generate_one_canonical_input(tmp_path):
    # Start with a valid Passthrough manual. Mapping artifacts then teach the
    # auto-detect path that the new interaction is actually Translation.
    manual_cfg = normalize_input_json(_base_passthrough())
    manual_bytes = build_profile_runner_manual_bytes(manual_cfg)
    manual = tmp_path / "Configuration_Manual.xlsx"
    manual.write_bytes(manual_bytes)
    sample = _xml(tmp_path / "sample.xml")
    raw_files = [sample] + _mapping_files(tmp_path, include_jar=True)
    combined = build_from_config_manual_and_raw_files(
        manual, raw_files, customer="LEGRAND", direction="Inbound",
        flow_type="", use_dell_aia=False, manual_primary=True,
    )
    assert combined["flow_type"] == "translation"
    assert combined["requires_data_map"] is True
    assert combined["_source"] == "Configuration Manual + customer artifacts"
    assert combined["objects"]["data_map"].get("map_data_file") == "Transform_MAP850.jar"


def test_user_request_is_an_audited_input_source_and_reapplies_passthrough_policy(tmp_path):
    raw = _base_passthrough()
    raw["flow_type"] = "translation"
    raw["requires_data_map"] = True
    data = normalize_input_json(raw)
    updated, audit = apply_user_request_hints(
        tmp_path, data,
        "This is an inbound passthrough flow. DUNS is 99887766. Target account is TGT_ACC. No separate target document type.",
        use_aia=False,
    )
    assert updated["flow_type"] == "passthrough"
    assert updated["partner_identifier_value"] == "99887766"
    assert updated["objects"]["target_transport_profile"]["existing_account_name"] == "TGT_ACC"
    assert updated["objects"]["target_document_type"].get("name") == ""
    assert audit["applied"]
    assert updated["_builder_audit"]["user_request"]["source"] == "explicit_user_request"


def test_builder_ui_exposes_all_three_intake_modes_and_user_request_learning():
    ui = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    assert "Customer files only — agent creates input.json" in ui
    assert "Configuration Manual + customer files — agent creates input.json" in ui
    assert "Existing input.json + supporting artifacts" in ui
    assert "User request / business instructions for input.json" in ui
    assert "Passthrough exception: configure a separate Target Document Type" in ui
