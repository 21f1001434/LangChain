import json
import shutil
from pathlib import Path

from customer_intake_report import build_customer_intake_model, write_customer_intake_report, REPORT_HTML, REPORT_JSON

ROOT = Path(__file__).resolve().parent


def _record(workspace: Path, **patch):
    data = {
        "workspace": str(workspace),
        "name": "Customer configuration",
        "customer": "Example Customer",
        "source_interface": "SFTP",
        "target_interface": "SFTP",
        "direction": "Outbound",
        "transaction_code": "856",
        "transaction_name": "Ship Notice",
        "flow_type": "Translation",
        "questions": [],
    }
    data.update(patch)
    return data


def test_v69_uhal_plain_language_report_contains_proven_reference_values(tmp_path: Path):
    shutil.copy2(ROOT / "input.json", tmp_path / "input.json")
    (tmp_path / "input_files").mkdir()
    for source in (ROOT / "input_files").iterdir():
        if source.is_file():
            shutil.copy2(source, tmp_path / "input_files" / source.name)
    model = write_customer_intake_report(tmp_path, _record(tmp_path, customer="U-HAUL"), ROOT)
    html = (tmp_path / "reports" / REPORT_HTML).read_text(encoding="utf-8")
    data = json.loads((tmp_path / "reports" / REPORT_JSON).read_text(encoding="utf-8"))
    assert model["readyForApiMapping"] is True
    assert model["requiredQuestionCount"] == 0
    assert "12345666" in html
    assert "External HIP partner identifier / DUNS" in html
    assert "What the agent can extract from customer files" in html
    assert "What the user ultimately has to provide" in html
    assert "Reference example" in html
    assert data["uhalReference"]["partnerReference"]["name"] == "dce-test-partner"
    assert data["uhalReference"]["partnerReference"]["identifierValue"] == "12345666"
    assert "not to U-HAUL" in data["uhalReference"]["partnerReference"]["note"]
    duns_row = next(r for r in data["rows"] if r["path"] == "partner_identifier_value")
    assert duns_row["referenceOwner"] == "dce-test-partner"
    assert duns_row["uhalValue"] == "dce-test-partner — DUNS 12345666"


def test_v69_report_marks_file_mapped_value_as_extracted_and_missing_folder_as_user_input(tmp_path: Path):
    canonical = json.loads((ROOT / "input.json").read_text(encoding="utf-8"))
    canonical["customer"] = "NEWCO"
    canonical["objects"]["target_transport_profile"].pop("subscription_folder", None)
    canonical["_file_mapping"] = {
        "fieldMappings": [
            {
                "path": "objects.source_document_type.data_format_type",
                "sourceFile": "customer_source.xml",
                "rule": "physical file format",
                "confidence": "high",
            }
        ]
    }
    (tmp_path / "input.json").write_text(json.dumps(canonical, indent=2), encoding="utf-8")
    (tmp_path / "input_files").mkdir()
    (tmp_path / "input_files" / "customer_source.xml").write_text("<DellAutoASN/>", encoding="utf-8")
    model = build_customer_intake_model(tmp_path, _record(tmp_path, customer="NEWCO"), ROOT)
    by_path = {row["path"]: row for row in model["rows"]}
    assert by_path["objects.source_document_type.data_format_type"]["status"] == "EXTRACTED"
    assert by_path["objects.source_document_type.data_format_type"]["source"] == "customer_source.xml"
    assert by_path["objects.target_transport_profile.subscription_folder"]["status"] == "USER_REQUIRED"
    assert "/Inbound/ASN" in by_path["objects.target_transport_profile.subscription_folder"]["uhalValue"]


def test_v69_report_explains_worktype_as_hip_managed_and_never_user_required(tmp_path: Path):
    shutil.copy2(ROOT / "input.json", tmp_path / "input.json")
    (tmp_path / "input_files").mkdir()
    model = build_customer_intake_model(tmp_path, _record(tmp_path, customer="U-HAUL"), ROOT)
    row = next(r for r in model["rows"] if r["path"] == "__worktype__")
    assert row["status"] == "HIP_MANAGED"
    assert row["uhalValue"] == "Omitted / HIP-managed"
    assert "No user action" in row["action"]


def test_v69_react_builder_exposes_required_values_html_button():
    builder = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    api = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    assert "Download Required Values HTML" in builder
    assert "What the agent knows vs what you still need to give" in builder
    assert "downloadIntakeReport" in api
    assert "/intake-report/download" in api
