$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host ""
Write-Host "Starting LIVE U-HAUL HIP execution..."
Write-Host "Dell AIA model: gpt-oss-120b"
Write-Host "Execution mode: LIVE ONLY"
Write-Host "LLM judge: mandatory"
Write-Host ""

python .\run_agent.py

if ($LASTEXITCODE -ne 0) {
    Write-Error "Execution failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Execution completed."
Write-Host "Reports are available under .\reports"
