import json
from pathlib import Path

from payload_overrides import PayloadOverrideStore
from webapp.backend.app import legacy_adapter
from webapp.backend.app.templates import generated_template_from_configuration


def _canonical():
    return {
        "profile_name": "INLINE_FIX_FLOW",
        "customer": "INLINE_FIX_CUSTOMER",
        "direction": "Inbound",
        "tx_code": "850",
        "requires_data_map": True,
        "partner_identifier_value": "OLD_PARTNER",
        "objects": {
            "source_transport_profile": {"profile_name": "SRC_TP", "existing_account_name": "old_source"},
            "target_transport_profile": {"profile_name": "TGT_TP", "existing_account_name": "old_target", "partner_name": "partner"},
            "source_document_type": {"name": "SRC_DOC"},
            "target_document_type": {"name": "TGT_DOC"},
            "data_map": {"map_name": "MAP"},
            "rule": {"name": "RULE"},
            "biz_flow": {},
        },
    }


def _preview():
    return {
        "items": [
            {
                "stepKey": "partner_target",
                "requestKind": "payload",
                "payload": {"partnerIdentifierValue": "OLD_PARTNER", "name": "partner"},
                "params": None,
                "extraHeaders": {"x-account-name": "old_source"},
                "applicable": True,
            },
            {
                "stepKey": "flow_deploy",
                "requestKind": "payload",
                "payload": {"flowName": "INLINE_FIX_FLOW", "user": {"emailId": "old@example.com"}},
                "params": None,
                "extraHeaders": {},
                "applicable": True,
            },
        ]
    }


def test_validation_blockers_become_same_screen_questions(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(legacy_adapter, "preview_api_requests", lambda workspace: _preview())
    validation = {
        "ok": False,
        "requests": {
            "items": [],
            "blockedItems": [{
                "stepKey": "partner_target", "label": "Partner Create", "valid": False,
                "errors": [
                    {"field": "partnerIdentifierValue", "message": "Required field is missing."},
                    {"field": "header.x-account-name", "message": "Required header is missing."},
                ],
            }],
        },
    }
    result = legacy_adapter.attach_inline_validation_repairs(tmp_path, validation)
    questions = result["requests"]["blockedItems"][0]["repairQuestions"]
    assert {q["field"] for q in questions} == {"partnerIdentifierValue", "header.x-account-name"}
    assert all(q["editable"] for q in questions)
    assert next(q for q in questions if q["field"] == "header.x-account-name")["currentValue"] == "old_source"
    assert next(q for q in questions if q["field"] == "partnerIdentifierValue")["canonicalPath"] == "partner_identifier_value"


def test_inline_fix_updates_input_template_values_and_request_override(monkeypatch, tmp_path: Path):
    (tmp_path / "input.json").write_text(json.dumps(_canonical()), encoding="utf-8")
    monkeypatch.setattr(legacy_adapter, "preview_api_requests", lambda workspace: _preview())
    result = legacy_adapter.apply_inline_validation_fixes(tmp_path, [
        {"step_key": "partner_target", "field": "partnerIdentifierValue", "value": "NEW_PARTNER"},
        {"step_key": "partner_target", "field": "header.x-account-name", "value": "new_source"},
        {"step_key": "flow_deploy", "field": "user.emailId", "value": "new@example.com"},
    ])
    assert result["count"] == 3
    canonical = json.loads((tmp_path / "input.json").read_text(encoding="utf-8"))
    assert canonical["partner_identifier_value"] == "NEW_PARTNER"
    assert canonical["objects"]["source_transport_profile"]["existing_account_name"] == "new_source"
    overrides = json.loads((tmp_path / "config_overrides.json").read_text(encoding="utf-8"))
    assert overrides["source_haft_account"] == "new_source"
    assert overrides["x_account_name"] == "new_source"
    stored = PayloadOverrideStore(tmp_path).get("flow_deploy")
    assert stored["mode"] == "merge"
    assert stored["value"]["user"]["emailId"] == "new@example.com"
    template = generated_template_from_configuration("cfg-inline", canonical)
    assert template["default_values"]["source_account"] == "new_source"
    flow_node = next(node for node in template["nodes"] if node["api_key"] == "flow_deploy")
    assert flow_node["request_override"]["user"]["emailId"] == "new@example.com"


def test_react_builder_exposes_inline_apply_and_revalidate():
    root = Path(__file__).resolve().parent
    ui = (root / "webapp" / "frontend" / "src" / "pages" / "BuilderPage.tsx").read_text(encoding="utf-8")
    api = (root / "webapp" / "frontend" / "src" / "lib" / "api.ts").read_text(encoding="utf-8")
    main = (root / "webapp" / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert "Agent asks you to fix it here" in ui
    assert "Apply this fix + revalidate" in ui
    assert "Apply entered fixes + revalidate" in ui
    assert "applyValidationFixes" in api
    assert "/validation-fixes" in main
    assert "result = validate_configuration(workspace)" in main
