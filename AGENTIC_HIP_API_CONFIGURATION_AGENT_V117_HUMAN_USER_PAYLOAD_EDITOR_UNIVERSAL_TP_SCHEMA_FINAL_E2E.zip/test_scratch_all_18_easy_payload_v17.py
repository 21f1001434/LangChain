from __future__ import annotations

from execution_flow import STEP_DEFINITIONS
from payload_ui_helpers import (
    apply_quick_field_change,
    get_json_path,
    json_field_paths,
    parse_json_value,
)
from run_agent import Runner
from scratch_flow import drag_palette_item, parse_drag_item, reconcile_drag_canvas


def test_exactly_all_18_hip_api_blocks_are_available_and_draggable():
    assert len(STEP_DEFINITIONS) == 18
    for step_key in STEP_DEFINITIONS:
        label = drag_palette_item(step_key)
        kind, parsed_key = parse_drag_item(label)
        assert kind == "template"
        assert parsed_key == step_key


def test_all_18_blocks_can_be_dropped_once_in_one_visual_flow():
    visual = [drag_palette_item(step_key) for step_key in STEP_DEFINITIONS]
    flow, change = reconcile_drag_canvas({"name": "All 18", "components": []}, visual)
    assert len(flow["components"]) == 18
    assert [row["stepKey"] for row in flow["components"]] == list(STEP_DEFINITIONS)
    assert len(change["addedInstanceIds"]) == 18
    assert len(set(change["addedInstanceIds"])) == 18


def test_all_18_blocks_have_non_mutating_request_inspection():
    runner = Runner(llm_enabled=False)
    for step_key in STEP_DEFINITIONS:
        request = runner.preview_step_request(step_key)
        assert request.get("method") in {"GET", "POST", "PUT", "PATCH", "DELETE"}
        assert request.get("urlKey")
        kind = request.get("requestKind") or "payload"
        assert kind in {"payload", "params"}
        body = request.get("params") if kind == "params" else request.get("payload")
        assert isinstance(body, dict), step_key


def test_easy_payload_editor_changes_nested_array_field_without_losing_siblings():
    payload = {
        "name": "DOC_A",
        "attributes": [
            {"name": "Sender", "value": "DELL", "usage": ["Identifier", "Display"]},
            {"name": "Receiver", "value": "UHAUL"},
        ],
        "documentIdentifier": {"rootElement": "Shipment"},
    }
    rows = json_field_paths(payload)
    paths = {row["path"] for row in rows}
    assert "attributes[0].value" in paths
    assert "attributes[0].usage[1]" in paths
    assert "documentIdentifier.rootElement" in paths

    changed = apply_quick_field_change(payload, "attributes[0].value", "NEW_SENDER")
    assert get_json_path(changed, "attributes[0].value") == "NEW_SENDER"
    assert changed["attributes"][0]["usage"] == ["Identifier", "Display"]
    assert changed["attributes"][1] == payload["attributes"][1]
    assert changed["documentIdentifier"] == payload["documentIdentifier"]
    assert payload["attributes"][0]["value"] == "DELL"  # input not mutated


def test_easy_payload_editor_preserves_field_types():
    assert parse_json_value("42", "integer") == 42
    assert parse_json_value("3.5", "number") == 3.5
    assert parse_json_value("false", "boolean") is False
    assert parse_json_value('["A", "B"]', "array") == ["A", "B"]
    assert parse_json_value('{"x":1}', "object") == {"x": 1}
    assert parse_json_value("00123", "string") == "00123"


def test_ui_exposes_easy_editor_and_18_api_coverage():
    text = open("scratch_flow_ui.py", "r", encoding="utf-8").read()
    assert 'HIP_API_BLOCK_COUNT = 18' in text
    assert 'Easy Payload Editor' in text
    assert 'See all 18 reusable HIP API blocks' in text
    assert 'Copy / import payload' in text
    assert 'Fill this field from input.json' in text
    assert 'Advanced Full JSON Editor' in text
