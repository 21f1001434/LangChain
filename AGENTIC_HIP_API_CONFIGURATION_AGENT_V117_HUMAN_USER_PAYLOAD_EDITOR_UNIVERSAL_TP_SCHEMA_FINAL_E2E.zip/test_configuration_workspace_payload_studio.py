from __future__ import annotations

import json
from pathlib import Path

from adaptive_engine import AdaptiveHipEngine
from configuration_workspace import build_guided_input, guided_questions
from payload_overrides import PayloadOverrideStore, save_override
from uhal_mapper import UhalInputMapper

ROOT = Path(__file__).resolve().parent


def main() -> None:
    fields = {
        "customer": "ACME",
        "flow_name": "ACME_PC_856_ANS_MAPPING_OB",
        "direction": "Outbound",
        "tx_standard": "X12",
        "tx_code": "856",
        "tx_name": "Ship Notice",
        "dell_app": "ANS",
        "version": "1",
        "data_format": "XML",
        "source_doc_name": "XML_ACME_ASN_IB",
        "source_root": "DellAutoASN",
        "source_receiver_expression": "/DellAutoASN/To",
        "source_sender_expression": "/DellAutoASN/From",
        "source_business_expression": "/DellAutoASN/PO",
        "source_alt_business_expression": "/DellAutoASN/PO2",
        "target_doc_name": "XML_SHIPMENT_NOTICE_ACME_OB",
        "target_root": "SHIPMENT_NOTICE",
        "target_receiver_expression": "/SHIPMENT_NOTICE/R/@d",
        "target_sender_expression": "/SHIPMENT_NOTICE/R/@s",
        "target_business_expression": "/SHIPMENT_NOTICE/PO/@n",
        "target_alt_business_expression": "/SHIPMENT_NOTICE/R/@s",
        "map_identifier": "ACME_ASN_MAP",
        "map_name": "ACME_ASN",
        "map_class": "Transform_ACME_ASN",
        "map_data_file": "Transform_DELLCoXMLASNXX08C.jar",
        "rule_name": "ACME_ASN_RULE",
        "receiver_value": "acme",
        "receiver_operator": "Equals",
        "sender_value": "DELL",
        "sender_operator": "Contains",
        "source_system": "AIC - DCE",
        "source_tp_profile": "SFTP_ACME_SRC",
        "source_flow_tp": "da-sender-sftphaft-dce-common",
        "source_account": "acct_src",
        "source_folder": "/src",
        "source_deployment_group": "hip-automation",
        "target_partner": "acme-partner",
        "target_tp_profile": "SFTP_ACME_TGT",
        "target_flow_tp": "pt-receiver-sftphaft-dce-common",
        "target_account": "acct_tgt",
        "target_folder": "/Inbound",
        "target_deployment_group": "hip-automation",
        "interface_environment": "UAT",
    }
    assert not guided_questions(fields), guided_questions(fields)
    canonical = build_guided_input(fields)
    engine = AdaptiveHipEngine(ROOT)
    config = engine.derive_config_updates(canonical, {})
    mapper_errors = [
        item.__dict__
        for item in UhalInputMapper(canonical, config, ROOT).validate()
        if item.severity == "ERROR"
    ]
    assert not mapper_errors, mapper_errors
    assert canonical["objects"]["biz_flow"]["configure_source"]["source_transport_profile"] == "da-sender-sftphaft-dce-common"
    assert canonical["objects"]["biz_flow"]["configure_targets"]["target_transport_profile"] == "pt-receiver-sftphaft-dce-common"
    assert canonical["_creation_source"]["mode"] == "GUIDED_UI"

    override_path = ROOT / "payload_overrides.json"
    original = override_path.read_text(encoding="utf-8") if override_path.exists() else None
    try:
        save_override(
            ROOT,
            "rule",
            {
                "documentTypeId": "{{runtime.source_document_type_id}}",
                "description": "USER EDITED",
            },
            request_kind="payload",
            mode="merge",
            note="test",
            edit_origin="USER",
        )
        store = PayloadOverrideStore(ROOT)
        factory = {"payload": {"documentTypeId": 0, "name": "R", "description": "generated"}}
        effective, meta = store.apply(
            "rule",
            factory,
            {"runtime": {"source_document_type_id": 92001}},
        )
        assert meta["applied"] is True
        assert effective["payload"]["documentTypeId"] == 92001
        assert effective["payload"]["description"] == "USER EDITED"
        assert effective["payload"]["name"] == "R"
    finally:
        if original is None:
            override_path.unlink(missing_ok=True)
        else:
            override_path.write_text(original, encoding="utf-8")

    ui = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8") + "\n" + (ROOT / "legacy_pages" / "90_Advanced_Technical_Workspace.py").read_text(encoding="utf-8")
    for token in [
        "Guided new configuration (no JSON)",
        "Start from API payloads",
        "API documentation PDF(s)",
        "Payload Studio",
        "Edit API payloads directly",
        "da-sender-sftphaft-dce-common",
        "pt-receiver-sftphaft-dce-common",
        "Ask Dell AIA to review/fix",
    ]:
        assert token in ui, token

    output = {
        "status": "PASS",
        "guidedCreationWithoutInputJson": True,
        "guidedMapperValidation": "PASS",
        "sourceFlowTpDefaultSupported": "da-sender-sftphaft-dce-common",
        "targetFlowTpDefaultSupported": "pt-receiver-sftphaft-dce-common",
        "runtimeTemplatedPayloadOverride": "PASS",
        "payloadMergeOverride": "PASS",
        "pdfUploadUi": True,
        "payloadFirstUi": True,
        "payloadStudioUi": True,
    }
    path = ROOT / "examples" / "CONFIGURATION_WORKSPACE_PAYLOAD_STUDIO_TEST.json"
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
