# HIP Application Studio V30

V30 adds validated multi-configuration parallel execution and backend latency optimizations without redesigning the existing Studio UI.

## Parallel configuration agents
- A configuration can enter the parallel queue only after the existing agent/mapper/MCP/API-contract validation returns PASS.
- Each queued configuration is frozen as an immutable snapshot of `input.json`, customer artifacts, config/payload overrides, execution flow, interface profile, and exact-request validation cache.
- Multiple queued configurations can run concurrently with bounded workers (`HIP_PARALLEL_CONFIG_WORKERS`, default 3, maximum 8).
- Parallelism is **across configurations only**. The 18 API steps inside a single configuration retain their dependency-aware order.
- Each live configuration receives an isolated workspace, payload directory, report directory, runtime state and live-run lock.
- OAuth credentials are not copied into queue snapshots. Parallel workers use the normal local `.env`/`Test.py`/environment credential configuration.

## Latency improvements
- HIP API calls reuse a pooled `requests.Session` (`HIP_HTTP_POOL_SIZE`, default 24) to reduce repeated TCP/TLS setup.
- Exact request-contract validation results are cached by a SHA-256 fingerprint (`HIP_REUSE_VALIDATED_REQUESTS=true` by default). A live run can reuse a prior PASS only when method, URL, headers, payload/params, build ID, validation mode and API-PDF state are identical.
- Existing retry/backoff behavior for 408/429/502/503/504 is retained.
- No visual redesign is required; the existing screens remain, with one additional `Parallel Configurations` workspace and a queue button after successful validation.

## Execution safety
All Run/Test/Launch paths are live-only. Parallel execution never bypasses preflight or dependency checks inside each configuration.
