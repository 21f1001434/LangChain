# Dev Document Type Payload Review

## Conclusion

The Dev-team POST payload is structurally consistent with the previously shared
v3 Document Type API schema, but it provides the exact nested shape and a few
runtime differences that the generic Swagger example did not make clear.

## Same as the API schema

- `name`
- `dataFormatType`
- `transactionType`
- `version`
- `description`
- `validationType`
- `schemaFileName`
- `schemaFileContent`
- `hipEnvironment`
- `documentIdentifier`
- `createdBy`
- `lastModifiedBy`
- `attributes[]`
- `attributes[].attributeName`
- `attributes[].derivedFrom`
- `attributes[].expression`
- `attributes[].usage[]`

## Exact Dev-team behavior applied

| Field | Final behavior |
|---|---|
| `statusDisabled` | Included as a Boolean |
| `version` | Sent as a string such as `"1.0"` |
| `transactionType` | Uses `INBOUND` or `OUTBOUND`, not `856` |
| `documentIdentifier` | `{ "operator": "ALL", "attributeList": [...] }` |
| Identifier entries | `derivedFrom` plus optional `expression` and `value` |
| `lastModifiedBy` | Included as an empty string |
| `filemask` | Omitted |
| `ediDelimiters` | Omitted for the XML U-HAUL flow |

## Important value correction

The example payload shared by Dev contains sample values from another document.
The runner uses only its structure. U-HAUL-specific values are retained:

- Source root: `DellAutoASN`
- Target root: `SHIPMENT_NOTICE`
- Source transaction type: `INBOUND`
- Target transaction type: `OUTBOUND`
- Source and target XPath expressions remain from `input.json`

## Final Source identifier

```json
{
  "operator": "ALL",
  "attributeList": [
    {
      "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
      "value": "DellAutoASN"
    }
  ]
}
```

## Final Target identifier

```json
{
  "operator": "ALL",
  "attributeList": [
    {
      "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
      "value": "SHIPMENT_NOTICE"
    }
  ]
}
```
