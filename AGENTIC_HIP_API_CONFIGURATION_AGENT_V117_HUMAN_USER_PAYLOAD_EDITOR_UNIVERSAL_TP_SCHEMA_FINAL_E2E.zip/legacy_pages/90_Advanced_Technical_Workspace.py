from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from dotenv import dotenv_values, load_dotenv, set_key

from adaptive_engine import AdaptiveHipEngine
from api_execution_plan import (
    ApiExecutionPlan,
    STEP_DEFINITIONS as PLAN_STEP_DEFINITIONS,
    UHAL_EXISTING_FOUNDATION_PRESET,
    clear_execution_plan,
    save_execution_plan,
)
from api_pdf_ingestion import PdfApiKnowledgeBase
from configuration_workspace import (
    FLOW_TP_PRESETS,
    INTERFACE_OPTIONS,
    build_guided_input,
    guided_questions,
    infer_fields_from_payload_bundle,
)
from execution_flow import (
    ExecutionFlowConfig,
    STEP_DEFINITIONS as FLOW_STEP_DEFINITIONS,
    reset_execution_flow,
    save_execution_flow,
)
from mcp_bridge import MCPBridge
from payload_overrides import (
    PayloadOverrideStore,
    clear_all_overrides,
    clear_override,
    save_override,
)
from uhal_mapper import UhalInputMapper
from ui_helpers import safe_table_rows
from payload_ui_helpers import json_change_paths, payload_status_row, safe_request_for_ui
from transport_interface_react import TransportInterfaceReActAgent, validate_interface_only_request_override
from runtime_payload_values import (
    has_runtime_payload_value,
    placeholder as runtime_payload_placeholder,
    save_runtime_payload_values,
)


ROOT = Path(__file__).resolve().parent.parent
INPUT_JSON = ROOT / "input.json"
CONFIG_JSON = ROOT / "config_overrides.json"
ENV_PATH = ROOT / ".env"
INCOMING_DIR = ROOT / "incoming_inputs"
INPUT_FILES = ROOT / "input_files"
REPORTS = ROOT / "reports"
DEV_APPROVED_DIR = ROOT / "dev_approved"
BUILD_ID = "2026-08-12-live-only-all18-interactive-game-upload-v23"
DEFAULT_HIP_TOKEN_URL = "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token"

INCOMING_DIR.mkdir(exist_ok=True)
INPUT_FILES.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)
load_dotenv(ENV_PATH, override=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def invalidate_connection_check() -> None:
    (REPORTS / "connection_check_latest.json").unlink(missing_ok=True)
    st.session_state.pop("connection_check", None)


def save_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    invalidate_connection_check()


def save_env(values: Dict[str, Any]) -> None:
    ENV_PATH.touch(exist_ok=True)
    for key, value in values.items():
        set_key(str(ENV_PATH), key, str(value or ""), quote_mode="always")
    load_dotenv(ENV_PATH, override=True)
    invalidate_connection_check()


def clear_env_values(keys: List[str]) -> None:
    ENV_PATH.touch(exist_ok=True)
    for key in keys:
        set_key(str(ENV_PATH), key, "", quote_mode="always")
    load_dotenv(ENV_PATH, override=True)


def configured(key: str) -> bool:
    value = os.getenv(key, "")
    return bool(value and not value.startswith(("REPLACE_", "PASTE_")))


def render_table(data: Any, empty_message: str = "No records") -> None:
    rows = safe_table_rows(data)
    if not rows:
        st.caption(empty_message)
        return
    st.dataframe(rows, width="stretch", hide_index=True)


def latest_report() -> Path | None:
    candidates = sorted(REPORTS.glob("UHAL_final_end_to_end_report_*.html"))
    if not candidates:
        candidates = sorted(REPORTS.glob("hip_aia_mcp_agent_report_*.html"))
    return candidates[-1] if candidates else None


def connection_component(title: str, component: Dict[str, Any]) -> None:
    status = str(component.get("status") or "NOT CHECKED").upper()
    if status == "OK":
        st.success(f"✅ {title}: connected")
    elif status in {"NOT_REQUIRED", "SKIPPED"}:
        st.info(f"⏭️ {title}: not required for this run")
        if component.get("reason"):
            st.caption(component["reason"])
    else:
        st.error(f"❌ {title}: {status.lower()}")
        if component.get("error"):
            st.caption(component["error"])


def apply_new_active_input(canonical: Dict[str, Any], *, reset_runtime_policy: bool = True) -> Dict[str, Any]:
    config = load_json(CONFIG_JSON, {})
    updated_config = engine.derive_config_updates(canonical, config)
    save_json(INPUT_JSON, canonical)
    save_json(CONFIG_JSON, updated_config)
    if reset_runtime_policy:
        clear_execution_plan(ROOT, INPUT_JSON)
        clear_all_overrides(ROOT)
        reset_execution_flow(ROOT)
    mapper = UhalInputMapper(canonical, updated_config, ROOT)
    try:
        engine.record_mapping_graph(mapper.execution_manifest())
    except Exception:
        pass
    return updated_config


def current_input_summary() -> Dict[str, Any]:
    value = load_json(INPUT_JSON, {})
    objects = value.get("objects") or {}
    biz = objects.get("biz_flow") or {}
    return {
        "Customer": value.get("customer") or "—",
        "Flow": value.get("profile_name") or (biz.get("flow_details") or {}).get("business_flow_name") or "—",
        "Direction": value.get("direction") or "—",
        "Transaction": " ".join(x for x in [str(value.get("tx_standard") or ""), str(value.get("tx_code") or ""), str(value.get("tx_name") or "")] if x) or "—",
        "Creation mode": (value.get("_creation_source") or {}).get("mode") or "input.json / existing package",
    }


def step_labels() -> Dict[str, str]:
    return {key: meta["label"] for key, meta in FLOW_STEP_DEFINITIONS.items()}


def bundle_from_runner() -> Dict[str, Any]:
    from run_agent import Runner
    runner = Runner(llm_enabled=False)
    bundle: Dict[str, Any] = {}
    for key in runner.execution_flow.ordered_steps():
        try:
            preview = runner.preview_step_request(key)
            bundle[key] = preview.get(preview.get("requestKind")) or {}
        except Exception as exc:
            bundle[key] = {"_preview_error": str(exc)}
    return bundle


def normalize_payload_bundle(value: Any) -> Dict[str, Dict[str, Any]]:
    if not isinstance(value, dict):
        raise ValueError("Payload bundle must be a JSON object keyed by API step.")
    valid_keys = set(FLOW_STEP_DEFINITIONS)
    out: Dict[str, Dict[str, Any]] = {}
    for key, raw in value.items():
        if key not in valid_keys:
            continue
        if isinstance(raw, dict) and "value" in raw and isinstance(raw.get("value"), dict):
            out[key] = raw["value"]
        elif isinstance(raw, dict) and "payload" in raw and isinstance(raw.get("payload"), dict):
            out[key] = raw["payload"]
        elif isinstance(raw, dict) and "params" in raw and isinstance(raw.get("params"), dict):
            out[key] = raw["params"]
        elif isinstance(raw, dict):
            out[key] = raw
    if not out:
        raise ValueError("No recognized HIP step keys were found in the payload bundle.")
    return out


def config_bundle_bytes() -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in [
            "input.json",
            "config_overrides.json",
            "api_execution_plan.json",
            "execution_flow.json",
            "payload_overrides.json",
        ]:
            path = ROOT / name
            if path.exists():
                zf.writestr(name, path.read_bytes())
    return buffer.getvalue()


engine = AdaptiveHipEngine(ROOT)
mcp = MCPBridge(ROOT, enabled=True, required=False)
pdf_kb = PdfApiKnowledgeBase(ROOT)


# ---------------------------------------------------------------------------
# Page and visual system
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="HIP Advanced Technical Workspace",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
<style>
:root{--navy:#061c38;--blue:#0b5cab;--cyan:#0e8792;--ink:#172033;--muted:#65758b;--line:#d9e3ef;--bg:#f3f7fb;--ok:#148447;--amber:#b76e00}
.stApp{background:linear-gradient(180deg,#f7faff 0,#eef4fa 100%)}
.block-container{max-width:1640px;padding-top:1rem;padding-bottom:4rem}
.hero{background:radial-gradient(circle at 86% 7%,rgba(41,196,199,.48),transparent 27%),linear-gradient(135deg,#051a34,#0b5cab 65%,#087f8f);color:white;padding:30px 34px;border-radius:22px;box-shadow:0 18px 46px rgba(9,48,84,.18);margin-bottom:16px}
.hero h1{margin:0;font-size:2rem}.hero p{color:#dceeff;margin:.5rem 0 0}.hero .build{font-size:.78rem;opacity:.8;margin-top:.75rem}
.workspace-card{background:white;border:1px solid var(--line);border-radius:16px;padding:16px 18px;margin:8px 0;box-shadow:0 8px 24px rgba(14,43,77,.05)}
.workspace-card b{color:#073d72}.hint{background:#eef7ff;border-left:5px solid var(--blue);padding:12px 14px;border-radius:10px;margin:8px 0 14px}.warn{background:#fff8e8;border-left:5px solid var(--amber);padding:12px 14px;border-radius:10px;margin:8px 0 14px}
[data-testid="stMetric"]{background:white;border:1px solid var(--line);padding:12px;border-radius:14px;box-shadow:0 6px 18px rgba(14,43,77,.04)}
.stButton>button{border-radius:10px;font-weight:650;min-height:2.7rem}
div[data-testid="stExpander"]{background:rgba(255,255,255,.72);border-radius:12px}
.small-label{font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;font-weight:750}
.payload-shell{background:white;border:1px solid var(--line);border-radius:18px;padding:18px 20px;box-shadow:0 10px 26px rgba(14,43,77,.05);margin:8px 0 14px}
.payload-status{display:inline-block;border-radius:999px;padding:4px 9px;font-size:.72rem;font-weight:800;margin-right:5px;background:#edf5ff;color:#07558f}
.payload-status.edited{background:#fff3d6;color:#895500}.payload-status.skip{background:#edf1f5;color:#596879}
</style>
<div class="hero">
  <h1>HIP Agentic Configuration Workspace</h1>
  <p>Create from a guided wizard, input JSON, or API payloads · upload API PDFs · edit/validate payloads · agent questions · execution planning · live deployment evidence.</p>
  <div class="build">Build: 2026-08-11-partner-payload-values-v12</div>
</div>
""",
    unsafe_allow_html=True,
)

active_summary = current_input_summary()
plan_summary_sidebar = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
override_summary_sidebar = PayloadOverrideStore(ROOT).summary()
flow_summary_sidebar = ExecutionFlowConfig(ROOT).summary()

with st.sidebar:
    st.header("Workspace")
    st.caption(f"Build {BUILD_ID}")
    st.metric("Customer", active_summary["Customer"])
    st.metric("Payload overrides", override_summary_sidebar.get("count", 0))
    st.metric("API skips", len(plan_summary_sidebar.get("skipSteps") or []))
    st.metric("API docs", len(pdf_kb.list_documents()))
    st.caption(f"Creation: {active_summary['Creation mode']}")
    if flow_summary_sidebar.get("valid"):
        st.success("Execution flow valid")
    else:
        st.error("Execution flow needs attention")
    st.divider()
    st.markdown("**Recommended workflow**")
    st.caption("1. Start / Create\n\n2. Credentials\n\n3. API Docs\n\n4. Agent Questions\n\n5. Payload Studio\n\n6–8. Plan\n\n9. Review & Run")


tabs = st.tabs([
    "1 · Start / Create",
    "2 · Credentials",
    "3 · API Docs",
    "4 · Agent Questions",
    "5 · Payload Studio",
    "6 · API Execution Plan",
    "7 · Flow & Timing",
    "8 · Dev Changes",
    "9 · Knowledge & Learning",
    "10 · Review & Run",
])


# ---------------------------------------------------------------------------
# 1. Start / Create
# ---------------------------------------------------------------------------
with tabs[0]:
    st.header("Start a configuration")
    st.markdown(
        '<div class="hint"><b>No input.json is required.</b> Choose the guided wizard or start from API payloads. The workspace creates the canonical metadata internally so the agent can still manage dependencies, IDs, validation and reports.</div>',
        unsafe_allow_html=True,
    )

    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Customer", active_summary["Customer"])
    s2.metric("Flow", active_summary["Flow"])
    s3.metric("Direction", active_summary["Direction"])
    s4.metric("Transaction", active_summary["Transaction"])

    if st.session_state.get("requested_create_mode"):
        st.session_state["create_mode"] = st.session_state.pop("requested_create_mode")

    create_mode = st.radio(
        "How do you want to start?",
        [
            "ReAct interface-only change from U-HAUL baseline",
            "Guided new configuration (no JSON)",
            "Upload input.json",
            "Start from API payloads",
            "Use / restore current U-HAUL configuration",
        ],
        horizontal=True,
        key="create_mode",
    )

    if create_mode == "ReAct interface-only change from U-HAUL baseline":
        st.subheader("ReAct Transport Profile Interface Agent")
        st.markdown(
            '<div class="hint"><b>Strict mode:</b> the approved U-HAUL configuration is frozen. The agent may change only Source/Target Transport Profile interface type + interface parameters. Any change to Document Types, Map, Rule, Account, Partner, System or Flow is rejected by the critic.</div>',
            unsafe_allow_html=True,
        )

        baseline = load_json(DEV_APPROVED_DIR / "UHAL_input_dev_approved.json", load_json(INPUT_JSON, {}))
        react = TransportInterfaceReActAgent(ROOT, baseline)
        ra1, ra2 = st.columns(2)
        src_type = ra1.selectbox("Source interface", INTERFACE_OPTIONS, index=0, key="adv_react_src_type")
        tgt_type = ra2.selectbox("Target interface", INTERFACE_OPTIONS, index=0, key="adv_react_tgt_type")

        src_params: Dict[str, Any] = {}
        tgt_params: Dict[str, Any] = {}
        src_secret = ""
        tgt_secret = ""

        x1, x2 = st.columns(2, gap="large")
        with x1:
            st.markdown("**Source parameters**")
            if src_type in {"SFTP", "FTP"}:
                st.info("Reuse U-HAUL file/account/folder values unchanged.")
            elif src_type == "HTTPS":
                src_params = {
                    "Protocol": st.text_input("Source Protocol", value="REST", key="adv_rs_protocol"),
                    "HIP URL": st.text_input("Source HIP URL", value="URL will be shared later after API Publish is successful.", key="adv_rs_hip"),
                    "Proxy URI": st.text_input("Source Proxy URI", value="dce-common-sv1", key="adv_rs_proxy"),
                    "Request Method": st.text_input("Source Request Method", value="POST", key="adv_rs_method"),
                    "Request Format": st.text_input("Source Request Format", value="Request Body", key="adv_rs_format"),
                    "Sender Authentication Type": st.text_input("Source Authentication", value="OAuth2", key="adv_rs_auth"),
                    "Are Input Files Compressed?": st.text_input("Source Compression", value="False", key="adv_rs_comp"),
                    "Sender Grant Type": st.text_input("Source Grant Type", value="client_credentials", key="adv_rs_grant"),
                }
                src_secret = st.text_input(
                    "Optional Source Client Secret", type="password", key="adv_rs_secret",
                    help="This is an interface payload value, not an application credential.",
                )
                if src_secret:
                    save_runtime_payload_values(ROOT, {"source": {"sender_client_secret": src_secret}}, merge=True)
                if src_secret or has_runtime_payload_value(ROOT, "source.sender_client_secret"):
                    src_params["Sender Client Secret"] = runtime_payload_placeholder("source.sender_client_secret")
            else:
                raw = st.text_area("Approved Source HTTPS-AS2 parameters", height=220, key="adv_rs_as2")
                try:
                    src_params = json.loads(raw) if raw.strip() else {}
                except Exception:
                    src_params = {}
                    st.error("Source AS2 parameters must be a JSON object.")

        with x2:
            st.markdown("**Target parameters**")
            if tgt_type in {"SFTP", "FTP"}:
                st.info("Reuse U-HAUL file/account/folder values unchanged.")
            elif tgt_type == "HTTPS":
                st.caption("Plain HTTPS Receiver SSL Certificate fields are intentionally ignored in the V117 Dev-validation candidate.")
                tgt_params = {
                    "Protocol": "REST",
                    "Partner URL": st.text_input("Partner URL", key="adv_rt_partner"),
                    "Request Method": st.text_input("Target Request Method", value="POST", key="adv_rt_method"),
                    "Request Format": st.text_input("Target Request Format", value="Request Body", key="adv_rt_format"),
                    "Receiver Authentication Type": st.text_input("Target Authentication", value="OAuth2", key="adv_rt_auth"),
                    "Gateway URL": st.text_input("Gateway URL", value="URL will be shared later after API Publish is successful.", key="adv_rt_gateway"),
                    "Are Input Files Compressed?": st.text_input("Target Compression", value="False", key="adv_rt_comp"),
                    "Receiver Grant Type": st.text_input("Target Grant Type", placeholder="Get from Partner", key="adv_rt_grant"),
                    "Receiver Token Endpoint": st.text_input("Receiver Token Endpoint", key="adv_rt_token"),
                    "Receiver Client Id": st.text_input("Receiver Client ID", key="adv_rt_client"),
                }
                tgt_secret = st.text_input(
                    "Receiver Client Secret", type="password", key="adv_rt_secret",
                    help="Partner-provided HTTPS payload value. It is not stored as a new .env credential.",
                )
                if tgt_secret:
                    save_runtime_payload_values(ROOT, {"target": {"receiver_client_secret": tgt_secret}}, merge=True)
                if tgt_secret or has_runtime_payload_value(ROOT, "target.receiver_client_secret"):
                    tgt_params["Receiver Client Secret"] = runtime_payload_placeholder("target.receiver_client_secret")
            else:
                raw = st.text_area("Approved Target HTTPS-AS2 parameters", height=220, key="adv_rt_as2")
                try:
                    tgt_params = json.loads(raw) if raw.strip() else {}
                except Exception:
                    tgt_params = {}
                    st.error("Target AS2 parameters must be a JSON object.")

        analysis = react.analyze(
            source_interface=src_type,
            target_interface=tgt_type,
            source_parameters=src_params,
            target_parameters=tgt_params,
        )
        render_table([{
            "Phase": row.get("phase"),
            "Status": row.get("status"),
            "Summary": row.get("summary"),
        } for row in analysis.get("trace") or []])

        if analysis.get("questions"):
            st.warning("Missing interface-only values")
            render_table(analysis["questions"])

        if st.button("Build strict ReAct proposal", type="primary", disabled=not analysis.get("ready"), width="stretch"):
            st.session_state["adv_react_proposal"] = react.propose(
                source_interface=src_type,
                target_interface=tgt_type,
                source_parameters=src_params,
                target_parameters=tgt_params,
            )

        proposal = st.session_state.get("adv_react_proposal")
        if proposal:
            critic = proposal.get("critic") or {}
            if critic.get("status") == "PASS":
                st.success("Critic PASS — only Transport Profile interface paths changed.")
            else:
                st.error("Critic FAIL — proposal rejected.")
                st.json(critic)
            with st.expander("Changed canonical paths", expanded=True):
                for path in proposal.get("changedPaths") or []:
                    st.code(path)
            with st.expander("Full proposal"):
                st.json(proposal.get("proposal") or {})
            approved = st.checkbox("I reviewed and approve this interface-only proposal", key="adv_react_approve")
            if st.button("Activate approved interface-only configuration", disabled=not (approved and proposal.get("valid")), width="stretch"):
                # Interface secrets are runtime payload values, not application
                # credential profiles. They were captured in the local transient
                # runtime payload store and will be injected only for the live call.
                save_json(REPORTS / "react_interface_latest.json", {
                    "buildId": BUILD_ID,
                    "sourceInterface": proposal.get("sourceInterface"),
                    "targetInterface": proposal.get("targetInterface"),
                    "changedPaths": proposal.get("changedPaths") or [],
                    "critic": proposal.get("critic") or {},
                    "trace": proposal.get("trace") or [],
                })
                apply_new_active_input(proposal["proposal"])
                st.session_state.pop("adv_react_proposal", None)
                st.success("Interface-only configuration activated.")
                st.rerun()

    elif create_mode == "Guided new configuration (no JSON)":
        seed = dict(st.session_state.get("guided_seed") or {})
        st.subheader("Guided configuration wizard")
        st.caption("Fill what you know. The agent lists anything still required before it lets you activate the configuration.")

        with st.expander("A. Business flow", expanded=True):
            a1, a2, a3, a4 = st.columns(4)
            customer = a1.text_input("Customer / partner", value=str(seed.get("customer") or ""), key="g_customer")
            flow_name = a2.text_input("Business Flow name", value=str(seed.get("flow_name") or ""), key="g_flow_name")
            direction = a3.selectbox("Direction", ["Outbound", "Inbound"], index=0 if str(seed.get("direction") or "Outbound") == "Outbound" else 1, key="g_direction")
            tx_standard = a4.text_input("Transaction standard", value=str(seed.get("tx_standard") or "X12"), key="g_tx_standard")
            a5, a6, a7, a8 = st.columns(4)
            tx_code = a5.text_input("Transaction code", value=str(seed.get("tx_code") or "856"), key="g_tx_code")
            tx_name = a6.text_input("Transaction name", value=str(seed.get("tx_name") or "Ship Notice"), key="g_tx_name")
            dell_app = a7.text_input("Dell application", value=str(seed.get("dell_app") or "ANS"), key="g_dell_app")
            version = a8.text_input("Version", value=str(seed.get("version") or "1"), key="g_version")
            flow_description = st.text_input("Flow description", value=str(seed.get("flow_description") or ""), key="g_flow_description")

        with st.expander("B. Document Types", expanded=True):
            src, tgt = st.columns(2, gap="large")
            with src:
                st.markdown("**Source Document Type**")
                source_doc_name = st.text_input("Source Document Type name", value=str(seed.get("source_doc_name") or ""), key="g_source_doc_name")
                source_root = st.text_input("Source root identifier", value=str(seed.get("source_root") or ""), key="g_source_root")
                source_receiver_expression = st.text_input("Receiver XPath / expression", value=str(seed.get("source_receiver_expression") or ""), key="g_source_receiver_expression")
                source_sender_expression = st.text_input("Sender XPath / expression", value=str(seed.get("source_sender_expression") or ""), key="g_source_sender_expression")
                source_business_expression = st.text_input("Business ID XPath / expression", value=str(seed.get("source_business_expression") or ""), key="g_source_business_expression")
                source_alt_business_expression = st.text_input("Alternate Business ID expression", value=str(seed.get("source_alt_business_expression") or ""), key="g_source_alt_business_expression")
            with tgt:
                st.markdown("**Target Document Type**")
                target_doc_name = st.text_input("Target Document Type name", value=str(seed.get("target_doc_name") or ""), key="g_target_doc_name")
                target_root = st.text_input("Target root identifier", value=str(seed.get("target_root") or ""), key="g_target_root")
                target_receiver_expression = st.text_input("Target Receiver XPath / expression", value=str(seed.get("target_receiver_expression") or ""), key="g_target_receiver_expression")
                target_sender_expression = st.text_input("Target Sender XPath / expression", value=str(seed.get("target_sender_expression") or ""), key="g_target_sender_expression")
                target_business_expression = st.text_input("Target Business ID expression", value=str(seed.get("target_business_expression") or ""), key="g_target_business_expression")
                target_alt_business_expression = st.text_input("Target Alternate Business ID expression", value=str(seed.get("target_alt_business_expression") or ""), key="g_target_alt_business_expression")
            data_format = st.selectbox("Document data format", ["XML", "EDI", "JSON"], index=0, key="g_data_format")

        with st.expander("C. Mapping and routing", expanded=True):
            m1, m2, m3 = st.columns(3)
            map_identifier = m1.text_input("MAC Map identifier", value=str(seed.get("map_identifier") or ""), key="g_map_identifier")
            map_name = m2.text_input("MAC Map name", value=str(seed.get("map_name") or ""), key="g_map_name")
            map_class = m3.text_input("Map class", value=str(seed.get("map_class") or ""), key="g_map_class")
            m4, m5, m6 = st.columns(3)
            map_data_file = m4.text_input("Mapping JAR file name", value=str(seed.get("map_data_file") or ""), key="g_map_data_file")
            contivo_version = m5.text_input("Contivo version", value=str(seed.get("contivo_version") or "6.7"), key="g_contivo_version")
            rule_name = m6.text_input("Mapping Rule name", value=str(seed.get("rule_name") or ""), key="g_rule_name")
            r1, r2, r3, r4 = st.columns(4)
            receiver_value = r1.text_input("Receiver value", value=str(seed.get("receiver_value") or ""), key="g_receiver_value")
            receiver_operator = r2.selectbox("Receiver operator", ["Equals", "Contains"], index=0, key="g_receiver_operator")
            sender_value = r3.text_input("Sender value", value=str(seed.get("sender_value") or "DELL"), key="g_sender_value")
            sender_operator = r4.selectbox("Sender operator", ["Contains", "Equals"], index=0, key="g_sender_operator")
            upload_jar = st.file_uploader("Optional mapping JAR", type=["jar"], key="g_jar_upload")
            upload_xbm = st.file_uploader("Optional XBM cross-reference file", type=["xbm"], key="g_xbm_upload")

        with st.expander("D. Transport Profiles and Flow references", expanded=True):
            preset_name = st.selectbox(
                "Flow Transport Profile reference preset",
                list(FLOW_TP_PRESETS),
                index=0,
                help="The DCE default preset reflects the sender/receiver SFTP HAFT names shown by your team. You can override either value below.",
                key="g_tp_preset",
            )
            preset = FLOW_TP_PRESETS[preset_name]
            t1, t2 = st.columns(2, gap="large")
            with t1:
                st.markdown("**Source / Sender**")
                source_system = st.text_input("Source Dell system", value=str(seed.get("source_system") or "AIC - DCE"), key="g_source_system")
                source_tp_profile = st.text_input("Source TP create name", value=str(seed.get("source_tp_profile") or ""), key="g_source_tp_profile")
                source_flow_tp = st.text_input("Source TP reference used by Flow", value=str(seed.get("source_flow_tp") or preset["source"]), key=f"g_source_flow_tp_{preset_name}")
                source_account = st.text_input("Source account name", value=str(seed.get("source_account") or ""), key="g_source_account")
                source_folder = st.text_input("Source subscription folder", value=str(seed.get("source_folder") or ""), key="g_source_folder")
                source_deployment_group = st.text_input("Source deployment group — fixed", value="hip-automation", disabled=True, key="g_source_deployment_group")
            with t2:
                st.markdown("**Target / Receiver**")
                target_partner = st.text_input("Target Partner", value=str(seed.get("target_partner") or ""), key="g_target_partner")
                target_tp_profile = st.text_input("Target TP create name", value=str(seed.get("target_tp_profile") or ""), key="g_target_tp_profile")
                target_flow_tp = st.text_input("Target TP reference used by Flow", value=str(seed.get("target_flow_tp") or preset["target"]), key=f"g_target_flow_tp_{preset_name}")
                target_account = st.text_input("Target account name", value=str(seed.get("target_account") or ""), key="g_target_account")
                target_folder = st.text_input("Target subscription folder", value=str(seed.get("target_folder") or "/Inbound"), key="g_target_folder")
                target_deployment_group = st.text_input("Target deployment group — fixed", value="hip-automation", disabled=True, key="g_target_deployment_group")
            interface_environment = st.selectbox("Interface environment", ["UAT", "DEV", "SIT", "PROD"], index=0, key="g_interface_environment")

        fields = {
            "customer": customer, "flow_name": flow_name, "direction": direction,
            "tx_standard": tx_standard, "tx_code": tx_code, "tx_name": tx_name,
            "dell_app": dell_app, "version": version, "flow_description": flow_description,
            "data_format": data_format,
            "source_doc_name": source_doc_name, "source_root": source_root,
            "source_receiver_expression": source_receiver_expression,
            "source_sender_expression": source_sender_expression,
            "source_business_expression": source_business_expression,
            "source_alt_business_expression": source_alt_business_expression,
            "target_doc_name": target_doc_name, "target_root": target_root,
            "target_receiver_expression": target_receiver_expression,
            "target_sender_expression": target_sender_expression,
            "target_business_expression": target_business_expression,
            "target_alt_business_expression": target_alt_business_expression,
            "map_identifier": map_identifier, "map_name": map_name, "map_class": map_class,
            "map_data_file": map_data_file, "contivo_version": contivo_version,
            "rule_name": rule_name, "receiver_value": receiver_value,
            "receiver_operator": receiver_operator, "sender_value": sender_value,
            "sender_operator": sender_operator, "source_system": source_system,
            "source_tp_profile": source_tp_profile, "source_flow_tp": source_flow_tp,
            "source_account": source_account, "source_folder": source_folder,
            "source_deployment_group": source_deployment_group,
            "target_partner": target_partner, "target_tp_profile": target_tp_profile,
            "target_flow_tp": target_flow_tp, "target_account": target_account,
            "target_folder": target_folder, "target_deployment_group": target_deployment_group,
            "interface_environment": interface_environment,
        }
        questions = guided_questions(fields)
        if questions:
            st.markdown('<div class="warn"><b>Agent needs a few answers before activation.</b> Fill the highlighted business values below; nothing is invented silently.</div>', unsafe_allow_html=True)
            render_table(questions)
        else:
            st.success("Guided configuration has all core values needed to build the canonical model.")

        b1, b2 = st.columns([2, 1])
        if b1.button("Create and activate this configuration", type="primary", width="stretch", disabled=bool(questions)):
            try:
                canonical = build_guided_input(fields)
                config = engine.derive_config_updates(canonical, load_json(CONFIG_JSON, {}))
                mapper_errors = [x.__dict__ for x in UhalInputMapper(canonical, config, ROOT).validate() if x.severity == "ERROR"]
                if mapper_errors:
                    st.error("The canonical model still has validation errors. The agent will not activate it yet.")
                    render_table(mapper_errors)
                else:
                    apply_new_active_input(canonical, reset_runtime_policy=True)
                    if upload_jar:
                        (INPUT_FILES / Path(upload_jar.name).name).write_bytes(upload_jar.getvalue())
                    if upload_xbm:
                        (INPUT_FILES / Path(upload_xbm.name).name).write_bytes(upload_xbm.getvalue())
                    st.session_state.pop("guided_seed", None)
                    st.success("New configuration activated. No input.json upload was required.")
                    st.rerun()
            except Exception as exc:
                st.error(str(exc))
        if b2.button("Preview canonical model", width="stretch"):
            st.session_state["guided_preview"] = build_guided_input(fields)
        if st.session_state.get("guided_preview"):
            with st.expander("Generated canonical model", expanded=False):
                st.json(st.session_state["guided_preview"])

    elif create_mode == "Upload input.json":
        st.subheader("Upload and map an input JSON")
        uploaded = st.file_uploader("Input JSON", type=["json"], key="input_json_upload")
        c1, c2 = st.columns(2)
        use_aia = c1.checkbox("Use Dell AIA semantic mapping", value=True, key="input_use_aia")
        apply_safe = c2.checkbox("Apply safe deterministic defaults", value=True, key="input_apply_safe")
        if uploaded:
            incoming_path = INCOMING_DIR / Path(uploaded.name).name
            incoming_path.write_bytes(uploaded.getvalue())
            try:
                raw_input = json.loads(uploaded.getvalue().decode("utf-8"))
                if st.button("Analyze and map uploaded JSON", type="primary", width="stretch"):
                    aia_callable = None
                    if use_aia:
                        from run_agent import AIAJudge
                        judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
                        judge.verify_connection()
                        aia_callable = judge.complete_json
                    prepared = engine.prepare_canonical_input(
                        raw_input,
                        apply_safe=apply_safe,
                        use_aia=bool(aia_callable),
                        aia_complete_json=aia_callable,
                    )
                    st.session_state["prepared_input"] = prepared
            except Exception as exc:
                st.error(f"Invalid input JSON: {exc}")
        prepared = st.session_state.get("prepared_input")
        if prepared:
            q = prepared.get("unresolvedQuestions") or []
            c1, c2, c3 = st.columns(3)
            c1.metric("Resolved", len((prepared.get("analysis") or {}).get("resolutions") or []))
            c2.metric("Safe defaults", len(prepared.get("appliedSafeSuggestions") or []))
            c3.metric("Questions", len(q))
            if q:
                render_table(q)
            edited = st.text_area("Canonical model", json.dumps(prepared.get("canonicalInput"), indent=2), height=480, key="uploaded_canonical_editor")
            if st.button("Validate and activate mapped configuration", width="stretch"):
                try:
                    canonical = json.loads(edited)
                    config = engine.derive_config_updates(canonical, load_json(CONFIG_JSON, {}))
                    validation = mcp.validate_uhal_input(canonical, config)
                    if not validation.get("valid", False):
                        st.error("Resolve the listed values before activation.")
                        st.json(validation)
                    else:
                        apply_new_active_input(canonical, reset_runtime_policy=True)
                        st.success("Mapped configuration activated.")
                        st.rerun()
                except Exception as exc:
                    st.error(str(exc))

    elif create_mode == "Start from API payloads":
        st.subheader("Payload-first configuration")
        st.write(
            "Paste or upload payloads keyed by logical API step. The agent extracts what it can, asks for missing business metadata, and can then use the payloads as runtime overrides. You do not need to supply input.json."
        )
        template = {
            "doctype_source": {}, "doctype_target": {}, "map": {}, "rule": {},
            "source_tp": {}, "target_tp": {}, "flow_create": {}, "flow_deploy": {},
        }
        payload_file = st.file_uploader("Optional payload bundle JSON", type=["json"], key="payload_first_upload")
        initial_payload_text = payload_file.getvalue().decode("utf-8") if payload_file else json.dumps(template, indent=2)
        payload_text = st.text_area("Payload bundle", value=initial_payload_text, height=500, key="payload_first_editor")
        use_aia_payload = st.checkbox("Use Dell AIA to infer additional canonical fields", value=True, key="payload_first_aia")
        if st.button("Analyze payloads and ask what is missing", type="primary", width="stretch"):
            try:
                bundle = normalize_payload_bundle(json.loads(payload_text))
                inferred = infer_fields_from_payload_bundle(bundle)
                proposal: Dict[str, Any] = {"guidedFields": inferred, "questions": guided_questions(inferred)}
                if use_aia_payload:
                    from run_agent import AIAJudge
                    judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
                    judge.verify_connection()
                    aia = judge.complete_json(
                        system=(
                            "You are a Dell HIP configuration analyst. Return JSON only with keys guidedFields and questions. "
                            "Infer only values actually supported by the API payload bundle. Never invent IDs, credentials, XPath expressions, customer names or routing values. "
                            "guidedFields may use these keys: customer, flow_name, direction, tx_standard, tx_code, tx_name, dell_app, version, source_doc_name, source_root, target_doc_name, target_root, map_identifier, map_name, map_class, map_data_file, rule_name, receiver_value, sender_value, source_system, target_partner, source_tp_profile, target_tp_profile, source_flow_tp, target_flow_tp, source_account, target_account, source_folder, target_folder, source_deployment_group, target_deployment_group, flow_description."
                        ),
                        user=json.dumps({"payloadBundle": bundle, "deterministicFields": inferred}, indent=2, default=str)[:18000],
                        temperature=0.1,
                    )
                    if isinstance(aia, dict):
                        aia_fields = aia.get("guidedFields") or {}
                        if isinstance(aia_fields, dict):
                            inferred.update({k: v for k, v in aia_fields.items() if v not in (None, "")})
                        proposal = {"guidedFields": inferred, "questions": aia.get("questions") or guided_questions(inferred)}
                st.session_state["payload_first_analysis"] = proposal
                st.session_state["payload_first_bundle"] = bundle
            except Exception as exc:
                st.error(str(exc))
        analysis = st.session_state.get("payload_first_analysis")
        if analysis:
            st.success(f"Extracted {len(analysis.get('guidedFields') or {})} candidate configuration fields.")
            with st.expander("Extracted guided fields", expanded=True):
                st.json(analysis.get("guidedFields") or {})
            if analysis.get("questions"):
                st.markdown("**The agent still needs these answers:**")
                render_table(analysis.get("questions"))
            c1, c2 = st.columns(2)
            if c1.button("Continue in Guided Wizard with extracted values", type="primary", width="stretch"):
                st.session_state["guided_seed"] = analysis.get("guidedFields") or {}
                st.session_state["requested_create_mode"] = "Guided new configuration (no JSON)"
                st.rerun()
            if c2.button("Import recognized payloads as overrides for current active configuration", width="stretch"):
                try:
                    bundle = st.session_state.get("payload_first_bundle") or {}
                    get_params = {"validate_flow", "flow_history", "source_tp_audit", "target_tp_audit"}
                    for key, value in bundle.items():
                        save_override(
                            ROOT, key, value,
                            request_kind="params" if key in get_params else "payload",
                            mode="replace",
                            note="Human user imported from payload-first workspace",
                            edit_origin="USER",
                        )
                    st.success(f"Imported {len(bundle)} payload override(s). Review them in Payload Studio before execution.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))

    else:
        st.subheader("Current / U-HAUL configuration")
        st.json(current_input_summary())
        current_model = load_json(INPUT_JSON, {})
        biz = ((current_model.get("objects") or {}).get("biz_flow") or {})
        st.markdown("**Quick Flow TP reference editor**")
        if st.session_state.get("requested_quick_source_flow_tp") is not None:
            st.session_state["quick_current_source_flow_tp"] = st.session_state.pop("requested_quick_source_flow_tp")
        if st.session_state.get("requested_quick_target_flow_tp") is not None:
            st.session_state["quick_current_target_flow_tp"] = st.session_state.pop("requested_quick_target_flow_tp")
        q1, q2 = st.columns(2)
        quick_src_tp = q1.text_input(
            "Source TP reference used by Flow",
            value=str((biz.get("configure_source") or {}).get("source_transport_profile") or ""),
            key="quick_current_source_flow_tp",
        )
        quick_tgt_tp = q2.text_input(
            "Target TP reference used by Flow",
            value=str((biz.get("configure_targets") or {}).get("target_transport_profile") or ""),
            key="quick_current_target_flow_tp",
        )
        q3, q4 = st.columns(2)
        if q3.button("Use DCE default sender/receiver TP references", width="stretch"):
            st.session_state["requested_quick_source_flow_tp"] = "da-sender-sftphaft-dce-common"
            st.session_state["requested_quick_target_flow_tp"] = "pt-receiver-sftphaft-dce-common"
            st.rerun()
        if q4.button("Save Flow TP reference changes", type="primary", width="stretch"):
            try:
                model = load_json(INPUT_JSON, {})
                objects = model.setdefault("objects", {})
                flow = objects.setdefault("biz_flow", {})
                flow.setdefault("configure_source", {})["source_transport_profile"] = quick_src_tp.strip()
                flow.setdefault("configure_targets", {})["target_transport_profile"] = quick_tgt_tp.strip()
                save_json(INPUT_JSON, model)
                st.success("Flow TP references updated. Payload Studio will show the regenerated Flow payload.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))
        with st.expander("Active canonical model"):
            st.json(current_model)
        if st.button("Restore Dev-approved U-HAUL baseline", width="stretch"):
            save_json(INPUT_JSON, load_json(DEV_APPROVED_DIR / "UHAL_input_dev_approved.json", {}))
            save_json(CONFIG_JSON, load_json(DEV_APPROVED_DIR / "UHAL_config_dev_approved.json", {}))
            clear_all_overrides(ROOT)
            reset_execution_flow(ROOT)
            st.success("Dev-approved U-HAUL input and configuration restored. Review API skip plan before running.")
            st.rerun()


# ---------------------------------------------------------------------------
# 2. Credentials
# ---------------------------------------------------------------------------
with tabs[1]:
    st.header("Credentials and connection health")
    st.markdown(
        '<div class="hint"><b>Service-specific OAuth.</b> HIP Config/MAC Map, Account, Partner and System may each use their own Client ID + Client Secret. Dell AIA has its own OAuth credential. A credential is only required if that API is actually going to execute.</div>',
        unsafe_allow_html=True,
    )
    env = {str(k): str(v or "") for k, v in dotenv_values(ENV_PATH).items()} if ENV_PATH.exists() else {}

    with st.expander("HIP Config + MAC Map OAuth", expanded=True):
        c1, c2 = st.columns([2, 1])
        hip_token_url = c1.text_input("HIP Config token URL", env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL))
        hip_scope = c2.text_input("HIP Config scope (optional)", env.get("HIP_SCOPE", ""))
        c3, c4 = st.columns(2)
        hip_client_id = c3.text_input("HIP Config client ID", env.get("HIP_CLIENT_ID", ""))
        hip_client_secret = c4.text_input("HIP Config client secret", type="password", placeholder="Configured — leave blank to keep" if configured("HIP_CLIENT_SECRET") else "Enter secret")
        st.caption("OAuth 2.0 Client Credentials · Basic Auth header · blank scope omitted. MAC Map reuses this token.")

    with st.expander("Account OAuth"):
        a1, a2 = st.columns([2, 1])
        account_token_url = a1.text_input("Account token URL", env.get("ACCOUNT_TOKEN_URL", env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL)))
        account_scope = a2.text_input("Account scope (optional)", env.get("ACCOUNT_SCOPE", ""))
        a3, a4 = st.columns(2)
        account_client_id = a3.text_input("Account client ID", env.get("ACCOUNT_CLIENT_ID", ""))
        account_client_secret = a4.text_input("Account client secret", type="password", placeholder="Configured — leave blank to keep" if configured("ACCOUNT_CLIENT_SECRET") else "Enter secret")

    with st.expander("Partner OAuth"):
        p1, p2 = st.columns([2, 1])
        partner_token_url = p1.text_input("Partner token URL", env.get("PARTNER_TOKEN_URL", env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL)))
        partner_scope = p2.text_input("Partner scope (optional)", env.get("PARTNER_SCOPE", ""))
        p3, p4 = st.columns(2)
        partner_client_id = p3.text_input("Partner client ID", env.get("PARTNER_CLIENT_ID", ""))
        partner_client_secret = p4.text_input("Partner client secret", type="password", placeholder="Configured — leave blank to keep" if configured("PARTNER_CLIENT_SECRET") else "Enter secret")

    with st.expander("System OAuth"):
        s1, s2 = st.columns([2, 1])
        system_token_url = s1.text_input("System token URL", env.get("SYSTEM_TOKEN_URL", env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL)))
        system_scope = s2.text_input("System scope (optional)", env.get("SYSTEM_SCOPE", ""))
        s3, s4 = st.columns(2)
        system_client_id = s3.text_input("System client ID", env.get("SYSTEM_CLIENT_ID", ""))
        system_client_secret = s4.text_input("System client secret", type="password", placeholder="Configured — leave blank to keep" if configured("SYSTEM_CLIENT_SECRET") else "Enter secret")

    with st.expander("Dell AIA OAuth", expanded=True):
        d1, d2 = st.columns(2)
        aia_base = d1.text_input("Dell AIA base URL", env.get("DELL_AIA_BASE_URL", "https://aia.gateway.dell.com/genai/dev/v1"))
        aia_model = d2.text_input("Dell AIA model", env.get("DELL_AIA_MODEL", "gpt-oss-120b"))
        d3, d4 = st.columns(2)
        aia_id = d3.text_input("Dell AIA client ID", env.get("DELL_AIA_CLIENT_ID", ""))
        aia_secret = d4.text_input("Dell AIA client secret", type="password", placeholder="Configured — leave blank to keep" if configured("DELL_AIA_CLIENT_SECRET") else "Enter secret")

    o1, o2, o3 = st.columns(3)
    mcp_required = o1.checkbox("Require MCP transport", value=env.get("MCP_REQUIRED", "false").lower() in {"true", "1", "yes"})
    pdf_mode = o2.selectbox("PDF validation mode", ["auto", "strict"], index=1 if env.get("PDF_CONTRACT_VALIDATION_MODE", "auto") == "strict" else 0)
    verify_ssl = o3.checkbox("Verify TLS certificates", value=env.get("HIP_VERIFY_SSL", "true").lower() in {"true", "1", "yes"})

    save_col, oauth_col, check_col = st.columns(3)
    if save_col.button("Save credential profiles", type="primary", width="stretch"):
        updates = {
            "HIP_TOKEN_URL": hip_token_url.strip(), "HIP_CLIENT_ID": hip_client_id.strip(), "HIP_SCOPE": hip_scope.strip(), "HIP_TOKEN_USER_AGENT": "PostmanRuntime/7.49.0",
            "ACCOUNT_TOKEN_URL": account_token_url.strip(), "ACCOUNT_CLIENT_ID": account_client_id.strip(), "ACCOUNT_SCOPE": account_scope.strip(),
            "PARTNER_TOKEN_URL": partner_token_url.strip(), "PARTNER_CLIENT_ID": partner_client_id.strip(), "PARTNER_SCOPE": partner_scope.strip(),
            "SYSTEM_TOKEN_URL": system_token_url.strip(), "SYSTEM_CLIENT_ID": system_client_id.strip(), "SYSTEM_SCOPE": system_scope.strip(),
            "DELL_AIA_BASE_URL": aia_base.strip(), "DELL_AIA_MODEL": aia_model.strip(), "DELL_AIA_CLIENT_ID": aia_id.strip(),
            "MCP_ENABLED": "true", "MCP_REQUIRED": str(mcp_required).lower(), "MCP_VALIDATE_EACH_REQUEST": "true",
            "PDF_CONTRACT_VALIDATION_MODE": pdf_mode, "HIP_VERIFY_SSL": str(verify_ssl).lower(),
        }
        for key, value in {
            "HIP_CLIENT_SECRET": hip_client_secret,
            "ACCOUNT_CLIENT_SECRET": account_client_secret,
            "PARTNER_CLIENT_SECRET": partner_client_secret,
            "SYSTEM_CLIENT_SECRET": system_client_secret,
            "DELL_AIA_CLIENT_SECRET": aia_secret,
        }.items():
            if value:
                updates[key] = value
        save_env(updates)
        clear_env_values(["HIP_ACCESS_TOKEN", "HIP_TOKEN_COOKIE", "MAC_MAP_TOKEN_URL", "MAC_MAP_CLIENT_ID", "MAC_MAP_CLIENT_SECRET", "MAC_MAP_SCOPE"])
        st.success("Credential profiles saved locally. Secrets are not written to reports or packaged source.")

    if oauth_col.button("Test HIP Config OAuth", width="stretch"):
        proc = subprocess.run([sys.executable, "test_live_hip_oauth.py"], cwd=ROOT, text=True, capture_output=True)
        if proc.returncode == 0:
            st.success("HIP Config OAuth token generated successfully.")
        else:
            st.error("HIP Config OAuth token generation failed.")
        with st.expander("OAuth diagnostic"):
            st.json(load_json(REPORTS / "hip_token_diagnostics_latest.json", {}))

    if check_col.button("Check all connections required for this run", width="stretch"):
        proc = subprocess.run([sys.executable, "connection_check.py"], cwd=ROOT, text=True, capture_output=True)
        details = load_json(REPORTS / "connection_check_latest.json", {})
        st.session_state["connection_check"] = details
        if proc.returncode == 0:
            st.success("All services required by the current execution plan are ready.")
        else:
            st.error("One or more required connections are not ready.")
        with st.expander("Connection-check command output"):
            st.code((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else ""))

    connection = st.session_state.get("connection_check") or load_json(REPORTS / "connection_check_latest.json", {})
    if connection:
        components = connection.get("components") or {}
        cols = st.columns(3)
        with cols[0]:
            connection_component("HIP Config OAuth", components.get("hipOAuth", {}))
            connection_component("MAC Map · HIP token", components.get("macMap", {}))
        with cols[1]:
            connection_component("Account OAuth", components.get("accountOAuth", {}))
            connection_component("Partner OAuth", components.get("partnerOAuth", {}))
            connection_component("System OAuth", components.get("systemOAuth", {}))
        with cols[2]:
            connection_component("Dell AIA", components.get("dellAia", {}))
            connection_component("MCP", components.get("mcp", {}))
        with st.expander("Connection details"):
            st.json(connection)


# ---------------------------------------------------------------------------
# 3. API Docs / PDF upload
# ---------------------------------------------------------------------------
with tabs[2]:
    st.header("API documentation and PDF contract knowledge")
    st.markdown(
        '<div class="hint"><b>Upload the API portal PDF here.</b> The agent extracts searchable text, detects API sections, builds structured contracts with Dell AIA, and uses them alongside built-in and MCP validation before requests are sent.</div>',
        unsafe_allow_html=True,
    )
    uploads = st.file_uploader("API documentation PDF(s)", type=["pdf"], accept_multiple_files=True, key="api_pdf_upload")
    c1, c2, c3 = st.columns(3)
    if c1.button("Ingest uploaded PDF(s)", type="primary", disabled=not uploads, width="stretch"):
        outcomes = []
        for item in uploads or []:
            try:
                result = pdf_kb.ingest_bytes(item.name, item.getvalue())
                outcomes.append(result.__dict__)
            except Exception as exc:
                outcomes.append({"name": item.name, "error": str(exc)})
        st.session_state["pdf_ingest_outcomes"] = outcomes
        st.success(f"Processed {len(outcomes)} PDF file(s).")
    if c2.button("Build / refresh contracts with Dell AIA", disabled=not pdf_kb.has_documents(), width="stretch"):
        try:
            from run_agent import AIAJudge
            judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
            judge.verify_connection()
            result = pdf_kb.extract_contracts_with_aia(judge)
            st.success(f"Structured contracts refreshed: {len(result.get('contracts') or {})} contract(s).")
            st.session_state["pdf_contract_result"] = result
        except Exception as exc:
            st.error(str(exc))
    require_pdf = c3.checkbox("Require API PDF before live execution", value=os.getenv("PDF_REQUIRE_DOCUMENTATION", "false").lower() in {"true", "1", "yes"})
    if c3.button("Save PDF requirement", width="stretch"):
        save_env({"PDF_REQUIRE_DOCUMENTATION": str(require_pdf).lower()})
        st.success("PDF execution requirement saved.")

    if st.session_state.get("pdf_ingest_outcomes"):
        with st.expander("Latest PDF ingestion details", expanded=True):
            st.json(st.session_state["pdf_ingest_outcomes"])

    docs = pdf_kb.list_documents()
    st.subheader("Ingested documentation")
    render_table(docs, "No API PDF has been ingested yet.")
    contracts = pdf_kb.load_pdf_contracts()
    st.subheader("Structured API contracts")
    if contracts:
        render_table([
            {
                "API key": key,
                "Method": value.get("method"),
                "Path": value.get("pathContains") or value.get("path"),
                "Required fields": ", ".join(value.get("requiredFields") or []),
                "Source": value.get("source") or "PDF / merged",
            }
            for key, value in contracts.items()
        ])
        selected_contract = st.selectbox("Inspect contract", list(contracts), key="inspect_pdf_contract")
        st.json(contracts[selected_contract])
    else:
        st.info("Upload a PDF and build contracts to supplement the built-in API contract knowledge.")


# ---------------------------------------------------------------------------
# 4. Agent Questions
# ---------------------------------------------------------------------------
with tabs[3]:
    st.header("Agent questions and missing values")
    current = load_json(INPUT_JSON, {})
    config = load_json(CONFIG_JSON, {})
    try:
        analysis = engine.prepare_canonical_input(current, apply_safe=False)
    except Exception as exc:
        analysis = {"unresolvedQuestions": [{"question": str(exc), "field": "input"}]}
    questions = analysis.get("unresolvedQuestions") or []
    q1, q2, q3 = st.columns(3)
    q1.metric("Open questions", len(questions))
    q2.metric("Payload overrides", PayloadOverrideStore(ROOT).summary().get("count", 0))
    q3.metric("API docs", len(pdf_kb.list_documents()))
    if questions:
        st.markdown("**The agent will not silently invent these values:**")
        render_table(questions)
    else:
        st.success("No unresolved canonical-input questions were detected.")

    with st.expander("MCP missing-value suggestions"):
        try:
            st.json(mcp.suggest_missing_values(current, config))
        except Exception as exc:
            st.error(str(exc))

    c1, c2 = st.columns(2)
    if c1.button("Ask Dell AIA what is still needed", width="stretch"):
        proc = subprocess.run([sys.executable, "run_agent.py", "--suggest-missing"], cwd=ROOT, text=True, capture_output=True)
        with st.expander("Agent output", expanded=True):
            st.code((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else ""))
        path = REPORTS / "missing_value_suggestions_latest.json"
        if path.exists():
            st.session_state["missing_suggestions"] = load_json(path, {})
    if c2.button("Generate a payload/readiness summary", width="stretch"):
        try:
            from run_agent import Runner
            runner = Runner(llm_enabled=False)
            rows = []
            for key in runner.execution_flow.ordered_steps():
                try:
                    pv = runner.preview_step_request(key)
                    rows.append({
                        "API": FLOW_STEP_DEFINITIONS[key]["label"],
                        "Method": pv.get("method"),
                        "Endpoint": pv.get("url"),
                        "Override": "YES" if (pv.get("override") or {}).get("applied") else "NO",
                        "Skip": "YES" if runner.execution_plan.is_skipped(key) else "NO",
                    })
                except Exception as exc:
                    rows.append({"API": FLOW_STEP_DEFINITIONS[key]["label"], "Error": str(exc)})
            st.session_state["readiness_rows"] = rows
        except Exception as exc:
            st.error(str(exc))
    if st.session_state.get("missing_suggestions"):
        with st.expander("Dell AIA suggestions", expanded=True):
            st.json(st.session_state["missing_suggestions"])
    if st.session_state.get("readiness_rows"):
        render_table(st.session_state["readiness_rows"])

    st.subheader("Answer the agent in plain language")
    answer = st.text_area(
        "Tell the agent the missing value or requested correction",
        placeholder="Example: Use da-sender-sftphaft-dce-common for source Flow TP and pt-receiver-sftphaft-dce-common for target Flow TP.",
        height=120,
        key="agent_answer_text",
    )
    if st.button("Turn my answer into a reviewable configuration patch", disabled=not answer.strip(), type="primary", width="stretch"):
        try:
            from run_agent import AIAJudge
            judge = AIAJudge(config, enabled=True)
            judge.verify_connection()
            proposal = engine.propose_change(
                answer, current, config,
                use_aia=True,
                aia_complete_json=judge.complete_json,
            )
            st.session_state["question_patch"] = proposal
        except Exception as exc:
            st.error(str(exc))
    if st.session_state.get("question_patch"):
        proposal = st.session_state["question_patch"]
        st.json(proposal)
        approved = st.checkbox("I reviewed and approve this answer/patch", key="approve_question_patch")
        if st.button("Apply approved answer", disabled=not approved, width="stretch"):
            try:
                applied = engine.apply_change(proposal, current, config, approve=True)
                save_json(INPUT_JSON, applied["input"])
                save_json(CONFIG_JSON, applied["config"])
                st.success("Approved answer applied. Re-run readiness checks.")
                st.session_state.pop("question_patch", None)
                st.rerun()
            except Exception as exc:
                st.error(str(exc))


# ---------------------------------------------------------------------------
# 5. Payload Studio
# ---------------------------------------------------------------------------
with tabs[4]:
    st.header("Payload Studio")
    st.markdown(
        '<div class="hint"><b>Edit API payloads directly.</b> The generated request remains visible for comparison. Saved overrides change only payload/query content; method, endpoint, OAuth profile and protected headers remain controlled by the agent. Every edited request still passes deterministic, MCP and optional PDF/AIA validation before sending.</div>',
        unsafe_allow_html=True,
    )
    try:
        from run_agent import AIAJudge, Runner
        runner = Runner(llm_enabled=False)
        active_payload_input = load_json(INPUT_JSON, {})
        strict_interface_mode = bool(
            isinstance(active_payload_input.get("_interface_only_mode"), dict)
            and active_payload_input.get("_interface_only_mode", {}).get("enabled")
        )
        labels = step_labels()
        ordered = runner.execution_flow.ordered_steps()
        store_summary = PayloadOverrideStore(ROOT).summary()

        # Build a compact request inventory so users can immediately see what
        # is generated, edited, skipped or ready for execution.
        inventory = []
        preview_cache: Dict[str, Dict[str, Any]] = {}
        for key in ordered:
            item = runner.preview_step_request(key)
            preview_cache[key] = item
            kind = item.get("requestKind") or "payload"
            generated_item = item.get("generatedParams") if kind == "params" else item.get("generatedPayload")
            effective_item = item.get("params") if kind == "params" else item.get("payload")
            changes = json_change_paths(
                safe_request_for_ui(generated_item or {}),
                safe_request_for_ui(effective_item or {}),
            )
            inventory.append(payload_status_row(
                step_key=key,
                label=labels[key],
                method=item.get("method") or "—",
                decision="SKIP" if runner.execution_plan.is_skipped(key) else "EXECUTE",
                override_active=bool((item.get("override") or {}).get("applied")),
                request_kind=kind,
                changed_paths=changes,
            ))

        pm1, pm2, pm3, pm4 = st.columns(4)
        pm1.metric("API steps", len(inventory))
        pm2.metric("Edited requests", store_summary.get("count", 0))
        pm3.metric("Skipped existing", sum(1 for row in inventory if row["Decision"] == "SKIP"))
        pm4.metric("Executable", sum(1 for row in inventory if row["Decision"] == "EXECUTE"))

        f1, f2, f3 = st.columns([1.4, 1, 1])
        group_options = ["All"] + sorted({
            str(FLOW_STEP_DEFINITIONS[key].get("group") or "Other")
            for key in ordered
        })
        selected_group = f1.selectbox("Filter by API area", group_options, key="payload_group_filter")
        edited_only = f2.checkbox("Show edited only", value=False, key="payload_edited_only")
        execute_only = f3.checkbox("Show executable only", value=False, key="payload_execute_only")

        visible_keys = []
        for row in inventory:
            key = row["stepKey"]
            group_ok = (
                selected_group == "All"
                or FLOW_STEP_DEFINITIONS[key].get("group") == selected_group
            )
            edited_ok = (not edited_only) or row["Edited"] == "Yes"
            execute_ok = (not execute_only) or row["Decision"] == "EXECUTE"
            if group_ok and edited_ok and execute_ok:
                visible_keys.append(key)

        render_table([
            {k: v for k, v in row.items() if k != "stepKey"}
            for row in inventory
            if row["stepKey"] in visible_keys
        ])

        if not visible_keys:
            st.info("No API requests match the current filters.")
            st.stop()

        selected_label = st.selectbox(
            "Choose a request to inspect or edit",
            [labels[k] for k in visible_keys],
            key="payload_step_select",
        )
        selected_key = next(k for k in visible_keys if labels[k] == selected_label)
        preview = preview_cache[selected_key]
        request_kind = preview.get("requestKind") or "payload"
        generated_value = preview.get("generatedParams") if request_kind == "params" else preview.get("generatedPayload")
        effective_value = preview.get("params") if request_kind == "params" else preview.get("payload")
        generated_safe = safe_request_for_ui(generated_value or {})
        effective_safe = safe_request_for_ui(effective_value or {})
        active_changes = json_change_paths(generated_safe, effective_safe)

        decision_text = "SKIP — EXISTING" if runner.execution_plan.is_skipped(selected_key) else "EXECUTE"
        edited_text = "USER EDIT ACTIVE" if (preview.get("override") or {}).get("applied") else "AGENT GENERATED"
        edited_class = "edited" if (preview.get("override") or {}).get("applied") else ""
        skip_badge = '<span class="payload-status skip">SKIP — EXISTING</span>' if decision_text.startswith("SKIP") else '<span class="payload-status">EXECUTE</span>'
        st.markdown(
            f"""
            <div class="payload-shell">
              <div style="font-size:1.08rem;font-weight:800;color:#061c38">{labels[selected_key]}</div>
              <div style="color:#65758b;margin:4px 0 10px">{preview.get('method')} · {preview.get('url')}</div>
              <span class="payload-status {edited_class}">{edited_text}</span>
              {skip_badge}
            </div>
            """,
            unsafe_allow_html=True,
        )

        h1, h2, h3, h4 = st.columns(4)
        h1.metric("Method", preview.get("method") or "—")
        h2.metric("OAuth profile", preview.get("tokenKind") or "HIP")
        h3.metric("Changed paths", len(active_changes))
        h4.metric("Decision", "SKIP" if runner.execution_plan.is_skipped(selected_key) else "EXECUTE")

        compare_tabs = st.tabs(["Effective request", "Generated baseline", "Change summary"])
        with compare_tabs[0]:
            st.json(effective_safe)
            st.caption("This is the request that will be used if this API step executes.")
        with compare_tabs[1]:
            st.json(generated_safe)
            st.caption("This is the untouched request generated from the active configuration.")
        with compare_tabs[2]:
            if active_changes:
                for path in active_changes[:60]:
                    st.markdown(f"- `{path}`")
                if len(active_changes) > 60:
                    st.caption(f"+ {len(active_changes) - 60} more changed paths")
            else:
                st.info("No user edits are active for this request.")

        st.markdown("### Edit request")
        st.caption(
            "The editor starts from the current effective request. Runtime placeholders are allowed. "
            "Secrets remain local environment references and are not exposed here."
        )
        editor = st.text_area(
            f"Edit {request_kind} JSON",
            value=json.dumps(effective_safe, indent=2, ensure_ascii=False),
            height=520,
            key=f"payload_editor_{selected_key}",
        )
        e1, e2 = st.columns(2)
        override_mode = e1.selectbox("Override mode", ["replace", "merge"], index=0, key=f"payload_mode_{selected_key}")
        override_note = e2.text_input("Reason / note", value=str((runner.payload_overrides.get(selected_key) or {}).get("note") or ""), key=f"payload_note_{selected_key}")
        st.caption("Runtime placeholders are supported, e.g. {{runtime.source_document_type_id}}, {{runtime.map_id}}, {{runtime.rule_id}}, {{runtime.flow_id}}, {{business.flowName}}.")

        parsed_editor = None
        try:
            parsed_editor = json.loads(editor)
            if not isinstance(parsed_editor, dict):
                raise ValueError("Edited request must be a JSON object.")
            st.success("JSON syntax valid.")
        except Exception as exc:
            st.error(f"JSON error: {exc}")

        # The ReAct interface-only constraint governs AGENT-generated proposals,
        # not the human Payload Studio. A HUMAN user may edit any existing canonical
        # value before LIVE; exact structure validation below remains mandatory.
        if strict_interface_mode:
            st.info(
                "Agent interface-only proposal mode is active. Human payload edits are still allowed for any existing "
                "canonical value; method, URL, headers, attribute names, nesting and array shape remain locked."
            )
        save_allowed = bool(parsed_editor is not None)

        b1, b2, b3, b4 = st.columns(4)
        if b1.button("✓ Validate edit", disabled=parsed_editor is None, width="stretch"):
            payload_arg = parsed_editor if request_kind == "payload" else None
            params_arg = parsed_editor if request_kind == "params" else None
            deterministic = runner.pdf_kb.validate_request(
                api_key=preview.get("urlKey"), method=preview.get("method"), url=preview.get("url"),
                headers={"x-requester-id": runner.requester, **(preview.get("extraHeaders") or {})},
                payload=payload_arg, params=params_arg,
            )
            mcp_result = mcp.validate_api_request(
                api_key=preview.get("urlKey"), method=preview.get("method"), url=preview.get("url"),
                headers={"x-requester-id": runner.requester, **(preview.get("extraHeaders") or {})},
                payload=payload_arg, params=params_arg,
            )
            mcp_critic = mcp.validate_payload_override(
                selected_key,
                generated_safe,
                safe_request_for_ui(parsed_editor or {}),
                interface_only=False,
            )
            st.session_state["payload_validation"] = {
                "deterministic": deterministic,
                "mcpContract": mcp_result,
                "mcpPayloadCritic": mcp_critic,
            }
        if b2.button("🤖 Ask Dell AIA to review", disabled=parsed_editor is None, width="stretch"):
            try:
                judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
                judge.verify_connection()
                contract = runner.pdf_kb.merged_contract(preview.get("urlKey"))
                aia_review = judge.complete_json(
                    system=(
                        "You are a Dell HIP API payload reviewer. Return JSON only with keys valid, issues, explanation, checksToPerform. "
                        "You have NO authority to edit, rewrite, correct or generate replacement payload values. Review only. "
                        "Do not invent credentials, object IDs or undocumented fields. Use the provided API contract and request."
                    ),
                    user=json.dumps({
                        "api": selected_key, "method": preview.get("method"), "url": preview.get("url"),
                        "contract": contract, "requestKind": request_kind, "request": parsed_editor,
                    }, indent=2, default=str)[:18000],
                    temperature=0.1,
                )
                st.session_state["payload_aia_review"] = aia_review
            except Exception as exc:
                st.error(str(exc))
        if b3.button("💾 Save request edit", type="primary", disabled=not save_allowed, width="stretch"):
            try:
                payload_arg = parsed_editor if request_kind == "payload" else None
                params_arg = parsed_editor if request_kind == "params" else None
                mcp_critic = mcp.validate_payload_override(
                    selected_key,
                    generated_safe,
                    safe_request_for_ui(parsed_editor or {}),
                    interface_only=False,
                )
                mcp_contract = mcp.validate_api_request(
                    api_key=preview.get("urlKey"),
                    method=preview.get("method"),
                    url=preview.get("url"),
                    headers={"x-requester-id": runner.requester, **(preview.get("extraHeaders") or {})},
                    payload=payload_arg,
                    params=params_arg,
                )
                if not mcp_critic.get("valid", True):
                    st.error("MCP payload critic blocked this edit.")
                    st.json(mcp_critic)
                elif not mcp_contract.get("valid", True):
                    st.error("MCP/API-contract validation blocked this edit.")
                    st.json(mcp_contract)
                else:
                    saved = save_override(
                        ROOT, selected_key, parsed_editor,
                        request_kind=request_kind, mode=override_mode, note=override_note, edit_origin="USER",
                    )
                    invalidate_connection_check()
                    st.success("Payload override saved after MCP critic + contract validation. It will be validated again immediately before live execution.")
                    st.json(saved)
                    st.rerun()
            except Exception as exc:
                st.error(str(exc))
        if b4.button("↩ Restore generated", width="stretch"):
            clear_override(ROOT, selected_key)
            invalidate_connection_check()
            st.success("Override removed; generated payload restored.")
            st.rerun()

        st.caption(
            "Security: payload evidence and UI previews are redacted. HTTPS/AS2 client secrets stay in local .env "
            "and are resolved only immediately before the live HTTP call."
        )

        if st.session_state.get("payload_validation"):
            with st.expander("Validation result", expanded=True):
                st.json(st.session_state["payload_validation"])
        aia_review = st.session_state.get("payload_aia_review")
        if aia_review:
            with st.expander("Dell AIA payload review", expanded=True):
                st.json(aia_review)
                corrected = aia_review.get("correctedRequest") if isinstance(aia_review, dict) else None
                if corrected:
                    st.info("Dell AIA suggestions are advisory only. The AI agent cannot save or apply payload changes. Copy any desired value into the Human Payload Value Editor yourself, review the diff, then click Save.")
                    st.code(json.dumps(corrected, indent=2, default=str), language="json")

        st.divider()
        d1, d2, d3 = st.columns(3)
        current_bundle = bundle_from_runner()
        d1.download_button(
            "Download current effective payload bundle",
            json.dumps(current_bundle, indent=2, default=str).encode("utf-8"),
            file_name="hip_effective_payload_bundle.json",
            mime="application/json",
            width="stretch",
        )
        if d2.button("Clear ALL payload overrides", width="stretch"):
            clear_all_overrides(ROOT)
            invalidate_connection_check()
            st.success("All payload overrides removed.")
            st.rerun()
        d3.metric("Active overrides", PayloadOverrideStore(ROOT).summary().get("count", 0))

        with st.expander("Bulk import payload overrides"):
            bulk = st.file_uploader("Payload bundle JSON", type=["json"], key="bulk_payload_override_upload")
            bulk_text = st.text_area("Or paste bundle", height=240, key="bulk_payload_override_text")
            if st.button("Import bundle as overrides", disabled=not (bulk or bulk_text.strip()), width="stretch"):
                try:
                    raw = json.loads(bulk.getvalue().decode("utf-8")) if bulk else json.loads(bulk_text)
                    bundle = normalize_payload_bundle(raw)
                    get_params = {"validate_flow", "flow_history", "source_tp_audit", "target_tp_audit"}
                    runner_for_bulk = Runner(llm_enabled=False)
                    validated = []
                    for key, value in bundle.items():
                        preview = runner_for_bulk.preview_step_request(key)
                        request_kind_bulk = "params" if key in get_params else "payload"
                        generated_bulk = (
                            preview.get("generatedParams") if request_kind_bulk == "params"
                            else preview.get("generatedPayload")
                        ) or {}
                        critic = mcp.validate_payload_override(
                            key,
                            safe_request_for_ui(generated_bulk),
                            safe_request_for_ui(value),
                            interface_only=False,
                        )
                        contract = mcp.validate_api_request(
                            api_key=preview.get("urlKey") or key,
                            method=preview.get("method") or "GET",
                            url=preview.get("url") or "",
                            headers={"x-requester-id": runner_for_bulk.requester, **(preview.get("extraHeaders") or {})},
                            payload=value if request_kind_bulk == "payload" else None,
                            params=value if request_kind_bulk == "params" else None,
                        )
                        if not critic.get("valid", True) or not contract.get("valid", True):
                            raise ValueError(
                                f"Bulk override {key} failed MCP validation: "
                                + json.dumps({"critic": critic, "contract": contract}, default=str)
                            )
                        save_override(
                            ROOT, key, value, request_kind=request_kind_bulk,
                            mode="replace", note="Bulk imported by human user after MCP validation", edit_origin="USER"
                        )
                        validated.append(key)
                    st.success(f"Imported {len(validated)} override(s) after MCP validation.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))
    except Exception as exc:
        st.error("Payload Studio could not build request previews. Complete the core configuration first.")
        st.code(str(exc))


# ---------------------------------------------------------------------------
# 6. API Execution Plan
# ---------------------------------------------------------------------------
with tabs[5]:
    st.header("API Execution Plan")
    st.markdown('<div class="hint"><b>Execute or skip existing.</b> A skipped API is not called. Downstream steps continue only when the existing object can safely resolve its dependency. Deployment History is always verified.</div>', unsafe_allow_html=True)
    active_input = load_json(INPUT_JSON, {})
    active_config = load_json(CONFIG_JSON, {})
    plan = ApiExecutionPlan(ROOT, INPUT_JSON)
    plan_summary = plan.summary()
    selected_raw = set(plan_summary.get("skipSteps") or [])
    skippable_keys = [key for key, meta in PLAN_STEP_DEFINITIONS.items() if meta.get("skippable", False)]
    label_to_key = {PLAN_STEP_DEFINITIONS[key]["label"]: key for key in skippable_keys}
    key_to_label = {value: key for key, value in label_to_key.items()}
    default_labels = [key_to_label[key] for key in skippable_keys if key in selected_raw]

    p1, p2 = st.columns([1.3, 1], gap="large")
    with p1:
        chosen_labels = st.multiselect("APIs to skip because the object/action already exists", list(label_to_key), default=default_labels)
        selected_keys = [label_to_key[label] for label in chosen_labels]
        reason = st.text_area("Reason / Dev-team confirmation", value=str(plan_summary.get("reason") or ""), height=100)
        confirm_skip = st.checkbox("I confirm the selected objects/actions already exist and may be skipped.", value=bool(plan_summary.get("confirmed") and plan_summary.get("inputMatches")), disabled=not selected_keys)
    existing_ids = plan_summary.get("existingIds") or {}
    with p2:
        source_doc_id = st.text_input("Existing Source Document Type ID", value=str(existing_ids.get("source_document_type_id") or active_config.get("source_document_type_id") or ""), key="plan_src_doc_id")
        target_doc_id = st.text_input("Existing Target Document Type ID", value=str(existing_ids.get("target_document_type_id") or active_config.get("target_document_type_id") or ""), key="plan_tgt_doc_id")
        existing_map_id = st.text_input("Existing MAC Map ID", value=str(existing_ids.get("map_id") or active_config.get("map_id") or ""), key="plan_map_id")
        existing_rule_id = st.text_input("Existing Rule ID", value=str(existing_ids.get("rule_id") or active_config.get("rule_id") or ""), key="plan_rule_id")
        existing_flow_id = st.text_input("Existing Flow ID", value=str(existing_ids.get("flow_id") or active_config.get("existing_flow_id") or ""), key="plan_flow_id")
        existing_flow_version = st.text_input("Existing Flow version", value=str(plan_summary.get("existingFlowVersion") or active_config.get("flowVersion") or "1.0"), key="plan_flow_version")
    ids = {"source_document_type_id": source_doc_id, "target_document_type_id": target_doc_id, "map_id": existing_map_id, "rule_id": existing_rule_id, "flow_id": existing_flow_id}
    c1, c2, c3 = st.columns(3)
    if c1.button("Save execution plan", type="primary", width="stretch"):
        try:
            save_execution_plan(ROOT, INPUT_JSON, selected_keys, ids, confirmed=bool(confirm_skip), reason=reason, existing_flow_version=existing_flow_version)
            invalidate_connection_check(); st.success("Execution plan saved."); st.rerun()
        except Exception as exc: st.error(str(exc))
    if c2.button("Use U-HAUL existing foundation preset", width="stretch"):
        try:
            save_execution_plan(ROOT, INPUT_JSON, sorted(UHAL_EXISTING_FOUNDATION_PRESET), ids, confirmed=True, reason="U-HAUL foundation objects are pre-existing: Source Account, Target Account, Target Partner and Source System.", existing_flow_version=existing_flow_version)
            invalidate_connection_check(); st.success("U-HAUL preset saved."); st.rerun()
        except Exception as exc: st.error(str(exc))
    if c3.button("Clear all skips", width="stretch"):
        clear_execution_plan(ROOT, INPUT_JSON); invalidate_connection_check(); st.success("All skips cleared."); st.rerun()
    plan_summary = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
    render_table([
        {"Stage": meta.get("group"), "API": meta.get("label"), "Decision": "ALWAYS VERIFY" if meta.get("always_verify") else ("SKIP — EXISTING" if key in set(plan_summary.get("skipSteps") or []) and plan_summary.get("active") else "EXECUTE"), "Existing ID required if skipped": bool(meta.get("existing_id_key"))}
        for key, meta in PLAN_STEP_DEFINITIONS.items()
    ])
    with st.expander("Execution-plan safety details"):
        st.json(plan_summary)


# ---------------------------------------------------------------------------
# 7. Flow & Timing
# ---------------------------------------------------------------------------
with tabs[6]:
    st.header("Execution Flow & Timing")
    st.markdown('<div class="hint"><b>Control order and wait time.</b> Reorder independent APIs and set wait-after seconds. Hard dependencies are validated, so unsafe orderings cannot be saved.</div>', unsafe_allow_html=True)
    flow = ExecutionFlowConfig(ROOT)
    rows = [{"Order": row.get("order"), "API Step": row.get("label"), "Step Key": row.get("stepKey"), "Group": row.get("group"), "Wait after (seconds)": row.get("waitAfterSeconds", 0.0), "Dependencies": ", ".join(row.get("dependencies") or []) or "—"} for row in flow.summary().get("steps") or []]
    edited = st.data_editor(
        rows, width="stretch", hide_index=True, num_rows="fixed",
        column_config={
            "Order": st.column_config.NumberColumn("Order", min_value=1, max_value=len(rows), step=1, required=True),
            "Wait after (seconds)": st.column_config.NumberColumn("Wait after (seconds)", min_value=0.0, max_value=3600.0, step=1.0, format="%.1f", required=True),
            "API Step": st.column_config.TextColumn("API Step", disabled=True),
            "Step Key": st.column_config.TextColumn("Step Key", disabled=True),
            "Group": st.column_config.TextColumn("Group", disabled=True),
            "Dependencies": st.column_config.TextColumn("Dependencies", disabled=True),
        }, key="execution_flow_editor_v2",
    )
    records = edited.to_dict(orient="records") if hasattr(edited, "to_dict") else list(edited)
    c1, c2, c3 = st.columns(3)
    if c1.button("Save flow and wait timings", type="primary", width="stretch"):
        try:
            payload_rows = [{"stepKey": str(row.get("Step Key") or ""), "order": int(row.get("Order")), "waitAfterSeconds": float(row.get("Wait after (seconds)") or 0)} for row in records]
            save_execution_flow(ROOT, payload_rows); invalidate_connection_check(); st.success("Flow and timings saved."); st.rerun()
        except Exception as exc: st.error(str(exc))
    if c2.button("Restore safe default flow", width="stretch"):
        reset_execution_flow(ROOT); invalidate_connection_check(); st.success("Safe defaults restored."); st.rerun()
    if c3.button("Ask Dell AIA to suggest order/timing", width="stretch"):
        try:
            from run_agent import AIAJudge
            judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True); judge.verify_connection()
            proposal = judge.complete_json(
                system="You are a Dell HIP orchestration planner. Return JSON only with steps [{stepKey,order,waitAfterSeconds}] and reason. Preserve all steps, obey dependencies, keep waits 0-300 seconds unless strongly justified.",
                user=json.dumps({"flow": flow.summary(), "executionPlan": ApiExecutionPlan(ROOT, INPUT_JSON).summary(), "payloadOverrides": PayloadOverrideStore(ROOT).summary()}, indent=2, default=str)[:16000],
                temperature=0.1,
            )
            st.session_state["aia_flow_proposal"] = proposal
        except Exception as exc: st.error(str(exc))
    if st.session_state.get("aia_flow_proposal"):
        with st.expander("Dell AIA proposal", expanded=True):
            st.json(st.session_state["aia_flow_proposal"])
            approved = st.checkbox("I reviewed and approve this flow/timing", key="approve_aia_flow_v2")
            if st.button("Apply approved proposal", disabled=not approved, width="stretch"):
                try:
                    save_execution_flow(ROOT, st.session_state["aia_flow_proposal"].get("steps") or [])
                    st.session_state.pop("aia_flow_proposal", None); invalidate_connection_check(); st.rerun()
                except Exception as exc: st.error(str(exc))
    summary = ExecutionFlowConfig(ROOT).summary()
    if summary.get("valid"): st.success("Execution flow is dependency-safe.")
    else: st.error("Execution flow is invalid."); st.json(summary.get("errors") or [])
    if summary.get("warnings"): st.warning("\n".join(summary.get("warnings") or []))


# ---------------------------------------------------------------------------
# 8. Dev Changes
# ---------------------------------------------------------------------------
with tabs[7]:
    st.header("User / Dev Team Change Agent")
    request_text = st.text_area("Describe the requested change", height=150, placeholder="Example: change Flow TP references, deployment group, field mapping, routing condition, API URL or payload rule.", key="dev_change_request")
    use_aia_change = st.checkbox("Use Dell AIA to interpret this change", value=True, key="dev_change_aia")
    if st.button("Propose change patch", type="primary", disabled=not request_text.strip(), width="stretch"):
        try:
            input_data = load_json(INPUT_JSON, {}); config_data = load_json(CONFIG_JSON, {})
            aia_callable = None
            if use_aia_change:
                from run_agent import AIAJudge
                judge = AIAJudge(config_data, enabled=True); judge.verify_connection(); aia_callable = judge.complete_json
            st.session_state["change_proposal"] = engine.propose_change(request_text, input_data, config_data, use_aia=bool(aia_callable), aia_complete_json=aia_callable)
        except Exception as exc: st.error(str(exc))
    if st.session_state.get("change_proposal"):
        proposal = st.session_state["change_proposal"]
        st.json(proposal)
        approve = st.checkbox("I reviewed and approve this patch", key="approve_dev_patch")
        if st.button("Apply approved patch", disabled=not approve, width="stretch"):
            try:
                applied = engine.apply_change(proposal, load_json(INPUT_JSON, {}), load_json(CONFIG_JSON, {}), approve=True)
                save_json(INPUT_JSON, applied["input"]); save_json(CONFIG_JSON, applied["config"])
                st.success("Patch applied. Revalidate payloads and execution plan before running.")
                st.session_state.pop("change_proposal", None); st.rerun()
            except Exception as exc: st.error(str(exc))


# ---------------------------------------------------------------------------
# 9. Knowledge & Learning
# ---------------------------------------------------------------------------
with tabs[8]:
    st.header("Knowledge Graph and AgentQ-inspired learning")
    k1, k2, k3 = st.columns(3)
    stats = engine.kg.stats(); aq = engine.agentq.stats()
    k1.metric("Knowledge nodes", stats.get("nodeCount", 0)); k2.metric("Knowledge edges", stats.get("edgeCount", 0)); k3.metric("AgentQ trajectories", aq.get("trajectoryCount", 0))
    sub1, sub2 = st.tabs(["Knowledge Graph", "AgentQ Memory"])
    with sub1:
        query = st.text_input("Search graph", placeholder="flow, document type, routing, customer, deployment group...", key="kg_query_v2")
        result = engine.kg.query(query, node_type="", limit=200)
        render_table(result.get("nodes") or [])
        with st.expander("Edges"): render_table(result.get("edges") or [])
        c1, c2, c3 = st.columns(3)
        if c1.button("Export JSON", width="stretch"): st.success(str(engine.kg.export_json()))
        if c2.button("Export GraphML", width="stretch"): st.success(str(engine.kg.export_graphml()))
        if c3.button("Sync to Neo4j", width="stretch"): st.json(engine.kg.sync_to_neo4j())
    with sub2:
        st.caption("Stores successful/failed trajectories and patch preferences. It does not fine-tune the Dell AIA model in this client package.")
        st.json(aq)
        render_table(engine.agentq.ranked_candidates("dev_change", limit=20))
        with st.expander("Recent trajectories"): render_table(engine.agentq.recent_trajectories(task_key="", limit=100))


# ---------------------------------------------------------------------------
# 10. Review & Run
# ---------------------------------------------------------------------------
with tabs[9]:
    st.header("Review, preflight and execute")
    input_data = load_json(INPUT_JSON, {})
    config_data = load_json(CONFIG_JSON, {})
    mapper = UhalInputMapper(input_data, config_data, ROOT)
    issues = [item.__dict__ for item in mapper.validate()]
    mcp_validation = mcp.validate_uhal_input(input_data, config_data)
    connection = load_json(REPORTS / "connection_check_latest.json", {})
    connected = connection.get("overall") == "OK"
    execution_plan_summary = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
    flow_summary = ExecutionFlowConfig(ROOT).summary()
    payload_summary = PayloadOverrideStore(ROOT).summary()
    pdf_required = os.getenv("PDF_REQUIRE_DOCUMENTATION", "false").lower() in {"true", "1", "yes"}
    pdf_ready = (not pdf_required) or pdf_kb.has_documents()
    plan_safe = not execution_plan_summary.get("confirmed") or execution_plan_summary.get("active")
    ready = (
        not any(item["severity"] == "ERROR" for item in issues)
        and bool(mcp_validation.get("valid"))
        and connected
        and plan_safe
        and bool(flow_summary.get("valid"))
        and bool(payload_summary.get("valid"))
        and pdf_ready
    )

    cols = st.columns(7)
    cols[0].metric("Mapper", "OK" if not any(x["severity"] == "ERROR" for x in issues) else "FIX")
    cols[1].metric("MCP", "OK" if mcp_validation.get("valid") else "FIX")
    cols[2].metric("Connections", "OK" if connected else "CHECK")
    cols[3].metric("API skips", len(execution_plan_summary.get("skipSteps") or []))
    cols[4].metric("Payload edits", payload_summary.get("count", 0))
    cols[5].metric("Flow", "OK" if flow_summary.get("valid") else "FIX")
    cols[6].metric("PDF", "OK" if pdf_ready else "REQUIRED")

    if ready:
        st.success("All readiness gates passed. The live execution button is enabled.")
    else:
        st.error("One or more readiness gates need attention before live execution.")

    if issues: render_table(issues)
    if not pdf_ready: st.error("API PDF is required by your setting but has not been uploaded/ingested.")
    if not plan_safe: st.error("The saved API skip plan belongs to another input or is invalid. Re-save it.")
    if not payload_summary.get("valid"): st.error("Payload overrides are invalid."); st.json(payload_summary.get("errors"))

    st.subheader("Effective run plan")
    override_keys = {row["stepKey"] for row in payload_summary.get("overrides") or [] if row.get("enabled")}
    skip_keys = set(execution_plan_summary.get("skipSteps") or []) if execution_plan_summary.get("active") else set()
    run_rows = []
    for index, key in enumerate(ExecutionFlowConfig(ROOT).ordered_steps(), start=1):
        meta = FLOW_STEP_DEFINITIONS[key]
        run_rows.append({
            "Order": index,
            "API": meta["label"],
            "Decision": "SKIP — EXISTING" if key in skip_keys else "EXECUTE",
            "Payload": "USER EDITED" if key in override_keys else "GENERATED",
            "Wait after (s)": ExecutionFlowConfig(ROOT).wait_after(key),
            "OAuth": "ACCOUNT" if key in {"account_source", "account_target"} else "PARTNER" if key == "partner_target" else "SYSTEM" if key == "system_source" else "HIP CONFIG",
        })
    render_table(run_rows)

    with st.expander("Active canonical configuration"): st.json(input_data)
    with st.expander("Payload override summary"): st.json(payload_summary)
    with st.expander("API execution plan"): st.json(execution_plan_summary)
    with st.expander("Execution flow/timing"): st.json(flow_summary)

    c1, c2, c3 = st.columns(3)
    if c1.button("Run preflight only", width="stretch"):
        proc = subprocess.run([sys.executable, "run_agent.py", "--preflight"], cwd=ROOT, text=True, capture_output=True)
        st.session_state["preflight_output"] = (proc.returncode, proc.stdout, proc.stderr)
    c2.download_button("Download configuration bundle", config_bundle_bytes(), file_name="hip_configuration_workspace_bundle.zip", mime="application/zip", width="stretch")
    if c3.button("Refresh connection readiness", width="stretch"):
        proc = subprocess.run([sys.executable, "connection_check.py"], cwd=ROOT, text=True, capture_output=True)
        st.session_state["connection_check"] = load_json(REPORTS / "connection_check_latest.json", {})
        st.rerun()
    if st.session_state.get("preflight_output"):
        rc, out, err = st.session_state["preflight_output"]
        with st.expander(f"Preflight output (exit {rc})", expanded=True): st.code((out or "") + ("\n" + err if err else ""))

    if st.button("Execute live end-to-end configuration", type="primary", disabled=not ready, width="stretch"):
        with st.status("Executing dependency-aware HIP configuration...", expanded=True) as status:
            proc = subprocess.run([sys.executable, "run_agent.py"], cwd=ROOT, text=True, capture_output=True)
            if proc.returncode == 0:
                status.update(label="Execution completed", state="complete")
                st.success("Live execution completed successfully.")
            else:
                status.update(label=f"Execution finished with failure ({proc.returncode})", state="error")
                st.error("The report contains complete request/response evidence and the blocking dependency.")
            with st.expander("Execution log", expanded=True): st.code((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else ""))
        report = latest_report()
        if report and report.exists():
            st.download_button("Download final HTML report", report.read_bytes(), file_name=report.name, mime="text/html", width="stretch")
            st.components.v1.html(report.read_text(encoding="utf-8"), height=900, scrolling=True)

    report = latest_report()
    if report and report.exists():
        st.divider(); st.subheader("Latest execution report")
        st.download_button("Download latest HTML report", report.read_bytes(), file_name=report.name, mime="text/html", width="stretch", key="latest_report_dl")
