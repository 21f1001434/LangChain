from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from streamlit_navigation import render_app_home_link, safe_page_link
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agentic_interface_orchestrator import (
    AgenticInterfaceOrchestrator,
    activate_proposal,
    impact_analysis,
    recommend_execution_strategy,
)
from api_execution_plan import ApiExecutionPlan, clear_execution_plan, save_execution_plan
from api_pdf_ingestion import PdfApiKnowledgeBase
from application_studio import request_inventory, run_local_request_checks
from business_demo import BUSINESS_DEMO_SKIP_STEPS
from execution_flow import STEP_DEFINITIONS, reset_execution_flow
from interface_registry import (
    get_interface,
    interface_keys,
    load_custom_interfaces,
    save_custom_interface,
)
from payload_overrides import clear_override, save_override
from payload_ui_helpers import json_change_paths, safe_request_for_ui
from production_guard import clear_stale_live_run, inspect_live_run, terminate_live_run
from mcp_bridge import MCPBridge
from runtime_payload_values import (
    placeholder as runtime_payload_placeholder,
    runtime_payload_status,
    save_runtime_payload_values,
)

INPUT_JSON = ROOT / "input.json"
CONFIG_JSON = ROOT / "config_overrides.json"
ENV_PATH = ROOT / ".env"
REPORTS = ROOT / "reports"
DEV_APPROVED_DIR = ROOT / "dev_approved"
BUILD_ID = "2026-08-12-live-only-all18-interactive-game-upload-v23"

REPORTS.mkdir(exist_ok=True)
load_dotenv(ENV_PATH, override=True)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def json_object(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object")
    return value


def existing_ids() -> Dict[str, Any]:
    cfg = load_json(CONFIG_JSON, {})
    return {
        "source_document_type_id": cfg.get("source_document_type_id"),
        "target_document_type_id": cfg.get("target_document_type_id"),
        "map_id": cfg.get("map_id") or 1670,
        "rule_id": cfg.get("rule_id"),
        "flow_id": cfg.get("existing_flow_id"),
    }


def latest_html_report() -> Path | None:
    candidates = sorted(REPORTS.glob("*.html"), key=lambda p: p.stat().st_mtime)
    return candidates[-1] if candidates else None


def render_trace(trace: List[Dict[str, Any]]) -> None:
    if not trace:
        return
    cols = st.columns(min(6, len(trace)))
    for idx, item in enumerate(trace):
        with cols[idx % len(cols)]:
            status = str(item.get("status") or "")
            icon = "✅" if status in {"OK", "PASS"} else ("🟡" if "NEEDS" in status else "⛔")
            st.markdown(f"**{icon} {item.get('phase')}**")
            st.caption(item.get("summary") or "")


st.set_page_config(
    page_title="Agentic Interface Studio",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
<style>
:root{--navy:#071f3c;--blue:#0b5cab;--teal:#0d8b92;--green:#148447;--line:#d8e4ef;--muted:#65758a}
.stApp{background:linear-gradient(180deg,#f8fbff,#eef5fb)}
.block-container{max-width:1540px;padding-top:1rem;padding-bottom:4rem}
.hero2{background:radial-gradient(circle at 88% 0%,rgba(57,220,212,.4),transparent 30%),linear-gradient(135deg,#061b36,#0b5cab 62%,#0a7e87);color:#fff;padding:32px 36px;border-radius:24px;box-shadow:0 18px 46px rgba(9,48,84,.18);margin-bottom:18px}.hero2 h1{margin:0}.hero2 p{color:#dceeff;margin:.5rem 0 0}.stage{background:#fff;border:1px solid var(--line);border-radius:18px;padding:18px 20px;box-shadow:0 8px 24px rgba(13,43,76,.05);margin:10px 0}.pill{display:inline-block;padding:5px 10px;border-radius:999px;font-weight:800;font-size:.74rem;background:#e8f4ff;color:#07558f;margin-right:6px}.ready{background:#ecf9f1;color:#17663a}.warn{background:#fff4dc;color:#865600}.muted{background:#eef1f5;color:#5e6c7b}.stButton>button{border-radius:11px;min-height:2.7rem;font-weight:700}[data-testid="stMetric"]{background:#fff;border:1px solid var(--line);border-radius:15px;padding:12px}
</style>
<div class="hero2">
<h1>🤖 Agentic Interface Studio</h1>
<p>Choose any registered interface, let the agent retrieve its contract, ask only for missing values, generate and critique the HIP requests, validate them, then execute the selected API plan.</p>
<div style="font-size:.78rem;opacity:.8;margin-top:.7rem">Built-in: SFTP · FTP · HTTPS · HTTPS-AS2 · plus user-defined interfaces · Build 2026-08-11-partner-payload-values-v12</div>
</div>
""",
    unsafe_allow_html=True,
)

pdf_kb = PdfApiKnowledgeBase(ROOT)
mcp = MCPBridge(
    ROOT,
    enabled=str(os.getenv("MCP_ENABLED", "true")).strip().lower() in {"1", "true", "yes", "on"},
    required=str(os.getenv("MCP_REQUIRED", "false")).strip().lower() in {"1", "true", "yes", "on"},
)

# MCP is a first-class agent/tool layer, but local deterministic fallbacks remain
# available unless MCP_REQUIRED=true. This keeps Business demos resilient while
# still allowing a strict protocol-transport mode for engineering validation.
mcp_status = mcp.status()
mc1, mc2, mc3, mc4 = st.columns(4)
mc1.metric("MCP", "READY" if mcp_status.get("active") else "OFF")
mc2.metric("Transport", mcp_status.get("transport") or "—")
mc3.metric("Tool calls", mcp_status.get("calls", 0))
mc4.metric("Fallback calls", mcp_status.get("fallbackCalls", 0))
with st.expander("🧰 MCP agent toolbox", expanded=False):
    st.caption(
        "MCP now covers interface planning, contracts, mapping, payload critique, execution policy, "
        "response interpretation, runtime-ID resolution, Knowledge Graph and AgentQ memory."
    )
    coverage = mcp_status.get("toolCoverage") or {}
    st.dataframe(
        [{"Capability": key, "Enabled": "✓" if value else "—"} for key, value in coverage.items()],
        hide_index=True,
        width="stretch",
    )
    st.json(mcp_status)

    trace_path = ROOT / "reports" / "mcp_tool_trace_latest.jsonl"
    if trace_path.exists():
        recent = []
        try:
            for line in trace_path.read_text(encoding="utf-8").splitlines()[-20:]:
                if line.strip():
                    recent.append(json.loads(line))
        except Exception:
            recent = []
        if recent:
            st.markdown("**Recent MCP tool activity**")
            st.dataframe(recent[::-1], hide_index=True, width="stretch")
        if st.button("Clear MCP tool activity", key="clear_mcp_trace", width="stretch"):
            trace_path.unlink(missing_ok=True)
            st.rerun()

# ---------------------------------------------------------------------------
# 1. INTERFACE LIBRARY
# ---------------------------------------------------------------------------
st.markdown("## 1 · Choose the interface")
left, right = st.columns([1.2, 1], gap="large")
with left:
    source_key = st.selectbox("Sender / Source interface", interface_keys(ROOT), key="any_src_interface")
    target_key = st.selectbox("Receiver / Target interface", interface_keys(ROOT), key="any_tgt_interface")
with right:
    source_def = get_interface(ROOT, source_key)
    target_def = get_interface(ROOT, target_key)
    st.markdown(
        f"""
        <div class="stage"><span class="pill">SOURCE</span><b>{source_def.get('displayName')}</b><br><span style="color:#65758a">{source_def.get('description')}</span><br><code>{source_def.get('apiInterfaceType')}</code></div>
        <div class="stage"><span class="pill">TARGET</span><b>{target_def.get('displayName')}</b><br><span style="color:#65758a">{target_def.get('description')}</span><br><code>{target_def.get('apiInterfaceType')}</code></div>
        """,
        unsafe_allow_html=True,
    )

with st.expander("➕ Register another interface", expanded=False):
    st.caption("Use this when a new HIP interface appears. The runner is parameter-object driven, so a new interface does not require a new Python branch.")
    c1, c2, c3 = st.columns(3)
    custom_name = c1.text_input("Studio name", placeholder="Example: MQ / Kafka / CustomHTTPS")
    custom_api_type = c2.text_input("HIP interfaceType", placeholder="Exact API value")
    custom_family = c3.selectbox("Interface family", ["CUSTOM", "HTTP", "FILE_TRANSFER", "AS2", "MESSAGING"], index=0)
    custom_description = st.text_input("Business description", placeholder="What this interface is used for")
    cp1, cp2, cp3 = st.columns(3)
    custom_group = cp1.text_input("Deployment group — fixed by Dev team", value="hip-automation", disabled=True)
    custom_source_shared = cp2.text_input("Source shared Flow profile", placeholder="Required if Flow uses a shared profile")
    custom_target_shared = cp3.text_input("Target shared Flow profile", placeholder="Required if Flow uses a shared profile")
    cr1, cr2 = st.columns(2)
    custom_source_defaults = cr1.text_area("Source parameter defaults (JSON)", value="{}", height=160)
    custom_target_defaults = cr2.text_area("Target parameter defaults (JSON)", value="{}", height=160)
    rr1, rr2 = st.columns(2)
    custom_source_required = rr1.text_input("Required Source parameter names", placeholder="Comma separated, or leave blank")
    custom_target_required = rr2.text_input("Required Target parameter names", placeholder="Comma separated, or leave blank")
    ss1, ss2 = st.columns(2)
    custom_source_sensitive = ss1.text_input(
        "Sensitive Source payload fields",
        placeholder="Example: Sender Client Secret",
        help="These are payload fields. The Studio will collect the value securely at runtime; no new .env credential is created.",
    )
    custom_target_sensitive = ss2.text_input(
        "Sensitive Target payload fields",
        placeholder="Example: Receiver Client Secret",
    )
    custom_docs = st.checkbox("Require API documentation before live execution", value=True)
    if st.button("Save custom interface", type="primary", width="stretch"):
        try:
            definition = {
                "displayName": custom_name,
                "apiInterfaceType": custom_api_type or custom_name,
                "family": custom_family,
                "description": custom_description,
                "deploymentGroup": "hip-automation",
                "sourceSharedProfile": custom_source_shared,
                "targetSharedProfile": custom_target_shared,
                "sourceDefaults": json_object(custom_source_defaults),
                "targetDefaults": json_object(custom_target_defaults),
                "sourceRequired": [x.strip() for x in custom_source_required.split(",") if x.strip()] or ["__PARAMETERS__", "__SHARED_PROFILE__"],
                "targetRequired": [x.strip() for x in custom_target_required.split(",") if x.strip()] or ["__PARAMETERS__", "__SHARED_PROFILE__"],
                "sourceSensitiveFields": [x.strip() for x in custom_source_sensitive.split(",") if x.strip()],
                "targetSensitiveFields": [x.strip() for x in custom_target_sensitive.split(",") if x.strip()],
                "requiresDocumentation": custom_docs,
            }
            save_custom_interface(ROOT, custom_name, definition)
            st.success("Interface registered. Reloading the Studio library.")
            st.rerun()
        except Exception as exc:
            st.error(str(exc))

# ---------------------------------------------------------------------------
# 2. BASELINE + DOCUMENTATION
# ---------------------------------------------------------------------------
st.markdown("## 2 · Choose the configuration baseline")
baseline_choice = st.radio(
    "Start from",
    ["Approved U-HAUL baseline", "Current active configuration"],
    horizontal=True,
)
if baseline_choice.startswith("Approved"):
    baseline_path = DEV_APPROVED_DIR / "UHAL_input_dev_approved.json"
else:
    baseline_path = INPUT_JSON
baseline = load_json(baseline_path, {})

m1, m2, m3, m4 = st.columns(4)
m1.metric("Customer", baseline.get("customer") or "—")
m2.metric("Flow", baseline.get("profile_name") or "—")
m3.metric("Direction", baseline.get("direction") or "—")
m4.metric("Deployment", "hip-automation")

needs_docs = bool(source_def.get("requiresDocumentation") or target_def.get("requiresDocumentation"))
with st.expander("📚 API / interface documentation", expanded=needs_docs and not pdf_kb.has_documents()):
    docs = st.file_uploader("Upload API documentation PDF(s)", type=["pdf"], accept_multiple_files=True)
    if docs and st.button("Teach the agent from uploaded PDF(s)", type="primary"):
        results = []
        for item in docs:
            try:
                result = pdf_kb.ingest_bytes(item.name, item.getvalue())
                results.append({"name": item.name, "status": "INGESTED", "pages": getattr(result, "pages", None)})
            except Exception as exc:
                results.append({"name": item.name, "status": "FAILED", "error": str(exc)})
        st.json(results)
        st.rerun()
    st.caption(f"Documentation currently loaded: {len(pdf_kb.list_documents())}")

# ---------------------------------------------------------------------------
# 3. INTERFACE VALUES + AGENT PLAN
# ---------------------------------------------------------------------------
st.markdown("## 3 · Let the agent build the interface plan")
source_defaults = source_def.get("sourceDefaults") or {}
target_defaults = target_def.get("targetDefaults") or {}

v1, v2 = st.columns(2, gap="large")
with v1:
    st.markdown("### Sender values")
    source_shared = st.text_input("Source shared Flow profile", value=str(source_def.get("sourceSharedProfile") or ""))
    source_param_text = st.text_area(
        "Source interface parameters",
        value=json.dumps(source_defaults, indent=2),
        height=300,
        help="For SFTP/FTP this can stay empty. For custom interfaces enter the approved parameter object.",
    )
with v2:
    st.markdown("### Receiver values")
    target_shared = st.text_input("Target shared Flow profile", value=str(target_def.get("targetSharedProfile") or ""))
    target_param_text = st.text_area(
        "Target interface parameters",
        value=json.dumps(target_defaults, indent=2),
        height=300,
    )

# Friendly HTTPS Partner-owned fields override the JSON defaults when present.
if target_key == "HTTPS":
    st.markdown("#### HTTPS Receiver values required from Partner")
    hp1, hp2, hp3 = st.columns(3)
    partner_url = hp1.text_input("Partner URL")
    receiver_grant = hp2.text_input("Receiver Grant Type")
    receiver_token = hp3.text_input("Receiver Token Endpoint")
    receiver_client = st.text_input("Receiver Client ID")
    st.caption(
        "Receiver Client Secret is also Partner-provided and belongs in the HTTPS payload. "
        "Enter it in Secure payload values below; it is not an application OAuth credential and is not written to .env."
    )

# Secure payload values are collected separately so generated/stored JSON never
# persists the literal secret. The live request still contains the actual field.
runtime_secret_inputs: Dict[str, Dict[str, str]] = {"source": {}, "target": {}}
source_sensitive = list(source_def.get("sourceSensitiveFields") or [])
target_sensitive = list(target_def.get("targetSensitiveFields") or [])
if source_sensitive or target_sensitive:
    with st.expander("🔐 Secure payload values", expanded=(target_key == "HTTPS")):
        st.caption(
            "These are interface payload values supplied by the Partner/endpoint owner. "
            "They are not added to the application Credentials page or .env."
        )
        sc1, sc2 = st.columns(2)
        with sc1:
            for idx, field in enumerate(source_sensitive):
                runtime_secret_inputs["source"][field] = st.text_input(
                    field, type="password", key=f"runtime_src_sensitive_{idx}_{field}",
                    placeholder="Enter only when required by this interface",
                )
        with sc2:
            for idx, field in enumerate(target_sensitive):
                runtime_secret_inputs["target"][field] = st.text_input(
                    field, type="password", key=f"runtime_tgt_sensitive_{idx}_{field}",
                    placeholder="Partner-provided payload value",
                )
        status = runtime_payload_status(ROOT)
        if status.get("available"):
            st.caption(f"Runtime payload values currently available: {status.get('keyCount', 0)}")

plan_button = st.button("🤖 Observe → Plan → Validate → Critic", type="primary", width="stretch")
if plan_button:
    try:
        source_params = json_object(source_param_text)
        target_params = json_object(target_param_text)
        if target_key == "HTTPS":
            if partner_url:
                target_params["Partner URL"] = partner_url
            if receiver_grant:
                target_params["Receiver Grant Type"] = receiver_grant
            if receiver_token:
                target_params["Receiver Token Endpoint"] = receiver_token
            if receiver_client:
                target_params["Receiver Client Id"] = receiver_client

        runtime_values: Dict[str, Any] = {"source": {}, "target": {}}
        for side, definition, params in [
            ("source", source_def, source_params),
            ("target", target_def, target_params),
        ]:
            sensitive_fields = definition.get(f"{side}SensitiveFields") or []
            for field in sensitive_fields:
                entered = str((runtime_secret_inputs.get(side) or {}).get(field) or "").strip()
                runtime_key = f"{side}." + re.sub(r"[^A-Za-z0-9]+", "_", field).strip("_").lower()
                if entered:
                    runtime_values[side][runtime_key.split(".", 1)[1]] = entered
                    params[field] = runtime_payload_placeholder(runtime_key)
                elif field in params and str(params.get(field) or "").strip().startswith("{{runtime_payload."):
                    pass

        if any(runtime_values.get(side) for side in ("source", "target")):
            save_runtime_payload_values(ROOT, runtime_values, merge=True)

        deployment_group = str(source_def.get("deploymentGroup") or target_def.get("deploymentGroup") or "hip-automation")
        proposal = mcp.plan_interface_configuration(
            baseline_input=baseline,
            source_interface=source_key,
            target_interface=target_key,
            source_parameters=source_params,
            target_parameters=target_params,
            source_shared_profile=source_shared,
            target_shared_profile=target_shared,
            deployment_group=deployment_group,
        )
        st.session_state["any_interface_proposal"] = proposal
    except Exception as exc:
        st.error(str(exc))

proposal = st.session_state.get("any_interface_proposal") or {}
if proposal:
    render_trace(proposal.get("trace") or [])
    if proposal.get("questions"):
        st.warning("The agent still needs the following before this interface can be activated:")
        for q in proposal.get("questions") or []:
            st.markdown(f"- **{q.get('question')}** — {q.get('why')}")
    critic = proposal.get("critic") or {}
    if critic.get("status") == "PASS":
        st.success(f"Critic PASS · {len(proposal.get('changedPaths') or [])} allowed configuration path(s) changed.")
        impact = proposal.get("impact") or impact_analysis(proposal.get("changedPaths") or [])
        im1, im2 = st.columns([1, 2])
        im1.metric("Affected API steps", impact.get("count", 0))
        im2.info(impact.get("summary"))
        with st.expander("Review changed paths / affected APIs"):
            st.markdown("**Changed canonical paths**")
            for path in proposal.get("changedPaths") or []:
                st.code(path)
            st.markdown("**Affected logical API steps**")
            for step in impact.get("affectedSteps") or []:
                st.markdown(f"- `{step}`")
            st.markdown("**MCP planning evidence**")
            st.json({
                "transport": proposal.get("mcpTransport"),
                "protocolUsed": proposal.get("mcpUsed"),
                "policy": proposal.get("mcpPolicy"),
                "executionStrategy": proposal.get("executionStrategy"),
            })
        if st.button("Activate this interface plan", type="primary", width="stretch"):
            activate_proposal(ROOT, proposal["proposal"])
            st.session_state["any_interface_activated"] = True
            st.session_state.pop("any_interface_checks", None)
            st.success("Interface-aware configuration activated. Choose the execution strategy next.")
            st.rerun()
    elif critic:
        st.error(f"Critic {critic.get('status')}: {critic.get('summary') or 'Proposal is blocked.'}")

active = load_json(INPUT_JSON, {})
mode = active.get("_agentic_interface_mode") if isinstance(active, dict) else None
activated = bool(isinstance(mode, dict) and mode.get("enabled"))
if activated:
    st.markdown("## 4 · Choose how the APIs should run")
    current_plan = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
    recommendation = recommend_execution_strategy(active, current_plan)
    st.markdown(
        f"<div class='stage'><span class='pill ready'>AGENT RECOMMENDS</span><b>{recommendation.get('label')}</b><br><span style='color:#65758a'>{recommendation.get('reason')}</span></div>",
        unsafe_allow_html=True,
    )
    strategy = st.radio(
        "Execution strategy",
        [
            "Governed validation — execute applicable APIs and use only each call's own evidence",
            "Use current API execution plan",
            "Full configure — execute create/deploy APIs too",
            "Plan only — do not call live APIs",
        ],
        horizontal=False,
    )

    full_confirmed = False
    if strategy.startswith("Full configure"):
        st.error(
            "Full configure can create or deploy HIP objects. Use this only for a genuinely new configuration or when the API owner has confirmed the create/update semantics for the selected interface."
        )
        full_confirmed = st.checkbox("I approve a mutating full configuration run for this active configuration.")

    if st.button("Apply execution strategy", width="stretch"):
        if strategy.startswith("Safe validation"):
            plan = save_execution_plan(
                ROOT,
                INPUT_JSON,
                BUSINESS_DEMO_SKIP_STEPS,
                existing_ids(),
                confirmed=True,
                reason="Agentic Interface Studio safe validation: reuse known objects; execute validation/history/audit APIs only.",
                existing_flow_version=str(load_json(CONFIG_JSON, {}).get("flowVersion") or "1.0"),
            )
            st.session_state["any_interface_strategy"] = "SAFE_VALIDATION"
            st.success("Safe validation plan applied.")
        elif strategy.startswith("Full configure"):
            if not full_confirmed:
                st.error("Approve the mutating run first.")
            else:
                clear_execution_plan(ROOT, INPUT_JSON)
                # The Business demo intentionally uses zero waits because all
                # mutating U-HAUL steps are skipped. A genuinely new Full
                # Configure run must restore the production-safe default timing
                # (for example, post-TP / post-deploy processing waits) instead
                # of inheriting the demo's zero-wait plan.
                reset_execution_flow(ROOT)
                st.session_state["any_interface_strategy"] = "FULL_CONFIGURE"
                st.success(
                    "Full configuration plan applied: normal API dependency order "
                    "and production-safe default waits were restored."
                )
        elif strategy.startswith("Use current"):
            if not current_plan.get("active"):
                st.error("Current plan is not active for this input. Save a plan in Advanced Technical Workspace or choose another strategy.")
            else:
                st.session_state["any_interface_strategy"] = "CURRENT_PLAN"
                st.success("Current execution plan selected.")
        else:
            st.session_state["any_interface_strategy"] = "PLAN_ONLY"
            st.info("Plan-only mode selected. Agent checks and payload review are available; live execution stays disabled.")

    strategy_key = st.session_state.get("any_interface_strategy")

    # -----------------------------------------------------------------------
    # 5. REQUEST STUDIO
    # -----------------------------------------------------------------------
    st.markdown("## 5 · Review generated API requests")
    try:
        inventory = request_inventory(ROOT)
    except Exception as exc:
        st.error(f"Could not build request inventory: {exc}")
        inventory = {"cards": [], "total": 0, "live": 0, "reused": 0, "edited": 0}

    im1, im2, im3, im4 = st.columns(4)
    im1.metric("Logical requests", inventory.get("total", 0))
    im2.metric("Will execute", inventory.get("live", 0))
    im3.metric("Reused / skipped", inventory.get("reused", 0))
    im4.metric("Edited", inventory.get("edited", 0))

    cards = inventory.get("cards") or []
    if cards:
        label_map = {f"{row['order']:02d} · {row['label']}": row for row in cards}
        selected_label = st.selectbox("Inspect a request", list(label_map))
        card = label_map[selected_label]
        st.markdown(f"**{card.get('decision')} · {card.get('method')}**  `{card.get('url')}`")
        tabs = st.tabs(["Effective request", "Generated baseline", "Edit"])
        with tabs[0]:
            st.json(card.get("effective") or {})
            if card.get("changedPaths"):
                st.caption("Changes from generated baseline:")
                for path in card.get("changedPaths") or []:
                    st.code(path)
        with tabs[1]:
            st.json(card.get("generated") or {})
        with tabs[2]:
            edit_text = st.text_area(
                "Request JSON",
                value=json.dumps(card.get("effective") or {}, indent=2),
                height=420,
                key=f"any_edit_{card.get('stepKey')}",
            )
            parsed = None
            try:
                parsed = json_object(edit_text)
                st.success("JSON is valid.")
            except Exception as exc:
                st.error(str(exc))
            e1, e2 = st.columns(2)
            if e1.button("Save edit", type="primary", disabled=parsed is None, width="stretch"):
                payload_guard = mcp.validate_payload_override(
                    card.get("stepKey"),
                    card.get("generated") or {},
                    parsed or {},
                    interface_only=bool(activated),
                )
                request_validation = mcp.validate_api_request(
                    api_key=card.get("urlKey") or card.get("stepKey"),
                    method=card.get("method") or "GET",
                    url=card.get("url") or "",
                    headers={"x-requester-id": "payload-studio-preview"},
                    payload=(parsed if (card.get("requestKind") or "payload") == "payload" else None),
                    params=(parsed if (card.get("requestKind") or "payload") == "params" else None),
                )
                if not payload_guard.get("valid", True):
                    st.error("MCP critic rejected this edit: " + "; ".join(payload_guard.get("errors") or []))
                    st.json(payload_guard)
                elif not request_validation.get("valid", True):
                    st.error("MCP/API-contract validation rejected this edit.")
                    st.json(request_validation)
                else:
                    save_override(
                        ROOT,
                        card.get("stepKey"),
                        parsed,
                        request_kind=card.get("requestKind") or "payload",
                        mode="replace",
                        note="Human user edit in Agentic Interface Studio after MCP critic + contract validation", edit_origin="USER",
                    )
                    st.session_state.pop("any_interface_checks", None)
                    st.success("Edit saved after MCP payload critic and contract validation.")
                    st.rerun()
            if e2.button("Restore generated", width="stretch"):
                clear_override(ROOT, card.get("stepKey"))
                st.session_state.pop("any_interface_checks", None)
                st.rerun()

    # -----------------------------------------------------------------------
    # 6. AGENT CHECKS
    # -----------------------------------------------------------------------
    st.markdown("## 6 · Agent checks before execution")
    if st.button("🤖 Run all checks", type="primary", width="stretch"):
        logs: List[str] = []
        with st.status("Agent is checking connections, MCP tools, contracts, payloads and production safety...", expanded=True) as status:
            st.write("1/4 · Service connections")
            conn = subprocess.run([sys.executable, "connection_check.py"], cwd=ROOT, text=True, capture_output=True)
            logs.append((conn.stdout or "") + ("\n" + conn.stderr if conn.stderr else ""))
            connection = load_json(REPORTS / "connection_check_latest.json", {})
            connection_ok = conn.returncode == 0 and connection.get("overall") == "OK"

            st.write("2/4 · Mapping, dependencies, MCP/PDF contracts and all generated requests")
            try:
                local = run_local_request_checks(ROOT)
                local_ok = bool(local.get("ok"))
            except Exception as exc:
                local = {"ok": False, "error": str(exc)}
                local_ok = False

            st.write("3/4 · MCP supervisor readiness")
            readiness = mcp.assess_execution_readiness(
                load_json(INPUT_JSON, {}),
                load_json(CONFIG_JSON, {}),
            )
            mcp_ready = bool(readiness.get("valid") and not readiness.get("liveRunBlocked"))

            st.write("4/4 · Production preflight")
            preflight = subprocess.run([sys.executable, "run_agent.py", "--preflight"], cwd=ROOT, text=True, capture_output=True)
            logs.append((preflight.stdout or "") + ("\n" + preflight.stderr if preflight.stderr else ""))
            preflight_ok = preflight.returncode == 0

            all_ok = bool(connection_ok and local_ok and mcp_ready and preflight_ok)
            status.update(label="Agent checks passed" if all_ok else "Agent found a blocker", state="complete" if all_ok else "error")
            st.session_state["any_interface_checks"] = {
                "ok": all_ok,
                "connections": connection_ok,
                "local": local_ok,
                "mcpSupervisor": mcp_ready,
                "preflight": preflight_ok,
                "connectionDetail": connection,
                "localDetail": local,
                "mcpReadiness": readiness,
                "mcpStatus": mcp.status(),
                "logs": "\n".join(logs),
            }

    checks = st.session_state.get("any_interface_checks") or {}
    if checks:
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Connections", "PASS" if checks.get("connections") else "CHECK")
        c2.metric("Payload contracts", "PASS" if checks.get("local") else "CHECK")
        c3.metric("MCP supervisor", "PASS" if checks.get("mcpSupervisor") else "CHECK")
        c4.metric("Preflight", "PASS" if checks.get("preflight") else "CHECK")
        c5.metric("Agent verdict", "READY" if checks.get("ok") else "ATTENTION")
        with st.expander("Agent-check evidence"):
            st.json({
                "connection": checks.get("connectionDetail"),
                "local": checks.get("localDetail"),
                "mcpReadiness": checks.get("mcpReadiness"),
                "mcpStatus": checks.get("mcpStatus"),
            })

    # -----------------------------------------------------------------------
    # 7. EXECUTION
    # -----------------------------------------------------------------------
    st.markdown("## 7 · Execute")
    lock = inspect_live_run(ROOT)
    if lock.get("stale"):
        clear_stale_live_run(ROOT)
        lock = inspect_live_run(ROOT)
    if lock.get("active"):
        st.warning(f"Another HIP run is active (PID {lock.get('pid')}).")
        k1, k2 = st.columns(2)
        if k1.button("🛑 Stop old/running configuration", type="primary", width="stretch"):
            outcome = terminate_live_run(ROOT)
            if outcome.get("stopped"):
                st.success("Old run stopped.")
                st.rerun()
            st.error(outcome.get("reason"))
        if k2.button("Refresh", width="stretch"):
            st.rerun()

    can_run = bool(
        checks.get("ok")
        and strategy_key not in {None, "PLAN_ONLY"}
        and not lock.get("active")
    )
    if strategy_key == "PLAN_ONLY":
        st.info("Plan-only mode: live execution is intentionally disabled.")
    elif not checks.get("ok"):
        st.info("Run all agent checks first. Live execution unlocks only after every required check passes.")

    if st.button("▶ Execute interface-aware HIP flow", type="primary", width="stretch", disabled=not can_run):
        clear_stale_live_run(ROOT)
        logs: List[str] = []
        with st.status("Executing HIP APIs using the selected interface and current execution plan...", expanded=True) as live_status:
            progress = st.progress(0.0)
            message = st.empty()
            proc = subprocess.Popen(
                [sys.executable, "-u", "run_agent.py"],
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
            )
            if proc.stdout is not None:
                for line in proc.stdout:
                    text = line.rstrip()
                    logs.append(text)
                    match = re.match(r"^\[(\d+)\]", text)
                    if match:
                        seq = int(match.group(1))
                        progress.progress(min(1.0, seq / max(1, len(STEP_DEFINITIONS))))
                        message.info(f"Processing step {seq}/{len(STEP_DEFINITIONS)}")
            rc = proc.wait()
            progress.progress(1.0)
            if rc == 0:
                live_status.update(label="HIP interface flow completed", state="complete")
                st.success("Execution completed. Review the report and runtime IDs below.")
            else:
                live_status.update(label="Execution stopped on a blocking step", state="error")
                st.error("The agent stopped the flow because an API/configuration check failed. Technical evidence was preserved.")
        st.session_state["any_interface_execution_logs"] = "\n".join(logs)

    report = latest_html_report()
    if report and report.exists():
        st.download_button("Download latest execution report", report.read_bytes(), file_name=report.name, mime="text/html", width="stretch")
    if st.session_state.get("any_interface_execution_logs"):
        with st.expander("Technical execution logs"):
            st.code(st.session_state["any_interface_execution_logs"])

st.divider()
render_app_home_link(st)
safe_page_link(st, "pages/90_Advanced_Technical_Workspace.py", label="Payload / MCP / Advanced", icon="🛠️")
