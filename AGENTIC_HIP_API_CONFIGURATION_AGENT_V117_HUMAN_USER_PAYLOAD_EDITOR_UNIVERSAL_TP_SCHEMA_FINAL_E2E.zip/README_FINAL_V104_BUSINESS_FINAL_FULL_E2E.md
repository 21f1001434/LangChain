# V104 — Business Final Full End-to-End

V104 is the business-handoff release of HIP API Agent Studio.

## Locked behavior

- The approved HIP API catalog remains exactly 18 reusable API blocks.
- `deployment_group`, `deployment-group`, `deploymentGroup`, and `deploymentGroupName` resolve to `hip-automation` where those approved fields exist.
- API request structure is immutable. Customer values come from Build Configuration/customer files plus current LIVE runtime dependency IDs only.
- The approved existing U-HAUL MAC Map is reused with map ID `1670` when HIP proves the map already exists; no MAP edit/update API is introduced.
- Historical packaged Document Type, Rule, and Flow IDs are not allowed to drive LIVE dependencies.
- Source/Target Document Type IDs must be captured from current-environment HIP responses before dependent Rule execution.
- Entity-specific identifiers (`documentTypeId`, `mapId`, `ruleId`, `flowId`) take precedence over generic wrapper `id` values.
- `RULE_DOCUMENTTYPE` / `FK_RULE_DOCUMENTTYPE` / parent-key failures invalidate the rejected Source Document Type ID. The dependency-safe LIVE completion loop then resolves Source Document Type again and retries Rule with the same immutable request structure.
- Strict whole-pipeline LIVE never fires a dependent API merely to satisfy coverage when a prerequisite is unresolved. Coverage is completed after safe dependency repair.
- Individual API Testing and Flow Game block execution use the same runtime-ID integrity. Runtime IDs are persisted only per configuration workspace, bound to the current `input.json` SHA-256, and contain no credentials.

## Business handoff validation

Run `RUN_FINAL_RELEASE_VALIDATION.bat` on Windows for the complete local/non-mutating validation suite. Credentialed Dell HIP LIVE certification remains environment-dependent and records request/response evidence for each applicable API.

## Final certification hardening

- Knowledge Graph GraphML export is release-safe: optional `None`, nested containers, Paths/UUID-like values, and other non-GraphML Python values are normalized to supported GraphML scalars without changing the authoritative JSON graph.
- Business-readiness smoke covers 67 non-mutating application workflows, including Builder/customer MAP extraction, Configuration Library, Templates, Flow Game, API Testing, immutable-contract rejection, parallel queue/delete/reindexing, Pipelines, Learn, Reports, Audit, and confirmation gates for every LIVE entry point.
- The collected Python regression suite contains 395 tests, all passing in the certified build.
- Frontend TypeScript/TSX source contains 24 files and passes syntax/transpile diagnostics with zero source syntax errors.
- Actual FastAPI/Uvicorn startup was verified with `/api/health` and `/api/bootstrap` returning HTTP 200. Bootstrap exposes Phase 6, the canonical 18-API catalog, and `hip-automation`.

### Certified validator results

- Final Release: 16/16 PASS
- Standard Package: 58/58 PASS
- Adaptive Package: 60/60 PASS
- Final self-check: 45/45 required checks PASS
- Phase 1: 12/12 PASS
- Phase 2: 19/19 PASS
- Phase 3: 31/31 PASS
- Phase 4: 26/26 PASS
- Phase 5: 28/28 PASS
- Phase 6: 38/38 PASS
- Business readiness: 67/67 PASS
- Python regression: 395/395 PASS

A real credentialed Dell HIP mutation is intentionally not performed by the local certification suite. LIVE execution remains approval/confirmation gated and records real request/response evidence when run inside the authorized Dell environment.
