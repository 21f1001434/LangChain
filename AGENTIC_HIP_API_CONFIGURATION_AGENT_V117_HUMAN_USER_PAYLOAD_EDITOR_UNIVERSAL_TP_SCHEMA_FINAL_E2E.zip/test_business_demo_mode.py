from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import run_agent
from business_demo import (
    build_business_demo_summary,
    prepare_uhal_business_demo,
    write_business_demo_report,
)
from production_integration_test import fake_response

ROOT = Path(__file__).resolve().parent


def main() -> None:
    managed = [
        ROOT / "input.json",
        ROOT / "config_overrides.json",
        ROOT / "api_execution_plan.json",
        ROOT / "execution_flow.json",
        ROOT / "payload_overrides.json",
    ]
    backups = {p: p.read_bytes() if p.exists() else None for p in managed}

    try:
        prep = prepare_uhal_business_demo(ROOT)
        assert prep["customer"] == "U-HAUL"
        assert prep["interface"] == "SFTP HAFT"
        assert prep["deploymentGroup"] == "hip-automation"
        assert prep["sourceSharedProfile"] == "da-sender-sftphaft-dce-common"
        assert prep["targetSharedProfile"] == "pt-receiver-sftphaft-dce-common"
        assert prep["executionPlan"]["skipSteps"] == []
        assert prep["executionFlow"]["valid"] is True

        runner = run_agent.Runner(llm_enabled=False)
        assert runner.full_api_coverage_mode is True
        runner.get_token = lambda token_kind, scope: "offline-token"
        runner.judge.judge = lambda result: {}
        runner.judge.available = lambda: False
        called_urls: list[str] = []

        def mocked_request(method: str, url: str, token_kind: str, scope: str, extra_headers: Any, payload: Any, params: Any):
            called_urls.append(url)
            return fake_response(method, url, payload, params)

        runner._request_with_retry = mocked_request
        with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(
            runner.adaptive, "record_mapping_graph", return_value={"status": "mocked"}
        ):
            results = runner.run()

        assert len(results) == 18
        assert len(called_urls) == 18
        assert not [r for r in results if str(r.classification).startswith("SKIPPED_")]
        assert runner.final_state["coverageComplete"] is True

        (ROOT / "reports" / "connection_check_latest.json").write_text(
            json.dumps({"overall": "OK"}, indent=2), encoding="utf-8"
        )
        run_agent.write_reports(results, runner)
        summary = build_business_demo_summary(ROOT)
        assert summary["success"] is True, summary
        assert summary["coverageComplete"] is True
        assert summary["liveApiCalls"] == 18
        assert summary["existingObjectsReused"] == 0
        assert summary["skippedApiCalls"] == 0
        assert len(summary["apiResults"]) == 18
        report = write_business_demo_report(ROOT, summary)
        assert report.exists()
        report_text = report.read_text(encoding="utf-8")
        assert "Request sent" in report_text
        assert "Response received" in report_text
        assert "Live request and response evidence" in report_text

        evidence = {
            "status": "PASS",
            "buildId": run_agent.BUILD_ID,
            "customer": prep["customer"],
            "mode": "full-live-api-coverage",
            "liveHttpCalls": len(called_urls),
            "existingObjectsReused": 0,
            "skippedCalls": 0,
            "coverageComplete": runner.final_state["coverageComplete"],
            "requestResponseEvidenceInBusinessReport": True,
        }
        path = ROOT / "examples" / "BUSINESS_UHAL_DEMO_VALIDATION.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
        print(json.dumps(evidence, indent=2))
    finally:
        for path, data in backups.items():
            if data is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(data)


if __name__ == "__main__":
    main()
