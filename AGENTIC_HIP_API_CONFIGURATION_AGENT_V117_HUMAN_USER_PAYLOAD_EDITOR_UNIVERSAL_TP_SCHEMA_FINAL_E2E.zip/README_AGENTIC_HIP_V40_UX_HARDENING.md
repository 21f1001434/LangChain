# Agentic HIP API Configuration Agent V40 — UX & LIVE Parallel Hardening

V40 is the Phase 6 hardening release. React/Bun remains the primary UI and FastAPI/Python remains the backend.

## UX improvements
- Removed the forced 1180px page width and hardened responsive layouts to avoid horizontal overflow.
- Sidebar navigation scrolls on short screens and collapses to icon-only mode on narrower desktop/tablet widths.
- API Flow Game now uses the full available viewport without the previous status-bar height overflow.
- API Block Deck and Quick Templates can be shown/hidden; Fit View centers the current workflow.
- Node inspector/edge inspector are constrained to the available viewport.
- The active page and active configuration are restored after a browser refresh.
- Run LIVE automatically performs a backend graph/API preflight if a current PASS preflight is not available.

## Parallel LIVE improvements
- Select All Ready / Clear Selection controls.
- Worker/wave summary before launch.
- Live job board with QUEUED/RUNNING/PASS/BLOCKED states and elapsed time.
- FastAPI persists per-job batch state so a browser/WebSocket reconnect can recover current status.
- Each configuration still runs from an isolated validated snapshot, while each configuration's internal HIP API dependency order remains serial/dependency-aware.

## Safety preserved
- LIVE-only mutation policy.
- `hip-automation` deployment group.
- Only agent-validated configurations can enter the parallel queue.
- Exact graph/API preflight before LIVE execution.
- PASS / EXISTING / BLOCKED response classification remains unchanged.
