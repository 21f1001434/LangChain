# V115 — Dev Flow Mapping Rule Name + Version Contract Fix

## Dev-team feedback implemented

On 2026-09-01 the HIP Dev team confirmed:

1. The Account/System/Partner 404 incident was caused by a migrated backend instance whose new upstream URL was not updated. The API team corrected the route. No client payload mutation is required.
2. Flow Orchestration does **not** need Mapping Rule `id` in the request body. The Flow rule reference must use Mapping Rule **name + version**.

## V115 runtime behavior

- Every applicable canonical API is still executed in strict LIVE mode.
- Rule Create/resolve is evaluated from its own actual HIP response.
- A Rule response that is success/EXISTING may progress without any numeric `ruleId`.
- Flow `ruleRefs.ruleDetails` contains only `name` and `version`; `id` is absent.
- Canonical LIVE execution no longer performs the V110-V114 Rule-ID GET lookup or raises `LIVE_RULE_ID_UNRESOLVED` as a Flow dependency blocker.
- Account, Partner and System calls execute normally on every fresh run. A future genuine route error will still be reported truthfully, but no previous outage state is cached/reused.
- Mapping Rule POST remains immutable and still omits `documentTypeId`, `flowDefinitionId`, and `actions.params.mapId`.
- No packaged/historical object ID is injected anywhere to manufacture success.
- Same-call HIP duplicate/existing responses are reported as PASS/EXISTING evidence from the API that was actually executed.

## Flow contract excerpt

```json
{
  "ruleRefs": {
    "hasNoRule": false,
    "ruleDetails": {
      "name": "<mapping-rule-name>",
      "version": "<mapping-rule-version>"
    }
  }
}
```

`ruleDetails.id` is intentionally absent.

## Retained protections

V114 noisy Windows worker JSON parsing, V113 generic <=40-character Flow naming, V109 governed skills/context budgeting, V108 no-reuse + immutable request fingerprints, V106 Document Type name/version progression, TP CREATE audit polling, Flow deploy/history polling, and `hip-automation` defaults are retained.
