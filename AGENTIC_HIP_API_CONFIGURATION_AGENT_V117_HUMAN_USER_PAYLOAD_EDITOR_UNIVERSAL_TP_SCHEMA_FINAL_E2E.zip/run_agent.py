#!/usr/bin/env python3
"""
HIP AIA + MCP Full API Agent
============================

End-to-end HIP Portal API tester with:
- Latest TP/Flow orchestration payload updates.
- Direct API testing.
- Direct workflow chain testing.
- Orchestration API testing.
- AIA/Dell LLM judge for ownership classification.
- Deterministic fallback classification if LLM is not configured.
- Full evidence reports: JSON, CSV, HTML, Markdown, Teams message.

Run direct:
    python run_agent.py

Connection check:
    python run_agent.py --check-connections

Missing-value suggestions:
    python run_agent.py --suggest-missing

Live execution always uses the Dell AIA judge.

Check MCP tools:
    python run_agent.py --mcp-status

Expose the local MCP server:
    python uhal_mcp_server.py

Required for live execution:
    Provide credentials through the environment/Test.py used by the React/FastAPI runtime; the archived Streamlit UI remains optional.
    Keep secrets outside source code and reports.
"""

from __future__ import annotations

import argparse
import ast
import base64
import csv
import datetime as dt
import html
import hashlib
import json
import os
import re
import sys
import time
import threading
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse
from urllib.parse import urlencode

import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
import urllib3

from production_guard import (
    LiveRunLock,
    runtime_lock_path,
    atomic_write_json,
    env_bool,
    redact_sensitive,
    validate_production_readiness,
)
from api_pdf_ingestion import PdfApiKnowledgeBase
from uhal_mapper import UhalInputMapper
from hip_naming import compact_hip_flow_name, normalize_input_flow_name, validate_hip_flow_name
from transport_interface_react import validate_interface_only_input, validate_interface_only_request_override
from mcp_bridge import MCPBridge
from adaptive_engine import AdaptiveHipEngine
from api_execution_plan import (
    ApiExecutionPlan,
    canonical_step_key,
    clear_execution_plan,
)
from execution_flow import (
    ExecutionFlowConfig,
    STEP_DEFINITIONS as FLOW_STEP_DEFINITIONS,
    reset_execution_flow,
)
from api_contract_policy import immutable_override_meta
from payload_overrides import (
    PayloadOverrideStore,
    clear_all_overrides,
)
from canonical_payload_contract import (
    canonical_request_kind as canonical_payload_request_kind,
    catalog_summary as canonical_payload_catalog_summary,
    lock_request_value as canonical_lock_request_value,
)
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
from runtime_payload_values import (
    clear_runtime_payload_values,
    missing_runtime_payload_values,
    resolve_runtime_payload_placeholders,
    runtime_payload_status,
)

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

CODE_ROOT = Path(__file__).resolve().parent
ROOT = Path(os.getenv("HIP_WORKSPACE_ROOT") or CODE_ROOT).expanduser().resolve()
INPUT_JSON = ROOT / "input.json"
INPUT_FILES = ROOT / "input_files"
PAYLOADS = ROOT / "payloads"
REPORTS = ROOT / "reports"
OVERRIDES = ROOT / "config_overrides.json"
BUILD_ID = "2026-09-01-agentic-hip-v117-strict-live-no-reuse-human-user-only-payload-value-editor-universal-tp-schema-interface-details-only"
DEFAULT_HIP_TOKEN_USER_AGENT = "PostmanRuntime/7.49.0"

PAYLOADS.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)

VERIFY_SSL = env_bool("HIP_VERIFY_SSL", True)
CA_BUNDLE = (
    os.getenv("HIP_CA_BUNDLE")
    or os.getenv("REQUESTS_CA_BUNDLE")
    or os.getenv("SSL_CERT_FILE")
    or ""
).strip()
REQUEST_VERIFY: Any = CA_BUNDLE if CA_BUNDLE else VERIFY_SSL
TIMEOUT_SECONDS = int(os.getenv("HTTP_TIMEOUT_SECONDS", "90"))

if not VERIFY_SSL:
    urllib3.disable_warnings(
        urllib3.exceptions.InsecureRequestWarning
    )

DEFAULT_SCOPES = {
    "document_type": "1772714374302_slg_dpl.write",
    "rule": "1772723189025_slg_dpl.write",
    "map": "1772722736492_slg_dpl.write",
    "partner": "hip-authz-service.access",
    "system": "hip-systems-authz-service.hip-systems-authz-service.access",
    "account": "hip-authz-service.access",
    "transport_profile": "1773848887457_slg_dpl.write",
    "flow": "1773849321851_slg_dpl.write",
}

HIP_CONFIG_SERVICE_BASE = (
    os.getenv("HIP_CONFIG_SERVICE_BASE_URL")
    or "https://apigtwtst.us.dell.com/hip-config-service"
).rstrip("/")

# Dev-team supplied OAuth endpoint for the new HIP API subscription.
# This endpoint is intentionally independent from the HIP API base URL.
CANONICAL_HIP_TOKEN_URL = (
    "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token"
)


def normalize_hip_token_url(value: Any) -> str:
    """Normalize a configured OAuth URL without silently replacing it."""
    raw = str(value or "").strip().strip('"').strip("'")
    if not raw:
        return CANONICAL_HIP_TOKEN_URL

    parsed = urlparse(raw)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise ValueError(
            "HIP token URL must be a valid HTTPS URL. "
            f"Received: {raw!r}"
        )
    return raw.rstrip("/")


def normalize_access_token(value: Any) -> str:
    """Normalize a manually supplied Bearer token without exposing it."""
    token = str(value or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    return token


def manual_token_is_expired(token: str) -> bool:
    """Best-effort JWT expiry check; opaque tokens are accepted."""
    parts = token.split(".")
    if len(parts) < 2:
        return False
    try:
        padded = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(
            base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
        )
        expires = payload.get("exp")
        return bool(expires and float(expires) <= time.time() + 30)
    except Exception:
        return False


def parse_token_response(response: requests.Response) -> Dict[str, Any]:
    """Parse normal JSON, JSON embedded in text, or a raw bearer token."""
    text_value = (response.text or "").strip()
    try:
        parsed = response.json()
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    # Some gateways prepend/append text. Decode the first JSON object only.
    first_brace = text_value.find("{")
    if first_brace >= 0:
        try:
            parsed, _ = json.JSONDecoder().raw_decode(text_value[first_brace:])
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    # Accept a direct JWT/access token body when returned as text/plain.
    if text_value and " " not in text_value and text_value.count(".") >= 2:
        return {"access_token": text_value}

    return {}


def extract_access_token(body: Dict[str, Any]) -> str:
    """Support OAuth and Dell proxy response aliases."""
    candidates = [
        body.get("access_token"),
        body.get("accessToken"),
        body.get("token"),
        body.get("bearerToken"),
    ]
    nested = body.get("data")
    if isinstance(nested, dict):
        candidates.extend([
            nested.get("access_token"),
            nested.get("accessToken"),
            nested.get("token"),
        ])
    return next((str(x) for x in candidates if x), "")


def hip_config_service_urls(base_url: str) -> Dict[str, str]:
    base = str(base_url).rstrip("/")
    return {
        "document_type": f"{base}/api/document-type",
        "rule": f"{base}/api/rule",
        # V110 read-only current-environment Rule identity resolution. The
        # POST /api/rule remains the canonical create/resolve call; these GETs
        # are auxiliary evidence only when HIP returns an existing Rule without
        # its ruleId.
        "rule_summary": f"{base}/api/rule/summary",
        "rule_details": f"{base}/api/rule/details",
        "map": f"{base}/api/mac-map",
        "tp_validate": (
            f"{base}/api/transport-profiles/"
            "validate-unique-interface-detail"
        ),
        # Kept for compatibility. Direct TP create remains disabled by the
        # orchestration-only execution policy.
        "tp_create": f"{base}/api/transport-profiles",
        "tp_audits": f"{base}/api/transport-profiles/audits",
        "flow_validate": f"{base}/api/flows/validate-name",
        # Kept for compatibility. Direct Flow APIs remain disabled.
        "flow_definition": f"{base}/api/flows/definition",
        "flow_deploy": f"{base}/api/flows/deployment",
        "flow_deploy_history": f"{base}/api/flows/deployment/history",
        "orch_tp_create": (
            f"{base}/api/transport-profiles/orchestration/create"
        ),
        "orch_flow_create": f"{base}/api/flows/orchestration/create",
        "orch_flow_deploy": f"{base}/api/flows/orchestration/deploy",
    }


DEFAULT_URLS = {
    **hip_config_service_urls(HIP_CONFIG_SERVICE_BASE),
    # Account and Partner stay on hip-partners, per the Dev-team message.
    "partner": "https://apigtwtst.us.dell.com/hip-partners/api/authz/partner",
    "account": "https://apigtwtst.us.dell.com/hip-partners/api/authz/account",
    # System stays on hip-systems, per the Dev-team message.
    "system": "https://apigtwtst.us.dell.com/hip-systems/api/domain-systems/domains/cb780edc-84b6-44ff-8aa9-27a8b810ed36/system",
    "workflow_workorder_get_base": "https://workflow-api-oauth.r1.pcf.dell.com/api/workorder",
    "workflow_workorder_create": "https://workflow-api-oauth.r1.pcf.dell.com/api/workorder/create",
    "workflow_workorder_close": "https://workflow-api-oauth.r1.pcf.dell.com/api/workorder/close",
}

@dataclass
class Result:
    sequence: int
    group: str
    api: str
    attempt: str
    method: str
    url: str
    token_kind: str
    scope: str
    status_code: Optional[int]
    classification: str
    business_success: bool
    elapsed_ms: Optional[int]
    payload_file: str
    request_preview: str
    response_preview: str
    extracted: Dict[str, Any]
    deterministic_owner: str
    llm_owner: str
    final_owner: str
    issue: str
    action_required: str
    error: str = ""

TOKEN_CACHE: Dict[Tuple[Any, ...], str] = {}
TOKEN_CACHE_LOCK = threading.RLock()
# Token diagnostics are a shared "latest" evidence file inside one LIVE worker.
# Serialize those writes so parallel dependency-ready HIP calls cannot replace
# the same Windows file at the same instant.
TOKEN_DIAGNOSTIC_LOCK = threading.RLock()
# V94/V95: parallel dependency-ready API threads must not stampede the OAuth
# gateway.  A per-credential in-process lock provides single-flight behavior; a
# secret-free cross-process lock serializes requests from separate AutoGen
# worker processes that share the same token endpoint.
TOKEN_REQUEST_LOCKS: Dict[Tuple[Any, ...], threading.RLock] = {}
TOKEN_REQUEST_LOCKS_GUARD = threading.RLock()
OAUTH_TRANSIENT_STATUSES = {408, 425, 429, 500, 502, 503, 504}


def _token_request_lock(cache_key: Tuple[Any, ...]) -> threading.RLock:
    with TOKEN_REQUEST_LOCKS_GUARD:
        lock = TOKEN_REQUEST_LOCKS.get(cache_key)
        if lock is None:
            lock = threading.RLock()
            TOKEN_REQUEST_LOCKS[cache_key] = lock
        return lock


class _OAuthEndpointLock:
    """Secret-free cross-process mutex keyed only by OAuth endpoint URL.

    Parallel AutoGen workers are separate Python processes, so an in-memory
    lock alone cannot prevent token-request bursts.  This lock stores only PID
    and timestamp in the OS temp directory; no client ID, secret or token is
    persisted.  Stale lock files are self-healed.
    """

    def __init__(self, token_url: str):
        digest = __import__('hashlib').sha256(str(token_url).encode('utf-8')).hexdigest()[:24]
        self.root = Path(tempfile.gettempdir()) / 'agentic_hip_oauth_locks'
        self.path = self.root / f'{digest}.lock'
        self.fd: Optional[int] = None
        self.timeout = max(10.0, float(os.getenv('HIP_OAUTH_LOCK_TIMEOUT_SECONDS', '120') or 120))

    def __enter__(self):
        self.root.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                self.fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                payload = json.dumps({'pid': os.getpid(), 'createdEpoch': time.time()}).encode('utf-8')
                os.write(self.fd, payload)
                os.close(self.fd)
                self.fd = None
                return self
            except FileExistsError:
                try:
                    age = time.time() - self.path.stat().st_mtime
                    if age > max(180.0, self.timeout * 2.0):
                        self.path.unlink(missing_ok=True)
                        continue
                except Exception:
                    pass
                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        f'OAuth endpoint coordination timed out after {self.timeout:.0f}s.'
                    )
                time.sleep(0.10)

    def __exit__(self, exc_type, exc, tb):
        try:
            self.path.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def _oauth_retry_delay(attempt_no: int, response: Optional[requests.Response] = None) -> float:
    if response is not None:
        retry_after = str(response.headers.get('Retry-After') or '').strip()
        if retry_after:
            try:
                return max(0.0, min(float(retry_after), 15.0))
            except Exception:
                pass
    base = max(0.1, float(os.getenv('HIP_OAUTH_RETRY_BASE_SECONDS', '0.6') or 0.6))
    return min(base * (2 ** max(0, attempt_no - 1)), 8.0)


def load_json(path: Path, default: Any) -> Any:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return default

def find_test_py() -> Path:
    for p in [ROOT / "Test.py", CODE_ROOT / "Test.py", CODE_ROOT.parent / "Test.py", ROOT.parent / "Test.py", Path.cwd() / "Test.py", Path.cwd().parent / "Test.py"]:
        if p.exists():
            return p
    raise FileNotFoundError("Test.py not found. Put your existing Test.py in this folder or parent folder.")

def load_test_py_config(path: Path) -> Dict[str, Any]:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
    out: Dict[str, Any] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except Exception:
                value = None
            for t in node.targets:
                if isinstance(t, ast.Name):
                    out[t.id] = value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            try:
                out[node.target.id] = ast.literal_eval(node.value)
            except Exception:
                out[node.target.id] = None
    return out

def b64_file(path: Path) -> str:
    if not path.exists():
        return ""
    return base64.b64encode(path.read_bytes()).decode("ascii")

def text_file(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="ignore")

def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def _write_token_diagnostic_best_effort(token_kind: str, diagnostic: Dict[str, Any]) -> Optional[Path]:
    """Persist redacted OAuth diagnostics without ever changing OAuth outcome.

    LIVE API execution must be decided by the token/API response, not by an
    auxiliary evidence file.  On managed Windows hosts the shared ``*_latest``
    file can be temporarily locked by Defender/indexing or another parallel HIP
    call.  We serialize + retry the normal report write, then fall back to a
    unique LocalAppData/temp diagnostic.  If both destinations are unavailable,
    execution continues and only a redacted warning is emitted.
    """
    kind = re.sub(r"[^a-z0-9]+", "_", str(token_kind or "hip").lower()).strip("_") or "hip"
    safe_payload = redact_sensitive(diagnostic)
    latest = REPORTS / f"{kind}_token_diagnostics_latest.json"
    latest_error: Optional[Exception] = None

    with TOKEN_DIAGNOSTIC_LOCK:
        try:
            atomic_write_json(latest, safe_payload, retries=12)
            return latest
        except Exception as exc:
            latest_error = exc

        local_base = str(os.getenv("LOCALAPPDATA") or "").strip()
        fallback_root = (
            Path(local_base) / "HIP API Agent Studio" / "diagnostics"
            if local_base
            else Path(tempfile.gettempdir()) / "hip_api_agent_studio" / "diagnostics"
        )
        fallback = fallback_root / (
            f"{kind}_token_diagnostics_{dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_"
            f"{os.getpid()}_{threading.get_ident()}.json"
        )
        try:
            atomic_write_json(fallback, safe_payload, retries=4)
            return fallback
        except Exception as fallback_error:
            # Never propagate evidence persistence failure into token/API logic.
            warning = {
                "tokenKind": str(token_kind or "HIP"),
                "latestWriteError": clean(str(latest_error))[:500] if latest_error else "",
                "fallbackWriteError": clean(str(fallback_error))[:500],
            }
            print("OAuth diagnostic persistence warning: " + json.dumps(redact_sensitive(warning), default=str), file=sys.stderr)
            return None


def clean(s: Any) -> str:
    if s is None:
        return ""
    return re.sub(r"\s+", " ", str(s).replace("\r", " ").replace("\n", " ")).strip()

def preview(obj: Any, limit: int = 1000000) -> str:
    if obj is None:
        return ""
    safe_obj = redact_sensitive(obj)
    if isinstance(safe_obj, str):
        return safe_obj[:limit]
    return json.dumps(safe_obj, indent=2, default=str)[:limit]

def save_payload(seq: int, group: str, api: str, attempt: str, payload: Any) -> str:
    if payload is None:
        return ""
    safe = re.sub(r"[^A-Za-z0-9_]+", "_", f"{seq:02d}_{group}_{api}_{attempt}")[:160]
    path = PAYLOADS / f"{safe}.json"
    # Evidence files must never persist credentials/client secrets.
    path.write_text(
        json.dumps(redact_sensitive(payload), indent=2, default=str),
        encoding="utf-8",
    )
    return str(path.relative_to(ROOT))


def save_response_evidence(
    seq: int, group: str, api: str, attempt: str, *,
    method: str, url: str, status_code: Optional[int], elapsed_ms: Optional[int],
    classification: str, business_success: bool, response: Any = None, error: str = "",
) -> str:
    """Persist one redacted LIVE HTTP result as standalone audit evidence.

    V96 uses this in addition to the aggregate HTML/JSON report so every API
    attempt has a direct request file and response/result file. Evidence
    persistence is best-effort and never changes the API verdict.
    """
    try:
        evidence_dir = REPORTS / "live_api_evidence"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9_]+", "_", f"{seq:02d}_{group}_{api}_{attempt}")[:160]
        path = evidence_dir / f"{safe}_response.json"
        atomic_write_json(path, redact_sensitive({
            "sequence": seq,
            "group": group,
            "api": api,
            "attempt": attempt,
            "method": str(method or "").upper(),
            "url": url,
            "httpStatus": status_code,
            "elapsedMs": elapsed_ms,
            "classification": classification,
            "businessSuccess": bool(business_success),
            "response": response,
            "error": error,
            "capturedAt": dt.datetime.now(dt.timezone.utc).isoformat(),
        }), retries=4)
        return str(path.relative_to(ROOT))
    except Exception as exc:
        print(f"LIVE response evidence persistence warning: {type(exc).__name__}: {exc}", file=sys.stderr)
        return ""

def as_nonempty(value: Any, fallback: Any = None) -> Any:
    if value is None:
        return fallback
    if isinstance(value, str) and value.strip() == "":
        return fallback
    return value

def get_path(d: Dict[str, Any], *keys, default=None):
    cur = d
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k)
    return cur if cur is not None else default

class AIAJudge:
    """
    Dell AIA / LLM judge.

    This version matches the working reference implementation style:
    - Supports AIA_* names
    - Supports DELL_AIA_* names
    - Supports your .env names: BASE_URL, MODEL_NAME, CLIENT_ID, CLIENT_SECRET
    - Supports static token if present
    - Supports explicit token URL if present
    - IMPORTANT: If token URL is missing but CLIENT_ID + CLIENT_SECRET are present,
      it tries the internal Dell `aia_auth` package:
          from aia_auth import auth
          auth.client_credentials(client_id, client_secret)

    This is why the working reference code can work even without AIA_TOKEN_URL.
    """

    def __init__(self, config: Dict[str, Any], enabled: bool = True):
        self.enabled = enabled and bool(config.get("llm_judge_enabled", True))
        aia_cfg = config.get("aia", {})

        self.base_url = (
            os.getenv("AIA_BASE_URL")
            or os.getenv("DELL_AIA_BASE_URL")
            or os.getenv("BASE_URL")
            or os.getenv(aia_cfg.get("base_url_env", "AIA_BASE_URL"), "")
            or "https://aia.gateway.dell.com/genai/dev/v1"
        ).rstrip("/")

        self.model = (
            os.getenv("AIA_MODEL")
            or os.getenv("DELL_AIA_MODEL")
            or os.getenv("AIA_TEXT_MODEL")
            or os.getenv("MODEL_NAME")
            or (os.getenv("TEXT_MODELS", "").split(",")[0].strip() if os.getenv("TEXT_MODELS") else "")
            or os.getenv(aia_cfg.get("model_env", "AIA_MODEL"), "")
            or aia_cfg.get("default_model", "gpt-oss-120b")
            or "gpt-oss-120b"
        )

        self.temperature = float(
            os.getenv("AIA_TEMPERATURE")
            or os.getenv("DELL_AIA_TEMPERATURE")
            or os.getenv("TEMPERATURE")
            or "0.2"
        )

        self.chat_path = (
            os.getenv("AIA_CHAT_PATH")
            or os.getenv("CHAT_PATH")
            or aia_cfg.get("openai_compatible_chat_path", "/chat/completions")
            or "/chat/completions"
        )
        if not self.chat_path.startswith("/"):
            self.chat_path = "/" + self.chat_path

        # Static tokens / API-key style auth
        self.static_token = (
            os.getenv("AIA_STATIC_BEARER_TOKEN")
            or os.getenv("DELL_AIA_TOKEN")
            or os.getenv("AIA_BEARER_TOKEN")
            or os.getenv("DELL_AIA_BEARER_TOKEN")
            or os.getenv("BEARER_TOKEN")
            or os.getenv("AIA_API_KEY")
            or os.getenv("OPENAI_API_KEY")
            or os.getenv(aia_cfg.get("api_key_env", "AIA_API_KEY"), "")
            or ""
        )

        # Client credentials. These exact CLIENT_ID/CLIENT_SECRET names are supported.
        self.client_id = (
            os.getenv("AIA_CLIENT_ID")
            or os.getenv("DELL_AIA_CLIENT_ID")
            or os.getenv("CLIENT_ID")
            or ""
        )
        self.client_secret = (
            os.getenv("AIA_CLIENT_SECRET")
            or os.getenv("DELL_AIA_CLIENT_SECRET")
            or os.getenv("CLIENT_SECRET")
            or ""
        )

        self.token_url = (
            os.getenv("AIA_TOKEN_URL")
            or os.getenv("DELL_AIA_TOKEN_URL")
            or os.getenv("DELL_TOKEN_URL")
            or os.getenv("DELL_AIA_TOKEN_URL")
            or os.getenv("OAUTH_TOKEN_URL")
            or ""
        )
        self.scope = os.getenv("AIA_SCOPE") or os.getenv("DELL_AIA_SCOPE") or ""

        self.use_dell_sso = str(os.getenv("USE_DELL_SSO", "")).lower() in ("true", "1", "yes", "y")
        self.auth_mode = (os.getenv("DELL_AUTH_MODE") or os.getenv("AIA_AUTH_MODE") or "auto").strip().lower()

        self.timeout = int(os.getenv("AIA_TIMEOUT_SECONDS", "90"))

        try:
            self.extra_headers = json.loads(os.getenv("AIA_EXTRA_HEADERS_JSON", "{}"))
        except Exception:
            self.extra_headers = {}

        self._token_cache: tuple[str, float] | None = None
        self._last_auth_error = ""

    def available(self) -> bool:
        if not self.enabled or not self.base_url:
            return False
        if self.static_token:
            return True
        # Explicit OAuth token URL path.
        if self.client_id and self.client_secret and self.token_url:
            return True
        # Working reference path: internal Dell aia_auth package.
        if self.client_id and self.client_secret:
            return True
        return False

    def auth_status(self) -> str:
        if not self.enabled:
            return "LLM judge disabled."
        if not self.base_url:
            return "LLM judge unavailable: BASE_URL/AIA_BASE_URL missing."
        if self.static_token:
            return "LLM judge auth: static bearer token/API key from env."
        if self.client_id and self.client_secret and self.token_url:
            return "LLM judge auth: client_credentials using explicit AIA_TOKEN_URL/DELL_AIA_TOKEN_URL."
        if self.client_id and self.client_secret:
            return "LLM judge auth: client_credentials using internal Dell aia_auth package fallback."
        return "LLM judge unavailable: no token, no token URL, and no CLIENT_ID/CLIENT_SECRET."

    def _token_from_explicit_oauth_url(self) -> str:
        data = {"grant_type": "client_credentials"}
        if self.scope:
            data["scope"] = self.scope

        headers = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}

        # Match reference style: basic auth with grant_type body.
        resp = requests.post(
            self.token_url,
            headers=headers,
            data=data,
            auth=(self.client_id, self.client_secret),
            timeout=self.timeout,
            verify=REQUEST_VERIFY,
        )

        # Fallback for gateways that require id/secret in body.
        if resp.status_code in (400, 401, 403):
            body_data = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
            if self.scope:
                body_data["scope"] = self.scope
            resp = requests.post(
                self.token_url,
                headers=headers,
                data=body_data,
                timeout=self.timeout,
                verify=REQUEST_VERIFY,
            )

        resp.raise_for_status()
        payload = resp.json()
        token = payload.get("access_token") or payload.get("token") or payload.get("id_token")
        if not token:
            raise RuntimeError(f"Token endpoint response did not include access_token/token/id_token: {json.dumps(payload)[:500]}")
        expires = float(payload.get("expires_in", 1800))
        self._token_cache = (token, time.time() + expires)
        return token

    def _token_from_internal_aia_auth(self) -> str:
        """
        This matches the reference browser_agent/dell_aia.py behavior:
            from aia_auth import auth
            token_resp = auth.client_credentials(client_id, client_secret)
        """
        try:
            from aia_auth import auth  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "CLIENT_ID/CLIENT_SECRET are present but internal Dell `aia_auth` package is not importable. "
                "Install/configure `aia_auth`, or set AIA_TOKEN_URL, or set AIA_STATIC_BEARER_TOKEN/AIA_BEARER_TOKEN. "
                f"Import error: {exc}"
            ) from exc

        try:
            token_resp = auth.client_credentials(self.client_id, self.client_secret)
            token = (
                getattr(token_resp, "token", "")
                or getattr(token_resp, "access_token", "")
                or (token_resp.get("token") if isinstance(token_resp, dict) else "")
                or (token_resp.get("access_token") if isinstance(token_resp, dict) else "")
            )
            if not token:
                raise RuntimeError(f"aia_auth returned no token/access_token. Response type={type(token_resp)}")
            self._token_cache = (token, time.time() + 1800)
            return token
        except Exception as exc:
            raise RuntimeError(
                "Dell internal `aia_auth.client_credentials` failed. "
                "Check CLIENT_ID/CLIENT_SECRET and Dell AIA environment setup. "
                f"Original error: {exc}"
            ) from exc

    def _get_token(self) -> str:
        if self.static_token:
            return self.static_token.strip().removeprefix("Bearer ").strip()

        if self._token_cache and self._token_cache[1] > time.time() + 60:
            return self._token_cache[0]

        if self.token_url:
            return self._token_from_explicit_oauth_url()

        if self.client_id and self.client_secret:
            return self._token_from_internal_aia_auth()

        raise RuntimeError(
            "No Dell AIA auth method available. Set AIA_STATIC_BEARER_TOKEN/DELL_AIA_TOKEN, "
            "or AIA_TOKEN_URL + CLIENT_ID/CLIENT_SECRET, or install/configure internal aia_auth with CLIENT_ID/CLIENT_SECRET."
        )

    def judge(self, item: Dict[str, Any]) -> Dict[str, str]:
        if not self.available():
            return {"owner": "", "issue": self.auth_status(), "action": ""}

        system = (
            "You are a Dell HIP Portal API test judge. Classify the API result safely. "
            "Allowed owner values: WORKING, EXPECTED_EXISTING_OBJECT, EXPECTED_DUPLICATE_FROM_RETEST, "
            "MISSING_REQUIRED_ID_OR_CONFIG, EXPECTED_DEPENDENCY_FAILURE, API_DOC_OR_BACKEND_MISMATCH, "
            "API_BACKEND_OR_ERROR_HANDLING, API_CONTRACT_CLARIFICATION, AUTH_OR_ENTITLEMENT, USER_PAYLOAD_BUG, NEEDS_REVIEW. "
            "Return JSON only with keys owner, issue, action. Be reputation-safe: do not blame the user if the failure needs internal IDs, "
            "API doc mismatch, existing object reuse, or backend 500."
        )
        user = json.dumps(item, indent=2, default=str)[:7000]
        url = self.base_url + self.chat_path

        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self.extra_headers)

        payload = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": self.temperature,
            "response_format": {"type": "json_object"},
        }

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=self.timeout, verify=REQUEST_VERIFY)
            resp.raise_for_status()
            data = resp.json()
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "{}")
            parsed = json.loads(content)
            return {
                "owner": clean(parsed.get("owner")),
                "issue": clean(parsed.get("issue")),
                "action": clean(parsed.get("action")),
            }
        except Exception as exc:
            self._last_auth_error = str(exc)
            return {
                "owner": "",
                "issue": f"LLM judge unavailable or non-compatible response: {exc}. Deterministic judge used.",
                "action": "",
            }

    def complete_json(
        self,
        system: str,
        user: str,
        temperature: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Run a Dell AIA JSON-only completion."""
        if not self.available():
            raise RuntimeError(self.auth_status())

        url = self.base_url + self.chat_path
        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self.extra_headers)
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": (
                self.temperature
                if temperature is None
                else float(temperature)
            ),
            "response_format": {"type": "json_object"},
        }
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.timeout,
            verify=REQUEST_VERIFY,
        )
        response.raise_for_status()
        body = response.json()
        content = (
            body.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "{}")
        )
        try:
            parsed = json.loads(content)
        except Exception as exc:
            raise RuntimeError(
                "Dell AIA did not return valid JSON: "
                f"{exc}; response={clean(content)[:700]}"
            ) from exc
        if not isinstance(parsed, dict):
            raise RuntimeError(
                "Dell AIA JSON response must be an object."
            )
        return parsed

    def vision_candidates(self) -> List[str]:
        """Return reviewed Dell AIA multimodal deployments, never the text model."""
        candidates: List[str] = []
        for env_name in (
            "HIP_VISION_MODEL", "AIA_VISION_MODEL", "VISION_MODEL_NAME",
            "VISION_MODEL", "GEMMA_MODEL_NAME", "GEMMA_MODEL",
            "VISION_AGENT_MODEL", "FAST_VISION_MODEL", "DELL_AIA_VISION_MODEL",
        ):
            raw = os.getenv(env_name, "")
            for item in raw.split(","):
                item = item.strip()
                if item and item not in candidates:
                    candidates.append(item)
        for item in ("gemma-3-27b-it", "pixtral-12b-2409"):
            if item not in candidates:
                candidates.append(item)
        text_names = {str(self.model or "").strip().lower(), "gpt-oss-120b"}
        return [x for x in candidates if x.strip().lower() not in text_names]

    def complete_multimodal(
        self,
        prompt: str,
        image_bytes: bytes,
        mime_type: str = "image/png",
        model: Optional[str] = None,
        max_completion_tokens: int = 900,
    ) -> Dict[str, Any]:
        """Analyze an image with Dell AIA OpenAI-compatible multimodal chat."""
        if not self.available():
            raise RuntimeError(self.auth_status())
        if not image_bytes:
            raise ValueError("Image data is empty.")
        data_url = "data:" + (mime_type or "image/png") + ";base64," + base64.b64encode(image_bytes).decode("ascii")
        candidates = [model] if model else self.vision_candidates()
        candidates = [x for x in candidates if x and x.strip().lower() not in {"gpt-oss-120b", str(self.model or "").strip().lower()}]
        if not candidates:
            raise RuntimeError("No Dell AIA multimodal model is configured.")
        url = self.base_url + self.chat_path
        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self.extra_headers)
        errors: List[str] = []
        for candidate in candidates:
            payload = {
                "model": candidate,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }],
                "temperature": 0,
                "max_completion_tokens": int(max_completion_tokens),
            }
            try:
                response = requests.post(
                    url, headers=headers, json=payload, timeout=self.timeout, verify=REQUEST_VERIFY
                )
                response.raise_for_status()
                body = response.json()
                content = body.get("choices", [{}])[0].get("message", {}).get("content", "")
                if isinstance(content, list):
                    content = " ".join(str(x.get("text", "") if isinstance(x, dict) else x) for x in content)
                content = str(content or "").strip()
                if content:
                    return {"status": "ok", "model": candidate, "content": content}
                errors.append(f"{candidate}: empty response")
            except Exception as exc:
                errors.append(f"{candidate}: {clean(exc)[:350]}")
        raise RuntimeError("Dell AIA vision analysis failed. " + " | ".join(errors))

    def analyze_frontend_image(
        self, image_bytes: bytes, filename: str = "image", mime_type: str = "image/png", question: str = ""
    ) -> Dict[str, Any]:
        """Interpret a HIP/frontend screenshot and relate visible fields to API/backend evidence."""
        prompt = (
            "You are Learn, a Dell HIP API multimodal analyst. Analyze this frontend screenshot. "
            "Identify visible fields, values, labels, errors and transport clues (SFTP/FTP/HTTPS/AS2). "
            "Explain which backend API/payload fields they likely correspond to, but clearly label any inference. "
            "Do not invent endpoint names, IDs, payload values, credentials or backend behavior not supported by the image. "
            "If an error is visible, explain what network/API evidence should be checked next. "
            f"Filename: {filename}. User question: {question or 'Explain the frontend/backend relationship for this screen.'}"
        )
        result = self.complete_multimodal(prompt, image_bytes, mime_type=mime_type)
        return {
            "status": result.get("status"),
            "model": result.get("model"),
            "analysis": result.get("content", ""),
            "filename": filename,
        }

    def verify_connection(self) -> Dict[str, Any]:
        """Perform a real Dell AIA model call and fail if it is unavailable."""
        if not self.available():
            raise RuntimeError(self.auth_status())

        url = self.base_url + self.chat_path
        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self.extra_headers)
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "Return JSON only.",
                },
                {
                    "role": "user",
                    "content": (
                        'Return exactly {"status":"ok","model":"'
                        + self.model
                        + '"}.'
                    ),
                },
            ],
            "temperature": 0,
            "response_format": {"type": "json_object"},
        }
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.timeout,
            verify=REQUEST_VERIFY,
        )
        response.raise_for_status()
        body = response.json()
        content = (
            body.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
        )
        return {
            "status": "ok",
            "model": self.model,
            "baseUrl": self.base_url,
            "response": clean(content)[:500],
        }

    def suggest_missing_values(
        self,
        missing_fields: List[Dict[str, Any]],
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Ask Dell AIA for missing-value suggestions.
        Secret values are intentionally excluded and must never be inferred.
        """
        safe_fields = [
            item for item in missing_fields
            if not bool(item.get("secret"))
        ]
        system = (
            "You are a Dell HIP configuration assistant. Suggest safe values "
            "for missing non-secret U-HAUL DEV configuration fields. Never "
            "invent credentials, client secrets, access tokens, internal IDs, "
            "or entitlements. For those, say REQUEST_FROM_OWNER. Return JSON "
            "with keys suggestions and warnings."
        )
        user = json.dumps({
            "missingFields": safe_fields,
            "context": context,
        }, indent=2, default=str)[:10000]

        url = self.base_url + self.chat_path
        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self.extra_headers)
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": self.temperature,
            "response_format": {"type": "json_object"},
        }
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.timeout,
            verify=REQUEST_VERIFY,
        )
        response.raise_for_status()
        body = response.json()
        content = (
            body.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "{}")
        )
        parsed = json.loads(content)
        return {
            "model": self.model,
            "suggestions": parsed.get("suggestions") or [],
            "warnings": parsed.get("warnings") or [],
        }

class Runner:
    # Class-level OAuth fallback keeps token acquisition safe even for
    # lightweight Runner instances created by connection diagnostics/tests
    # without calling the full constructor. Instance configuration still
    # overrides this value during normal application startup.
    hip_token_user_agent = DEFAULT_HIP_TOKEN_USER_AGENT

    def _resolved_hip_token_user_agent(self) -> str:
        """Return a valid HIP OAuth User-Agent and repair partial instances.

        Some connection diagnostics construct Runner via ``__new__`` and set
        only the OAuth URL/client fields. Token acquisition must remain usable
        in that path instead of raising AttributeError.
        """
        value = str(getattr(self, "hip_token_user_agent", "") or "").strip()
        if not value:
            cfg = getattr(self, "cfg", {}) or {}
            value = str(
                os.getenv("HIP_TOKEN_USER_AGENT")
                or (cfg.get("HIP_TOKEN_USER_AGENT") if isinstance(cfg, dict) else "")
                or DEFAULT_HIP_TOKEN_USER_AGENT
            ).strip()
            self.hip_token_user_agent = value
        return value

    def _ensure_token_runtime_state(self) -> None:
        """Initialize token bookkeeping for partial/lightweight runners."""
        if not isinstance(getattr(self, "token_sources", None), dict):
            self.token_sources = {}

    def __init__(self, llm_enabled: bool = True):
        # Production runner is live-only. Request inspection uses preview_step_request(),
        # which builds requests without executing them.
        try:
            self.test_py = find_test_py()
            self.cfg = load_test_py_config(self.test_py)
        except FileNotFoundError:
            # The final package supports a local .env without requiring Test.py.
            self.test_py = ROOT / "Test.py"
            self.cfg = {}
        raw_input = load_json(INPUT_JSON, {})
        # V113: reconcile all persisted Flow-name representations before the
        # mapper, preflight, or any LIVE request can observe them.  This closes
        # the upgrade case where nested business_flow_name was already valid but
        # top-level profile_name still held the old >40-character LEGRAND value.
        self.input = normalize_input_flow_name(raw_input) if isinstance(raw_input, dict) else raw_input
        if isinstance(self.input, dict) and self.input != raw_input:
            atomic_write_json(INPUT_JSON, self.input)
            atomic_write_json(REPORTS / "flow_name_normalization_latest.json", {
                "stage": "runner-init-before-request-materialization",
                "inputChanged": True,
                "flowNameNormalization": self.input.get("_flow_name_normalization") or {},
                "apiRequestAlreadyMaterialized": False,
            })
        self.ov = load_json(OVERRIDES, {})
        self.env = self.ov.get("hipEnvironment") or "DEV"
        self.judge = AIAJudge(self.ov, enabled=llm_enabled)

        self.requester = os.getenv("HIP_REQUESTED_BY") or os.getenv("REQUESTED_BY") or self.ov.get("requestedBy") or self.cfg.get("REQUESTER_ID") or self.cfg.get("USER_EMAIL") or "adheesh.srivastava@dell.com"
        self.user_id = as_nonempty(get_path(self.ov, "user", "userId"), self.cfg.get("USER_ID") or 16679)
        self.user = self.make_user()

        self.hip_token_url = normalize_hip_token_url(
            os.getenv("HIP_TOKEN_URL") or self.cfg.get("HIP_TOKEN_URL")
        )
        self.hip_client_id = str(
            os.getenv("HIP_CLIENT_ID") or self.cfg.get("HIP_CLIENT_ID") or ""
        ).strip()
        self.hip_client_secret = str(
            os.getenv("HIP_CLIENT_SECRET") or self.cfg.get("HIP_CLIENT_SECRET") or ""
        ).strip()
        # IMPORTANT: HIP token scope is ONLY the explicitly configured HIP_SCOPE.
        # We never fall back to per-API legacy scopes because the working
        # Postman Client Credentials request sends no scope.
        self.hip_scope = str(
            os.getenv("HIP_SCOPE")
            if os.getenv("HIP_SCOPE") is not None
            else (self.cfg.get("HIP_SCOPE") or "")
        ).strip()
        self.hip_token_user_agent = (
            os.getenv("HIP_TOKEN_USER_AGENT")
            or self.cfg.get("HIP_TOKEN_USER_AGENT")
            or DEFAULT_HIP_TOKEN_USER_AGENT
        ).strip()
        self.hip_token_auth_mode = "oauth2-client-credentials-basic-auth"
        self.token_sources: Dict[str, str] = {}
        # Lazy pooled HTTP session for the 18 HIP API calls. Reusing TLS/TCP
        # connections lowers backend latency without changing the Streamlit UI.
        self._http_session: Optional[requests.Session] = None
        self._http_session_local = threading.local()
        self._llm_lock = threading.RLock()
        self._mcp_lock = threading.RLock()
        self._validation_cache_lock = threading.RLock()
        self._runtime_state_lock = threading.RLock()
        self._adaptive_result_lock = threading.RLock()
        self._validation_cache_path = ROOT / "request_validation_cache.json"
        self._validation_cache = self._load_request_validation_cache()

        # Dedicated OAuth credential profiles for services that currently use
        # separate subscriptions/credentials. These are required only when the
        # corresponding API is actually executed; a user-approved skip does not
        # require that service credential. Token URLs default to the HIP OAuth
        # route for convenience, while client IDs/secrets remain independent.
        self.account_token_url = normalize_hip_token_url(
            os.getenv("ACCOUNT_TOKEN_URL") or self.cfg.get("ACCOUNT_TOKEN_URL") or self.hip_token_url
        )
        self.account_client_id = str(
            os.getenv("ACCOUNT_CLIENT_ID") or self.cfg.get("ACCOUNT_CLIENT_ID") or ""
        ).strip()
        self.account_client_secret = str(
            os.getenv("ACCOUNT_CLIENT_SECRET") or self.cfg.get("ACCOUNT_CLIENT_SECRET") or ""
        ).strip()
        self.account_scope = str(
            os.getenv("ACCOUNT_SCOPE") or self.cfg.get("ACCOUNT_SCOPE") or ""
        ).strip()

        self.partner_token_url = normalize_hip_token_url(
            os.getenv("PARTNER_TOKEN_URL") or self.cfg.get("PARTNER_TOKEN_URL") or self.hip_token_url
        )
        self.partner_client_id = str(
            os.getenv("PARTNER_CLIENT_ID") or self.cfg.get("PARTNER_CLIENT_ID") or ""
        ).strip()
        self.partner_client_secret = str(
            os.getenv("PARTNER_CLIENT_SECRET") or self.cfg.get("PARTNER_CLIENT_SECRET") or ""
        ).strip()
        self.partner_scope = str(
            os.getenv("PARTNER_SCOPE") or self.cfg.get("PARTNER_SCOPE") or ""
        ).strip()

        self.system_token_url = normalize_hip_token_url(
            os.getenv("SYSTEM_TOKEN_URL") or self.cfg.get("SYSTEM_TOKEN_URL") or self.hip_token_url
        )
        self.system_client_id = str(
            os.getenv("SYSTEM_CLIENT_ID") or self.cfg.get("SYSTEM_CLIENT_ID") or ""
        ).strip()
        self.system_client_secret = str(
            os.getenv("SYSTEM_CLIENT_SECRET") or self.cfg.get("SYSTEM_CLIENT_SECRET") or ""
        ).strip()
        self.system_scope = str(
            os.getenv("SYSTEM_SCOPE") or self.cfg.get("SYSTEM_SCOPE") or ""
        ).strip()

        self.workflow_token_url = os.getenv("WORKFLOW_TOKEN_URL") or self.cfg.get("WORKFLOW_TOKEN_URL")
        self.workflow_client_id = os.getenv("WORKFLOW_CLIENT_ID") or self.cfg.get("WORKFLOW_CLIENT_ID")
        self.workflow_client_secret = os.getenv("WORKFLOW_CLIENT_SECRET") or self.cfg.get("WORKFLOW_CLIENT_SECRET")
        self.workflow_scope = os.getenv("WORKFLOW_SCOPE") or self.ov.get("workflow_scope") or self.cfg.get("WORKFLOW_SCOPE") or ""

        # One HIP OAuth credential/token is reused for every HIP endpoint,
        # including MAC Map. No MAC_MAP_* credential is read.
        self.map_token_url = self.hip_token_url
        self.map_client_id = self.hip_client_id
        self.map_client_secret = self.hip_client_secret
        self.map_scope = self.hip_scope
        self.map_token_auth_mode = "shared-hip-oauth-token"

        self.scopes = dict(DEFAULT_SCOPES)
        self.scopes.update(self.cfg.get("SCOPES") or {})

        configured_config_base = (
            os.getenv("HIP_CONFIG_SERVICE_BASE_URL")
            or self.ov.get("hip_config_service_base_url")
            or HIP_CONFIG_SERVICE_BASE
        ).rstrip("/")
        self.hip_config_service_base_url = configured_config_base
        self.urls = dict(DEFAULT_URLS)
        self.urls.update(
            hip_config_service_urls(self.hip_config_service_base_url)
        )
        # Explicit URL overrides remain available for controlled testing.
        self.urls.update(self.cfg.get("URLS") or {})

        # V106: Account / Partner / System endpoints are independently
        # replaceable without mutating developer-approved payload contracts.
        # This is specifically for cases where the Dell gateway is reachable
        # but its configured upstream PCF route has been retired/not deployed.
        # Environment values intentionally win over packaged/Test.py URLs so
        # an API-team endpoint replacement can be applied through .env only.
        endpoint_overrides = {
            "account": os.getenv("HIP_ACCOUNT_API_URL"),
            "partner": os.getenv("HIP_PARTNER_API_URL"),
            "system": os.getenv("HIP_SYSTEM_API_URL"),
            "rule_summary": os.getenv("HIP_RULE_SUMMARY_API_URL"),
            "rule_details": os.getenv("HIP_RULE_DETAILS_API_URL"),
        }
        self.endpoint_overrides: Dict[str, str] = {}
        for endpoint_key, configured_url in endpoint_overrides.items():
            value = str(configured_url or "").strip()
            if value:
                self.urls[endpoint_key] = value.rstrip("/")
                self.endpoint_overrides[endpoint_key] = self.urls[endpoint_key]

        self.partner_x_account_id = (
            get_path(self.ov, "partnerCreate", "x-account-id")
            or get_path(self.ov, "partner_create_full_payload_fixed", "x-account-id_header")
            or self.ov.get("x_account_id")
            or self.ov.get("accountId")
            or self.cfg.get("ACCOUNT_ID")
            or "23ffd247-3067-47d9-9f8b-af1e70b16568"
        )
        self.account_header = self.partner_x_account_id
        self.partner_x_account_name = (
            get_path(self.ov, "partnerCreate", "x-account-name")
            or self.ov.get("x_account_name")
            or self.ov.get("source_haft_account")
            or get_path(self.input, "objects", "source_transport_profile", "existing_account_name")
            or ""
        )

        self.pdf_kb = PdfApiKnowledgeBase(ROOT)
        self.pdf_validation_mode = (
            os.getenv("PDF_CONTRACT_VALIDATION_MODE", "auto")
            .strip()
            .lower()
        )
        self.pdf_aia_validate_each_request = (
            os.getenv(
                "PDF_AIA_VALIDATE_EACH_REQUEST",
                "true",
            ).strip().lower()
            in {"true", "1", "yes", "y"}
        )
        self.pdf_require_documentation = (
            os.getenv(
                "PDF_REQUIRE_DOCUMENTATION",
                "false",
            ).strip().lower()
            in {"true", "1", "yes", "y"}
        )

        self.adaptive = AdaptiveHipEngine(ROOT)
        self.mapper = UhalInputMapper(self.input, self.ov, ROOT)
        self.mcp = MCPBridge(
            ROOT,
            enabled=(
                os.getenv("MCP_ENABLED", "true").strip().lower()
                in {"true", "1", "yes", "y"}
            ),
            required=(
                os.getenv("MCP_REQUIRED", "false").strip().lower()
                in {"true", "1", "yes", "y"}
            ),
        )
        self.mcp_validate_each_request = (
            os.getenv("MCP_VALIDATE_EACH_REQUEST", "true")
            .strip().lower() in {"true", "1", "yes", "y"}
        )
        self.mcp_input_validation: Dict[str, Any] = {}
        self.business = self.mapper.normalized()
        # Runtime IDs must represent objects proven by THIS LIVE run. V108 does
        # not pre-seed Document Type, Map, Rule, or Flow IDs from packaged/history
        # values. Every applicable create/resolve API is executed and only its own
        # response may populate runtime identity.
        self.runtime_state: Dict[str, Any] = {
            "source_document_type_id": None,
            "target_document_type_id": None,
            "map_id": None,
            "rule_id": None,
            "flow_id": None,
            "flow_version": self.ov.get("flowVersion") or "1.0",
            "source_tp_name": self.business.get("sourceTpFlowName"),
            "target_tp_name": self.business.get("targetTpFlowName"),
        }
        # V108 runtime request immutability: after a logical LIVE API is first
        # materialized, retries/polls must use the same method/endpoint/body/query.
        # Only authentication headers are outside this fingerprint. No agent, LLM,
        # retry loop, or later API response is allowed to rewrite the request.
        self._live_request_fingerprints: Dict[str, str] = {}
        self._live_request_fingerprint_lock = threading.Lock()

        # User-approved API execution policy. A skip plan is active only when
        # it is explicitly confirmed and bound to the SHA-256 of the current
        # input.json. This prevents a U-HAUL plan from leaking into another
        # customer's run.
        self.execution_plan = ApiExecutionPlan(ROOT, INPUT_JSON)
        self.execution_flow = ExecutionFlowConfig(ROOT)
        self.payload_overrides = PayloadOverrideStore(ROOT)
        self.execution_timing_events: List[Dict[str, Any]] = []
        self.final_state: Dict[str, Any] = {}
        # V96 strict LIVE pipeline is the production behavior used by the React
        # RUN LIVE EXECUTION button. It is intentionally independent from the
        # historical diagnostic "full coverage" switch: strict mode stays
        # dependency-safe, but it refuses every persisted/user skip and requires
        # an actual HTTP result for every applicable canonical API before success.
        self.strict_live_pipeline_mode = env_bool("HIP_STRICT_LIVE_PIPELINE", False)
        # Default-on business rule: LIVE execution never suppresses a canonical
        # API because an execution plan says the object already exists. The API
        # is called and its own response is the evidence.
        self.no_reuse_live_mode = env_bool("HIP_NO_REUSE_LIVE", True)
        coverage_env = os.getenv("HIP_FULL_API_COVERAGE_MODE")
        if coverage_env is not None:
            self.full_api_coverage_mode = str(coverage_env).strip().lower() in {"1", "true", "yes", "on"}
        else:
            self.full_api_coverage_mode = bool(self.ov.get("fullApiCoverageMode"))

    def _api_http_session(self) -> requests.Session:
        """Return a per-thread pooled HTTP session for concurrent HIP calls.

        Requests sessions are connection-pool containers but are not guaranteed to
        be safe when mutated by multiple threads.  V89 executes dependency-ready
        HIP API steps concurrently inside one agent, so each worker thread receives
        its own Session while still benefiting from HTTP keep-alive/pooling.
        """
        local = getattr(self, "_http_session_local", None)
        if local is None:
            local = threading.local()
            self._http_session_local = local
        session = getattr(local, "session", None)
        if session is not None:
            return session
        session = requests.Session()
        session.trust_env = True
        pool_size = max(4, min(int(os.getenv("HIP_HTTP_POOL_SIZE", "24") or 24), 128))
        adapter = HTTPAdapter(pool_connections=pool_size, pool_maxsize=pool_size, max_retries=0, pool_block=False)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        local.session = session
        return session

    def _load_request_validation_cache(self) -> Dict[str, Any]:
        path = getattr(self, "_validation_cache_path", ROOT / "request_validation_cache.json")
        try:
            value = json.loads(Path(path).read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def _validation_fingerprint(self, *, api_key: str, method: str, url: str, headers: Dict[str, Any], payload: Any, params: Any) -> str:
        pdf_state = []
        try:
            for path in sorted(self.pdf_kb.index_dir.glob("*.json")):
                stat = path.stat()
                pdf_state.append([path.name, stat.st_size, int(stat.st_mtime_ns)])
        except Exception:
            pdf_state = []
        body = {
            "buildId": BUILD_ID,
            "apiKey": api_key,
            "method": method.upper(),
            "url": url,
            "headers": redact_sensitive(headers),
            "payload": redact_sensitive(payload),
            "params": redact_sensitive(params),
            "pdfMode": self.pdf_validation_mode,
            "mcpValidate": bool(self.mcp_validate_each_request and self.mcp.enabled),
            "pdfState": pdf_state,
        }
        raw = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return __import__("hashlib").sha256(raw).hexdigest()

    def _save_request_validation_cache(self) -> None:
        try:
            atomic_write_json(self._validation_cache_path, self._validation_cache)
        except Exception:
            pass

    def production_preflight(self) -> Dict[str, Any]:
        # Build the same effective Document Type requests used by API Testing.
        # This prevents Execute from validating stale/raw input.json metadata when
        # the actual persisted request is already correct.
        effective_requests: Dict[str, Any] = {}
        for step_key in ("doctype_source", "doctype_target"):
            try:
                effective_requests[step_key] = self.preview_step_request(step_key)
            except Exception:
                # The production guard can still fall back to canonical input data;
                # contract validation will separately report any request-build error.
                pass

        report = validate_production_readiness(
            root=ROOT,
            input_data=self.input,
            config=self.ov,
            urls=self.urls,
            token_url=self.hip_token_url,
            requester=self.requester,
            verify_ssl=REQUEST_VERIFY,
            effective_requests=effective_requests,
        )

        mapping_errors = [
            asdict(item)
            for item in self.mapper.validate()
            if item.severity == "ERROR"
        ]
        if mapping_errors:
            report["errors"].append({
                "check": "input-mapping",
                "message": json.dumps(mapping_errors, default=str),
            })
            report["ready"] = False

        # V110: Flow Orchestration Create enforces a stricter naming contract
        # than the name-validation API currently reports. Fail before any LIVE
        # mutation if a legacy input bypassed the canonical builder. The builder
        # itself deterministically compacts invalid names before this point.
        flow_name_check = validate_hip_flow_name(self.flow_name())
        report["flowNamePolicy"] = {
            **flow_name_check,
            "suggested": compact_hip_flow_name(self.flow_name()),
        }
        if not flow_name_check.get("valid"):
            report["errors"].append({
                "check": "hip-flow-name-policy",
                "message": (
                    "Invalid HIP flow name before LIVE execution: "
                    + "; ".join(flow_name_check.get("errors") or [])
                    + f" Suggested canonical name: {compact_hip_flow_name(self.flow_name())!r}. "
                      "Rebuild/save canonical input; do not rename after an API failure."
                ),
            })
            report["ready"] = False

        # Final business-value gate.  Contract-shape validation alone only proves
        # that partnerIdentifierValue is non-empty; it cannot prove that a routing
        # label was not accidentally used as a DUNS.  the approved U-HAUL reference uses a DUNS owned by dce-test-partner
        # and must use it immediately before any LIVE call.  The check runs against
        # the *effective* request so persistent payload edits cannot bypass it.
        customer_key = re.sub(r"[^a-z0-9]+", "", str(self.input.get("customer") or "").lower())
        if customer_key == "uhaul" and (
            self.strict_live_pipeline_mode
            or not self.execution_plan.is_skipped("partner_target")
        ):
            expected_duns = "12345666"
            try:
                partner_request = self.preview_step_request("partner_target")
                partner_payload = partner_request.get("payload") or {}
                actual_type = str(partner_payload.get("partnerIdentifier") or "").strip()
                actual_value = str(partner_payload.get("partnerIdentifierValue") or "").strip()
            except Exception as exc:
                actual_type, actual_value = "", ""
                report["errors"].append({
                    "check": "uhaul-approved-duns",
                    "message": f"Could not build the U-HAUL reference Partner request for final dce-test-partner DUNS validation: {type(exc).__name__}: {exc}",
                })
                report["ready"] = False
            if actual_type != "DUNS Number" or actual_value != expected_duns:
                report["errors"].append({
                    "check": "uhaul-approved-duns",
                    "message": (
                        "The U-HAUL reference Partner Create for dce-test-partner must use partnerIdentifier='DUNS Number' "
                        f"and partnerIdentifierValue='{expected_duns}' immediately before LIVE execution. "
                        f"Effective request currently has type={actual_type!r}, value={actual_value!r}."
                    ),
                })
                report["ready"] = False
            report["approvedBusinessValues"] = {
                **(report.get("approvedBusinessValues") or {}),
                "uhaulDuns": {
                    "expected": expected_duns,
                    "effective": actual_value,
                    "valid": actual_type == "DUNS Number" and actual_value == expected_duns,
                },
            }

        mcp_validation = self.mcp.validate_uhal_input(
            self.input,
            self.ov,
        )
        report["mcpInputValidation"] = mcp_validation
        if not mcp_validation.get("valid", True):
            report["errors"].append({
                "check": "mcp-input-validation",
                "message": json.dumps(
                    mcp_validation.get("issues") or [],
                    default=str,
                ),
            })
            report["ready"] = False

        # MCP supervisor combines mapping, interface registration, execution
        # policy, payload-override and live-run health checks into one evidence
        # object. This is a first-class preflight checkpoint rather than a UI-only
        # validator.
        mcp_readiness = self.mcp.assess_execution_readiness(self.input, self.ov)
        report["mcpExecutionReadiness"] = mcp_readiness
        if not mcp_readiness.get("valid", True):
            report["errors"].append({
                "check": "mcp-execution-readiness",
                "message": json.dumps(mcp_readiness.get("errors") or [], default=str),
            })
            report["ready"] = False
        if mcp_readiness.get("liveRunBlocked"):
            report["errors"].append({
                "check": "mcp-live-run-health",
                "message": "Another verified HIP run is currently active.",
            })
            report["ready"] = False

        execution_plan = self.execution_plan.summary()
        report["apiExecutionPlan"] = execution_plan
        if execution_plan.get("confirmed") and not execution_plan.get("active"):
            report["errors"].append({
                "check": "api-execution-plan",
                "message": (
                    "A confirmed API skip plan is invalid or belongs to a "
                    "different input.json. Re-save the plan before live execution. "
                    + json.dumps(
                        {
                            "errors": execution_plan.get("errors", []),
                            "warnings": execution_plan.get("warnings", []),
                            "inputMatches": execution_plan.get("inputMatches"),
                        },
                        default=str,
                    )
                ),
            })
            report["ready"] = False

        execution_flow = self.execution_flow.summary()
        report["executionFlow"] = execution_flow
        if not execution_flow.get("valid"):
            report["errors"].append({
                "check": "execution-flow",
                "message": json.dumps(execution_flow.get("errors", []), default=str),
            })
            report["ready"] = False

        payload_overrides = self.payload_overrides.summary()
        report["payloadOverrides"] = payload_overrides
        if not payload_overrides.get("valid"):
            report["errors"].append({
                "check": "payload-overrides",
                "message": json.dumps(payload_overrides.get("errors", []), default=str),
            })
            report["ready"] = False

        # Partner/interface credentials are payload values, not application OAuth
        # credential profiles. Secure fields use runtime_payload placeholders in
        # the canonical request and must be available before a live run.
        missing_payload_values = missing_runtime_payload_values(ROOT, self.input)
        report["runtimePayloadValues"] = {
            **runtime_payload_status(ROOT),
            "missing": missing_payload_values,
        }
        if missing_payload_values:
            report["errors"].append({
                "check": "runtime-payload-values",
                "message": (
                    "Missing Partner/interface payload value(s): "
                    + ", ".join(missing_payload_values)
                    + ". Enter them in the Interface Studio. These are API payload values, not .env credentials."
                ),
            })
            report["ready"] = False

        credential_profiles = {
            "hipConfig": {
                "required": True,
                "configured": bool(self.hip_token_url and self.hip_client_id and self.hip_client_secret),
            },
            "account": {
                "required": self.strict_live_pipeline_mode or not (
                    self.execution_plan.is_skipped("account_source")
                    and self.execution_plan.is_skipped("account_target")
                ),
                "configured": bool(self.account_token_url and self.account_client_id and self.account_client_secret),
            },
            "partner": {
                "required": self.strict_live_pipeline_mode or not self.execution_plan.is_skipped("partner_target"),
                "configured": bool(self.partner_token_url and self.partner_client_id and self.partner_client_secret),
            },
            "system": {
                "required": self.strict_live_pipeline_mode or not self.execution_plan.is_skipped("system_source"),
                "configured": bool(self.system_token_url and self.system_client_id and self.system_client_secret),
            },
            "dellAia": {
                "required": True,
                "configured": bool(self.judge.available()),
            },
        }
        report["credentialProfiles"] = credential_profiles
        for profile_name, profile in credential_profiles.items():
            if profile.get("required") and not profile.get("configured"):
                report["errors"].append({
                    "check": f"credential-profile-{profile_name}",
                    "message": f"Required credential profile {profile_name} is not configured.",
                })
                report["ready"] = False

        path = REPORTS / "production_preflight_latest.json"
        atomic_write_json(path, redact_sensitive(report))
        report["reportPath"] = str(path)
        return report

    def validate_live_configuration(self) -> None:
        missing: List[str] = []
        required = {
            "HIP_TOKEN_URL": self.hip_token_url,
            "HIP_CLIENT_ID": self.hip_client_id,
            "HIP_CLIENT_SECRET": self.hip_client_secret,
        }

        # Dedicated service credentials follow the active execution mode. In
        # strict whole-pipeline LIVE mode all applicable APIs are called, so
        # Account/Partner/System credentials are mandatory even if a persisted
        # legacy execution plan marks an object as existing.
        if self.strict_live_pipeline_mode or not (
            self.execution_plan.is_skipped("account_source")
            and self.execution_plan.is_skipped("account_target")
        ):
            required.update({
                "ACCOUNT_TOKEN_URL": self.account_token_url,
                "ACCOUNT_CLIENT_ID": self.account_client_id,
                "ACCOUNT_CLIENT_SECRET": self.account_client_secret,
            })
        if self.strict_live_pipeline_mode or not self.execution_plan.is_skipped("partner_target"):
            required.update({
                "PARTNER_TOKEN_URL": self.partner_token_url,
                "PARTNER_CLIENT_ID": self.partner_client_id,
                "PARTNER_CLIENT_SECRET": self.partner_client_secret,
            })
        if self.strict_live_pipeline_mode or not self.execution_plan.is_skipped("system_source"):
            required.update({
                "SYSTEM_TOKEN_URL": self.system_token_url,
                "SYSTEM_CLIENT_ID": self.system_client_id,
                "SYSTEM_CLIENT_SECRET": self.system_client_secret,
            })

        for key, value in required.items():
            if not value:
                missing.append(key)

        if not self.execution_flow.summary().get("valid"):
            missing.append("VALID_EXECUTION_FLOW")
        if not self.payload_overrides.summary().get("valid"):
            missing.append("VALID_PAYLOAD_OVERRIDES")

        if not self.judge.available():
            missing.extend([
                "DELL_AIA_CLIENT_ID/CLIENT_ID",
                "DELL_AIA_CLIENT_SECRET/CLIENT_SECRET",
            ])

        if missing:
            raise RuntimeError(
                "Missing mandatory live configuration: "
                + ", ".join(sorted(set(missing)))
                + ". Update credentials / Execution Flow from Streamlit "
                "or the local configuration files."
            )

    def collect_missing_values(self) -> List[Dict[str, Any]]:
        """Return missing fields with deterministic safe suggestions."""
        items: List[Dict[str, Any]] = []

        def add(
            field: str,
            current: Any,
            suggestion: str,
            source: str,
            secret: bool = False,
        ) -> None:
            if current not in (None, "", [], {}):
                return
            items.append({
                "field": field,
                "current": current,
                "suggestedValue": suggestion,
                "source": source,
                "secret": secret,
            })

        add(
            "HIP_TOKEN_URL",
            self.hip_token_url,
            "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token",
            "Dev-team new API token endpoint",
        )
        add(
            "HIP_CLIENT_ID",
            self.hip_client_id,
            "REQUEST_FROM_API_OWNER",
            "Som/API subscription",
            True,
        )
        add(
            "HIP_CLIENT_SECRET",
            self.hip_client_secret,
            "REQUEST_FROM_API_OWNER_AND_ROTATE",
            "Som/API subscription",
            True,
        )
        add(
            "DELL_AIA_BASE_URL",
            self.judge.base_url,
            "https://aia.gateway.dell.com/genai/dev/v1",
            "Dell AIA configuration",
        )
        add(
            "DELL_AIA_MODEL",
            self.judge.model,
            "gpt-oss-120b",
            "Dell AIA configuration",
        )
        add(
            "DELL_AIA_CLIENT_ID",
            self.judge.client_id,
            "REQUEST_FROM_DELL_AIA_OWNER",
            "Dell AIA service account",
            True,
        )
        add(
            "DELL_AIA_CLIENT_SECRET",
            self.judge.client_secret,
            "REQUEST_FROM_DELL_AIA_OWNER_AND_ROTATE",
            "Dell AIA service account",
            True,
        )

        source_doc = self.source_doc()
        target_doc = self.target_doc()
        target_doc_required = self.is_translation() or self.has_separate_passthrough_target()
        add(
            "source_document_type.name",
            source_doc.get("name"),
            "ASK_INPUT_BUILDER_OR_USER",
            "Active canonical input",
        )
        add(
            "source_document_type.api_transaction_type",
            source_doc.get("api_transaction_type"),
            "INBOUND",
            "Name suffix IB and Dev payload enum",
        )
        if target_doc_required:
            add(
                "target_document_type.name",
                target_doc.get("name"),
                "ASK_INPUT_BUILDER_OR_USER",
                "Active canonical input",
            )
            add(
                "target_document_type.api_transaction_type",
                target_doc.get("api_transaction_type"),
                "OUTBOUND",
                "Name suffix OB and Dev payload enum",
            )
        add(
            "source_document_type.api_document_identifier",
            source_doc.get("api_document_identifier"),
            json.dumps({"operator": "ALL", "attributeList": []}),
            "Dev Document Type POST shape; root comes from active input",
        )
        if target_doc_required:
            add(
                "target_document_type.api_document_identifier",
                target_doc.get("api_document_identifier"),
                json.dumps({"operator": "ALL", "attributeList": []}),
                "Dev Document Type POST shape; root comes from active input",
            )
        add(
            "source_haft_account",
            self.ov.get("source_haft_account"),
            "ASK_INPUT_BUILDER_OR_USER",
            "Customer/environment account value",
        )
        add(
            "target_haft_account",
            self.ov.get("target_haft_account"),
            "ASK_INPUT_BUILDER_OR_USER",
            "Customer/environment account value",
        )
        add(
            "deployment_group",
            self.ov.get("source_deployment_group_name"),
            "hip-automation",
            "Latest Dev-team common deployment group",
        )
        # Dev guidance: the complete workType object is derived inside HIP.
        # It is not a customer/configuration value and must never be requested.
        return items

    def build_suggestion_context(self) -> Dict[str, Any]:
        return {
            "customer": self.input.get("customer"),
            "direction": self.input.get("direction"),
            "profileName": self.input.get("profile_name"),
            "sourceDocumentType": self.source_doc().get("name"),
            "targetDocumentType": self.effective_target_doc().get("name"),
            "mapIdentifier": self.data_map().get("map_identifier"),
            "ruleName": self.rule().get("name"),
            "sourceTransportProfile": self.ov.get(
                "source_transport_profile_name"
            ),
            "targetTransportProfile": self.ov.get(
                "target_transport_profile_name"
            ),
            "hipEnvironment": self.env,
            "ingestedPdfDocuments": [
                {
                    "filename": item.get("filename"),
                    "detectedApis": item.get("detectedApis"),
                    "warnings": item.get("warnings"),
                }
                for item in self.pdf_kb.list_documents()
            ],
            "pdfContractApis": sorted(
                self.pdf_kb.load_pdf_contracts().keys()
            ),
        }

    def make_user(self) -> Dict[str, Any]:
        return {
            "emailId": get_path(self.ov, "user", "emailId") or self.requester,
            "firstName": get_path(self.ov, "user", "firstName") or "Adheesh",
            "lastName": get_path(self.ov, "user", "lastName") or "Srivastava",
            "userId": self.user_id,
        }

    def obj(self, key: str) -> Dict[str, Any]:
        return ((self.input.get("objects") or {}).get(key)) or {}

    def source_doc(self): return self.obj("source_document_type")
    def target_doc(self): return self.obj("target_document_type")
    def data_map(self): return self.obj("data_map")
    def rule(self): return self.obj("rule")
    def source_tp(self): return self.obj("source_transport_profile")
    def target_tp(self): return self.obj("target_transport_profile")
    def biz_flow(self): return self.obj("biz_flow")

    def source_account_name(self) -> str:
        return str(
            self.ov.get("source_haft_account")
            or self.source_tp().get("existing_account_name")
            or ""
        ).strip()

    def target_account_name(self) -> str:
        return str(
            self.ov.get("target_haft_account")
            or self.target_tp().get("existing_account_name")
            or ""
        ).strip()

    def partner_identifier_value(self) -> str:
        explicit = str(
            self.input.get("partner_identifier_value")
            or self.input.get("partner_id")
            or self.ov.get("partner_identifier_value")
            or get_path(self.ov, "partnerCreate", "partnerIdentifierValue")
            or ""
        ).strip()

        # The U-HAUL reference Partner Create uses the Dev-approved dce-test-partner DUNS identifier.  Sender/
        # Receiver routing identities are business-routing values and must not be
        # substituted for a DUNS value.  Keep the approved reference here as a
        # deterministic fallback for legacy U-HAUL workspaces that predate the
        # explicit partner_identifier_value field.
        customer_key = re.sub(r"[^a-z0-9]+", "", str(self.input.get("customer") or "").lower())
        if customer_key == "uhaul":
            if not explicit or explicit.lower() in {"uhaul", "u-haul"}:
                return "12345666"
            return explicit

        if explicit:
            return explicit

        # Approved input.json files frequently already carry the external
        # partner identity in Sender/Receiver routing conditions. Reuse that
        # provable value instead of forcing the user to duplicate it solely for
        # Partner Create contract validation.
        direction = str(self.input.get("direction") or "Outbound").strip().lower()
        wanted = "sender" if direction == "inbound" else "receiver"
        biz = self.biz_flow()
        candidates = list(((biz.get("flow_identifiers") or {}).get("conditions") or []))
        candidates += list(((self.rule().get("conditions") or {}).get("rows") or []))
        routing = biz.get("configure_routing") if isinstance(biz.get("configure_routing"), dict) else {}
        candidates += list(((routing.get("conditions") or {}).get("rows") or []))
        for row in candidates:
            if not isinstance(row, dict):
                continue
            attr = str(row.get("attribute_name") or row.get("attribute_name_unit") or row.get("attribute") or "").strip().lower()
            value = str(row.get("value") or "").strip()
            if attr == wanted and value:
                return value
        return ""

    def is_translation(self) -> bool:
        return self.mapper.is_translation()

    def has_separate_passthrough_target(self) -> bool:
        return self.mapper.has_separate_passthrough_target()

    def effective_target_doc(self) -> Dict[str, Any]:
        return self.mapper.effective_target_doc()

    def step_applicable(self, step_key: str) -> bool:
        """Return whether the API building block applies to this canonical flow.

        All 18 APIs stay available in the Studio/Game. For a passthrough flow,
        Map and Mapping Rule creation are genuinely not part of the business
        configuration and therefore are marked NOT_APPLICABLE rather than sent
        with fabricated payload values.
        """
        key = canonical_step_key(step_key)
        if not self.is_translation() and key in {"map", "rule"}:
            return False
        if not self.is_translation() and key == "doctype_target" and not self.has_separate_passthrough_target():
            return False
        return True

    def applicability_reason(self, step_key: str) -> str:
        key = canonical_step_key(step_key)
        if not self.is_translation() and key == "map":
            return "Passthrough flow: no translation Data Map is required."
        if not self.is_translation() and key == "rule":
            return "Passthrough flow: no Mapping Rule is required; target routing remains in the Flow definition."
        if not self.is_translation() and key == "doctype_target" and not self.has_separate_passthrough_target():
            return "Passthrough flow: no separate Target Document Type is required; Target TP and Flow reuse the Source Document Type."
        return ""

    def get_token(self, token_kind: str, scope: str = "") -> str:
        """Get an OAuth 2.0 Client Credentials token exactly like Postman.

        HIP request:
          POST <HIP_TOKEN_URL>
          Authorization: Basic base64(client_id:client_secret)
          Content-Type: application/x-www-form-urlencoded
          grant_type=client_credentials

        Scope is sent only when HIP_SCOPE is explicitly non-empty.
        The normal Requests/Windows environment is preserved (trust_env=True),
        so corporate/system proxy settings that Postman uses transparently are
        not bypassed. No manual token, cookie, JSON-auth, or alternate HIP
        credential mode is used.
        """
        token_kind = str(token_kind or "").upper()
        self._ensure_token_runtime_state()
        hip_user_agent = self._resolved_hip_token_user_agent()

        if token_kind == "MAP":
            token = self.get_token("HIP", self.hip_scope)
            self.token_sources["MAP"] = "shared-hip-oauth-token"
            return token

        if token_kind == "HIP":
            token_url = self.hip_token_url
            client_id = self.hip_client_id
            client_secret = self.hip_client_secret
            effective_scope = self.hip_scope
            user_agent = hip_user_agent
        elif token_kind == "ACCOUNT":
            token_url = self.account_token_url
            client_id = self.account_client_id
            client_secret = self.account_client_secret
            effective_scope = self.account_scope
            user_agent = hip_user_agent
        elif token_kind == "PARTNER":
            token_url = self.partner_token_url
            client_id = self.partner_client_id
            client_secret = self.partner_client_secret
            effective_scope = self.partner_scope
            user_agent = hip_user_agent
        elif token_kind == "SYSTEM":
            token_url = self.system_token_url
            client_id = self.system_client_id
            client_secret = self.system_client_secret
            effective_scope = self.system_scope
            user_agent = hip_user_agent
        elif token_kind == "WORKFLOW":
            token_url = str(self.workflow_token_url or "").strip()
            client_id = self.workflow_client_id
            client_secret = self.workflow_client_secret
            effective_scope = str(self.workflow_scope or "").strip()
            user_agent = "PostmanRuntime/7.49.0"
        else:
            raise ValueError(f"Unknown token kind {token_kind}")

        if not token_url or not client_id or not client_secret:
            raise RuntimeError(
                f"{token_kind} token URL/client ID/client secret is missing."
            )

        cache_key = (
            token_kind,
            token_url,
            str(client_id),
            effective_scope,
        )
        with TOKEN_CACHE_LOCK:
            cached = TOKEN_CACHE.get(cache_key)
        if cached:
            self.token_sources[token_kind] = "memory-cache"
            return cached

        form_body: Dict[str, str] = {
            "grant_type": "client_credentials",
        }
        if effective_scope:
            form_body["scope"] = effective_scope

        headers = {
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache",
            "User-Agent": user_agent or DEFAULT_HIP_TOKEN_USER_AGENT,
        }

        # Do NOT disable trust_env. Requests with trust_env=True uses the
        # machine/environment proxy configuration on Windows when present and
        # connects directly when none exists. That is the closest equivalent to
        # a normal Postman request on the same Dell laptop.
        #
        # V94/V95: token acquisition is single-flight inside this worker and
        # serialized across AutoGen worker processes. Transient gateway/proxy
        # failures retry with bounded backoff; real credential errors are never
        # hidden.
        request_lock = _token_request_lock(cache_key)
        with request_lock:
            # Another dependency-ready thread may have populated the cache while
            # this thread waited for the single-flight lock.
            with TOKEN_CACHE_LOCK:
                cached = TOKEN_CACHE.get(cache_key)
            if cached:
                self.token_sources[token_kind] = "memory-cache"
                return cached

            max_attempts = max(1, int(os.getenv("HIP_OAUTH_RETRY_ATTEMPTS", "4") or 4))
            attempt_history: List[Dict[str, Any]] = []
            response: Optional[requests.Response] = None
            final_exception: Optional[Exception] = None
            detected_proxies = requests.utils.get_environ_proxies(token_url)
            proxy_keys = sorted(str(key) for key in detected_proxies.keys())
            started = time.time()

            with _OAuthEndpointLock(token_url):
                session = requests.Session()
                session.trust_env = True
                try:
                    for attempt_no in range(1, max_attempts + 1):
                        attempt_started = time.time()
                        try:
                            candidate = session.post(
                                token_url,
                                auth=HTTPBasicAuth(str(client_id), str(client_secret)),
                                headers=headers,
                                data=form_body,
                                timeout=TIMEOUT_SECONDS,
                                verify=REQUEST_VERIFY,
                                allow_redirects=True,
                            )
                            response = candidate
                            attempt_history.append({
                                "attempt": attempt_no,
                                "status": candidate.status_code,
                                "elapsedSeconds": round(time.time() - attempt_started, 3),
                            })
                            # 400/401/403 represent request/credential/scope
                            # problems. Do not retry them and do not mislabel them
                            # as network failures.
                            if candidate.status_code in {400, 401, 403}:
                                break
                            if candidate.status_code in OAUTH_TRANSIENT_STATUSES and attempt_no < max_attempts:
                                delay = _oauth_retry_delay(attempt_no, candidate)
                                attempt_history[-1]["retryDelaySeconds"] = delay
                                time.sleep(delay)
                                continue
                            break
                        except (requests.exceptions.RequestException, OSError, TimeoutError) as exc:
                            final_exception = exc
                            attempt_history.append({
                                "attempt": attempt_no,
                                "exceptionType": type(exc).__name__,
                                "error": clean(str(exc))[:600],
                                "elapsedSeconds": round(time.time() - attempt_started, 3),
                            })
                            if attempt_no >= max_attempts:
                                break
                            delay = _oauth_retry_delay(attempt_no)
                            attempt_history[-1]["retryDelaySeconds"] = delay
                            time.sleep(delay)
                finally:
                    session.close()

            if response is None:
                diag = {
                    "buildId": BUILD_ID,
                    "tokenKind": token_kind,
                    "status": "NETWORK_ERROR",
                    "tokenUrl": token_url,
                    "authentication": "oauth2-client-credentials-basic-auth",
                    "scopeSent": bool(effective_scope),
                    "trustEnv": True,
                    "systemProxyDetected": bool(detected_proxies),
                    "proxyKeys": proxy_keys,
                    "attempts": attempt_history,
                    "errorType": type(final_exception).__name__ if final_exception else "UnknownNetworkError",
                    "error": clean(str(final_exception))[:1200] if final_exception else "No OAuth response received.",
                }
                diagnostic_path = _write_token_diagnostic_best_effort(token_kind, diag)
                diagnostic_hint = (
                    f" Review {diagnostic_path}."
                    if diagnostic_path is not None
                    else " Diagnostic evidence could not be persisted, but that did not change the OAuth result."
                )
                root_cause = f" {type(final_exception).__name__}: {clean(str(final_exception))[:500]}" if final_exception else ""
                raise RuntimeError(
                    f"{token_kind} OAuth network error after {len(attempt_history)} attempt(s) using the Postman-equivalent request.{root_cause}"
                    + diagnostic_hint
                ) from final_exception

            body = parse_token_response(response)
            token = extract_access_token(body)
            history = [
                {
                    "status": item.status_code,
                    "url": str(item.url),
                    "location": item.headers.get("Location", ""),
                }
                for item in response.history
            ]
            diag = {
                "buildId": BUILD_ID,
                "tokenKind": token_kind,
                "status": response.status_code,
                "tokenUrl": token_url,
                "finalUrl": str(response.url),
                "authentication": "oauth2-client-credentials-basic-auth",
                "scopeSent": bool(effective_scope),
                "trustEnv": True,
                "systemProxyDetected": bool(detected_proxies),
                "proxyKeys": proxy_keys,
                "redirectHistory": history,
                "attempts": attempt_history,
                "contentType": response.headers.get("Content-Type", ""),
                "tokenFound": bool(token),
                "elapsedSeconds": round(time.time() - started, 3),
                "bodyPreview": redact_sensitive(clean(response.text))[:800],
            }
            diagnostic_path = _write_token_diagnostic_best_effort(token_kind, diag)

            if response.ok and token:
                with TOKEN_CACHE_LOCK:
                    TOKEN_CACHE[cache_key] = token
                self.token_sources[token_kind] = "oauth2-client-credentials-basic-auth"
                return token

            diagnostic_hint = (
                f" The exact redacted response is in {diagnostic_path}."
                if diagnostic_path is not None
                else " Redacted diagnostic evidence could not be persisted."
            )
            raise RuntimeError(
                f"{token_kind} OAuth failed. HTTP={response.status_code}; "
                f"final URL={response.url}; tokenFound={bool(token)}; attempts={len(attempt_history)}."
                + diagnostic_hint
            )

    def headers(self, token: str, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-requester-id": self.requester,
        }
        # Do not send x-account-id globally. Partner Create uses
        # x-account-name explicitly, per the latest API-team correction.
        if extra:
            for k, v in extra.items():
                if v is not None and str(v) != "":
                    h[k] = str(v)
        return h

    def classify_http(
        self,
        status: Optional[int],
        text: str,
        error: str = "",
    ) -> Tuple[str, bool]:
        low = (text or error or "").lower()
        if error:
            return (
                "AUTH_OR_EXECUTION_ERROR"
                if "token" in low or "credentials" in low
                else "EXECUTION_ERROR",
                False,
            )

        try:
            parsed: Any = json.loads(text) if text else None
        except Exception:
            parsed = None

        def has_business_error(node: Any) -> bool:
            if not isinstance(node, dict):
                return False
            if node.get("success") is False:
                return True
            if node.get("error") is True:
                return True
            if node.get("errorFlag") is True:
                return True
            if node.get("failedStep") not in (None, "", False):
                return True
            if node.get("errorMessage") not in (None, "", False):
                return True
            for key in (
                "tpCreateResponse",
                "deployResponse",
                "flowCreateResponse",
            ):
                if has_business_error(node.get(key)):
                    return True
            return False

        if status in (200, 201, 202, 204):
            if has_business_error(parsed):
                return "HTTP_SUCCESS_BUT_BUSINESS_ERROR", False
            if parsed is None and any(
                marker in low
                for marker in (
                    '"errorflag": true',
                    '"success": false',
                    "unable to find",
                )
            ):
                return "HTTP_SUCCESS_BUT_BUSINESS_ERROR", False
            return "PASS_SUCCESS", True

        if status in (400, 409, 415, 422):
            return "PAYLOAD_SCHEMA_OR_VALIDATION_ERROR", False
        if status in (401, 403):
            return "AUTH_OR_ENTITLEMENT_ERROR", False
        # V106: Cloud Foundry/Dell gateway route-not-found is not a JSON
        # payload defect and must not be reported as an application path bug.
        # The distinctive backend message proves the request reached the
        # gateway, which then failed to locate its configured upstream route.
        if status == 404 and (
            ("requested route" in low and "does not exist" in low)
            or ("pcf.dell.com" in low and "route" in low and "does not exist" in low)
        ):
            return "API_UPSTREAM_ROUTE_UNAVAILABLE", False
        if status in (404, 405):
            return "PATH_OR_METHOD_ERROR", False
        if status and status >= 500:
            return "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False
        return "UNKNOWN", False

    def validate_step_business_result(
        self,
        url_key: str,
        body: Any,
        classification: str,
        ok: bool,
    ) -> Tuple[str, bool]:
        if not ok:
            return classification, ok

        def normalized_status(value: Any) -> str:
            return re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")

        def latest_record_statuses(records: Any) -> set[str]:
            if not isinstance(records, list) or not records:
                return set()
            # The HIP audit/history APIs return the most recent event first.
            # Inspect that event only so an older successful deployment cannot
            # accidentally satisfy a newer pending/failed request.
            latest = records[0] if isinstance(records[0], dict) else {}
            values: set[str] = set()
            status_keys = {
                "status", "taskStatus", "operationStatus", "auditStatus",
                "deploymentStatus", "transportProfileStatus",
                "flowDeploymentStatus", "result", "state",
            }

            def walk(node: Any) -> None:
                if isinstance(node, dict):
                    for key, value in node.items():
                        if key in status_keys and value not in (None, ""):
                            values.add(normalized_status(value))
                        if isinstance(value, (dict, list)):
                            walk(value)
                elif isinstance(node, list):
                    for item in node:
                        walk(item)

            walk(latest)
            return {value for value in values if value}

        success_statuses = {
            "SUCCESS", "SUCCEEDED", "COMPLETED", "COMPLETE",
            "DEPLOYED", "ACTIVE", "DONE", "FINISHED",
        }
        failure_statuses = {
            "FAIL", "FAILED", "FAILURE", "ERROR", "ERRORED",
            "REJECTED", "CANCELLED", "CANCELED", "ABORTED",
            "TERMINATED",
        }

        if url_key == "flow_deploy_history":
            records: Any = body
            if isinstance(body, dict):
                records = (
                    body.get("deploymentHistory")
                    or body.get("data")
                    or []
                )
            if not isinstance(records, list):
                return "FLOW_DEPLOYMENT_AUDIT_RESPONSE_INVALID", False
            if not records:
                return "FLOW_DEPLOYMENT_AUDIT_PENDING", False
            statuses = latest_record_statuses(records)
            if statuses.intersection(failure_statuses):
                return "FLOW_DEPLOYMENT_AUDIT_FAILED", False
            if statuses.intersection(success_statuses):
                return "PASS_SUCCESS", True
            return "FLOW_DEPLOYMENT_AUDIT_PENDING", False

        if url_key == "tp_audits":
            records: Any = body
            if isinstance(body, dict):
                records = body.get("data") or body.get("audits") or []
            if not isinstance(records, list):
                return "TP_AUDIT_RESPONSE_INVALID", False
            if not records:
                return "TP_AUDIT_PENDING", False

            # V110 live finding: TP history can start with newer failed EDIT
            # records even though the canonical CREATE record succeeded. This
            # runner executes TP orchestration CREATE ONLY, so unrelated edit
            # history must not turn a valid create audit into a failure. Prefer
            # create records when operation metadata is available, preserving
            # the API's original newest-first ordering within that operation.
            create_records = [
                row for row in records
                if isinstance(row, dict)
                and normalized_status(row.get("operation") or row.get("operationType") or row.get("action"))
                in {"CREATE", "CREATED"}
            ]
            relevant_records = create_records or records
            statuses = latest_record_statuses(relevant_records)
            if statuses.intersection(failure_statuses):
                return "TP_AUDIT_FAILED", False
            if statuses.intersection(success_statuses):
                return "PASS_SUCCESS", True
            return "TP_AUDIT_PENDING", False

        return classification, ok

    def deterministic_owner(self, result: Dict[str, Any]) -> Tuple[str, str, str]:
        text = clean((result.get("response_preview") or "") + " " + (result.get("error") or "")).lower()
        group = result.get("group", "")
        api = result.get("api", "")
        status = result.get("status_code")
        ok = result.get("business_success")

        if ok:
            return "WORKING", "No issue observed.", "Keep as evidence."

        if str(result.get("classification") or "").upper() == "API_UPSTREAM_ROUTE_UNAVAILABLE" or (
            status == 404
            and "requested route" in text
            and "does not exist" in text
        ):
            return (
                "API_UPSTREAM_ROUTE_UNAVAILABLE",
                "The Dell API gateway was reached, but its configured upstream PCF service route does not exist/is not deployed.",
                "API/platform team should restore the upstream route or provide a replacement endpoint. Configure it with HIP_ACCOUNT_API_URL, HIP_PARTNER_API_URL, or HIP_SYSTEM_API_URL; do not mutate the approved payload.",
            )

        if (
            str(group).strip().lower() == "rule"
            and any(marker in text for marker in (
                "fk_mac_rule_flow_def", "mac_rule_flow_def",
                "flowdefinitionid", "flow_definition_id",
            ))
            and ("parent key not found" in text or "ora-02291" in text or "integrity constraint" in text)
        ):
            return (
                "API_BACKEND_CONTRACT_MISMATCH",
                "HIP returned FK_MAC_RULE_FLOW_DEF while processing the standalone Mapping Rule request.",
                "Keep flowDefinitionId omitted per the corrected developer-approved standalone Rule contract. Do not inject, infer, or retry with a synthetic parent ID; API/backend ownership is required if the FK still appears.",
            )

        if (
            str(group).strip().lower() == "rule"
            and any(marker in text for marker in (
                "rule_documenttype", "fk_rule_documenttype",
                "parent key not found in rule_documenttype",
            ))
        ):
            return (
                "API_BACKEND_CONTRACT_MISMATCH",
                "HIP rejected Mapping Rule persistence through RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE even though the developer-approved Rule request contains no documentTypeId.",
                "Keep documentTypeId omitted. API/backend team should align Rule persistence with the approved name+version contract; do not run a fake Document Type ID repair cycle.",
            )

        if "already exists" in text or "already exist" in text:
            return "EXPECTED_EXISTING_OBJECT", "Object already exists/configured.", "The API was executed. Keep this explicit EXISTING response as evidence; do not infer/reuse an ID from another step. Optional API improvement: return 409/400 instead of 500."

        if (
            ("unique constraint" in text and ("mac_map" in text or "name_version_env_unique" in text))
            or ("map identifier should be unique in an environment" in text)
            or ("map identifier should be unique" in text and (str(group).lower() == "map" or "mac map" in str(api).lower()))
        ):
            return (
                "EXPECTED_DUPLICATE_FROM_RETEST",
                "HIP reports that this MAC Map identifier already exists in the environment.",
                "The MAP create API was executed. Keep the explicit EXISTING response as evidence; do not inject the packaged mapId into downstream requests.",
            )

        if "documenttypeid" in text or "document_type_id" in text:
            return (
                "API_BACKEND_OR_ERROR_HANDLING",
                "HIP referenced documentTypeId even though the latest Dev-approved Rule payload omits that field.",
                "Keep documentTypeId omitted and review the HIP backend/document-type propagation evidence.",
            )

        if "systemid is mandatory" in text:
            return "MISSING_REQUIRED_ID_OR_CONFIG", "Direct TP API requires systemId.", "Provide systemId/deploymentGroupId or use TP orchestration with systemName/deploymentGroupName."

        if "unable to find the flow" in text:
            return "EXPECTED_DEPENDENCY_FAILURE", "Flow does not exist yet.", "Create Flow Definition first, then deploy."

        if "user not found in system" in text:
            return "API_DOC_OR_BACKEND_MISMATCH", "Latest doc says user not required, but API validates user.", "Dev team should confirm required user payload or fix doc/backend."

        if "mandatory parameters" in text:
            return "API_DOC_OR_BACKEND_MISMATCH", "API rejects updated payload as missing mandatory fields.", "Dev team should identify exact missing fields."

        if "invalid_scope" in text:
            return "API_BACKEND_OR_ERROR_HANDLING", "Backend downstream OAuth invalid_scope.", "API team to fix backend scope/client config."

        if status in (401, 403):
            return "AUTH_OR_ENTITLEMENT", "API entitlement or scope issue.", "Confirm scope/audience/API access."

        if status and status >= 500:
            return "API_BACKEND_OR_ERROR_HANDLING", "Backend returned 500/unhandled error.", "API team should return clear validation or fix backend."

        if status == 400:
            return "API_CONTRACT_CLARIFICATION", "400 validation failure.", "Need field-level validation message or sample payload."

        return "NEEDS_REVIEW", "Needs manual review.", "Review payload/response."

    # ---------------- payloads ----------------

    def version_str(self, v: Any = "1") -> str:
        s = str(v or "1")
        return "1.0" if s == "1" else s

    def version_float(self, v: Any = "1") -> float:
        try:
            return float(v)
        except Exception:
            return 1.0

    def direction(self) -> str:
        return self.ov.get("flowType") or str(self.input.get("direction") or "Outbound")

    def doc_root(self, doc: Dict[str, Any]) -> str:
        rows = ((doc.get("document_identifier") or {}).get("rows")) or []
        return str(rows[0].get("value") or "") if rows else ""

    def doc_transaction_type(self, doc: Dict[str, Any], kind: str) -> str:
        """Resolve the API transactionType, not the EDI transaction code."""
        explicit = str(doc.get("api_transaction_type") or "").strip().upper()
        if explicit in {"INBOUND", "OUTBOUND"}:
            return explicit
        return "INBOUND" if str(kind).lower() == "source" else "OUTBOUND"

    def doc_identifier_payload(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """
        Dev-reviewed v3 shape:
        {
          "operator": "ALL",
          "attributeList": [
            {"derivedFrom": "...", "expression": "...", "value": "..."}
          ]
        }
        """
        exact = (
            doc.get("api_document_identifier")
            or doc.get("document_identifier_payload")
        )
        if isinstance(exact, dict) and exact.get("attributeList") is not None:
            return exact

        source = doc.get("document_identifier") or {}
        operation = str(
            source.get("operator")
            or source.get("operation")
            or "ALL"
        ).strip().upper()
        operator = "ALL" if operation in {
            "ALL", "ALL CONDITIONS ARE SATISFIED", "AND"
        } else "ANY"

        rows = (
            source.get("attributeList")
            or source.get("rows")
            or []
        )
        attribute_list: List[Dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            item: Dict[str, Any] = {
                "derivedFrom": (
                    row.get("derivedFrom")
                    or row.get("derived_from")
                    or "TRANSACTION_ROOT_ELEMENT"
                )
            }
            expression = row.get("expression")
            value = row.get("value")
            if expression not in (None, ""):
                item["expression"] = str(expression)
            if value not in (None, ""):
                item["value"] = str(value)
            attribute_list.append(item)

        if not attribute_list:
            root = self.doc_root(doc)
            if root:
                attribute_list.append({
                    "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
                    "value": root,
                })

        return {
            "operator": operator,
            "attributeList": attribute_list,
        }

    def doc_payload(self, doc: Dict[str, Any], kind: str) -> Dict[str, Any]:
        attrs: List[Dict[str, Any]] = []
        for a in doc.get("attributes_to_configure", []):
            if not isinstance(a, dict):
                continue
            item: Dict[str, Any] = {
                "attributeName": a.get("attribute_name") or a.get("attributeName"),
                "derivedFrom": (
                    a.get("derived_from")
                    or a.get("derivedFrom")
                    or "ELEMENT_IN_PAYLOAD"
                ),
                "usage": [
                    x.strip()
                    for x in (
                        a.get("usage")
                        if isinstance(a.get("usage"), list)
                        else str(a.get("usage") or "").split(",")
                    )
                    if str(x).strip()
                ],
            }
            expression = a.get("expression")
            if expression not in (None, ""):
                item["expression"] = str(expression)
            attrs.append(item)

        # This matches the Dev-team POST sample. Values remain U-HAUL-specific.
        return {
            "name": doc.get("name"),
            "dataFormatType": doc.get("data_format_type") or "XML",
            "transactionType": self.doc_transaction_type(doc, kind),
            "version": self.version_str(doc.get("version", "1")),
            "statusDisabled": bool(doc.get("status_disabled", False)),
            "description": doc.get("description") or doc.get("name"),
            "validationType": (
                doc.get("validation_type")
                or self.ov.get("document_validation_type")
                or "Structure"
            ),
            "schemaFileName": doc.get("schema_file_name") or "",
            "schemaFileContent": doc.get("schema_file_content") or "",
            "hipEnvironment": self.env,
            "documentIdentifier": self.doc_identifier_payload(doc),
            # Dev sample explicitly includes an empty lastModifiedBy.
            "lastModifiedBy": doc.get("last_modified_by") or "",
            "attributes": attrs,
            "createdBy": doc.get("created_by") or self.requester,
        }

    def _sample_file_for_document(self, doc: Dict[str, Any], exclude: str = "") -> str:
        """Choose the uploaded sample that best matches a canonical Document Type."""
        files = [p for p in INPUT_FILES.iterdir() if p.is_file()] if INPUT_FILES.exists() else []
        fmt = str(doc.get("data_format_type") or "").upper()
        if "XML" in fmt:
            allowed = {".xml"}
        elif any(x in fmt for x in ("X12", "EDI", "EDIFACT")):
            allowed = {".edi", ".x12", ".txt"}
        elif "CSV" in fmt:
            allowed = {".csv", ".txt"}
        else:
            allowed = {".xml", ".edi", ".x12", ".txt", ".csv"}
        roots = []
        ident = doc.get("document_identifier") if isinstance(doc.get("document_identifier"), dict) else {}
        for row in ident.get("rows") or []:
            if isinstance(row, dict) and row.get("value"):
                roots.append(str(row.get("value")))
        scored = []
        for file in files:
            if file.name == exclude or file.suffix.lower() not in allowed:
                continue
            score = 0
            name_lower = file.name.lower()
            doc_name = str(doc.get("name") or "").lower()
            if doc_name and any(tok and tok in name_lower for tok in re.split(r"[^a-z0-9]+", doc_name) if len(tok) > 4):
                score += 2
            try:
                sample = file.read_text(encoding="utf-8", errors="replace")[:250000]
            except Exception:
                sample = ""
            for root_value in roots:
                if root_value and root_value in sample:
                    score += 10
            if file.stat().st_size > 0:
                score += 1
            scored.append((score, file.name))
        scored.sort(key=lambda item: (-item[0], item[1].lower()))
        return scored[0][1] if scored else ""

    def _map_xbm_file(self, map_name: str) -> str:
        candidates = [p.name for p in INPUT_FILES.glob("*.xbm")] if INPUT_FILES.exists() else []
        if not candidates:
            return ""
        wanted = str(map_name or "").lower()
        for name in candidates:
            if wanted and wanted in Path(name).stem.lower():
                return name
        return sorted(candidates)[0]

    def map_payload(self, with_xref: bool) -> Dict[str, Any]:
        m = self.data_map()
        jar_name = str(m.get("map_data_file") or "")
        xbm_name = self._map_xbm_file(str(m.get("map_name") or ""))
        source_sample = self._sample_file_for_document(self.source_doc())
        target_sample = self._sample_file_for_document(self.target_doc(), exclude=source_sample)
        if not target_sample:
            target_sample = self._sample_file_for_document(self.target_doc())
        cross: List[Dict[str, Any]] = []
        if with_xref and xbm_name:
            xbm_b64 = b64_file(INPUT_FILES / xbm_name)
            if xbm_b64:
                cross.append({
                    "crossReferenceMapData": xbm_b64,
                    "crossReferenceMapDataFilename": xbm_name,
                    "crossReferenceMapNasLocation": "",
                })
        return {
            "mapName": m.get("map_name"),
            "hipEnvironment": self.env,
            "mapIdentifier": m.get("map_identifier"),
            "mapIdentifierVersion": self.version_float(m.get("map_identifier_version", "1")),
            "requestedBy": self.requester,
            "status": "1",
            "mapClassName": m.get("map_class"),
            "contivoVersion": m.get("contivo_version"),
            "mapFileName": jar_name,
            "mapData": b64_file(INPUT_FILES / jar_name) if jar_name else "",
            "inputSchema": text_file(INPUT_FILES / source_sample) if source_sample else "",
            "inputSchemaFileName": source_sample,
            "outputSchema": text_file(INPUT_FILES / target_sample) if target_sample else "",
            "outputSchemaFileName": target_sample,
            "isCrossRef": bool(cross),
            "crossReferenceMapList": cross,
            "crossReferenceMapParameters": {},
        }

    def normalize_operator(self, op: str) -> str:
        v = (op or "").strip()
        return {"equals": "Equals", "contains": "Contains", "startswith": "StartsWith"}.get(v.lower(), v or "Equals")

    def source_doc_id(self) -> int:
        # Never fall back to a historical packaged Document Type ID. The Rule
        # FK must use an ID returned/resolved in the current LIVE environment.
        return int(self.runtime_state.get("source_document_type_id") or 0)

    def target_doc_id(self) -> int:
        return int(self.runtime_state.get("target_document_type_id") or 0)

    def map_id(self) -> int:
        # V108 NO-REUSE policy: a MAP ID must come from this LIVE run only.
        return int(self.runtime_state.get("map_id") or 0)

    def rule_id(self) -> int:
        # Rule IDs are also environment-owned runtime values.
        return int(self.runtime_state.get("rule_id") or 0)

    @staticmethod
    def _first_int(value: Any) -> Optional[int]:
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, float) and value.is_integer():
            return int(value)
        if isinstance(value, str) and value.strip().isdigit():
            return int(value.strip())
        return None

    def capture_runtime_state(self, step_key: str, result: Result) -> None:
        """Capture created/existing IDs so downstream payloads use live values."""
        extracted = result.extracted or {}

        def candidates(node: Any, names: set[str]) -> List[int]:
            found: List[int] = []
            if isinstance(node, dict):
                for key, value in node.items():
                    if str(key).lower() in names:
                        parsed = self._first_int(value)
                        if parsed is not None:
                            found.append(parsed)
                    found.extend(candidates(value, names))
            elif isinstance(node, list):
                for item in node:
                    found.extend(candidates(item, names))
            return found

        # Preserve any authoritative flow-definition parent reference observed
        # from validation/orchestration responses for subsequent Rule retries.
        flow_definition_values = candidates(extracted, {"flowdefinitionid"})
        if flow_definition_values and flow_definition_values[0] > 0:
            self.runtime_state["flow_definition_id"] = flow_definition_values[0]

        if step_key == "doctype_source":
            # Entity-specific IDs are authoritative. A generic wrapper `id` can
            # be a work-order/task/request ID and must never feed RULE_DOCUMENTTYPE.
            values = candidates(extracted, {"documenttypeid"})
            if values:
                self.runtime_state["source_document_type_id"] = values[0]
        elif step_key == "doctype_target":
            values = candidates(extracted, {"documenttypeid"})
            if values:
                self.runtime_state["target_document_type_id"] = values[0]
        elif step_key in {"map", "map_primary", "map_fallback"}:
            values = candidates(extracted, {"mapid"})
            if not values:
                values = candidates(extracted, {"id"})
            if values:
                self.runtime_state["map_id"] = values[0]
        elif step_key == "rule":
            values = candidates(extracted, {"ruleid"})
            if not values:
                values = candidates(extracted, {"id"})
            if values:
                self.runtime_state["rule_id"] = values[0]
        elif step_key == "flow_create":
            values = candidates(extracted, {"flowid"})
            if not values:
                values = candidates(extracted, {"id"})
            if values:
                self.runtime_state["flow_id"] = values[0]
            version = extracted.get("flowVersion")
            if version not in (None, ""):
                self.runtime_state["flow_version"] = str(version)

    def required_live_runtime_id(self, step_key: str) -> Optional[int]:
        """Return the current-environment ID required to safely resolve a step.

        Document Type and Rule IDs are never inferred from packaged history.
        The MAC Map may use the explicitly approved reusable map_id configured
        for the current U-HAUL baseline when HIP reports the map already exists.
        """
        key = canonical_step_key(step_key)
        if key == "doctype_source":
            return self._first_int(self.runtime_state.get("source_document_type_id"))
        if key == "doctype_target":
            return self._first_int(self.runtime_state.get("target_document_type_id"))
        if key == "map":
            return self._first_int(self.runtime_state.get("map_id") or self.ov.get("map_id"))
        if key == "rule":
            return self._first_int(self.runtime_state.get("rule_id"))
        if key == "flow_create":
            # Flow downstream APIs use name/version, so flowId is useful evidence
            # but is not mandatory for deploy/history progression.
            return self._first_int(self.runtime_state.get("flow_id"))
        return None

    def step_requires_live_id_for_progress(self, step_key: str) -> bool:
        # V115 contract-aware dependency rule (Dev correction 2026-09-01):
        # - Document Type is referenced downstream by name + version.
        # - MAC Map is referenced by mapIdentifier + mapVersion.
        # - Mapping Rule is referenced inside Flow ruleRefs by name + version.
        # - Flow Deploy/History use Flow name + version.
        # Therefore no canonical dependency requires a numeric object ID merely
        # to progress. IDs returned by HIP may still be captured as evidence.
        canonical_step_key(step_key)
        return False

    @staticmethod
    def is_rule_document_type_fk_failure(result: Result) -> bool:
        text = (str(result.response_preview or "") + " " + str(result.error or "") + " " + str(result.issue or "")).lower()
        return any(marker in text for marker in (
            "rule_documenttype", "fk_rule_documenttype",
            "parent key not found in rule_documenttype",
        ))

    @staticmethod
    def is_rule_flow_definition_fk_failure(result: Result) -> bool:
        text = (str(result.response_preview or "") + " " + str(result.error or "") + " " + str(result.issue or "")).lower()
        return (
            any(marker in text for marker in (
                "fk_mac_rule_flow_def", "mac_rule_flow_def",
                "flowdefinitionid", "flow_definition_id",
            ))
            and ("parent key not found" in text or "ora-02291" in text or "integrity constraint" in text)
        )

    def annotate_rule_flow_definition_fk_failure(self, result: Result) -> bool:
        if not self.is_rule_flow_definition_fk_failure(result):
            return False
        result.extracted = dict(result.extracted or {})
        result.extracted["backendContractMismatch"] = {
            "constraint": "FK_MAC_RULE_FLOW_DEF",
            "requestFlowDefinitionId": None,
            "requestContainsFlowDefinitionId": False,
            "runtimeIdMutationPerformed": False,
            "retrySafe": False,
        }
        result.classification = "API_BACKEND_CONTRACT_MISMATCH"
        result.business_success = False
        result.deterministic_owner = "API_BACKEND_CONTRACT_MISMATCH"
        result.final_owner = "API_BACKEND_CONTRACT_MISMATCH"
        result.issue = (
            "HIP backend returned FK_MAC_RULE_FLOW_DEF even though the V108 "
            "developer-approved standalone Mapping Rule request omits flowDefinitionId."
        )
        result.action_required = (
            "Do not mutate the Rule payload or inject a parent ID. Keep the corrected "
            "developer-approved payload unchanged and route the FK to the API/backend team."
        )
        return False

    def invalidate_rule_document_type_runtime(self, result: Result) -> bool:
        """Compatibility shim: classify stale Rule FK behavior without ID repair.

        The current developer-approved Mapping Rule request does not carry
        documentTypeId. Re-resolving or changing a Source Document Type ID cannot
        truthfully repair RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE. The backend
        must align its persistence contract with name + version.
        """
        if not self.is_rule_document_type_fk_failure(result):
            return False
        result.extracted = dict(result.extracted or {})
        result.extracted["backendContractMismatch"] = {
            "constraint": "RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE",
            "requestContainsDocumentTypeId": False,
            "documentTypeResolution": "name+version",
            "runtimeIdMutationPerformed": False,
        }
        result.classification = "API_BACKEND_CONTRACT_MISMATCH"
        result.business_success = False
        result.deterministic_owner = "API_BACKEND_CONTRACT_MISMATCH"
        result.final_owner = "API_BACKEND_CONTRACT_MISMATCH"
        result.issue = (
            "HIP backend referenced RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE even though "
            "the approved Mapping Rule request resolves Document Type by name + version."
        )
        result.action_required = (
            "API/backend team should correct the Rule persistence contract. Keep "
            "documentTypeId omitted; no runtime Document Type ID repair is valid."
        )
        return False

    @staticmethod
    def _normalized_version_value(value: Any) -> str:
        raw = str(value or "").strip()
        if not raw:
            return ""
        try:
            number = float(raw)
            if number.is_integer():
                return f"{number:.1f}"
            return str(number)
        except Exception:
            return raw

    def _exact_rule_ids_from_read_response(
        self,
        body: Any,
        *,
        rule_name: str,
        rule_version: str,
        environment: str,
        environment_scoped: bool,
    ) -> List[int]:
        """Extract one exact Rule identity from heterogeneous current-LIVE reads.

        This parser is intentionally customer-agnostic and wrapper-agnostic. HIP
        Rule reads have appeared as detail objects, collection rows, paged content,
        ``availableEnvironments`` maps/lists, and ``versions`` arrays.  A numeric
        ID is accepted only when the same current response proves exact Rule name,
        exact version, and the requested environment (or the request itself is
        explicitly environment-scoped).  No local KB/package ID is consulted.
        """
        wanted_name = str(rule_name or "").strip()
        wanted_version = self._normalized_version_value(rule_version)
        wanted_env = str(environment or "").strip().upper()
        found: set[int] = set()

        name_keys = ("ruleName", "rule_name", "name", "displayName", "objectName")
        env_keys = ("hipEnvironment", "hip_environment", "environment", "environmentName", "env")
        id_keys = ("ruleId", "rule_id", "primaryRuleId", "primaryId", "objectId", "id")
        version_keys = ("ruleVersion", "rule_version", "version")
        dev_version_keys = ("latestDevVersion", "latestDEVVersion", "devVersion")
        environment_container_keys = (
            "availableEnvironments", "environments", "environmentVersions",
            "versionsByEnvironment", "environmentVersionDetails",
        )

        def exact_version(value: Any) -> bool:
            return bool(wanted_version) and self._normalized_version_value(value) == wanted_version

        def first_value(node: Dict[str, Any], keys: tuple[str, ...]) -> Any:
            for key in keys:
                value = node.get(key)
                if value not in (None, ""):
                    return value
            return None

        def has_target_environment(node: Dict[str, Any]) -> bool:
            for key in environment_container_keys:
                value = node.get(key)
                if isinstance(value, dict):
                    for env_key, env_value in value.items():
                        if str(env_key).strip().upper() == wanted_env:
                            if not isinstance(env_value, dict):
                                return True
                            versions = env_value.get("versions") or env_value.get("ruleVersions") or []
                            if not versions:
                                return True
                            if any(isinstance(v, dict) and exact_version(first_value(v, version_keys)) for v in versions):
                                return True
                elif isinstance(value, list):
                    for item in value:
                        if not isinstance(item, dict):
                            continue
                        item_env = str(first_value(item, env_keys) or "").strip().upper()
                        if item_env == wanted_env:
                            versions = item.get("versions") or item.get("ruleVersions") or []
                            if not versions or any(isinstance(v, dict) and exact_version(first_value(v, version_keys)) for v in versions):
                                return True
                elif isinstance(value, str) and wanted_env and wanted_env in value.upper():
                    return True
            return False

        def add_id(node: Dict[str, Any]) -> None:
            candidate = self._first_int(first_value(node, id_keys))
            if candidate and candidate > 0:
                found.add(candidate)

        def walk(node: Any, inherited_name: str = "", inherited_env: str = "") -> None:
            if isinstance(node, list):
                for item in node:
                    walk(item, inherited_name, inherited_env)
                return
            if not isinstance(node, dict):
                return

            local_name = str(first_value(node, name_keys) or inherited_name or "").strip()
            local_env = str(first_value(node, env_keys) or inherited_env or "").strip().upper()
            name_matches = local_name == wanted_name
            env_matches = local_env == wanted_env if local_env else bool(environment_scoped)

            version = first_value(node, version_keys)
            dev_version = first_value(node, dev_version_keys)

            # Direct detail/summary row. latestDevVersion is explicit DEV evidence.
            if name_matches and exact_version(version) and (env_matches or has_target_environment(node)):
                add_id(node)
            if name_matches and exact_version(dev_version) and wanted_env == "DEV":
                add_id(node)

            # Summary shape: exact Rule row -> DEV/environment row -> versions[].
            versions = node.get("versions")
            if not isinstance(versions, list):
                versions = node.get("ruleVersions") if isinstance(node.get("ruleVersions"), list) else None
            if name_matches and isinstance(versions, list) and (env_matches or has_target_environment(node)):
                for row in versions:
                    if not isinstance(row, dict) or not exact_version(first_value(row, version_keys)):
                        continue
                    candidate = self._first_int(first_value(row, id_keys))
                    if candidate and candidate > 0:
                        found.add(candidate)

            # Environment dictionaries are often keyed by DEV/TEST1/... rather
            # than carrying hipEnvironment inside each child object.
            for key in environment_container_keys:
                value = node.get(key)
                if isinstance(value, dict):
                    for env_key, env_value in value.items():
                        if isinstance(env_value, (dict, list)):
                            walk(env_value, local_name, str(env_key).strip().upper())
                elif isinstance(value, list):
                    walk(value, local_name, local_env)

            for key, value in node.items():
                if key in set(environment_container_keys) | {"versions", "ruleVersions"}:
                    continue
                if isinstance(value, (dict, list)):
                    walk(value, local_name, local_env)

        walk(body)
        return sorted(found)

    def _exact_rule_ids_from_read_text(
        self,
        text: Any,
        *,
        rule_name: str,
        rule_version: str,
        environment: str,
    ) -> List[int]:
        """Conservative exact Rule-ID extraction from a current non-JSON response.

        This exists for Dell read surfaces that return HTML/text wrappers around
        the Rule inventory.  It never searches local files.  The exact Rule name,
        requested environment, requested version, and an explicit ``ruleId`` or
        ``Primary ID`` marker must occur in the same bounded response window.
        """
        raw = str(text or "")
        wanted_name = str(rule_name or "").strip()
        wanted_version = self._normalized_version_value(rule_version)
        wanted_env = str(environment or "").strip().upper()
        if not raw or not wanted_name or not wanted_version or not wanted_env:
            return []
        found: set[int] = set()

        # Prefer an exact enclosing HTML table row when available. This avoids
        # collecting IDs from adjacent Rule rows in a large page and also
        # supports the SecureLink inventory shape where the numeric rule ID is
        # a dedicated table cell rather than an explicit ``ruleId:`` label.
        for row_match in re.finditer(r"(?is)<tr\b[^>]*>.*?</tr>", raw):
            row = row_match.group(0)
            if wanted_name.lower() not in row.lower() or wanted_env not in row.upper():
                continue
            cells = [
                re.sub(r"\s+", " ", re.sub(r"(?is)<[^>]+>", " ", cell)).strip()
                for cell in re.findall(r"(?is)<td\b[^>]*>(.*?)</td>", row)
            ]
            if wanted_name not in cells or wanted_version not in cells:
                continue
            name_index = cells.index(wanted_name)
            version_index = cells.index(wanted_version)
            if version_index > name_index:
                for cell in cells[name_index + 1:version_index]:
                    if re.fullmatch(r"\d+", cell or ""):
                        candidate = self._first_int(cell)
                        if candidate and candidate > 0:
                            found.add(candidate)
                            break
            for pat in (
                r'(?i)["\']ruleId["\']\s*[:=]\s*["\']?(\d+)',
                r'(?i)ruleId(?:&#x27;|&quot;|["\'])?\s*[:=]\s*(\d+)',
                r'(?i)Primary\s+ID\s*</dt>\s*<dd>\s*(\d+)',
            ):
                for match in re.findall(pat, row):
                    candidate = self._first_int(match)
                    if candidate and candidate > 0:
                        found.add(candidate)
        if len(found) == 1:
            return sorted(found)

        lower = raw.lower()
        needle = wanted_name.lower()
        pos = 0
        while True:
            idx = lower.find(needle, pos)
            if idx < 0:
                break
            window = raw[max(0, idx - 2200): min(len(raw), idx + len(wanted_name) + 4200)]
            window_upper = window.upper()
            version_patterns = (
                rf'(?i)(?:ruleVersion|rule_version|version)["\'\s:=<>/]*{re.escape(wanted_version)}(?:\D|$)',
                rf'(?i)Version(?:\(s\))?["\'\s:=<>/]*{re.escape(wanted_version)}(?:\D|$)',
                rf'(?i)<td[^>]*>\s*{re.escape(wanted_version)}\s*</td>',
            )
            if wanted_env in window_upper and any(re.search(pat, window) for pat in version_patterns):
                id_patterns = (
                    r'(?i)["\']ruleId["\']\s*[:=]\s*["\']?(\d+)',
                    r'(?i)ruleId(?:&#x27;|&quot;|["\'])?\s*[:=]\s*(\d+)',
                    r'(?i)Primary\s+ID\s*</dt>\s*<dd>\s*(\d+)',
                )
                for pat in id_patterns:
                    for match in re.findall(pat, window):
                        candidate = self._first_int(match)
                        if candidate and candidate > 0:
                            found.add(candidate)
            pos = idx + len(needle)
        return sorted(found)

    def resolve_current_live_rule_id(self, result: Result) -> Optional[int]:
        """Resolve an exact current-environment Rule ID after the canonical POST.

        V113 generalizes the current-LIVE read-only resolver using the actual Rules
        portal behavior: ``/api/rule/summary`` is commonly loaded as an ordinary
        listing (without search parameters) and carries environment/version rows
        that contain ``ruleId``.  Some gateways reject or ignore ad-hoc search
        parameters, so the resolver tries exact targeted reads, plain summary
        reads, environment-scoped summary reads, and finally bounded pagination.
        It never changes/retries the Rule POST and never consumes a packaged or
        historical Rule ID.
        """
        target_name = str(self.business.get("mappingRuleName") or self.rule().get("name") or "").strip()
        target_version = str(self.business.get("mappingRuleVersion") or self.rule().get("version") or "1.0").strip()
        target_env = str(self.env or "DEV").strip().upper()
        if not target_name:
            return None

        # First consume only same-call response identity evidence, if the API
        # exposed a standards-compliant Location/Content-Location header. This is
        # current-LIVE evidence, not reuse, and requires no second mutation.
        for _key in ("responseLocation", "responseContentLocation"):
            _location = str((result.extracted or {}).get(_key) or "")
            _match = re.search(r"(?i)/rule(?:s)?/(\d+)(?:/details)?(?:[/?#]|$)", _location)
            if _match:
                _candidate = self._first_int(_match.group(1))
                if _candidate and _candidate > 0:
                    self.runtime_state["rule_id"] = _candidate
                    result.extracted = dict(result.extracted or {})
                    result.extracted["liveRuleIdResolution"] = {
                        "resolved": True, "ruleId": _candidate, "ruleName": target_name,
                        "ruleVersion": target_version, "hipEnvironment": target_env,
                        "source": "CURRENT_RULE_POST_RESPONSE_LOCATION",
                        "requestPayloadMutated": False, "historicalIdUsed": False,
                    }
                    return _candidate

        attempts: List[Dict[str, Any]] = []
        seen_requests: set[str] = set()

        legacy_rule_base = str(os.getenv("HIP_RULE_LEGACY_READ_BASE_URL") or "https://apigtwtst.us.dell.com/hip/map-rule/api/rule").rstrip("/")
        portal_rule_base = str(os.getenv("HIP_RULE_PORTAL_READ_BASE_URL") or "https://developer.dell.com/inaas-gateway/hipService-svc/api/rule").rstrip("/")
        config_rule_base = f"{self.hip_config_service_base_url}/api/rule"
        # Optional API-team supplied current-LIVE listing base. It is not guessed
        # or hardcoded; when absent, the existing approved/provider surfaces are
        # used. This keeps future-customer routing configurable without code edits.
        extra_rule_read_base = str(os.getenv("HIP_RULE_READ_BASE_URL") or "").strip().rstrip("/")

        detail_urls = [
            str(self.urls.get("rule_details") or "").strip(),
            f"{config_rule_base}/details",
            f"{legacy_rule_base}/details",
            f"{portal_rule_base}/details",
            f"{extra_rule_read_base}/details" if extra_rule_read_base else "",
        ]
        rule_root_urls = [
            config_rule_base,
            legacy_rule_base,
            portal_rule_base,
            extra_rule_read_base,
        ]
        summary_urls = [
            str(self.urls.get("rule_summary") or "").strip(),
            f"{config_rule_base}/summary",
            f"{legacy_rule_base}/summary",
            f"{portal_rule_base}/summary",
            f"{extra_rule_read_base}/summary" if extra_rule_read_base else "",
        ]

        def unique_urls(values: List[str]) -> List[str]:
            out: List[str] = []
            for raw in values:
                value = str(raw or "").strip().rstrip("/")
                if value and value not in out:
                    out.append(value)
            return out

        def vetted(url: str) -> tuple[bool, str]:
            parsed_url = urlparse(str(url))
            host = str(parsed_url.hostname or "").lower()
            ok = parsed_url.scheme.lower() == "https" and (host == "dell.com" or host.endswith(".dell.com"))
            return ok, host

        def request_once(source: str, url: str, params: Optional[Dict[str, Any]], *, environment_scoped: bool) -> Optional[int]:
            canonical_params = dict(params or {})
            request_key = json.dumps([url, sorted((str(k), str(v)) for k, v in canonical_params.items())], separators=(",", ":"))
            if request_key in seen_requests:
                return None
            seen_requests.add(request_key)
            ok, host = vetted(url)
            if not ok:
                attempts.append({
                    "source": source, "method": "GET", "url": url, "params": canonical_params,
                    "error": "RULE_ID_LOOKUP_ENDPOINT_REJECTED: HTTPS Dell-owned host required",
                    "host": host, "exactIds": [],
                })
                return None
            try:
                response = self._request_with_retry(
                    method="GET", url=url, token_kind="HIP", scope=self.scopes.get("rule", ""),
                    extra_headers=None, payload=None, params=canonical_params or None,
                )
                body = None
                try:
                    body = response.json()
                except Exception:
                    body = None
                ids = self._exact_rule_ids_from_read_response(
                    body, rule_name=target_name, rule_version=target_version, environment=target_env,
                    environment_scoped=environment_scoped,
                ) if body is not None else []
                parsed_from_text = False
                if not ids and body is None and int(response.status_code or 0) < 400:
                    ids = self._exact_rule_ids_from_read_text(
                        response.text, rule_name=target_name, rule_version=target_version, environment=target_env
                    )
                    parsed_from_text = bool(ids)
                # A standards-compliant read endpoint may expose the identity in
                # Location/Content-Location even when the response body is empty.
                if not ids and int(response.status_code or 0) < 400:
                    for location_header in ("Location", "Content-Location"):
                        location = str(response.headers.get(location_header) or "")
                        m = re.search(r"(?i)/rule(?:s)?/(\d+)(?:/details)?(?:[/?#]|$)", location)
                        if m:
                            candidate = self._first_int(m.group(1))
                            if candidate and candidate > 0:
                                ids = [candidate]
                                break
                attempt = {
                    "source": source, "method": "GET", "url": url, "params": canonical_params,
                    "statusCode": int(response.status_code or 0), "exactIds": ids,
                }
                if parsed_from_text:
                    attempt["parsedFromText"] = True
                if body is None:
                    attempt["nonJsonResponse"] = True
                    attempt["contentType"] = str(response.headers.get("content-type") or "")[:200]
                else:
                    try:
                        compact_body = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str)
                        attempt["bodySha256"] = hashlib.sha256(compact_body.encode("utf-8")).hexdigest()
                    except Exception:
                        pass
                    if isinstance(body, list):
                        attempt["responseShape"] = "list"
                        attempt["responseItemCount"] = len(body)
                    elif isinstance(body, dict):
                        attempt["responseShape"] = "dict"
                        attempt["responseTopKeys"] = sorted(str(k) for k in body.keys())[:40]
                        for list_key in ("content", "data", "items", "results", "rules", "ruleList", "records"):
                            if isinstance(body.get(list_key), list):
                                attempt["responseListKey"] = list_key
                                attempt["responseItemCount"] = len(body.get(list_key) or [])
                                break
                attempts.append(attempt)
                if len(ids) == 1:
                    return ids[0]
                if len(ids) > 1:
                    # Exact identity must be unique. Never guess.
                    raise RuntimeError(f"AMBIGUOUS_CURRENT_RULE_ID:{ids}")
            except RuntimeError as exc:
                if str(exc).startswith("AMBIGUOUS_CURRENT_RULE_ID:"):
                    raise
                attempts.append({
                    "source": source, "method": "GET", "url": url, "params": canonical_params,
                    "error": f"{type(exc).__name__}: {exc}", "exactIds": [],
                })
            except Exception as exc:
                attempts.append({
                    "source": source, "method": "GET", "url": url, "params": canonical_params,
                    "error": f"{type(exc).__name__}: {exc}", "exactIds": [],
                })
            return None

        resolved_id: Optional[int] = None
        try:
            # Targeted detail queries: support both environment spellings seen in
            # HIP service and portal contracts.
            for url in unique_urls(detail_urls):
                for params in (
                    {"ruleName": target_name, "environment": target_env, "ruleVersion": target_version},
                    {"ruleName": target_name, "hipEnvironment": target_env, "ruleVersion": target_version},
                    {"name": target_name, "hipEnvironment": target_env, "version": target_version},
                ):
                    resolved_id = request_once("details-targeted", url, params, environment_scoped=True)
                    if resolved_id:
                        break
                if resolved_id:
                    break

            # Targeted summary/search queries before any broad scan.
            if not resolved_id:
                for url in unique_urls(summary_urls):
                    for params in (
                        {"ruleName": target_name, "hipEnvironment": target_env},
                        {"ruleName": target_name, "environment": target_env},
                        {"name": target_name, "hipEnvironment": target_env},
                        {"search": target_name, "hipEnvironment": target_env},
                        {"searchText": target_name, "hipEnvironment": target_env},
                    ):
                        resolved_id = request_once("summary-targeted", url, params, environment_scoped=False)
                        if resolved_id:
                            break
                    if resolved_id:
                        break

            # The real SecureLink Rules page loads /api/rule/summary as a plain
            # listing.  V111 missed this exact request shape.  Read the current
            # LIVE listing without parameters, then with only the environment.
            # These are GET-only identity reads; they do not skip or replace the
            # canonical Rule POST.
            if not resolved_id:
                for url in unique_urls(summary_urls):
                    for source, params, scoped in (
                        ("summary-plain", None, False),
                        ("summary-environment", {"hipEnvironment": target_env}, True),
                        ("summary-environment-alias", {"environment": target_env}, True),
                    ):
                        resolved_id = request_once(source, url, params, environment_scoped=scoped)
                        if resolved_id:
                            break
                    if resolved_id:
                        break

            # Some Rule services expose the listing directly on the collection
            # root rather than /summary. Try the ordinary GET first, then exact
            # targeted/environment forms. This remains read-only and generic.
            if not resolved_id:
                for url in unique_urls(rule_root_urls):
                    for source, params, scoped in (
                        ("rule-root-plain", None, False),
                        ("rule-root-environment", {"hipEnvironment": target_env}, True),
                        ("rule-root-targeted", {"ruleName": target_name, "hipEnvironment": target_env, "ruleVersion": target_version}, True),
                        ("rule-root-targeted-alias", {"name": target_name, "environment": target_env, "version": target_version}, True),
                    ):
                        resolved_id = request_once(source, url, params, environment_scoped=scoped)
                        if resolved_id:
                            break
                    if resolved_id:
                        break

            # Bounded deterministic pagination. The Rules portal inventory is a
            # listing API; a first-page-only request can miss U-HAUL. Try the two
            # common pagination parameter families and stop as soon as an exact
            # name/version/DEV match is found.
            if not resolved_id:
                max_pages = max(1, min(int(os.getenv("HIP_RULE_LOOKUP_MAX_PAGES", "25") or 25), 100))
                page_size = max(25, min(int(os.getenv("HIP_RULE_LOOKUP_PAGE_SIZE", "500") or 500), 1000))
                for url in unique_urls(summary_urls):
                    if resolved_id:
                        break
                    for page_style, start_page in (("page", 0), ("pageNumber", 1)):
                        if resolved_id:
                            break
                        previous_fingerprints: set[str] = set()
                        for offset in range(max_pages):
                            page = start_page + offset
                            if page_style == "page":
                                params = {"hipEnvironment": target_env, "page": page, "size": page_size}
                            else:
                                params = {"hipEnvironment": target_env, "pageNumber": page, "pageSize": page_size}
                            before_count = len(attempts)
                            resolved_id = request_once(f"summary-pagination-{page_style}", url, params, environment_scoped=False)
                            if resolved_id:
                                break
                            # Stop quickly when pagination is unsupported, empty,
                            # or ignored.  The body digest makes this deterministic
                            # without inspecting or mutating the request payload.
                            if len(attempts) > before_count:
                                last = attempts[-1]
                                status = int(last.get("statusCode") or 0)
                                if status >= 400:
                                    break
                                if last.get("responseItemCount") == 0:
                                    break
                                fingerprint = str(last.get("bodySha256") or json.dumps(
                                    [status, last.get("exactIds"), last.get("nonJsonResponse")], sort_keys=True
                                ))
                                if fingerprint in previous_fingerprints:
                                    break
                                previous_fingerprints.add(fingerprint)
        except RuntimeError as exc:
            attempts.append({"source": "identity-policy", "error": str(exc), "exactIds": []})
            resolved_id = None

        if resolved_id and resolved_id > 0:
            self.runtime_state["rule_id"] = resolved_id
            result.extracted = dict(result.extracted or {})
            result.extracted["liveRuleIdResolution"] = {
                "resolved": True, "ruleId": resolved_id, "ruleName": target_name,
                "ruleVersion": target_version, "hipEnvironment": target_env,
                "source": "CURRENT_LIVE_RULE_READ", "requestPayloadMutated": False,
                "historicalIdUsed": False, "attempts": attempts,
            }
            atomic_write_json(REPORTS / "live_rule_id_resolution_latest.json", redact_sensitive(result.extracted["liveRuleIdResolution"]))
            return resolved_id

        result.extracted = dict(result.extracted or {})
        result.extracted["liveRuleIdResolution"] = {
            "resolved": False, "ruleName": target_name, "ruleVersion": target_version,
            "hipEnvironment": target_env, "source": "CURRENT_LIVE_RULE_READ",
            "requestPayloadMutated": False, "historicalIdUsed": False, "attempts": attempts,
            "configuration": {
                "ruleDetailsOverride": "HIP_RULE_DETAILS_API_URL",
                "ruleSummaryOverride": "HIP_RULE_SUMMARY_API_URL",
                "legacyReadBaseOverride": "HIP_RULE_LEGACY_READ_BASE_URL",
                "portalReadBaseOverride": "HIP_RULE_PORTAL_READ_BASE_URL",
                "genericReadBaseOverride": "HIP_RULE_READ_BASE_URL",
            },
        }
        atomic_write_json(REPORTS / "live_rule_id_resolution_latest.json", redact_sensitive(result.extracted["liveRuleIdResolution"]))
        return None

    def standalone_runtime_requirements(self, step_key: str) -> Dict[str, int]:
        """Numeric current-environment IDs required by an isolated API call."""
        key = canonical_step_key(step_key)
        required: Dict[str, int] = {}
        if key == "rule":
            # Developer-approved Rule request contains no numeric dependency IDs.
            pass
        elif key == "flow_create" and self.is_translation():
            # V115 Dev correction (2026-09-01): Flow ruleRefs use Mapping Rule
            # name + version only. A numeric ruleId is neither sent nor required.
            pass
        return required

    def missing_standalone_runtime_requirements(self, step_key: str) -> List[str]:
        return [name for name, value in self.standalone_runtime_requirements(step_key).items() if not self._first_int(value)]

    def enforce_live_id_integrity(self, step_key: str, result: Result, *, require_dependency_ids: Optional[bool] = None) -> bool:
        """Capture LIVE IDs and decide whether this result may unblock dependencies.

        This is shared by whole-pipeline LIVE execution and individual API/Flow
        blocks so every entry point follows the same environment-ID integrity
        policy.
        """
        key = canonical_step_key(step_key)
        result.extracted = dict(result.extracted or {})
        with self._runtime_state_lock:
            self.capture_runtime_state(key, result)
            if key == "rule":
                # V108 treats both known permanent Rule FK failures as contract
                # evidence. Neither condition is repaired through invented IDs.
                self.invalidate_rule_document_type_runtime(result)
                self.annotate_rule_flow_definition_fk_failure(result)
        from report_insights import analyze_api_response
        analysis = analyze_api_response(result)
        progress = bool(result.business_success) or str(analysis.get("outcome") or "").upper() == "EXISTING" or str(analysis.get("verdict") or "").upper() == "PASS"
        require_ids = self.strict_live_pipeline_mode if require_dependency_ids is None else bool(require_dependency_ids)
        if progress and require_ids and self.step_requires_live_id_for_progress(key):
            runtime_id = self.required_live_runtime_id(key)
            result.extracted["liveIdRequired"] = True
            if not runtime_id:
                result.classification = "LIVE_ID_UNRESOLVED"
                result.business_success = False
                result.issue = (
                    f"{FLOW_STEP_DEFINITIONS[key]['label']} exists/succeeded but HIP did not provide or expose an exact current-environment ID required by downstream APIs."
                )
                result.action_required = (
                    "Resolve the exact entity ID from a current LIVE read endpoint; do not use a packaged historical ID. "
                    "For Rule identity, configure HIP_RULE_DETAILS_API_URL/HIP_RULE_SUMMARY_API_URL if the API team uses a different read endpoint."
                )
                result.extracted["liveIdResolved"] = False
                return False
            result.extracted["liveIdResolved"] = True
            result.extracted["liveId"] = runtime_id
        return progress

    def write_mapping_manifest(self) -> Path:
        path = REPORTS / "uhal_input_to_api_mapping_manifest.json"
        source_manifest = (
            self.mcp_input_validation.get("executionManifest")
            if isinstance(self.mcp_input_validation, dict)
            else None
        ) or self.mapper.execution_manifest()
        manifest = json.loads(json.dumps(source_manifest, default=str))
        if isinstance(manifest, dict):
            manifest["mcp"] = self.mcp.status()
            manifest["mcpInputValidation"] = {
                key: value
                for key, value in self.mcp_input_validation.items()
                if key not in {"executionManifest", "lineage"}
            }
        path.write_text(
            json.dumps(manifest, indent=2, default=str),
            encoding="utf-8",
        )
        return path
    def rule_conditions(self) -> List[Dict[str, Any]]:
        out = []
        for row in ((self.rule().get("conditions") or {}).get("rows") or []):
            out.append({
                "id": 0,
                "propertyName": "Attributes",
                "attributeName": row.get("attribute_name_unit") or row.get("attribute_name"),
                "operation": self.normalize_operator(row.get("operator")),
                "value": row.get("value"),
                "unit": "",
            })
        return out

    def direct_rule_actions(self) -> List[Dict[str, Any]]:
        dm = self.data_map()
        return [{
            "id": 0,
            "name": "ApplyMapping",
            "type": "MAPPING",
            "target": "MAP",
            "params": {
                # Dev feedback 2026-08-28: do not send mapId: 0 (or any mapId)
                # in Rule actions. The approved API resolves the MAP from its
                # identifier/version values.
                "mapIdentifier": dm.get("map_identifier"),
                "mapVersion": self.version_str(dm.get("map_identifier_version", "1")),
            }
        }]

    def rule_payload(self) -> Dict[str, Any]:
        """Developer-approved standalone Mapping Rule request.

        V108 correction: do NOT send documentTypeId, actions.params.mapId, or
        flowDefinitionId. The HIP Rules UI and the accepted dev contract address
        the Document Type and Map by name/version. A synthetic flowDefinitionId
        creates the FK_MAC_RULE_FLOW_DEF failure seen in the V107 LIVE report.
        The shape is fixed here and is never changed at runtime.
        """
        r = self.rule()
        return {
            "id": 0,
            "name": r.get("name"),
            "hipEnvironment": self.env,
            "description": r.get("description") or r.get("name"),
            "ruleType": "MAPPING",
            "documentTypeName": self.source_doc().get("name"),
            "documentTypeVersion": self.version_float(self.source_doc().get("version", "1")),
            "appliesTo": "SOURCE",
            "disable": False,
            "executeAlways": False,
            "version": self.version_float(r.get("version", "1")),
            "ruleScope": "DOCUMENT",
            "executeActionWhen": "ON_SUCCESS",
            "createdBy": self.requester,
            "modifiedBy": "",
            "cacheKey": "",
            "ruleConditions": self.rule_conditions(),
            "actions": self.direct_rule_actions(),
        }

    def tp_usage(self, tp: Dict[str, Any]) -> str:
        raw = (tp.get("profile_usage") or "").strip().upper()
        if raw in ("SENDER", "SOURCE"): return "Sender"
        if raw in ("RECEIVER", "TARGET"): return "Receiver"
        return raw.title() if raw else "Sender"

    def tp_interface_type(self, tp: Dict[str, Any]) -> str:
        raw = str(tp.get("interface_type") or "SFTP HAFT").strip().upper().replace("_", "-")
        if raw in {"SFTP", "SFTP HAFT", "SFTP-HAFT"}:
            return "SFTP HAFT"
        if raw == "FTP":
            return "FTP"
        if raw in {"HTTPS", "REST", "HTTPS REST"}:
            return "HTTPS"
        if raw in {"HTTPS-AS2", "AS2", "HTTPS AS2"}:
            return "HTTPS-AS2"
        return str(tp.get("interface_type") or "SFTP HAFT").strip()

    def _resolve_interface_secrets(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Transport Profile interface values belong to the API payload.

        There is no separate TP_SOURCE/TP_TARGET credential profile and no
        `.env` secret indirection. Secure Partner values are represented by a
        `{{runtime_payload...}}` placeholder until the live request is sent.
        """
        return dict(params or {})

    def _resolve_runtime_payload_values(self, value: Any) -> Any:
        """Inject Partner-provided runtime payload values immediately before send."""
        return resolve_runtime_payload_placeholders(ROOT, value, strict=True)

    def tp_parameters(self, tp: Dict[str, Any], kind: str | None = None) -> Dict[str, Any]:
        """Build only developer-approved transport interface attributes.

        The 18 API request structure is immutable.  FILE (SFTP/FTP), HTTPS/REST,
        and HTTPS-AS2 each have a reviewed source/target ``parameters`` shape.
        Customer evidence can populate values, but it can never add a new HIP
        payload attribute.  Aliases below only translate learned/manual names
        into the exact developer-approved output key.
        """
        interface_type = self.tp_interface_type(tp)
        supplied = tp.get("interface_parameters")
        supplied = dict(supplied) if isinstance(supplied, dict) else {}
        role = str(kind or "").strip().lower()
        if role not in {"source", "target"}:
            role = "source" if self.tp_usage(tp).lower() == "sender" else "target"

        def pick(*names: str, default: Any = "") -> Any:
            for name in names:
                if name in supplied and supplied.get(name) not in (None, ""):
                    return supplied.get(name)
            return default

        def text_bool(value: Any, default: str = "False") -> str:
            if value in (None, ""):
                return default
            if isinstance(value, bool):
                return "True" if value else "False"
            raw = str(value).strip().lower()
            if raw in {"true", "yes", "1", "y"}: return "True"
            if raw in {"false", "no", "0", "n"}: return "False"
            return str(value)

        # FILE family: SFTP HAFT and FTP use the final U-HAUL/dev-tested shape.
        if interface_type in {"SFTP HAFT", "FTP"}:
            existing = str(tp.get("existing_account") or pick("Existing Account", default="Yes"))
            compression = text_bool(
                pick("Is Compression Required", default=tp.get("is_compression_required", "False"))
            ).upper()
            return {
                "Interface Environment": pick("Interface Environment", default=tp.get("interface_environment") or "UAT"),
                "File Filtering Pattern": pick("File Filtering Pattern", default=tp.get("file_filtering_pattern") or ".*\\.*"),
                "Post Transfer Action": pick("Post Transfer Action", default=tp.get("post_transfer_action") or "Move To Archive"),
                "Is Compression Required": compression,
                "Use Existing Folder": pick("Use Existing Folder", default=str(tp.get("use_existing_folder") or "No")),
                "Existing Account": existing,
                "Subscription Folder": pick("Subscription Folder", default=tp.get("subscription_folder") or ""),
                "Existing Account Name": pick("Existing Account Name", default=tp.get("existing_account_name") or ""),
            }

        # Plain HTTPS/REST Sender: exact dev-team Sender interfaceDetails shape.
        if interface_type == "HTTPS" and role == "source":
            return self._resolve_interface_secrets({
                "Protocol": pick("Protocol", default="REST"),
                "HIP URL": pick("HIP URL", "Gateway URL"),
                "Proxy URI": pick("Proxy URI"),
                "Request Method": pick("Request Method", default="POST"),
                "Request Format": pick("Request Format", default="Request Body"),
                "Sender Authentication Type": pick("Sender Authentication Type"),
                "Are Input Files Compressed?": text_bool(pick("Are Input Files Compressed?", "Is Compression Required", default="False")),
                "Sender Grant Type": pick("Sender Grant Type"),
            })

        # Plain HTTPS/REST Receiver: exact dev-team Receiver interfaceDetails shape.
        if interface_type == "HTTPS" and role == "target":
            return self._resolve_interface_secrets({
                "Protocol": pick("Protocol", default="REST"),
                "Partner URL": pick("Partner URL"),
                "Request Method": pick("Request Method", default="POST"),
                "Request Format": pick("Request Format", default="Request Body"),
                "Receiver Authentication Type": pick("Receiver Authentication Type"),
                "Gateway URL": pick("Gateway URL", "HIP URL"),
                "Are Input Files Compressed?": text_bool(pick("Are Input Files Compressed?", "Is Compression Required", default="False")),
                "Receiver Grant Type": pick("Receiver Grant Type"),
                "Receiver Token Endpoint": pick("Receiver Token Endpoint"),
                "Receiver Client Id": pick("Receiver Client Id"),
                "Receiver Client Secret": pick("Receiver Client Secret"),
            })

        # HTTPS-AS2 source/Sender. Names are normalized to the actual HIP
        # source-profile parameter keys observed in the approved/deep profiles.
        if interface_type == "HTTPS-AS2" and role == "source":
            return self._resolve_interface_secrets({
                "Partner Verification Certificate": pick(
                    "Partner Verification Certificate",
                    "Partner Public Certificate (for verification at Dell)",
                    "Partner Public Certificate",
                ),
                "AS2 URL": pick("AS2 URL", "Dell AS2 URL", "Dell AS2 endpoint URL"),
                "Partner Verification Certificate Id": pick("Partner Verification Certificate Id"),
                "Dell Identifier": pick("Dell Identifier", "Dell Identifier (AS2 ID)", "Dell AS2 ID"),
                "Interface Environment": pick("Interface Environment", default=tp.get("interface_environment") or "UAT"),
                "Partner Identifier": pick("Partner Identifier", "Partner Identifier (AS2 ID)", "Partner AS2 ID"),
                "Request Method": pick("Request Method", default="POST"),
                "Are SSL and Partner Verification Certificates identical?": pick(
                    "Are SSL and Partner Verification Certificates identical?",
                    "Are SSL and Partner Verification Certificates identical",
                ),
                "Partner Verification Certificate CN – Expiry": pick(
                    "Partner Verification Certificate CN – Expiry",
                    "Partner Verification Certificate CN - Expiry",
                    "Certificate CN - Expiry",
                    "Certificate CN – Expiry",
                ),
            })

        # HTTPS-AS2 target/Receiver.  These are the fixed receiver/outbound AS2
        # keys confirmed in the HIP deep-profile/dev evidence; only values vary.
        if interface_type == "HTTPS-AS2" and role == "target":
            return self._resolve_interface_secrets({
                "Encryption Certificate": pick("Encryption Certificate", "Encryption Certificate / Partner Public Certificate"),
                "Asynchronous MDN Required": text_bool(pick("Asynchronous MDN Required", default="False")),
                "Encryption Certificate CN – Expiry": pick("Encryption Certificate CN – Expiry", "Encryption Certificate CN - Expiry", "Certificate CN - Expiry"),
                "Signing Algorithm": pick("Signing Algorithm"),
                "Dell Identifier": pick("Dell Identifier", "Dell Identifier (AS2 ID)", "Dell AS2 ID"),
                "Interface Environment": pick("Interface Environment", default=tp.get("interface_environment") or "UAT"),
                "Encryption Certificate Id": pick("Encryption Certificate Id"),
                "Partner URL": pick("Partner URL", "Partner AS2 URL"),
                "Partner Identifier": pick("Partner Identifier", "Partner Identifier (AS2 ID)", "Partner AS2 ID"),
                "Is Compression Required": text_bool(pick("Is Compression Required", default="False")),
                "Request Method": pick("Request Method", default="POST"),
                "Encryption Algorithm": pick("Encryption Algorithm"),
            })

        # Unknown/custom interfaces may still be learned at the input-model level,
        # but they cannot mutate one of the 18 LIVE HIP API payload contracts until
        # the dev team registers an approved interfaceDetails template.
        return {}

    def tp_doc_details(self, tp: Dict[str, Any], kind: str) -> List[Dict[str, Any]]:
        doc = self.source_doc() if kind == "source" else self.effective_target_doc()
        return [{
            "documentTypeName": (tp.get("document_type") or doc.get("name") or "").split("(")[0],
            "documentTypeVersion": self.version_str(doc.get("version", "1")),
            "dataFormatType": doc.get("data_format_type") or "XML",
        }]

    def tp_direct_payload(self, tp: Dict[str, Any], kind: str, work_order_id: Any = "", task_id: Any = "") -> Dict[str, Any]:
        return {
            "workOrderId": str(work_order_id or self.ov.get("workOrderId") or ""),
            "taskId": str(task_id or self.ov.get("taskId") or ""),
            "systemType": tp.get("system_type") or ("Dell Application" if kind == "source" else "Partner"),
            "systemId": as_nonempty(self.ov.get(f"{kind}_system_id"), ""),
            "requestedBy": self.requester,
            "hipEnvironment": self.env,
            "domainId": as_nonempty(self.ov.get("domainId"), "6"),
            "transportProfileDetails": [{
                "transportProfileOperation": "create",
                "transportProfileName": tp.get("profile_name"),
                "transportProfileUsage": self.tp_usage(tp),
                "deploymentGroupId": as_nonempty(self.ov.get(f"{kind}_deployment_group_id"), ""),
                "isFirstMigration": bool(self.ov.get("isFirstMigration", True)),
                "interfaceDetails": [{
                    "interfaceType": self.tp_interface_type(tp),
                    "interfaceRole": self.ov.get("tpInterfaceRole") or "Primary",
                    "parameters": self.tp_parameters(tp, kind),
                }],
                "documentTypeDetails": self.tp_doc_details(tp, kind),
                "splitterConfig": {"isSplitRequired": False, "regexExpression": ""},
                "flowSteps": [],
                "tags": [{"key": "customer", "value": self.input.get("customer") or "CUSTOMER"}],
            }]
        }

    def tp_orch_payload(self, tp: Dict[str, Any], kind: str) -> Dict[str, Any]:
        is_source = str(kind).lower() == "source"
        tp_name = str(tp.get("profile_name") or "").strip()
        system_name = as_nonempty(self.ov.get(f"{kind}_system_name"), tp.get("partner_name"))
        haft_account = (
            self.source_account_name()
            if is_source
            else self.target_account_name()
        )
        doc = self.source_doc() if is_source else self.effective_target_doc()

        parameters = self.tp_parameters(tp, kind)
        if self.tp_interface_type(tp) in {"SFTP HAFT", "FTP"}:
            parameters = {
                **parameters,
                "Existing Account Name": haft_account,
            }

        return {
            "operation": "Create",
            "systemName": system_name,
            "systemType": tp.get("system_type") or (
                "Dell Application" if is_source else "Partner"
            ),
            "requestedBy": self.requester,
            "hipEnvironment": self.env,
            "transportProfileDetails": [{
                "transportProfileName": tp_name,
                "transportProfileUsage": self.tp_usage(tp),
                "isFirstMigration": bool(self.ov.get("isFirstMigration", True)),
                # Dev review: remove transportProfileVersion.
                # Dev review: remove flowTypeSupported.
                "transportProfileOperation": "create",
                "deploymentGroupName": DEFAULT_DEPLOYMENT_GROUP,
                "interfaceDetails": [{
                    "interfaceType": self.tp_interface_type(tp),
                    # Dev review: remove interfaceEnvironment.
                    "interfaceRole": self.ov.get("tpInterfaceRole") or "Primary",
                    "parameters": parameters,
                }],
                "isInterfaceDetailChangeRequired": bool(
                    self.ov.get("isInterfaceDetailChangeRequired", False)
                ),
                "documentTypeDetails": [{
                    "documentTypeName": doc.get("name"),
                    "documentTypeVersion": self.version_str(doc.get("version", "1")),
                    "dataFormatType": doc.get("data_format_type") or "XML",
                }],
                "isDocumentTypeChangeRequired": bool(
                    self.ov.get("isDocumentTypeChangeRequired", False)
                ),
                "flowSteps": [],
                "isFlowStepChangeRequired": bool(
                    self.ov.get("isFlowStepChangeRequired", False)
                ),
                "callbackConfig": None,
                "isCallbackConfigChangeRequired": bool(
                    self.ov.get("isCallbackConfigChangeRequired", False)
                ),
                "tags": [
                    {"key": "customer", "value": self.input.get("customer") or "CUSTOMER"},
                    {"key": "haftAccount", "value": haft_account},
                ],
                "isTagChangeRequired": bool(self.ov.get("isTagChangeRequired", False)),
                "splitterConfig": {
                    "isSplitRequired": False,
                    "regexExpression": "",
                },
                "isTPSplitterConfigChangeRequired": bool(
                    self.ov.get("isTPSplitterConfigChangeRequired", False)
                ),
                "ediConfig": None,
                "isEdiConfigurationChangeRequired": bool(
                    self.ov.get("isEdiConfigurationChangeRequired", False)
                ),
            }],
            "transportProfileEditDetails": [],
            "crqDetails": None,
            # Dev review: remove user and workType.
        }

    def processing_wait(self, seconds_key: str, default_seconds: int, reason: str) -> None:
        seconds = int(self.ov.get(seconds_key, default_seconds) or 0)
        if seconds <= 0:
            return
        print(f"Waiting {seconds}s: {reason}")
        time.sleep(seconds)

    def flow_name(self) -> str:
        # V108/V110: the canonical flow name is immutable once the Runner is
        # constructed. Invalid legacy names are stopped by production preflight;
        # they are never renamed after a failed HTTP request.
        return str(
            get_path(self.biz_flow(), "flow_details", "business_flow_name")
            or self.input.get("profile_name")
            or ""
        ).strip()

    @staticmethod
    def is_flow_create_name_conflict(result: Result) -> bool:
        # Kept as a compatibility API for older tests/callers. V110 never uses a
        # name-conflict response to create a different request.
        return False

    def allocate_unique_flow_name(self) -> str:
        raise RuntimeError(
            "IMMUTABLE_FLOW_NAME: V110 never renames Flow after an API response. "
            "Fix/rebuild canonical input before LIVE execution."
        )

    def flow_description(self) -> str:
        return (
            get_path(self.biz_flow(), "flow_details", "flow_description")
            or self.business.get("flowDescription")
            or f"{self.direction()} {self.input.get('tx_code') or ''} flow for {self.input.get('customer') or 'customer'}"
        )

    def source_tp_name(self) -> str:
        return get_path(self.biz_flow(), "configure_source", "source_transport_profile") or self.source_tp().get("profile_name")

    def target_tp_name(self) -> str:
        return get_path(self.biz_flow(), "configure_targets", "target_transport_profile") or self.target_tp().get("profile_name")

    def flow_inner(self) -> Dict[str, Any]:
        """Build the active configuration flowDefinition from canonical input/runtime IDs."""
        n = self.business
        source_doc_name = n["sourceDocumentType"]
        target_doc_name = n["targetDocumentType"]
        source_doc_version = float(n["sourceDocumentVersion"])
        target_doc_version = float(n["targetDocumentVersion"])
        flow_name = self.flow_name()
        flow_description = n["flowDescription"]
        source_tp_name = n["sourceTpFlowName"]
        target_tp_name = n["targetTpFlowName"]
        source_application = n["sourceApplication"]
        target_application = n["targetApplication"]
        source_type = n.get("sourceType") or "Dell Application"
        target_type = n.get("targetType") or "Partner"
        mapping_rule_name = n["mappingRuleName"]
        mapping_rule_version = n["mappingRuleVersion"]
        translation = self.is_translation()
        routing_rule_name = (
            self.ov.get("flow_rule_name")
            or get_path(self.biz_flow(), "configure_routing", "rule", "name")
            or f"FLOWROUTE_{re.sub(r'[^A-Za-z0-9]+', '_', flow_name).strip('_')}"
        )
        conditions = self.mapper.conditions()
        identifier_attributes = [
            {
                "documentTypeName": source_doc_name,
                "documentTypeVersion": source_doc_version,
                "attributeName": row.get("attributeName"),
                "value": row.get("value"),
                "operator": row.get("operator"),
            }
            for row in conditions
        ]
        routing_conditions = [
            {
                "propertyName": "Attributes",
                "operation": row.get("operator"),
                "value": row.get("value"),
                "attributeName": row.get("attributeName"),
            }
            for row in conditions
        ]

        return {
            "flowDetails": {
                "businessFlowName": flow_name,
                "flowDescription": flow_description,
                "flowVersion": n["flowVersion"],
            },
            "sourceDetails": {
                "sourceType": source_type,
                "sourceApplication": source_application,
                "sourceTransportProfile": [source_tp_name],
                "documentTypeName": source_doc_name,
                "documentTypeVersion": source_doc_version,
                "flowIdentifiers": {
                    "flowIdentifierOperator": "ALL",
                    "attributes": identifier_attributes,
                },
                "processSteps": [
                    {
                        "type": "splitter",
                        "name": "Split-1",
                        "configuration": {
                            "configurationList": [],
                            "defaultConfig": {
                                "documentTypeName": "default",
                                "documentTypeVersion": "default",
                                "dataFormat": "default",
                                "action": "DONOT_SPLIT",
                            },
                        },
                    }
                ],
            },
            "targetDetails": {
                "targets": [
                    {
                        "targetType": target_type,
                        "targetApplication": target_application,
                        "targetTransportProfile": target_tp_name,
                        "documentTypeName": source_doc_name,
                        "documentTypeVersion": source_doc_version,
                        "processSteps": ([
                            {
                                "type": "mappingTransformer",
                                "name": "Mapping-1",
                                "configuration": {
                                    "configurationList": [
                                        {
                                            "documentTypeName": source_doc_name,
                                            "documentTypeVersion": n["sourceDocumentVersion"],
                                            "dataFormat": self.source_doc().get("data_format_type") or "XML",
                                            "action": "SKIP",
                                        }
                                    ],
                                    "defaultConfig": {
                                        "documentTypeName": "default",
                                        "documentTypeVersion": "default",
                                        "dataFormat": "default",
                                        "action": "MAPPING",
                                        "targetDocumentTypeName": target_doc_name,
                                        "targetDocumentTypeVersion": n["targetDocumentVersion"],
                                        "isDbBacked": False,
                                        "ruleRefs": {
                                            "hasNoRule": False,
                                            "ruleDetails": {
                                                "name": mapping_rule_name,
                                                "version": mapping_rule_version,
                                            },
                                        },
                                    },
                                },
                            }
                        ] if translation else []),
                    }
                ]
            },
            "ruleDetails": [
                {
                    "name": routing_rule_name,
                    "description": flow_description,
                    "ruleType": "Target Routing",
                    "documentTypeName": source_doc_name,
                    "documentTypeVersion": source_doc_version,
                    "disable": False,
                    "executeAlways": False,
                    "version": n["flowVersion"],
                    "ruleScope": "LOCAL",
                    "executeActionWhen": "ALL",
                    "createdBy": self.requester,
                    "modifiedBy": "",
                    "ruleConditions": routing_conditions,
                    "actions": [
                        {
                            "name": routing_rule_name,
                            "type": "FlowTargetsResponse",
                            "target": target_tp_name,
                        }
                    ],
                }
            ],
        }

    def flow_definition_string(self) -> str:
        return json.dumps(self.flow_inner(), separators=(",", ":"), default=str)

    def flow_direct_payload(self, wo: Any = "", task: Any = "") -> Dict[str, Any]:
        return {
            "workOrderId": str(wo or self.ov.get("workOrderId") or ""),
            "taskId": str(task or self.ov.get("taskId") or ""),
            "submittedBy": self.requester,
            "flowName": self.flow_name(),
            "flowDescription": self.flow_description(),
            "flowTemplateId": self.ov.get("flowTemplateId", 1),
            "flowDefinition": self.flow_definition_string(),
            "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
            "flowType": self.ov.get("flowType", self.direction()),
        }

    def flow_orch_payload(self) -> Dict[str, Any]:
        return {
            "flowName": self.flow_name(),
            "flowDescription": self.flow_description(),
            "flowTemplateName": self.ov.get(
                "flowTemplateName", "B2B-Flow-PubSub-Template"
            ),
            "flowType": self.direction(),
            "operation": "create",
            # v3 schema confirms this is a string.
            "flowDefinition": self.flow_definition_string(),
            "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
            "user": {
                "userId": int(self.user_id or 0),
                "emailId": self.requester,
            },
        }

    def deploy_direct_payload(self, wo: Any = "", task: Any = "") -> Dict[str, Any]:
        return {
            "flowName": self.flow_name(),
            "environment": self.env,
            "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
            "deployedBy": self.requester,
            "workorderId": str(wo or self.ov.get("workOrderId") or ""),
            "taskId": str(task or self.ov.get("taskId") or ""),
        }

    def deploy_orch_payload(self) -> Dict[str, Any]:
        return {
            "flowName": self.flow_name(),
            "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
            "environment": self.env,
            "user": {
                "userId": int(self.user_id or 0),
                "emailId": self.requester,
            },
        }

    def workorder_payload(self, key: str, payload_string: Optional[str] = None) -> Dict[str, Any]:
        # HIP derives the full workType object internally; never send it.
        body = {"user": self.user}
        if payload_string is not None:
            body["payload"] = payload_string
        return body

    def account_payload(self) -> Dict[str, Any]:
        # Dev review: Account Create accepts only account identity/description
        # and domains. Contact, requestedBy, domain and primaryDomain fields
        # must not be sent.
        return {
            "accountName": self.source_account_name(),
            "description": "Generated by HIP AIA MCP agent",
            "domains": ["dce.com"],
        }

    def partner_payload(self) -> Dict[str, Any]:
        # Dev contract: Partner Create uses x-account-name and requires a real
        # partner identifier. Optional contact fields are intentionally omitted
        # unless a future approved contract requires them; the live agent never
        # sends synthetic phone/email placeholders for a new customer.
        return {
            "name": self.business["externalPartner"],
            "description": "Generated by HIP AIA MCP agent",
            "partnerIdentifier": "DUNS Number",
            "partnerIdentifierValue": self.partner_identifier_value(),
            "primaryDomain": "Supply Chain",
            "additionalDomains": [
                "Technology Transformation and Platform Services (TTPS)"
            ],
        }

    def system_payload(self) -> Dict[str, Any]:
        # Dev review: domain is already represented by the endpoint path;
        # domainId must not be duplicated in the request body.
        return {
            "systemName": self.business["dellSystem"],
            "businessContactName": "Subba Reddy Eega",
            "supportContactName": "Subba Reddy Eega",
            "businessContactNumber": "3142953151",
            "supportContactNumber": "3142953151",
            "businessContactEmail": "Subba.Reddy@dell.com",
            "supportContactEmail": "Subba.Reddy@dell.com",
        }

    # ---------------- call helpers ----------------

    def build_url(self, key: str, suffix: str = "") -> str:
        base = self.urls.get(key, key)
        return base.rstrip("/") + ("/" + str(suffix).lstrip("/") if suffix else "")

    def extract_ids(self, body: Any) -> Dict[str, Any]:
        """Recursively preserve IDs/statuses from wrappers and nested data objects."""
        out: Dict[str, Any] = {}
        interesting = {
            "id", "documentTypeId", "mapId", "ruleId", "flowId",
            "flowDefinitionId", "flowVersion", "workOrderId", "taskId", "taskStatus",
            "success", "failedStep", "errorMessage", "deploymentStatus",
            "status", "operationStatus", "transportProfileName",
        }

        def walk(node: Any, prefix: str = "") -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    path = f"{prefix}.{key}" if prefix else str(key)
                    if key in interesting and value not in (None, ""):
                        out.setdefault(key, value)
                        out[path] = value
                    if isinstance(value, (dict, list)):
                        walk(value, path)
            elif isinstance(node, list):
                for index, item in enumerate(node):
                    walk(item, f"{prefix}[{index}]")

        walk(body)
        try:
            mcp_result = self.mcp.resolve_response_ids(body)
            for key, value in (mcp_result or {}).items():
                if key in {"mcpUsed", "mcpTransport", "warning"}:
                    continue
                if value not in (None, ""):
                    out.setdefault(key, value)
            out["_mcpResolution"] = {
                "used": bool((mcp_result or {}).get("mcpUsed")),
                "transport": (mcp_result or {}).get("mcpTransport"),
                "warning": (mcp_result or {}).get("warning"),
            }
        except Exception as exc:
            out["_mcpResolution"] = {
                "used": False,
                "error": str(exc),
            }
        return out

    def extract_workorder_id(self, r: Result) -> Optional[Any]:
        return r.extracted.get("id") or r.extracted.get("workOrderId")

    def extract_task_id(self, r: Result) -> Optional[Any]:
        return r.extracted.get("taskId")

    def close_payload(self, wo_result: Result) -> Dict[str, Any]:
        try:
            body = json.loads(wo_result.response_preview)
            if isinstance(body, dict):
                return body
        except Exception:
            pass
        return {"id": self.extract_workorder_id(wo_result), "user": self.user}

    def validate_pdf_readiness(self) -> None:
        if (
            self.pdf_require_documentation
            and not self.pdf_kb.has_documents()
        ):
            raise RuntimeError(
                "PDF documentation is required but no API PDF has been "
                "ingested. Upload it from the API Docs tab in Streamlit."
            )

    def _contract_validation_path(self, seq: int) -> Path:
        return REPORTS / f"contract_validation_{seq:02d}.json"

    def validate_request_contract(
        self,
        seq: int,
        api_key: str,
        method: str,
        url: str,
        extra_headers: Optional[Dict[str, str]],
        payload: Any,
        params: Any,
    ) -> Dict[str, Any]:
        header_names = self.headers(
            "<TOKEN>",
            extra_headers,
        )
        header_names["Authorization"] = "<REDACTED>"

        fingerprint = self._validation_fingerprint(
            api_key=api_key, method=method, url=url, headers=header_names,
            payload=payload, params=params,
        )
        reuse_validated = str(os.getenv("HIP_REUSE_VALIDATED_REQUESTS", "false")).strip().lower() in {"1", "true", "yes", "on"}
        with self._validation_cache_lock:
            cached = self._validation_cache.get(fingerprint) if reuse_validated else None
        if isinstance(cached, dict) and cached.get("valid") is True:
            output = dict(cached)
            output["sequence"] = seq
            output["cacheHit"] = True
            output["validationFingerprint"] = fingerprint
            self._contract_validation_path(seq).write_text(
                json.dumps(output, indent=2, default=str), encoding="utf-8"
            )
            return output

        deterministic = self.pdf_kb.validate_request(
            api_key=api_key,
            method=method,
            url=url,
            headers=header_names,
            payload=payload,
            params=params,
        )

        mcp_result: Dict[str, Any] = {
            "valid": True,
            "mcpUsed": False,
            "disabled": True,
            "errors": [],
            "warnings": [],
        }
        if self.mcp_validate_each_request and self.mcp.enabled:
            with self._mcp_lock:
                mcp_result = self.mcp.validate_api_request(
                    api_key=api_key,
                    method=method,
                    url=url,
                    headers=header_names,
                    payload=payload,
                    params=params,
                )

        aia_result: Dict[str, Any] = {
            "performed": False,
            "valid": True,
            "errors": [],
            "warnings": [],
        }
        if (
            self.pdf_kb.has_documents()
            and self.pdf_aia_validate_each_request
            and self.pdf_validation_mode
            in {"auto", "strict", "aia"}
        ):
            # One Runner process represents one Dell AIA LLM agent. Keep the
            # LLM judge serialized inside that agent even when several HIP HTTP
            # requests are prepared concurrently.
            with self._llm_lock:
                aia_result = self.pdf_kb.aia_validate_request(
                    judge=self.judge,
                    api_key=api_key,
                    method=method,
                    url=url,
                    headers=header_names,
                    payload=payload,
                    params=params,
                )

        strict_pdf_error = (
            self.pdf_validation_mode == "strict"
            and aia_result.get("performed")
            and not aia_result.get("valid", False)
        )
        valid = (
            bool(deterministic.get("valid"))
            and bool(mcp_result.get("valid", True))
            and not strict_pdf_error
        )

        output = {
            "sequence": seq,
            "apiKey": api_key,
            "method": method,
            "url": url,
            "valid": valid,
            "deterministic": deterministic,
            "mcpToolValidation": mcp_result,
            "dellAiaPdfValidation": aia_result,
            "mode": self.pdf_validation_mode,
            "mcpStatus": self.mcp.status(),
            "cacheHit": False,
            "validationFingerprint": fingerprint,
        }
        if valid:
            with self._validation_cache_lock:
                self._validation_cache[fingerprint] = dict(output)
                # Keep the cache bounded; only exact request fingerprints are reused.
                if len(self._validation_cache) > 256:
                    self._validation_cache = dict(list(self._validation_cache.items())[-256:])
                self._save_request_validation_cache()
        self._contract_validation_path(seq).write_text(
            json.dumps(output, indent=2, default=str),
            encoding="utf-8",
        )
        return output

    def _request_with_retry(
        self,
        method: str,
        url: str,
        token_kind: str,
        scope: str,
        extra_headers: Optional[Dict[str, str]],
        payload: Any,
        params: Any,
    ) -> requests.Response:
        max_attempts = max(
            1,
            int(os.getenv("HTTP_RETRY_ATTEMPTS", "3")),
        )
        retry_statuses = {408, 429, 502, 503, 504}
        last_response: Optional[requests.Response] = None

        for attempt_no in range(1, max_attempts + 1):
            callback = getattr(self, "request_event_callback", None)
            if callable(callback):
                try:
                    callback({"type": "http.attempt", "attempt": attempt_no, "maxAttempts": max_attempts, "method": method.upper(), "url": url})
                except Exception:
                    pass
            token = self.get_token(token_kind, scope)
            headers = self.headers(token, extra_headers)

            try:
                if method.upper() == "GET":
                    response = self._api_http_session().get(
                        url,
                        headers=headers,
                        params=params,
                        timeout=TIMEOUT_SECONDS,
                        verify=REQUEST_VERIFY,
                    )
                else:
                    response = self._api_http_session().post(
                        url,
                        headers=headers,
                        params=params,
                        json=payload,
                        timeout=TIMEOUT_SECONDS,
                        verify=REQUEST_VERIFY,
                    )
            except (requests.exceptions.RequestException, OSError, TimeoutError):
                if attempt_no >= max_attempts:
                    raise
                delay = min(2 ** (attempt_no - 1), 8)
                if callable(callback):
                    try:
                        callback({"type": "http.retry", "attempt": attempt_no, "maxAttempts": max_attempts, "status": None, "delaySeconds": delay, "reason": "transient network exception"})
                    except Exception:
                        pass
                time.sleep(delay)
                continue

            last_response = response

            # Refresh a cached API token once after an authentication failure.
            if (
                response.status_code in {401, 403}
                and attempt_no < max_attempts
            ):
                with TOKEN_CACHE_LOCK:
                    for cache_key in list(TOKEN_CACHE):
                        if cache_key and cache_key[0] == token_kind:
                            TOKEN_CACHE.pop(cache_key, None)
                delay = min(2 ** (attempt_no - 1), 4)
                if callable(callback):
                    try:
                        callback({"type": "http.retry", "attempt": attempt_no, "maxAttempts": max_attempts, "status": response.status_code, "delaySeconds": delay, "reason": "authentication refresh"})
                    except Exception:
                        pass
                time.sleep(delay)
                continue

            if (
                response.status_code in retry_statuses
                and attempt_no < max_attempts
            ):
                retry_after = response.headers.get("Retry-After")
                try:
                    delay = float(retry_after)
                except Exception:
                    delay = min(2 ** (attempt_no - 1), 8)
                if callable(callback):
                    try:
                        callback({"type": "http.retry", "attempt": attempt_no, "maxAttempts": max_attempts, "status": response.status_code, "delaySeconds": delay, "reason": "transient HTTP response"})
                    except Exception:
                        pass
                time.sleep(delay)
                continue

            return response

        if last_response is None:
            raise RuntimeError("HTTP request did not produce a response.")
        return last_response

    def call(self, seq: int, group: str, api: str, attempt: str, method: str, url_key: str, scope_key: str,
             payload: Any = None, params: Any = None, token_kind: str = "HIP", scope_override: Optional[str] = None,
             suffix: str = "", extra_headers: Optional[Dict[str, str]] = None) -> Result:
        url = self.build_url(url_key, suffix)
        scope = scope_override if scope_override is not None else self.scopes.get(scope_key, "")
        payload_file = save_payload(seq, group, api, attempt, payload if payload is not None else params)

        contract_validation = self.validate_request_contract(
            seq=seq,
            api_key=url_key,
            method=method,
            url=url,
            extra_headers=extra_headers,
            payload=payload,
            params=params,
        )
        if not contract_validation.get("valid", False):
            error_messages = [
                item.get("message", "")
                for item in (
                    contract_validation
                    .get("deterministic", {})
                    .get("errors", [])
                )
            ]
            error_messages.extend(
                str(item)
                for item in (
                    contract_validation
                    .get("mcpToolValidation", {})
                    .get("errors", [])
                )
            )
            error_messages.extend(
                str(item)
                for item in (
                    contract_validation
                    .get("dellAiaPdfValidation", {})
                    .get("errors", [])
                )
            )
            issue = (
                "Request blocked by API contract validation: "
                + "; ".join(x for x in error_messages if x)
            )
            action = (
                "Correct the generated request or update the ingested API "
                "documentation after Dev confirmation."
            )
            return Result(
                seq,
                group,
                api,
                attempt,
                method.upper(),
                url,
                token_kind,
                scope,
                None,
                "CONTRACT_VALIDATION_BLOCKED",
                False,
                None,
                payload_file,
                preview(payload if payload is not None else params),
                json.dumps(contract_validation, indent=2),
                {"contractValidation": contract_validation},
                "USER_PAYLOAD_BUG",
                "",
                "USER_PAYLOAD_BUG",
                issue,
                action,
            )

        try:
            start = time.perf_counter()
            resp = self._request_with_retry(
                method=method,
                url=url,
                token_kind=token_kind,
                scope=scope,
                extra_headers=extra_headers,
                payload=payload,
                params=params,
            )
            elapsed = int((time.perf_counter() - start) * 1000)
            try:
                body = resp.json()
                response_text = json.dumps(body, indent=2, default=str)
            except Exception:
                body = None
                response_text = resp.text
            classification, ok = self.classify_http(
                resp.status_code,
                response_text,
            )
            classification, ok = self.validate_step_business_result(
                url_key=url_key,
                body=body,
                classification=classification,
                ok=ok,
            )

            # V106 contextual backend-contract classification. This is based on
            # the immutable request contract plus HIP's own FK error text.
            response_low = str(response_text or "").lower()
            if (
                url_key == "rule"
                and resp.status_code is not None
                and int(resp.status_code) >= 400
                and (
                    any(marker in response_low for marker in (
                        "rule_documenttype", "fk_rule_documenttype",
                        "parent key not found in rule_documenttype",
                    ))
                    or (
                        any(marker in response_low for marker in (
                            "fk_mac_rule_flow_def", "mac_rule_flow_def",
                            "flowdefinitionid", "flow_definition_id",
                        ))
                        and ("parent key not found" in response_low or "ora-02291" in response_low or "integrity constraint" in response_low)
                    )
                )
            ):
                classification, ok = "API_BACKEND_CONTRACT_MISMATCH", False

            # Independent MCP semantic response interpreter. Local checks stay
            # authoritative for compatibility, but MCP can only make the result
            # stricter (for example HTTP 200 with success=false, failed deploy
            # history, or malformed TP audit data).
            with self._mcp_lock:
                mcp_response = self.mcp.interpret_api_response(
                    api_key=url_key,
                    status_code=resp.status_code,
                    response_body=body if body is not None else response_text,
                )
            if not mcp_response.get("businessSuccess", True):
                ok = False
                # Do not let a generic semantic classifier erase deterministic
                # ownership for two V106 conditions proven by response evidence.
                if classification not in {
                    "API_UPSTREAM_ROUTE_UNAVAILABLE",
                    "API_BACKEND_CONTRACT_MISMATCH",
                }:
                    classification = str(
                        mcp_response.get("classification") or classification
                    )

            response_text = str(redact_sensitive(response_text))
            # V110: HIP Flow Create applies the documented 1-40 character /
            # restricted-character rule even when the separate validation API
            # returns 200. Treat that deterministic 400 as terminal; never send
            # the same invalid request in auto-completion rounds.
            if url_key in {"orch_flow_create", "flow_definition"} and int(resp.status_code or 0) == 400:
                # V116: a duplicate-name response is current-LIVE evidence that the
                # canonical Flow exists. It must not be collapsed into
                # FLOW_NAME_INVALID, because Deploy operates on the same
                # canonical Flow name/version. Genuine length/character/format
                # validation errors remain terminal.
                existing_name_markers = (
                    "already exists", "already exist", "already present",
                    "duplicate", "record exists",
                )
                invalid_name_markers = (
                    "1-40", "40 characters", "40 character",
                    "start with", "letters", "numbers", "special characters",
                    "invalid flow name", "flow name is invalid",
                )
                explicit_existing = any(marker in response_low for marker in existing_name_markers)
                if (not explicit_existing) and any(marker in response_low for marker in invalid_name_markers):
                    classification, ok = "FLOW_NAME_INVALID", False

            extracted = self.extract_ids(body)
            for _header in ("Location", "Content-Location"):
                _value = str(resp.headers.get(_header) or "").strip()
                if _value:
                    extracted[f"response{_header.replace('-', '')}"] = _value[:2000]
            extracted["contractValidation"] = contract_validation
            extracted["mcpResponseInterpretation"] = mcp_response
            extracted["responseEvidenceFile"] = save_response_evidence(
                seq, group, api, attempt, method=method, url=str(resp.url),
                status_code=resp.status_code, elapsed_ms=elapsed,
                classification=classification, business_success=ok,
                response=body if body is not None else response_text,
            )
            temp = {"group": group, "api": api, "status_code": resp.status_code, "classification": classification, "business_success": ok, "request_preview": preview(payload if payload is not None else params), "response_preview": response_text}
            deterministic_owner, issue, action = self.deterministic_owner(temp)
            with self._llm_lock:
                llm = self.judge.judge(temp)
            llm_owner = llm.get("owner") or ""
            deterministic_protected = deterministic_owner in {
                "API_UPSTREAM_ROUTE_UNAVAILABLE",
                "API_BACKEND_CONTRACT_MISMATCH",
            }
            final_owner = deterministic_owner if deterministic_protected else (llm_owner or deterministic_owner)
            if not deterministic_protected and llm_owner and llm.get("issue"):
                issue = llm["issue"]
            if not deterministic_protected and llm_owner and llm.get("action"):
                action = llm["action"]
            return Result(seq, group, api, attempt, method.upper(), resp.url, token_kind, scope, resp.status_code, classification, ok, elapsed, payload_file, preview(payload if payload is not None else params), response_text, extracted, deterministic_owner, llm_owner, final_owner, issue, action)
        except Exception as exc:
            temp = {"group": group, "api": api, "status_code": None, "classification": "EXECUTION_ERROR", "business_success": False, "request_preview": preview(payload if payload is not None else params), "error": str(exc)}
            deterministic_owner, issue, action = self.deterministic_owner(temp)
            evidence_file = save_response_evidence(
                seq, group, api, attempt, method=method,
                url=url + (("?" + urlencode(params)) if params else ""),
                status_code=None, elapsed_ms=None, classification="EXECUTION_ERROR",
                business_success=False, error=str(exc),
            )
            return Result(seq, group, api, attempt, method.upper(), url + (("?" + urlencode(params)) if params else ""), token_kind, scope, None, "EXECUTION_ERROR", False, None, payload_file, preview(payload if payload is not None else params), "", {"responseEvidenceFile": evidence_file}, deterministic_owner, "", deterministic_owner, issue, action, error=str(exc))

    def lock_request_value(
        self,
        step_key: str,
        request_kind: str,
        value: Any,
        *,
        fallback: Any = None,
        strict_unknown: bool = False,
    ) -> Tuple[Any, Dict[str, Any]]:
        """Lock one of the 18 HIP requests to its developer-approved structure.

        Customer extraction, LLM reasoning, persisted overrides and Flow Game
        mappings may change values only. FILE uses the U-HAUL/dev-tested shape;
        HTTPS and HTTPS-AS2 use their dev-approved interfaceDetails shape.
        """
        return canonical_lock_request_value(
            canonical_step_key(step_key),
            request_kind,
            value,
            fallback=fallback,
            strict_unknown=strict_unknown,
        )

    def _lock_call_factory(
        self,
        step_key: str,
        factory: Dict[str, Any],
        *,
        fallback_factory: Optional[Dict[str, Any]] = None,
        strict_unknown: bool = False,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        key = canonical_step_key(step_key)
        kind = canonical_payload_request_kind(key)
        locked_factory = json.loads(json.dumps(factory, default=str))
        fallback_value = None
        if isinstance(fallback_factory, dict):
            fallback_value = fallback_factory.get(kind)
        value = locked_factory.get(kind)
        locked_value, meta = self.lock_request_value(
            key, kind, value, fallback=fallback_value, strict_unknown=strict_unknown
        )
        locked_factory[kind] = locked_value
        # A step's request transport is part of the immutable 18-API contract.
        # Do not let an old/customer override switch payload <-> params.
        other = "params" if kind == "payload" else "payload"
        locked_factory.pop(other, None)
        return locked_factory, meta

    def lock_live_request_fingerprint(self, step_key: str, factory: Dict[str, Any]) -> str:
        """Fail closed if a retry changes the already-materialized LIVE request.

        This is a value+shape lock, not only a schema lock. It prevents agent/LLM
        recovery from rewriting names, IDs, XREF mode, or any other request field
        after the first HTTP attempt for a logical canonical step.
        """
        key = canonical_step_key(step_key)
        kind = canonical_payload_request_kind(key)
        headers = {
            str(k).lower(): v
            for k, v in (factory.get("extra_headers") or {}).items()
            if str(k).lower() not in {"authorization", "cookie", "set-cookie"}
        }
        record = {
            "stepKey": key,
            "method": str(factory.get("method") or "").upper(),
            "urlKey": str(factory.get("url_key") or ""),
            "suffix": str(factory.get("suffix") or ""),
            "requestKind": kind,
            "request": factory.get(kind),
            "extraHeaders": headers,
        }
        raw = json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        fingerprint = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        with self._live_request_fingerprint_lock:
            previous = self._live_request_fingerprints.get(key)
            if previous and previous != fingerprint:
                raise ValueError(
                    "IMMUTABLE_LIVE_REQUEST_CHANGED: "
                    f"{key} was already executed with fingerprint {previous}; "
                    f"a later attempt produced {fingerprint}. Runtime API payload mutation is disabled."
                )
            self._live_request_fingerprints.setdefault(key, fingerprint)
        return fingerprint

    @staticmethod
    def is_non_retryable_completion_reason(reason: Any) -> bool:
        """Return True for terminal failures that bounded auto-completion must not repeat."""
        return str(reason or "").strip().upper() in {
            "TP_AUDIT_TIMEOUT",
            "FLOW_DEPLOYMENT_AUDIT_TIMEOUT",
            "API_UPSTREAM_ROUTE_UNAVAILABLE",
            "API_BACKEND_CONTRACT_MISMATCH",
            "LIVE_RULE_ID_UNRESOLVED",
            "FLOW_NAME_INVALID",
        }

    def payload_override_context(self) -> Dict[str, Any]:
        return {
            "runtime": dict(self.runtime_state),
            "business": dict(self.business),
            "environment": self.env,
            "requester": self.requester,
            "user": self.user,
            "input": self.input,
            "config": self.ov,
        }

    def preview_step_request(self, step_key: str) -> Dict[str, Any]:
        """Return the effective request definition without making an API call.

        Used by the Streamlit Payload Studio. The returned payload/params already
        includes any saved user override and runtime placeholder resolution.
        OAuth secrets and bearer tokens are never included.
        """
        key = canonical_step_key(step_key)
        if not self.step_applicable(key):
            definition = FLOW_STEP_DEFINITIONS.get(key, {})
            return {
                "stepKey": key,
                "group": definition.get("group") or "Configuration",
                "api": definition.get("label") or key,
                "method": "N/A",
                "urlKey": key,
                "url": "",
                "tokenKind": "HIP",
                "scopeKey": "",
                "requestKind": "payload",
                "generatedPayload": {},
                "generatedParams": None,
                "payload": {},
                "params": None,
                "extraHeaders": {},
                "override": {"applied": False},
                "applicable": False,
                "applicabilityReason": self.applicability_reason(key),
            }
        if key == "validate_source":
            factory = {
                "group": "Validation", "api": "Validate source TP unique",
                "attempt": "validate_source", "method": "POST", "url_key": "tp_validate",
                "scope_key": "transport_profile",
                "payload": {
                    "interfaceType": self.tp_interface_type(self.source_tp()),
                    "propertyMap": self.tp_parameters(self.source_tp(), "source"),
                    "transportProfileName": self.source_tp().get("profile_name"),
                    "hipEnvironment": self.env,
                },
            }
        elif key == "validate_target":
            factory = {
                "group": "Validation", "api": "Validate target TP unique",
                "attempt": "validate_target", "method": "POST", "url_key": "tp_validate",
                "scope_key": "transport_profile",
                "payload": {
                    "interfaceType": self.tp_interface_type(self.target_tp()),
                    "propertyMap": self.tp_parameters(self.target_tp(), "target"),
                    "transportProfileName": self.target_tp().get("profile_name"),
                    "hipEnvironment": self.env,
                },
            }
        elif key == "validate_flow":
            factory = {
                "group": "Validation", "api": "Validate flow name", "attempt": "validate_flow",
                "method": "GET", "url_key": "flow_validate", "scope_key": "flow",
                "params": {"flowName": self.flow_name()},
            }
        elif key == "account_source":
            factory = {
                "group": "Account", "api": "Create source account", "attempt": "source_account_dce_domain",
                "method": "POST", "url_key": "account", "scope_key": "account",
                "token_kind": "ACCOUNT", "scope_override": self.account_scope,
                "payload": self.account_payload(),
            }
        elif key == "account_target":
            payload = self.account_payload()
            payload["accountName"] = self.target_account_name()
            payload["description"] = "Target HAFT account generated by HIP dependency sequencer"
            factory = {
                "group": "Account", "api": "Create target account", "attempt": "target_account_dce_domain",
                "method": "POST", "url_key": "account", "scope_key": "account",
                "token_kind": "ACCOUNT", "scope_override": self.account_scope,
                "payload": payload,
            }
        elif key == "partner_target":
            factory = {
                "group": "Partner", "api": "Create partner", "attempt": "partner_payload_x_account_name",
                "method": "POST", "url_key": "partner", "scope_key": "partner",
                "token_kind": "PARTNER", "scope_override": self.partner_scope,
                "payload": self.partner_payload(),
                "extra_headers": {"x-account-name": self.partner_x_account_name},
            }
        elif key == "system_source":
            factory = {
                "group": "System", "api": "Create system", "attempt": "system_payload",
                "method": "POST", "url_key": "system", "scope_key": "system",
                "token_kind": "SYSTEM", "scope_override": self.system_scope,
                "payload": self.system_payload(),
            }
        elif key == "doctype_source":
            factory = {
                "group": "Document Type", "api": "Create source document type", "attempt": "fixed_payload",
                "method": "POST", "url_key": "document_type", "scope_key": "document_type",
                "payload": self.doc_payload(self.source_doc(), "source"),
            }
        elif key == "doctype_target":
            factory = {
                "group": "Document Type", "api": "Create target document type", "attempt": "fixed_payload",
                "method": "POST", "url_key": "document_type", "scope_key": "document_type",
                "payload": self.doc_payload(self.target_doc(), "target"),
            }
        elif key == "map":
            xbm_available = bool(self._map_xbm_file(str(self.data_map().get("map_name") or "")))
            factory = {
                "group": "Map", "api": "Create/resolve MAC Map",
                "attempt": "primary_with_xref" if xbm_available else "primary_without_xref",
                "method": "POST", "url_key": "map", "scope_key": "map",
                "token_kind": "MAP", "scope_override": self.map_scope,
                "payload": self.map_payload(xbm_available),
            }
        elif key == "rule":
            factory = {
                "group": "Rule", "api": "Create mapping rule", "attempt": "dev_approved_rule_without_runtime_ids",
                "method": "POST", "url_key": "rule", "scope_key": "rule",
                "payload": self.rule_payload(),
            }
        elif key == "source_tp":
            factory = {
                "group": "Orchestration", "api": "Source TP orchestration create ONLY",
                "attempt": "dependency_gated_systemName_deploymentGroupName",
                "method": "POST", "url_key": "orch_tp_create", "scope_key": "transport_profile",
                "payload": self.tp_orch_payload(self.source_tp(), "source"),
            }
        elif key == "target_tp":
            factory = {
                "group": "Orchestration", "api": "Target TP orchestration create ONLY",
                "attempt": "dependency_gated_systemName_deploymentGroupName",
                "method": "POST", "url_key": "orch_tp_create", "scope_key": "transport_profile",
                "payload": self.tp_orch_payload(self.target_tp(), "target"),
            }
        elif key == "flow_create":
            factory = {
                "group": "Orchestration", "api": "Flow orchestration create ONLY",
                "attempt": "dependency_gated_flow_create", "method": "POST",
                "url_key": "orch_flow_create", "scope_key": "flow",
                "payload": self.flow_orch_payload(),
            }
        elif key == "flow_deploy":
            factory = {
                "group": "Orchestration", "api": "Flow orchestration deploy ONLY",
                "attempt": "dependency_gated_flow_deploy", "method": "POST",
                "url_key": "orch_flow_deploy", "scope_key": "flow",
                "payload": self.deploy_orch_payload(),
            }
        elif key == "flow_history":
            factory = {
                "group": "History", "api": "Flow deployment history", "attempt": "flow_history",
                "method": "GET", "url_key": "flow_deploy_history", "scope_key": "flow",
                "params": {
                    "flowName": self.flow_name(),
                    "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
                    "environment": self.env,
                },
            }
        elif key == "source_tp_audit":
            factory = {
                "group": "History", "api": "Source TP audit history", "attempt": "tp_source_audit",
                "method": "GET", "url_key": "tp_audits", "scope_key": "transport_profile",
                "params": {
                    "transportProfileName": self.source_tp().get("profile_name"),
                    "hipEnvironment": self.env,
                },
            }
        elif key == "target_tp_audit":
            factory = {
                "group": "History", "api": "Target TP audit history", "attempt": "tp_target_audit",
                "method": "GET", "url_key": "tp_audits", "scope_key": "transport_profile",
                "params": {
                    "transportProfileName": self.target_tp().get("profile_name"),
                    "hipEnvironment": self.env,
                },
            }
        else:
            raise ValueError(f"Unknown API step: {step_key}")

        # V71: first normalize the generated customer request itself, then apply
        # value overrides, then lock again. This guarantees API Testing, Flow
        # Game and Execute all expose/send the exact same U-HAUL-tested attribute
        # structure for every customer. No U-HAUL business value is borrowed.
        factory, generated_structure = self._lock_call_factory(key, factory)
        generated = json.loads(json.dumps(factory, default=str))
        # V117 HUMAN-USER-ONLY Payload Value Editor: the developer-approved
        # request structure remains immutable. The AI/agent has zero edit authority;
        # only an explicit human-user persisted edit may change VALUES of existing canonical fields before LIVE.
        # The edit is applied to the generated customer request, then the
        # canonical structure lock runs again so unknown attributes/nesting can
        # never reach preflight or HTTP.
        override_summary = self.payload_overrides.summary()
        effective, override_meta = self.payload_overrides.apply(
            key,
            factory,
            {"runtime": dict(self.runtime_state), "input": self.input, "config": self.ov},
        )
        effective, effective_structure = self._lock_call_factory(
            key, effective, fallback_factory=generated
        )
        override_meta = dict(override_meta or {})
        override_meta["canonicalStructure"] = effective_structure
        override_meta["generatedCanonicalStructure"] = generated_structure
        return {
            "stepKey": key,
            "group": effective.get("group"),
            "api": effective.get("api"),
            "method": effective.get("method"),
            "urlKey": effective.get("url_key"),
            "url": self.build_url(effective.get("url_key", ""), effective.get("suffix", "")),
            "tokenKind": effective.get("token_kind", "HIP"),
            "scopeKey": effective.get("scope_key", ""),
            "scopeOverride": effective.get("scope_override"),
            "suffix": effective.get("suffix", ""),
            "requestKind": "params" if effective.get("params") is not None else "payload",
            "generatedPayload": generated.get("payload"),
            "generatedParams": generated.get("params"),
            "payload": effective.get("payload"),
            "params": effective.get("params"),
            "extraHeaders": effective.get("extra_headers") or {},
            "override": override_meta,
            "canonicalStructure": {
                "generated": generated_structure,
                "effective": effective_structure,
                "catalog": canonical_payload_catalog_summary(),
            },
            "applicable": True,
            "applicabilityReason": "",
        }

    def run_single_step(self, step_key: str) -> Result:
        """Execute one selected API request exactly as previewed in the API Testing Area."""
        request = self.preview_step_request(step_key)
        if request.get("applicable") is False:
            raise ValueError(
                f"{request.get('api') or step_key} is not applicable to this active flow: "
                f"{request.get('applicabilityReason') or 'not required by the canonical configuration'}"
            )
        live_payload = self._resolve_runtime_payload_values(request.get("payload")) if request.get("payload") is not None else None
        live_params = self._resolve_runtime_payload_values(request.get("params")) if request.get("params") is not None else None
        result = self.call(
            1,
            str(request.get("group") or "API Testing Area"),
            str(request.get("api") or step_key),
            f"api_testing_area_{request.get('stepKey') or step_key}",
            str(request.get("method") or "POST"),
            str(request.get("urlKey") or ""),
            str(request.get("scopeKey") or ""),
            payload=live_payload,
            params=live_params,
            token_kind=str(request.get("tokenKind") or "HIP"),
            scope_override=request.get("scopeOverride"),
            suffix=str(request.get("suffix") or ""),
            extra_headers=request.get("extraHeaders") or {},
        )
        result.extracted = dict(result.extracted or {})
        result.extracted["logicalStepKey"] = request.get("stepKey") or step_key
        result.extracted["apiTestingArea"] = True
        return result

    def run(self) -> List[Result]:
        """
        Dependency-aware execution order.

        Rule:
        - APIs with no dependency run when input/auth is available.
        - APIs whose inputs depend on other objects run only after those objects
          are PASS or EXISTING.
        - Create calls are always executed in V108 LIVE. If HIP itself returns an
          already-exists/duplicate response, that exact API response is recorded
          as EXISTING; no downstream success is used to infer or rewrite it.
        """
        results: List[Result] = []
        seq = 1
        resolved: Dict[str, bool] = {}
        reasons: Dict[str, str] = {}
        state_lock = threading.RLock()
        seq_lock = threading.RLock()

        def reserve_sequence() -> int:
            nonlocal seq
            with seq_lock:
                value = seq
                seq += 1
                return value

        def add_result(result: Result) -> None:
            with state_lock:
                results.append(result)

        def is_existing_response(r: Result) -> bool:
            # Keep dependency resolution aligned with the final report judge.
            # EXISTING is accepted only when this exact API was executed and HIP
            # returned explicit duplicate/existing evidence.
            from report_insights import analyze_api_response
            return str(analyze_api_response(r).get("outcome") or "").upper() == "EXISTING"

        def is_resolved(r: Result) -> bool:
            if r.classification == "SKIPPED_BY_USER_EXISTING_OBJECT":
                return not self.no_reuse_live_mode
            if r.business_success:
                return True
            if is_existing_response(r):
                # V116: EXISTING is accepted only because this exact canonical
                # API was executed in the current run and HIP itself proved the
                # named/versioned object exists. This is not historical reuse:
                # no Flow ID is loaded/injected and the Flow name is not renamed.
                # Therefore Flow Create EXISTING safely satisfies the Deploy
                # prerequisite, which uses the same canonical name/version.
                return True
            # Generic HTTP 500 responses are never treated as existing objects.
            # Existing-object bypass is now explicit through the API Execution
            # Plan, or proven by an API response that says already exists /
            # duplicate / unique constraint.
            return False

        def result_reason(r: Result) -> str:
            if r.classification == "SKIPPED_BY_USER_EXISTING_OBJECT":
                return "SKIPPED_EXISTING_OBJECT"
            if r.classification in {
                "API_UPSTREAM_ROUTE_UNAVAILABLE",
                "API_BACKEND_CONTRACT_MISMATCH",
                "LIVE_RULE_ID_UNRESOLVED",
                "FLOW_NAME_INVALID",
            }:
                return r.classification
            if r.business_success:
                return "PASS"
            if is_existing_response(r):
                return "EXISTING"
            txt = ((r.response_preview or "") + " " + (r.error or "")).strip()
            return txt[:1200] if txt else (r.classification or "FAILED")

        def do(*args, **kwargs):
            current_seq = reserve_sequence()
            print(f"[{current_seq}] {args[0]} - {args[1]} - {args[2]}")
            r = self.call(current_seq, *args, **kwargs)
            elapsed_text = f"{(r.elapsed_ms or 0) / 1000:.3f}s" if r.elapsed_ms is not None else "n/a"
            print(f"  -> HTTP {r.status_code} | {r.classification} | {r.final_owner} | time={elapsed_text}")
            add_result(r)
            try:
                with self._adaptive_result_lock:
                    self.adaptive.record_api_result(current_seq, str(args[2]), r)
            except Exception as adaptive_exc:
                print(f"Adaptive memory warning: {adaptive_exc}")
            return r

        def skip(call_factory: Dict[str, Any], deps: List[str]) -> Result:
            current_seq = reserve_sequence()
            group = call_factory["group"]
            api = call_factory["api"]
            attempt = call_factory["attempt"]
            method = call_factory.get("method", "SKIP")
            url_key = call_factory.get("url_key", "")
            params = call_factory.get("params")
            payload = call_factory.get("payload")
            planned_request = payload if payload is not None else params
            with state_lock:
                missing = [d for d in deps if not resolved.get(d)]
            issue = "Skipped because prerequisite steps are not resolved: " + ", ".join(missing)
            action = "Fix or resolve prerequisite APIs first, then rerun this step."
            for d in missing:
                if reasons.get(d):
                    issue += f"\n- {d}: {reasons[d]}"

            payload_file = save_payload(
                current_seq, group, api, attempt,
                planned_request if planned_request is not None else {}
            )
            url = self.build_url(url_key) if url_key else ""
            if params:
                url = url + "?" + urlencode(params)

            r = Result(
                current_seq, group, api, attempt, method, url,
                call_factory.get("token_kind", "HIP"),
                call_factory.get("scope_override")
                if call_factory.get("scope_override") is not None
                else self.scopes.get(call_factory.get("scope_key", ""), ""),
                None, "SKIPPED_DEPENDENCY", False, None,
                payload_file,
                preview(planned_request if planned_request is not None else {}),
                "",
                {
                    "missing_dependencies": missing,
                    "planned_request_preserved": True,
                },
                "SKIPPED_DEPENDENCY", "", "SKIPPED_DEPENDENCY",
                issue, action
            )
            print(f"[{current_seq}] {group} - {api} - SKIPPED: {', '.join(missing)}")
            add_result(r)
            return r

        def not_applicable(step_key: str) -> Result:
            current_seq = reserve_sequence()
            logical_key = canonical_step_key(step_key)
            meta = FLOW_STEP_DEFINITIONS.get(logical_key, {})
            reason = self.applicability_reason(logical_key)
            evidence = {
                "apiCalled": False,
                "classification": "NOT_APPLICABLE",
                "stepKey": logical_key,
                "reason": reason,
                "flowType": "translation" if self.is_translation() else "passthrough",
            }
            payload_file = save_payload(current_seq, meta.get("group") or "Configuration", meta.get("label") or logical_key, "not_applicable", evidence)
            r = Result(
                current_seq, meta.get("group") or "Configuration", meta.get("label") or logical_key,
                "not_applicable", "N/A", "", "HIP", "", None,
                "NOT_APPLICABLE", True, 0, payload_file, json.dumps(evidence),
                json.dumps(evidence), {"logicalStepKey": logical_key, "applicable": False},
                "NOT_APPLICABLE", "", "NOT_APPLICABLE", reason,
                "No API call is required for this canonical flow."
            )
            print(f"[{current_seq}] {meta.get('label') or logical_key} - NOT_APPLICABLE: {reason}")
            add_result(r)
            with state_lock:
                resolved[logical_key] = True
                reasons[logical_key] = "NOT_APPLICABLE"
            return r

        def skip_existing(key: str, call_factory: Dict[str, Any]) -> Result:
            current_seq = reserve_sequence()
            logical_key = canonical_step_key(key)
            group = call_factory["group"]
            api = call_factory["api"]
            attempt = call_factory["attempt"]
            method = call_factory.get("method", "SKIP")
            url_key = call_factory.get("url_key", "")
            params = call_factory.get("params")
            payload = call_factory.get("payload")
            planned_request = payload if payload is not None else params

            # Apply the approved existing ID before any downstream payload is
            # generated. For Account/Partner/System/TP skips no numeric ID is
            # needed because downstream contracts use names.
            self.execution_plan.apply_existing_runtime_id(
                logical_key,
                self.runtime_state,
            )
            extracted = self.execution_plan.synthetic_extracted(logical_key)

            payload_file = save_payload(
                current_seq,
                group,
                api,
                attempt + "_SKIPPED_EXISTING",
                planned_request if planned_request is not None else {},
            )
            url = self.build_url(url_key, call_factory.get("suffix", "")) if url_key else ""
            if params:
                url = url + "?" + urlencode(params)

            response_record = {
                "apiCalled": False,
                "executionDecision": "SKIP_EXISTING",
                "classification": "SKIPPED_BY_USER_EXISTING_OBJECT",
                "stepKey": logical_key,
                "stepLabel": self.execution_plan.label(logical_key),
                "existing": extracted,
                "reason": self.execution_plan.summary().get("reason", ""),
            }
            issue = (
                f"{self.execution_plan.label(logical_key)} was intentionally "
                "not called because the user confirmed the HIP object already exists."
            )
            action = (
                "No create API call was sent. Downstream dependency processing "
                "continues using the approved existing object/value."
            )

            r = Result(
                current_seq,
                group,
                api,
                attempt + "_SKIPPED_EXISTING",
                method.upper(),
                url,
                call_factory.get("token_kind", "HIP"),
                call_factory.get("scope_override")
                if call_factory.get("scope_override") is not None
                else self.scopes.get(call_factory.get("scope_key", ""), ""),
                None,
                "SKIPPED_BY_USER_EXISTING_OBJECT",
                True,
                0,
                payload_file,
                preview(planned_request if planned_request is not None else {}),
                json.dumps(response_record, indent=2, default=str),
                extracted,
                "USER_APPROVED_SKIP",
                "",
                "USER_APPROVED_SKIP",
                issue,
                action,
            )

            print(
                f"[{current_seq}] {group} - {api} - "
                f"SKIPPED_EXISTING ({logical_key})"
            )
            add_result(r)
            try:
                with self._adaptive_result_lock:
                    self.adaptive.record_api_result(current_seq, str(api), r)
            except Exception as adaptive_exc:
                print(f"Adaptive memory warning: {adaptive_exc}")

            # capture_runtime_state also understands map_primary/map_fallback.
            with self._runtime_state_lock:
                self.capture_runtime_state(key, r)
            return r

        def run_one(key: str, deps: List[str], call_factory):
            logical_key = canonical_step_key(key)

            # The canonical request shape is immutable even for a step that is
            # intentionally skipped because an object already exists. This keeps
            # planned/audit payloads structurally identical to API Testing, Flow
            # Game and LIVE execution while still making no API call.
            call_factory, generated_structure = self._lock_call_factory(
                logical_key, call_factory
            )

            if (
                self.execution_plan.is_skipped(logical_key)
                and not self.no_reuse_live_mode
                and not self.full_api_coverage_mode
                and not self.strict_live_pipeline_mode
            ):
                r = skip_existing(key, call_factory)
                with state_lock:
                    resolved[key] = True
                    reasons[key] = "SKIPPED_EXISTING_OBJECT"
                return r

            # V117 explicit HUMAN USER VALUE edit. The AI/agent cannot create or apply an edit. Method, endpoint, OAuth profile,
            # request kind, protected headers and canonical attribute structure
            # remain runner-controlled. Persisted edits are applied only before
            # first LIVE materialization; the existing immutable fingerprint then
            # prevents any mid-run/retry rewrite.
            generated_factory = json.loads(json.dumps(call_factory, default=str))
            call_factory, override_meta = self.payload_overrides.apply(
                logical_key,
                call_factory,
                {"runtime": dict(self.runtime_state), "input": self.input, "config": self.ov},
            )
            call_factory, effective_structure = self._lock_call_factory(
                logical_key, call_factory, fallback_factory=generated_factory
            )
            override_meta = dict(override_meta or {})
            override_meta["canonicalStructure"] = effective_structure
            override_meta["generatedCanonicalStructure"] = generated_structure

            # Human payload-value edits are governed separately from the agent's
            # interface-only proposal mode. The agent may propose only the allowed
            # interface transformation, but an explicit HUMAN USER may edit ANY
            # existing canonical request value before LIVE. Structure/method/URL/
            # headers remain immutable and the resulting request is fingerprinted.
            # Therefore agent proposal restrictions are never applied to a USER edit.

            # Every saved HUMAN request edit also passes through the MCP payload
            # critic. It catches unsafe raw secret values. Interface-only mode is
            # intentionally disabled here because it governs the agent proposal,
            # not the human user's value editor.
            if override_meta.get("applied"):
                request_kind = override_meta.get("requestKind") or (
                    "params" if call_factory.get("params") is not None else "payload"
                )
                mcp_override_guard = self.mcp.validate_payload_override(
                    logical_key,
                    generated_factory.get(request_kind) or {},
                    call_factory.get(request_kind) or {},
                    interface_only=False,
                )
                override_meta["mcpCritic"] = mcp_override_guard
                if not mcp_override_guard.get("valid", True):
                    raise ValueError(
                        "MCP_PAYLOAD_OVERRIDE_BLOCKED: "
                        + json.dumps(mcp_override_guard.get("errors") or [], default=str)
                    )

            # Keep payload editors/previews secret-free. Partner credentials
            # are payload fields, not application/.env credentials. Resolve
            # secure runtime_payload placeholders only in the live execution
            # path after user overrides/runtime templates have been applied.
            if call_factory.get("payload") is not None:
                call_factory["payload"] = self._resolve_runtime_payload_values(
                    call_factory.get("payload")
                )
            if call_factory.get("params") is not None:
                call_factory["params"] = self._resolve_runtime_payload_values(
                    call_factory.get("params")
                )

            with state_lock:
                missing = [d for d in deps if not resolved.get(d)]
            if missing and (self.strict_live_pipeline_mode or not self.full_api_coverage_mode):
                # Strict LIVE is assumption-free *and* dependency-safe. Do not
                # fire a dependent API with 0/stale IDs just to satisfy coverage;
                # bounded repair/coverage rounds will call it after prerequisites
                # have real LIVE evidence.
                r = skip(call_factory, deps)
                r.extracted["payloadOverride"] = override_meta
                r.extracted["logicalStepKey"] = logical_key
                r.extracted["strictDependencyGate"] = bool(self.strict_live_pipeline_mode)
                with state_lock:
                    resolved[key] = False
                    reasons[key] = r.issue
                return r

            if missing and self.full_api_coverage_mode:
                print(
                    "  -> FULL_API_COVERAGE diagnostic mode: prerequisite result(s) unresolved, "
                    "but this non-strict diagnostic call will still use configured/runtime fallback values: "
                    + ", ".join(missing)
                )

            live_request_fingerprint = self.lock_live_request_fingerprint(logical_key, call_factory)

            r = do(
                call_factory["group"], call_factory["api"], call_factory["attempt"],
                call_factory["method"], call_factory["url_key"], call_factory["scope_key"],
                payload=call_factory.get("payload"),
                params=call_factory.get("params"),
                token_kind=call_factory.get("token_kind", "HIP"),
                scope_override=call_factory.get("scope_override"),
                suffix=call_factory.get("suffix", ""),
                extra_headers=call_factory.get("extra_headers"),
            )
            if not isinstance(r.extracted, dict):
                r.extracted = {}
            r.extracted["payloadOverride"] = override_meta
            r.extracted["logicalStepKey"] = logical_key
            r.extracted["immutableLiveRequest"] = True
            r.extracted["liveRequestFingerprint"] = live_request_fingerprint
            r.extracted["fullApiCoverageMode"] = self.full_api_coverage_mode
            if missing:
                r.extracted["unresolvedPrerequisitesAtCallTime"] = missing

            resolved_now = self.enforce_live_id_integrity(logical_key, r)
            # V106 deliberately does NOT invalidate/re-resolve Document Type on
            # RULE_DOCUMENTTYPE/FK_RULE_DOCUMENTTYPE. The current Rule request has
            # no documentTypeId to repair; such a response is a backend contract
            # mismatch and remains attached to the Rule step itself.
            # Preserve stricter deterministic runner semantics for ambiguous
            # WARNING responses: only a business PASS/EXISTING can progress.
            resolved_now = bool(resolved_now and is_resolved(r))
            with state_lock:
                resolved[key] = resolved_now
                reasons[key] = result_reason(r)
            return r

        print(f"Using Test.py: {self.test_py}")
        print(f"AIA LLM judge available: {self.judge.available()}")
        print(f"AIA auth status: {self.judge.auth_status()}")
        print("Mode: STRICT WHOLE-PIPELINE LIVE — execute every applicable canonical API; no reuse/skip inference; request structures are immutable and approved value edits are locked before LIVE." if self.strict_live_pipeline_mode else ("Mode: FULL LIVE API COVERAGE — every configured API is called with schema-locked requests and approved value edits." if self.full_api_coverage_mode else ("Mode: dependency-aware LIVE with execute-all/no-reuse policy." if self.no_reuse_live_mode else "Mode: dependency-aware sequence with user-approved API skip gating.")))

        plan_summary = self.execution_plan.summary()
        print("API execution plan: " + json.dumps(plan_summary, default=str))
        print("Payload overrides: " + json.dumps(self.payload_overrides.summary(), default=str))

        interface_only_mode = self.input.get("_interface_only_mode") if isinstance(self.input, dict) else None
        if isinstance(interface_only_mode, dict) and interface_only_mode.get("enabled"):
            baseline = load_json(DEV_APPROVED_DIR / "UHAL_input_dev_approved.json", {})
            guard = validate_interface_only_input(baseline, self.input)
            print("ReAct interface-only critic: " + json.dumps(guard, default=str))
            if not guard.get("valid"):
                raise ValueError(
                    "INTERFACE_ONLY_CRITIC_BLOCKED: Everything was declared unchanged except "
                    "Transport Profile interfaceDetails, but these non-interface paths changed: "
                    + json.dumps(guard.get("violations") or [], default=str)
                )
        if not self.payload_overrides.summary().get("valid"):
            raise ValueError(
                "Payload overrides are invalid: "
                + json.dumps(self.payload_overrides.summary().get("errors", []), default=str)
            )
        if plan_summary.get("confirmed") and not plan_summary.get("active"):
            raise ValueError(
                "The saved API execution plan is confirmed but inactive/invalid. "
                "Open 'API Execution Plan' in Streamlit and re-save it for the "
                "current input.json. Details: "
                + json.dumps(
                    {
                        "errors": plan_summary.get("errors", []),
                        "warnings": plan_summary.get("warnings", []),
                        "inputMatches": plan_summary.get("inputMatches"),
                    },
                    default=str,
                )
            )

        mapping_issues = self.mapper.validate()
        mapping_errors = [item for item in mapping_issues if item.severity == "ERROR"]
        if mapping_errors:
            adaptive_analysis = self.adaptive.prepare_canonical_input(
                self.input,
                apply_safe=False,
            )
            missing_path = REPORTS / "adaptive_missing_values_required.json"
            missing_path.write_text(
                json.dumps(adaptive_analysis, indent=2, default=str),
                encoding="utf-8",
            )
            raise ValueError(
                "Input mapping has unresolved required values. Review "
                f"{missing_path} or use the Adaptive Input UI. Errors: "
                + json.dumps([asdict(item) for item in mapping_errors], default=str)
            )
        self.mcp_input_validation = self.mcp.validate_uhal_input(
            self.input,
            self.ov,
        )
        mcp_evidence_path = REPORTS / "mcp_uhal_input_validation.json"
        mcp_evidence_path.write_text(
            json.dumps(
                self.mcp_input_validation,
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )
        if not self.mcp_input_validation.get("valid", True):
            raise ValueError(
                "MCP HIP input validation failed: "
                + json.dumps(
                    self.mcp_input_validation.get("issues", []),
                    default=str,
                )
            )
        print("MCP tool status: " + json.dumps(self.mcp.status()))
        print(f"MCP input validation evidence: {mcp_evidence_path}")
        manifest_path = self.write_mapping_manifest()
        try:
            graph_status = self.adaptive.record_mapping_graph(
                self.mapper.execution_manifest()
            )
            print("Knowledge Graph: " + json.dumps(graph_status, default=str))
        except Exception as adaptive_exc:
            print(f"Knowledge Graph warning: {adaptive_exc}")
        print(f"HIP input mapping manifest: {manifest_path}")
        if self.ov.get("orchestration_only_for_flow_and_tp"):
            print("Mode: ORCHESTRATION ONLY for Transport Profile and Flow. Old direct TP/Flow APIs are disabled.")

        # ------------------------------------------------------------------
        # User-configurable execution flow + per-step wait times.
        # The UI may reorder independent steps. execution_flow.py rejects any
        # ordering that violates a hard dependency, so unsafe sequences never
        # reach live execution.
        # ------------------------------------------------------------------
        flow_summary = self.execution_flow.summary()
        if not flow_summary.get("valid"):
            raise ValueError(
                "Execution Flow & Timing configuration is invalid: "
                + json.dumps(flow_summary.get("errors", []), default=str)
            )
        print("Execution Flow & Timing: " + json.dumps(flow_summary, default=str))

        def apply_configured_wait(
            step_key: str,
            result: Result,
            *,
            step_started_perf: float,
            step_started_at: dt.datetime,
        ) -> Dict[str, Any]:
            configured = float(self.execution_flow.wait_after(step_key) or 0.0)
            actual = 0.0
            wait_status = "NOT_CONFIGURED" if configured <= 0 else "CONFIGURED"
            should_wait = (
                configured > 0
                and result.classification not in {
                    "SKIPPED_BY_USER_EXISTING_OBJECT",
                    "SKIPPED_DEPENDENCY",
                }
            )
            if should_wait:
                print(
                    f"Waiting {configured:g}s after "
                    f"{FLOW_STEP_DEFINITIONS[step_key]['label']} before the next API."
                )
                wait_started = time.perf_counter()
                time.sleep(configured)
                actual = round(time.perf_counter() - wait_started, 3)
                wait_status = "WAITED"
            elif configured > 0:
                wait_status = "SKIPPED_STEP_NOT_WAITED"

            step_finished_at = dt.datetime.now(dt.timezone.utc)
            total_step_seconds = round(time.perf_counter() - step_started_perf, 3)
            api_elapsed_ms = result.elapsed_ms if result.elapsed_ms is not None else 0
            event = {
                "stepKey": step_key,
                "label": FLOW_STEP_DEFINITIONS[step_key]["label"],
                "sequence": result.sequence,
                "resultClassification": result.classification,
                "startedAt": step_started_at.isoformat(),
                "finishedAt": step_finished_at.isoformat(),
                "apiElapsedMs": api_elapsed_ms,
                "apiElapsedSeconds": round(api_elapsed_ms / 1000.0, 3),
                "configuredWaitAfterSeconds": configured,
                "actualWaitSeconds": actual,
                "waitStatus": wait_status,
                "totalStepSeconds": total_step_seconds,
                "recordedAt": step_finished_at.isoformat(),
            }
            with state_lock:
                self.execution_timing_events.append(event)
            print(
                f"  -> STEP TIME {FLOW_STEP_DEFINITIONS[step_key]['label']}: "
                f"API={event['apiElapsedSeconds']:.3f}s | wait={actual:.3f}s | total={total_step_seconds:.3f}s"
            )
            return event

        def deps_for(step_key: str) -> List[str]:
            deps = list(FLOW_STEP_DEFINITIONS.get(step_key, {}).get("dependencies", []))

            # V108 execute-all contract-aware soft foundation dependencies. Account/Partner/
            # System create APIs are name-addressed foundation operations, while
            # TP orchestration consumes the already-known names (systemName,
            # Existing Account Name, Partner name, deploymentGroupName), not an
            # ID returned by those create calls. A gateway route outage therefore
            # must remain visible on the foundation step but must not automatically
            # suppress a TP call that can independently prove whether the named
            # object already exists.
            if step_key == "partner_target":
                deps = [d for d in deps if d != "account_source"]
            if step_key in {"source_tp", "target_tp"}:
                deps = [
                    d for d in deps
                    if d not in {"system_source", "partner_target", "account_source", "account_target"}
                ]
            return deps

        def poll_terminal_audit(
            step_key: str,
            call_factory: Dict[str, Any],
            *,
            pending_classification: str,
            timeout_classification: str,
            poll_kind: str,
        ) -> Result:
            """Poll one HIP Audit API until SUCCESS/FAILURE or the one-hour timeout.

            Dev feedback 2026-08-28 requires TP and Flow-deployment completion
            to be based on Audit status, not on a fixed sleep or request
            acceptance. Defaults are one request per minute for one hour.
            Tests/non-production diagnostics may shorten these values through
            the explicit environment variables below.
            """
            prefix = "HIP_TP" if poll_kind == "TP" else "HIP_FLOW"
            interval = float(os.getenv(
                f"{prefix}_AUDIT_POLL_INTERVAL_SECONDS",
                os.getenv("HIP_AUDIT_POLL_INTERVAL_SECONDS", "60"),
            ) or 60)
            timeout = float(os.getenv(
                f"{prefix}_AUDIT_POLL_TIMEOUT_SECONDS",
                os.getenv("HIP_AUDIT_POLL_TIMEOUT_SECONDS", "3600"),
            ) or 3600)
            interval = max(0.01, interval)
            timeout = max(0.01, timeout)
            started = time.monotonic()
            poll_attempt = 0
            last: Optional[Result] = None

            while True:
                poll_attempt += 1
                factory = json.loads(json.dumps(call_factory, default=str))
                factory["attempt"] = f"{call_factory.get('attempt') or step_key}_poll_{poll_attempt:02d}"
                last = run_one(step_key, deps_for(step_key), factory)
                if not isinstance(last.extracted, dict):
                    last.extracted = {}
                elapsed = max(0.0, time.monotonic() - started)
                last.extracted["auditPolling"] = {
                    "kind": poll_kind,
                    "attempt": poll_attempt,
                    "intervalSeconds": interval,
                    "timeoutSeconds": timeout,
                    "elapsedSeconds": round(elapsed, 3),
                    "terminal": bool(last.business_success or last.classification != pending_classification),
                }

                if last.business_success:
                    return last
                if last.classification != pending_classification:
                    # Audit explicitly returned FAILURE/ERROR. Do not wait out
                    # the whole hour once a terminal failure is known.
                    return last

                remaining = timeout - elapsed
                if remaining <= 0:
                    last.classification = timeout_classification
                    last.business_success = False
                    last.issue = (
                        f"{poll_kind} audit did not return a terminal success/failure "
                        f"within {timeout:g} seconds."
                    )
                    last.action_required = (
                        "Treat the operation as stuck. Review HIP audit evidence before retrying."
                    )
                    last.error = timeout_classification
                    last.extracted["auditPolling"]["terminal"] = True
                    last.extracted["auditPolling"]["timedOut"] = True
                    with state_lock:
                        resolved[step_key] = False
                        reasons[step_key] = timeout_classification
                    return last

                sleep_for = min(interval, remaining)
                callback = getattr(self, "request_event_callback", None)
                if callable(callback):
                    try:
                        callback({
                            "type": "audit.poll.wait",
                            "stepKey": step_key,
                            "pollKind": poll_kind,
                            "attempt": poll_attempt,
                            "sleepSeconds": sleep_for,
                            "timeoutSeconds": timeout,
                        })
                    except Exception:
                        pass
                print(
                    f"  -> {poll_kind} audit pending; polling again in "
                    f"{sleep_for:g}s (attempt {poll_attempt})."
                )
                time.sleep(sleep_for)

        def execute_step(step_key: str) -> Result:
            if step_key == "validate_source":
                return run_one(step_key, [], {
                    "group": "Validation",
                    "api": "Validate source TP unique",
                    "attempt": "validate_source",
                    "method": "POST",
                    "url_key": "tp_validate",
                    "scope_key": "transport_profile",
                    "payload": {
                        "interfaceType": self.tp_interface_type(self.source_tp()),
                        "propertyMap": self.tp_parameters(self.source_tp(), "source"),
                        "transportProfileName": self.source_tp().get("profile_name"),
                        "hipEnvironment": self.env,
                    },
                })

            if step_key == "validate_target":
                return run_one(step_key, [], {
                    "group": "Validation",
                    "api": "Validate target TP unique",
                    "attempt": "validate_target",
                    "method": "POST",
                    "url_key": "tp_validate",
                    "scope_key": "transport_profile",
                    "payload": {
                        "interfaceType": self.tp_interface_type(self.target_tp()),
                        "propertyMap": self.tp_parameters(self.target_tp(), "target"),
                        "transportProfileName": self.target_tp().get("profile_name"),
                        "hipEnvironment": self.env,
                    },
                })

            if step_key == "validate_flow":
                return run_one(step_key, [], {
                    "group": "Validation",
                    "api": "Validate flow name",
                    "attempt": "validate_flow",
                    "method": "GET",
                    "url_key": "flow_validate",
                    "scope_key": "flow",
                    "params": {"flowName": self.flow_name()},
                })

            if step_key == "account_source":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Account",
                    "api": "Create source account",
                    "attempt": "source_account_dce_domain",
                    "method": "POST",
                    "url_key": "account",
                    "scope_key": "account",
                    "token_kind": "ACCOUNT",
                    "scope_override": self.account_scope,
                    "payload": self.account_payload(),
                })

            if step_key == "account_target":
                target_account_payload = self.account_payload()
                target_account_payload["accountName"] = (
                    self.target_account_name()
                )
                target_account_payload["description"] = (
                    "Target HAFT account generated by HIP dependency sequencer"
                )
                return run_one(step_key, deps_for(step_key), {
                    "group": "Account",
                    "api": "Create target account",
                    "attempt": "target_account_dce_domain",
                    "method": "POST",
                    "url_key": "account",
                    "scope_key": "account",
                    "token_kind": "ACCOUNT",
                    "scope_override": self.account_scope,
                    "payload": target_account_payload,
                })

            if step_key == "partner_target":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Partner",
                    "api": "Create partner",
                    "attempt": "partner_payload_x_account_name",
                    "method": "POST",
                    "url_key": "partner",
                    "scope_key": "partner",
                    "token_kind": "PARTNER",
                    "scope_override": self.partner_scope,
                    "payload": self.partner_payload(),
                    "extra_headers": {"x-account-name": self.partner_x_account_name},
                })

            if step_key == "system_source":
                return run_one(step_key, deps_for(step_key), {
                    "group": "System",
                    "api": "Create system",
                    "attempt": "system_payload",
                    "method": "POST",
                    "url_key": "system",
                    "scope_key": "system",
                    "token_kind": "SYSTEM",
                    "scope_override": self.system_scope,
                    "payload": self.system_payload(),
                })

            if step_key == "doctype_source":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Document Type",
                    "api": "Create source document type",
                    "attempt": "fixed_payload",
                    "method": "POST",
                    "url_key": "document_type",
                    "scope_key": "document_type",
                    "payload": self.doc_payload(self.source_doc(), "source"),
                })

            if step_key == "doctype_target":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Document Type",
                    "api": "Create target document type",
                    "attempt": "fixed_payload",
                    "method": "POST",
                    "url_key": "document_type",
                    "scope_key": "document_type",
                    "payload": self.doc_payload(self.target_doc(), "target"),
                })

            if step_key == "map":
                xbm_available = bool(self._map_xbm_file(str(self.data_map().get("map_name") or "")))
                # V108: one canonical MAP request only. Never mutate the request by
                # dropping XREF and retrying a different payload after an error.
                return run_one("map", deps_for(step_key), {
                    "group": "Map",
                    "api": "Create/resolve MAC Map",
                    "attempt": "dev_approved_with_xref" if xbm_available else "dev_approved_without_xref",
                    "method": "POST",
                    "url_key": "map",
                    "scope_key": "map",
                    "token_kind": "MAP",
                    "scope_override": self.map_scope,
                    "payload": self.map_payload(xbm_available),
                })

            if step_key == "rule":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Rule",
                    "api": "Create mapping rule",
                    "attempt": "dev_approved_rule_without_runtime_ids",
                    "method": "POST",
                    "url_key": "rule",
                    "scope_key": "rule",
                    "payload": self.rule_payload(),
                })

            if step_key == "source_tp":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Orchestration",
                    "api": "Source TP orchestration create ONLY",
                    "attempt": "dependency_gated_systemName_deploymentGroupName",
                    "method": "POST",
                    "url_key": "orch_tp_create",
                    "scope_key": "transport_profile",
                    "payload": self.tp_orch_payload(self.source_tp(), "source"),
                })

            if step_key == "target_tp":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Orchestration",
                    "api": "Target TP orchestration create ONLY",
                    "attempt": "dependency_gated_systemName_deploymentGroupName",
                    "method": "POST",
                    "url_key": "orch_tp_create",
                    "scope_key": "transport_profile",
                    "payload": self.tp_orch_payload(self.target_tp(), "target"),
                })

            if step_key == "flow_create":
                # V108: execute exactly the canonical Flow Create request. A name
                # collision is reported as returned by HIP; the agent must not
                # rewrite flowName and issue a different payload.
                return run_one(step_key, deps_for(step_key), {
                    "group": "Orchestration",
                    "api": "Flow orchestration create ONLY",
                    "attempt": "dependency_gated_flow_create",
                    "method": "POST",
                    "url_key": "orch_flow_create",
                    "scope_key": "flow",
                    "payload": self.flow_orch_payload(),
                })

            if step_key == "flow_deploy":
                return run_one(step_key, deps_for(step_key), {
                    "group": "Orchestration",
                    "api": "Flow orchestration deploy ONLY",
                    "attempt": "dependency_gated_flow_deploy",
                    "method": "POST",
                    "url_key": "orch_flow_deploy",
                    "scope_key": "flow",
                    "payload": self.deploy_orch_payload(),
                })

            if step_key == "flow_history":
                return poll_terminal_audit(step_key, {
                    "group": "History",
                    "api": "Flow deployment history",
                    "attempt": "flow_history",
                    "method": "GET",
                    "url_key": "flow_deploy_history",
                    "scope_key": "flow",
                    "params": {
                        "flowName": self.flow_name(),
                        "flowVersion": self.version_str(self.ov.get("flowVersion", "1.0")),
                        "environment": self.env,
                    },
                }, pending_classification="FLOW_DEPLOYMENT_AUDIT_PENDING",
                   timeout_classification="FLOW_DEPLOYMENT_AUDIT_TIMEOUT",
                   poll_kind="FLOW")

            if step_key == "source_tp_audit":
                return poll_terminal_audit(step_key, {
                    "group": "History",
                    "api": "Source TP audit history",
                    "attempt": "tp_source_audit",
                    "method": "GET",
                    "url_key": "tp_audits",
                    "scope_key": "transport_profile",
                    "params": {
                        "transportProfileName": self.source_tp().get("profile_name"),
                        "hipEnvironment": self.env,
                    },
                }, pending_classification="TP_AUDIT_PENDING",
                   timeout_classification="TP_AUDIT_TIMEOUT",
                   poll_kind="TP")

            if step_key == "target_tp_audit":
                return poll_terminal_audit(step_key, {
                    "group": "History",
                    "api": "Target TP audit history",
                    "attempt": "tp_target_audit",
                    "method": "GET",
                    "url_key": "tp_audits",
                    "scope_key": "transport_profile",
                    "params": {
                        "transportProfileName": self.target_tp().get("profile_name"),
                        "hipEnvironment": self.env,
                    },
                }, pending_classification="TP_AUDIT_PENDING",
                   timeout_classification="TP_AUDIT_TIMEOUT",
                   poll_kind="TP")

            raise ValueError(f"Unknown execution-flow step: {step_key}")

        ordered_steps = self.execution_flow.ordered_steps()
        api_parallel_enabled = env_bool("HIP_API_PARALLEL_ENABLED", False)
        api_parallel_limit = max(1, min(int(os.getenv("HIP_API_MAX_PARALLEL", "18") or 18), len(ordered_steps)))

        def execute_timed_step(step_key: str) -> Result:
            step_started_perf = time.perf_counter()
            step_started_at = dt.datetime.now(dt.timezone.utc)
            if self.step_applicable(step_key):
                result = execute_step(step_key)
                apply_configured_wait(
                    step_key, result,
                    step_started_perf=step_started_perf,
                    step_started_at=step_started_at,
                )
                return result
            result = not_applicable(step_key)
            step_finished_at = dt.datetime.now(dt.timezone.utc)
            total_step_seconds = round(time.perf_counter() - step_started_perf, 3)
            event = {
                "stepKey": step_key,
                "label": FLOW_STEP_DEFINITIONS[step_key]["label"],
                "sequence": result.sequence,
                "resultClassification": result.classification,
                "startedAt": step_started_at.isoformat(),
                "finishedAt": step_finished_at.isoformat(),
                "apiElapsedMs": 0,
                "apiElapsedSeconds": 0.0,
                "configuredWaitAfterSeconds": 0.0,
                "actualWaitSeconds": 0.0,
                "waitStatus": "NOT_APPLICABLE",
                "totalStepSeconds": total_step_seconds,
                "recordedAt": step_finished_at.isoformat(),
            }
            with state_lock:
                self.execution_timing_events.append(event)
            return result

        if not api_parallel_enabled:
            for step_key in ordered_steps:
                execute_timed_step(step_key)
        else:
            print(
                "HIP API parallel scheduler: enabled. One LLM agent may issue all "
                f"dependency-ready HIP API calls concurrently (max {api_parallel_limit})."
            )
            pending = list(ordered_steps)
            completed_steps: set[str] = set()
            wave_number = 0
            while pending:
                # NOT_APPLICABLE steps are safe to resolve locally immediately; this
                # can unblock downstream canonical steps without an HTTP call.
                local_steps = [key for key in pending if not self.step_applicable(key)]
                for key in local_steps:
                    execute_timed_step(key)
                    pending.remove(key)
                    completed_steps.add(key)
                if not pending:
                    break

                ready = [
                    key for key in pending
                    if all(dep in completed_steps for dep in deps_for(key))
                ]
                if not ready:
                    # Defensive fallback: execution_flow validation should make this
                    # impossible, but never deadlock a LIVE run if a dynamic TP
                    # dependency was introduced incorrectly.
                    ready = [pending[0]]
                wave = ready[:api_parallel_limit]
                wave_number += 1
                print(
                    f"API parallel wave {wave_number}: {len(wave)} dependency-ready call(s): "
                    + ", ".join(FLOW_STEP_DEFINITIONS[key]["label"] for key in wave)
                )
                with ThreadPoolExecutor(max_workers=len(wave), thread_name_prefix="hip-api") as executor:
                    futures = {executor.submit(execute_timed_step, key): key for key in wave}
                    for future in as_completed(futures):
                        key = futures[future]
                        # Propagate unexpected exceptions; normal API failures are
                        # represented as Result rows and remain dependency-aware.
                        future.result()
                        completed_steps.add(key)
                        pending.remove(key)

        # V95 LIVE AUTO-COMPLETE
        # ----------------------
        # Clicking RUN LIVE EXECUTION must do more than produce a validation
        # report: it must actually finish every missing business object it can
        # safely create/resolve.  The first dependency-aware pass remains fast
        # and parallel. If a transient OAuth/network/API problem left a required
        # prerequisite unresolved, perform bounded repair passes in dependency
        # order using the now-populated runtime state. Successful later evidence
        # also reconciles an earlier error-shaped create as reusable.
        completion_business_steps = [
            "account_source", "account_target", "partner_target", "system_source",
            "doctype_source", "doctype_target", "map", "rule",
            "source_tp", "target_tp", "source_tp_audit", "target_tp_audit",
            "flow_create", "flow_deploy", "flow_history",
        ]
        completion_business_steps = [key for key in completion_business_steps if self.step_applicable(key)]
        auto_complete_enabled = env_bool("HIP_LIVE_AUTO_COMPLETE", True) and (not self.full_api_coverage_mode or self.strict_live_pipeline_mode)
        auto_complete_max_rounds = max(0, min(int(os.getenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2") or 2), 5))
        completion_rounds: List[Dict[str, Any]] = []

        def reconcile_runtime_resolution() -> None:
            from report_insights import reconcile_execution_analyses
            analyses = reconcile_execution_analyses(results)
            for row, analysis in zip(results, analyses):
                extracted = row.extracted if isinstance(row.extracted, dict) else {}
                key = canonical_step_key(str(extracted.get("logicalStepKey") or extracted.get("stepKey") or ""))
                if not key:
                    continue
                verdict = str(analysis.get("verdict") or "").upper()
                outcome = str(analysis.get("outcome") or "").upper()
                # Strict whole-pipeline LIVE never resolves an API from a later
                # dependent call. The same logical API must itself return PASS,
                # EXISTING, or a successful retry. Non-strict mode retains the
                # historical reconciliation behavior for compatibility.
                accepted_outcomes = {"EXISTING", "RETRIED_SUCCESS"}
                # V116: current-run explicit EXISTING evidence from Flow Create
                # is a resolved dependency for Deploy. Historical/packaged state
                # still never resolves a step because strict LIVE executes the
                # canonical Create API first and accepts only its own response.
                if verdict == "PASS" or outcome in accepted_outcomes:
                    # A previous PASS cannot resurrect a runtime ID that a later
                    # dependent API proved invalid. ID-bearing prerequisites are
                    # reconciled only while their *current* runtime ID is present.
                    if self.step_requires_live_id_for_progress(key) and not self.required_live_runtime_id(key):
                        continue
                    with state_lock:
                        resolved[key] = True
                        reasons[key] = outcome or verdict or "RECONCILED"

        reconcile_runtime_resolution()
        if auto_complete_enabled and auto_complete_max_rounds > 0:
            for repair_round in range(1, auto_complete_max_rounds + 1):
                unresolved_before = [key for key in completion_business_steps if not resolved.get(key)]
                if not unresolved_before:
                    break
                attempted: List[str] = []
                resolved_this_round: List[str] = []
                for key in completion_business_steps:
                    if resolved.get(key):
                        continue
                    if self.is_non_retryable_completion_reason(reasons.get(key)):
                        # A gateway-proven missing upstream PCF route is not a
                        # transient customer/request problem. Avoid wasting repair
                        # rounds until the endpoint is changed/restored.
                        continue
                    dependencies = [dep for dep in deps_for(key) if self.step_applicable(dep)]
                    if any(not resolved.get(dep) for dep in dependencies):
                        continue
                    attempted.append(key)
                    was_resolved = bool(resolved.get(key))
                    execute_timed_step(key)
                    if not was_resolved and resolved.get(key):
                        resolved_this_round.append(key)
                reconcile_runtime_resolution()
                unresolved_after = [key for key in completion_business_steps if not resolved.get(key)]
                completion_rounds.append({
                    "round": repair_round,
                    "attempted": attempted,
                    "resolvedThisRound": resolved_this_round,
                    "unresolvedBefore": unresolved_before,
                    "unresolvedAfter": unresolved_after,
                })
                if not unresolved_after:
                    break
                # No ready step means a genuine dependency/config blocker remains;
                # do not loop forever. If steps were attempted but remained
                # unresolved, one later bounded round is still allowed for a
                # transient backend condition.
                if not attempted:
                    break
                if repair_round < auto_complete_max_rounds:
                    time.sleep(min(1.0 * repair_round, 2.0))

        # V96 STRICT WHOLE-PIPELINE LIVE COVERAGE
        # --------------------------------------
        # The production LIVE button must not merely infer that an API was not
        # needed.  After business-object auto-completion, explicitly retry every
        # applicable canonical step that still has no real HTTP response. This
        # includes the three validation calls and both TP audit calls. Persisted
        # skip plans are ignored in strict mode, so "already exists" is proven
        # by the API response rather than assumed.
        strict_coverage_rounds: List[Dict[str, Any]] = []
        strict_coverage_max_rounds = max(1, min(int(os.getenv("HIP_STRICT_COVERAGE_ROUNDS", "3") or 3), 6))

        def logical_http_steps() -> set[str]:
            return {
                canonical_step_key(str((row.extracted or {}).get("logicalStepKey") or ""))
                for row in results
                if row.status_code is not None
                and str((row.extracted or {}).get("logicalStepKey") or "").strip()
            }

        if self.strict_live_pipeline_mode:
            ordered_applicable = [key for key in ordered_steps if self.step_applicable(key)]
            for coverage_round in range(1, strict_coverage_max_rounds + 1):
                already_called = logical_http_steps()
                missing_before = [key for key in ordered_applicable if key not in already_called]
                if not missing_before:
                    break
                attempted: List[str] = []
                blocked_by_dependency: Dict[str, List[str]] = {}
                for key in ordered_applicable:
                    if key not in missing_before:
                        continue
                    dependencies = [dep for dep in deps_for(key) if self.step_applicable(dep)]
                    missing_deps = [dep for dep in dependencies if not resolved.get(dep)]
                    if missing_deps:
                        blocked_by_dependency[key] = missing_deps
                        continue
                    attempted.append(key)
                    execute_timed_step(key)
                    reconcile_runtime_resolution()
                missing_after = [key for key in ordered_applicable if key not in logical_http_steps()]
                strict_coverage_rounds.append({
                    "round": coverage_round,
                    "missingBefore": missing_before,
                    "attempted": attempted,
                    "blockedByDependency": blocked_by_dependency,
                    "missingAfter": missing_after,
                })
                if not missing_after:
                    break
                if not attempted:
                    break
                if coverage_round < strict_coverage_max_rounds:
                    time.sleep(min(0.75 * coverage_round, 2.0))

        # Parallel completion order is intentionally non-deterministic; sequence is
        # allocated before each HTTP call so reports remain stable and readable.
        results.sort(key=lambda row: int(getattr(row, "sequence", 0) or 0))
        self.execution_timing_events.sort(key=lambda row: int(row.get("sequence") or 0))

        atomic_write_json(
            REPORTS / "execution_timing_latest.json",
            {
                "generatedAt": dt.datetime.now().isoformat(),
                "buildId": BUILD_ID,
                "executionFlow": self.execution_flow.summary(),
                "events": self.execution_timing_events,
            },
        )

        required_business_steps = list(completion_business_steps)
        reconcile_runtime_resolution()
        unresolved_required = [
            key for key in required_business_steps if not resolved.get(key)
        ]
        observed_logical_steps = {
            canonical_step_key(str((r.extracted or {}).get("logicalStepKey") or ""))
            for r in results
            if str((r.extracted or {}).get("logicalStepKey") or "").strip()
        }
        # Full API coverage requires an actual HTTP response for every logical
        # building block. A contract-blocked/local exception result is
        # evidence, but it is not counted as a completed live API call.
        http_response_steps = {
            canonical_step_key(str((r.extracted or {}).get("logicalStepKey") or ""))
            for r in results
            if r.status_code is not None
            and str((r.extracted or {}).get("logicalStepKey") or "").strip()
        }
        expected_logical_steps = {
            key for key in self.execution_flow.ordered_steps() if self.step_applicable(key)
        }
        coverage_missing_steps = sorted(expected_logical_steps - http_response_steps)
        skipped_api_results = [
            r for r in results
            if str(r.classification or "").startswith("SKIPPED_")
        ]
        coverage_required = bool(self.full_api_coverage_mode or self.strict_live_pipeline_mode)
        coverage_complete = bool(
            coverage_required
            and not coverage_missing_steps
            # Historical dependency skips are acceptable in strict mode only if
            # the same logical APIs were subsequently called and captured.
            and (self.strict_live_pipeline_mode or not skipped_api_results)
        )

        # Build one assumption-free canonical evidence manifest. For each API,
        # select the latest real HTTP attempt (never a local inferred/skip row).
        latest_http_by_step: Dict[str, Result] = {}
        latest_any_by_step: Dict[str, Result] = {}
        for row in results:
            key = canonical_step_key(str((row.extracted or {}).get("logicalStepKey") or ""))
            if not key:
                continue
            latest_any_by_step[key] = row
            if row.status_code is not None:
                latest_http_by_step[key] = row
        live_evidence_rows: List[Dict[str, Any]] = []
        for key in self.execution_flow.ordered_steps():
            applicable = self.step_applicable(key)
            row = latest_http_by_step.get(key) or latest_any_by_step.get(key)
            live_evidence_rows.append(redact_sensitive({
                "stepKey": key,
                "label": FLOW_STEP_DEFINITIONS[key]["label"],
                "applicable": applicable,
                "apiCalled": bool(key in latest_http_by_step),
                "httpStatus": getattr(row, "status_code", None) if row else None,
                "classification": getattr(row, "classification", "NOT_EXECUTED") if row else "NOT_EXECUTED",
                "businessSuccess": bool(getattr(row, "business_success", False)) if row else False,
                "sequence": getattr(row, "sequence", None) if row else None,
                "requestEvidenceFile": getattr(row, "payload_file", "") if row else "",
                "responseEvidenceFile": ((getattr(row, "extracted", {}) or {}).get("responseEvidenceFile") if row else ""),
                "elapsedMs": getattr(row, "elapsed_ms", None) if row else None,
                "error": getattr(row, "error", "") if row else "",
            }))
        strict_nonpassing_steps = sorted(
            key for key in expected_logical_steps
            if key in latest_http_by_step and not is_resolved(latest_http_by_step[key])
        )
        live_evidence_manifest = {
            "generatedAt": dt.datetime.now(dt.timezone.utc).isoformat(),
            "buildId": BUILD_ID,
            "mode": "STRICT_WHOLE_PIPELINE_LIVE" if self.strict_live_pipeline_mode else ("FULL_LIVE_API_COVERAGE" if self.full_api_coverage_mode else "DEPENDENCY_AWARE"),
            "assumptionFree": bool(self.strict_live_pipeline_mode),
            "skipPlanIgnored": bool(self.strict_live_pipeline_mode),
            "expectedApplicableApiCount": len(expected_logical_steps),
            "calledApplicableApiCount": len(expected_logical_steps.intersection(http_response_steps)),
            "coverageComplete": coverage_complete,
            "coverageMissingSteps": coverage_missing_steps,
            "nonPassingLiveSteps": strict_nonpassing_steps,
            "rows": live_evidence_rows,
        }
        atomic_write_json(REPORTS / "live_api_evidence_manifest_latest.json", live_evidence_manifest)

        strict_success = bool(
            not unresolved_required
            and (coverage_complete if self.strict_live_pipeline_mode else True)
            and (not strict_nonpassing_steps if self.strict_live_pipeline_mode else True)
        )
        self.final_state = {
            "generatedAt": dt.datetime.now().isoformat(),
            "success": strict_success,
            "businessSuccess": not unresolved_required,
            "strictLivePipelineMode": self.strict_live_pipeline_mode,
            "assumptionFreeExecution": self.strict_live_pipeline_mode,
            "fullApiCoverageMode": self.full_api_coverage_mode,
            "coverageComplete": coverage_complete,
            "coverageMissingSteps": coverage_missing_steps,
            "strictNonPassingLiveSteps": strict_nonpassing_steps if self.strict_live_pipeline_mode else [],
            "logicalStepsObserved": sorted(observed_logical_steps),
            "logicalStepsWithHttpResponse": sorted(http_response_steps),
            "skippedApiResultCount": len(skipped_api_results),
            "liveResultCount": len(results),
            "unresolvedRequiredSteps": unresolved_required,
            "resolved": resolved,
            "reasons": reasons,
            "runtimeIds": self.runtime_state,
            "apiExecutionPlan": self.execution_plan.summary(),
            "payloadOverrides": self.payload_overrides.summary(),
            "executionFlow": self.execution_flow.summary(),
            "executionTiming": self.execution_timing_events,
            "apiParallelExecutionEnabled": api_parallel_enabled,
            "apiParallelLimit": api_parallel_limit if api_parallel_enabled else 1,
            "apiParallelStrategy": "DEPENDENCY_READY" if api_parallel_enabled else "SEQUENTIAL",
            "liveApiExecution": True,
            "autoCompleteMissingEnabled": auto_complete_enabled,
            "autoCompleteMaxRounds": auto_complete_max_rounds,
            "autoCompletionRounds": completion_rounds,
            "strictCoverageMaxRounds": strict_coverage_max_rounds if self.strict_live_pipeline_mode else 0,
            "strictCoverageRounds": strict_coverage_rounds,
            "liveApiEvidenceManifest": str(REPORTS / "live_api_evidence_manifest_latest.json"),
            "mappingManifest": str(REPORTS / "uhal_input_to_api_mapping_manifest.json"),
        }
        atomic_write_json(
            REPORTS / "uhal_end_to_end_status_latest.json",
            redact_sensitive(self.final_state),
        )

        # Write dependency state evidence beside normal reports.
        dep_state = {
            "generated_at": dt.datetime.now().isoformat(),
            "mode": "strict_whole_pipeline_live" if self.strict_live_pipeline_mode else ("full_live_api_coverage" if self.full_api_coverage_mode else "dependency_aware_sequence_with_user_api_skip_plan"),
            "api_execution_plan": self.execution_plan.summary(),
            "execution_flow": self.execution_flow.summary(),
            "execution_timing": self.execution_timing_events,
            "resolved": resolved,
            "reasons": reasons,
            "end_to_end_success": self.final_state.get("success", False),
            "unresolved_required_steps": self.final_state.get("unresolvedRequiredSteps", []),
            "runtime_ids": self.runtime_state,
            "order": self.execution_flow.ordered_steps(),
        }
        (REPORTS / f"dependency_sequence_state_{stamp()}.json").write_text(json.dumps(dep_state, indent=2, default=str), encoding="utf-8")
        return results


def write_reports(results: List[Result], runner: Runner) -> Path:
    from report_insights import analyze_api_response, reconcile_execution_analyses, format_duration_ms, format_duration_seconds
    ts = stamp()
    json_path = REPORTS / f"hip_aia_mcp_agent_report_{ts}.json"
    csv_path = REPORTS / f"hip_aia_mcp_agent_findings_{ts}.csv"
    html_path = REPORTS / f"hip_aia_mcp_agent_report_{ts}.html"
    md_path = REPORTS / f"hip_aia_mcp_agent_verdict_{ts}.md"
    teams_path = REPORTS / f"teams_summary_{ts}.txt"
    runtime_path = REPORTS / f"runtime_context_{ts}.json"

    json_path.write_text(json.dumps([asdict(r) for r in results], indent=2, default=str), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(asdict(results[0]).keys()))
        w.writeheader()
        for r in results:
            w.writerow(asdict(r))

    counts: Dict[str, int] = {}
    owner_counts: Dict[str, int] = {}
    for r in results:
        counts[r.classification] = counts.get(r.classification, 0) + 1
        owner_counts[r.final_owner] = owner_counts.get(r.final_owner, 0) + 1

    runtime = {
        "generated_at": dt.datetime.now().isoformat(),
        "build_id": BUILD_ID,
        "test_py_path": str(runner.test_py),
        "requester": runner.requester,
        "secrets_written_to_report": False,
        "aia_llm_judge_available": runner.judge.available(),
        "aia_llm_auth_status": runner.judge.auth_status(),
        "api_execution_plan": runner.execution_plan.summary(),
        "payload_overrides": runner.payload_overrides.summary(),
        "execution_flow": runner.execution_flow.summary(),
        "execution_timing": runner.execution_timing_events,
        "credential_profiles": {
            "hipConfig": {"configured": bool(runner.hip_client_id and runner.hip_client_secret), "tokenUrl": runner.hip_token_url},
            "account": {"configured": bool(runner.account_client_id and runner.account_client_secret), "required": runner.strict_live_pipeline_mode or not (runner.execution_plan.is_skipped("account_source") and runner.execution_plan.is_skipped("account_target")), "tokenUrl": runner.account_token_url},
            "partner": {"configured": bool(runner.partner_client_id and runner.partner_client_secret), "required": runner.strict_live_pipeline_mode or not runner.execution_plan.is_skipped("partner_target"), "tokenUrl": runner.partner_token_url},
            "system": {"configured": bool(runner.system_client_id and runner.system_client_secret), "required": runner.strict_live_pipeline_mode or not runner.execution_plan.is_skipped("system_source"), "tokenUrl": runner.system_token_url},
            "dellAia": {"configured": runner.judge.available(), "model": runner.judge.model},
        },
        "implemented_docs": ["HIP Flow Orchestration (2).docx", "HIP Orchestration (2).docx"],
        "key_updates": [
            "HIP Config OAuth is shared with MAC Map; Account, Partner and System support separate OAuth credential profiles.",
            "Strict whole-pipeline LIVE requires every credential profile used by the 18 canonical APIs.",
            "Strict whole-pipeline LIVE ignores user skip plans; existing objects must be proven by the live API response.",
            "Execution order and per-API wait-after timing are user-configurable with hard dependency validation.",
            "Payload Studio overrides are user-approved, runtime-templated and contract-validated before live execution.",
            "API documentation PDFs can be uploaded in Streamlit and merged with built-in/MCP validation knowledge.",
            "Dell AIA can propose a flow/timing plan, but user approval is required before applying it.",
            "Generic HTTP 500 responses are not treated as existing objects.",
            "TP and Flow creation use orchestration-only APIs; old direct TP/Flow create is disabled."
        ],
    }
    runtime_path.write_text(json.dumps(runtime, indent=2), encoding="utf-8")

    raw_rows = [asdict(r) for r in results]
    analyses = reconcile_execution_analyses(raw_rows)
    verdict_counts = {key: 0 for key in ("PASS", "WARNING", "FAIL", "BLOCKED", "SKIPPED")}
    compact_rows = []
    attention = []
    total_api_seconds = sum(float(r.elapsed_ms or 0) for r in results) / 1000.0
    for r, analysis in zip(results, analyses):
        verdict = str(analysis.get("verdict") or "WARNING").upper()
        verdict_counts[verdict] = verdict_counts.get(verdict, 0) + 1
        if verdict in {"WARNING", "FAIL", "BLOCKED"}:
            attention.append(f"<div class='att {verdict}'><b>#{r.sequence} {html.escape(r.api)} · {html.escape(verdict)}</b><p>{html.escape(str(analysis.get('reason') or ''))}</p></div>")
        compact_rows.append(f"""<tr><td>{r.sequence}</td><td><b>{html.escape(r.group)} — {html.escape(r.api)}</b><small>{html.escape(r.attempt)}</small></td><td>{html.escape(str(r.status_code if r.status_code is not None else '—'))}</td><td><span class='pill {verdict}'>{html.escape(verdict)}</span><small>{html.escape(str(analysis.get('outcome') or ''))}</small></td><td>{html.escape(format_duration_ms(r.elapsed_ms or 0))}</td><td>{html.escape(str(analysis.get('reason') or ''))}</td><td><details><summary>Evidence</summary><p><b>Next:</b> {html.escape(str(analysis.get('nextAction') or ''))}</p><details><summary>Request</summary><pre>{html.escape(r.request_preview or '')}</pre></details><details><summary>Response / error</summary><pre>{html.escape(r.response_preview or r.error or '')}</pre></details><details><summary>Extracted</summary><pre>{html.escape(json.dumps(r.extracted, indent=2, default=str))}</pre></details></details></td></tr>""")
    overall = "FAIL" if verdict_counts.get("FAIL") else ("BLOCKED" if verdict_counts.get("BLOCKED") else ("WARNING" if verdict_counts.get("WARNING") else "PASS"))
    html_doc = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>HIP Agent Final Response Report</title>
<style>:root{{--green:#137454;--amber:#8a5a00;--red:#a8241b;--blue:#0672ce;--line:rgba(159,185,202,.48);--muted:#536d7e;--glass:rgba(255,255,255,.84)}}*{{box-sizing:border-box}}body{{font-family:Inter,Segoe UI,Arial,sans-serif;margin:0;background:radial-gradient(circle at 80% 0,#e8f5ff 0,transparent 34%),linear-gradient(145deg,#edf5f9,#f8fbfd 52%,#eaf3f7);color:#173047;min-height:100vh}}header{{padding:26px 30px;background:linear-gradient(135deg,rgba(6,55,89,.97),rgba(6,114,206,.94));color:#fff;box-shadow:0 14px 35px rgba(7,55,88,.18)}}header h1{{margin:3px 0}}main{{padding:18px 28px 44px;max-width:1450px;margin:auto}}.metrics{{display:grid;grid-template-columns:repeat(6,minmax(110px,1fr));gap:10px;margin:14px 0}}.metric,.panel{{background:var(--glass);border:1px solid rgba(255,255,255,.92);border-radius:15px;padding:13px;box-shadow:0 10px 28px rgba(36,72,94,.08),inset 0 0 0 1px var(--line);backdrop-filter:blur(16px) saturate(1.15);-webkit-backdrop-filter:blur(16px) saturate(1.15)}}.metric span{{display:block;font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;white-space:nowrap}}.metric b{{font-size:19px;color:#173047}}.verdict{{border-left:6px solid var(--green)!important;background:linear-gradient(120deg,rgba(232,249,241,.92),rgba(255,255,255,.86))}}.verdict.WARNING{{border-left-color:var(--amber)!important;background:linear-gradient(120deg,rgba(255,247,224,.94),rgba(255,255,255,.88))}}.verdict.FAIL,.verdict.BLOCKED{{border-left-color:var(--red)!important;background:linear-gradient(120deg,rgba(255,237,235,.94),rgba(255,255,255,.88))}}.verdict h2,.verdict p{{color:#173047;text-shadow:none}}table{{width:100%;border-collapse:separate;border-spacing:0;background:rgba(255,255,255,.76);border:1px solid var(--line);border-radius:12px;overflow:hidden}}th,td{{padding:10px;border-bottom:1px solid #e8eef3;text-align:left;vertical-align:top;font-size:10.5px}}th{{background:rgba(237,244,248,.92);font-size:8.5px;text-transform:uppercase;color:var(--muted)}}td small{{display:block;color:var(--muted);margin-top:3px}}.pill{{color:#fff!important;border-radius:999px;padding:4px 8px;font-size:9px;font-weight:800;display:inline-block}}.PASS{{background:var(--green)}}.WARNING{{background:var(--amber)}}.FAIL,.BLOCKED{{background:var(--red)}}.SKIPPED{{background:#6e8190}}details summary{{cursor:pointer;color:var(--blue);font-weight:800}}pre{{white-space:pre-wrap;word-break:break-word;background:#0d1b28;color:#d8edf7;border-radius:9px;padding:10px;max-height:420px;overflow:auto;font-size:9.5px}}.att{{border:1px solid rgba(188,143,34,.25);background:rgba(255,253,244,.82);border-radius:12px;padding:10px;margin:7px 0;backdrop-filter:blur(10px)}}.att.FAIL,.att.BLOCKED{{border-color:rgba(180,35,24,.25);background:rgba(255,241,240,.84)}}.att p{{margin:4px 0;font-size:10px;color:#29485d}}@media(max-width:900px){{main{{padding:12px}}.metrics{{grid-template-columns:repeat(2,minmax(0,1fr))}}table{{display:block;overflow:auto}}}}</style></head><body>
<header><small>Agentic HIP API Configuration Agent</small><h1>Final API response assessment</h1><p>Compact agent verdict first; complete request/response evidence stays expandable.</p></header><main>
<div class='metrics'><div class='metric'><span>Steps</span><b>{len(results)}</b></div><div class='metric'><span>PASS</span><b>{verdict_counts['PASS']}</b></div><div class='metric'><span>WARNING</span><b>{verdict_counts['WARNING']}</b></div><div class='metric'><span>FAIL</span><b>{verdict_counts['FAIL']}</b></div><div class='metric'><span>BLOCKED</span><b>{verdict_counts['BLOCKED']}</b></div><div class='metric'><span>API time</span><b>{html.escape(format_duration_seconds(total_api_seconds))}</b></div></div>
<section class='panel verdict {overall}'><h2>Agent verdict · <span class='pill {overall}'>{overall}</span></h2><p>{'LIVE execution completed with one or more review-only warnings; each API keeps its own response verdict and no downstream reuse inference is applied.' if overall == 'WARNING' else ('All evaluated LIVE API results completed successfully.' if overall == 'PASS' else 'A terminal API failure or blocking condition remains and needs attention.')}</p></section>
{("<section class='panel'><h2>Needs attention</h2>" + ''.join(attention) + "</section>" if attention else '')}
<section class='panel'><h2>API summary</h2><table><thead><tr><th>#</th><th>API</th><th>HTTP</th><th>Agent verdict</th><th>Time</th><th>Reason</th><th>Evidence</th></tr></thead><tbody>{''.join(compact_rows)}</tbody></table></section>
<details class='panel'><summary>Technical appendix · execution plan, payload overrides and runtime context</summary><pre>{html.escape(json.dumps({'apiExecutionPlan':runner.execution_plan.summary(),'payloadOverrides':runner.payload_overrides.summary(),'executionFlow':runner.execution_flow.summary(),'runtime':runtime}, indent=2, default=str))}</pre></details>
</main></body></html>"""
    html_path.write_text(html_doc, encoding="utf-8")

    md = ["# HIP AIA + MCP Agent Verdict\n\n"]
    md.append(f"- Total attempts: **{len(results)}**\n")
    md.append(f"- Business successes: **{sum(1 for r in results if r.business_success)}**\n")
    md.append(f"- AIA LLM judge available: **{runner.judge.available()}**\n")
    md.append(f"- User-approved skipped APIs: **{sum(1 for r in results if r.classification == 'SKIPPED_BY_USER_EXISTING_OBJECT')}**\n\n")
    md.append("## API Execution Plan\n\n")
    md.append("```json\n" + json.dumps(runner.execution_plan.summary(), indent=2, default=str) + "\n```\n\n")
    md.append("## Payload Overrides\n\n")
    md.append("```json\n" + json.dumps(runner.payload_overrides.summary(), indent=2, default=str) + "\n```\n\n")
    md.append("## Execution Flow & Timing\n\n")
    md.append("```json\n" + json.dumps(runner.execution_flow.summary(), indent=2, default=str) + "\n```\n\n")
    md.append("## Owner Verdict Counts\n\n")
    for k, v in sorted(owner_counts.items()):
        md.append(f"- {k}: **{v}**\n")
    md.append("\n## Detailed Verdict\n\n")
    md.append("| # | API | HTTP | Raw | Owner | Issue | Action |\n|---:|---|---:|---|---|---|---|\n")
    for r in results:
        md.append(f"| {r.sequence} | {r.group} - {r.api} | {r.status_code} | {r.classification} | {r.final_owner} | {r.issue.replace('|','/')} | {r.action_required.replace('|','/')} |\n")
    md_path.write_text("".join(md), encoding="utf-8")

    teams = []
    teams.append("HIP AIA/MCP Agent Run Summary\n\n")
    teams.append(f"Total attempts: {len(results)}\n")
    teams.append(f"Business successes: {sum(1 for r in results if r.business_success)}\n")
    teams.append(f"AIA LLM judge used: {runner.judge.available()}\n")
    teams.append(
        "User-approved skipped APIs: "
        + str(sum(1 for r in results if r.classification == "SKIPPED_BY_USER_EXISTING_OBJECT"))
        + "\n\n"
    )
    teams.append("Owner verdict counts:\n")
    for k, v in sorted(owner_counts.items()):
        teams.append(f"- {k}: {v}\n")
    teams.append("\nKey interpretation:\n")
    teams.append("- If items are classified as MISSING_REQUIRED_ID_OR_CONFIG, we need internal HIP IDs/values, not code/auth fixes.\n")
    teams.append("- If items are API_DOC_OR_BACKEND_MISMATCH or API_BACKEND_OR_ERROR_HANDLING, Dev/API team should verify docs/backend behavior.\n")
    teams.append("- Working items prove access and major parts of the payload implementation are functioning.\n")
    teams_path.write_text("".join(teams), encoding="utf-8")

    print("\nGenerated reports:")
    for p in [html_path, json_path, csv_path, md_path, teams_path, runtime_path]:
        print(f"- {p}")
    return html_path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check-connections",
        action="store_true",
        help="Verify HIP API OAuth and Dell AIA model without running APIs.",
    )
    parser.add_argument(
        "--preflight",
        action="store_true",
        help="Run production-readiness checks without executing HIP APIs.",
    )
    parser.add_argument(
        "--suggest-missing",
        action="store_true",
        help="Ask Dell AIA to suggest missing non-secret configuration values.",
    )
    parser.add_argument(
        "--ingest-pdf",
        action="append",
        default=[],
        help="Ingest a searchable API documentation PDF. May be repeated.",
    )
    parser.add_argument(
        "--refresh-pdf-contracts",
        action="store_true",
        help="Rebuild structured API contracts from all ingested PDFs.",
    )
    parser.add_argument(
        "--list-pdf-docs",
        action="store_true",
        help="List ingested API PDF documents and detected API sections.",
    )
    parser.add_argument(
        "--mcp-status",
        action="store_true",
        help="Show MCP SDK, transport and tool status without running APIs.",
    )
    parser.add_argument(
        "--mcp-self-test",
        action="store_true",
        help="Run the non-mutating MCP toolchain self-test against the active configuration.",
    )
    parser.add_argument(
        "--mcp-contract",
        help="Show the merged MCP/PDF contract summary for one API key.",
    )
    parser.add_argument(
        "--prepare-input",
        help="Analyze an uploaded/new input JSON and create a canonical preview.",
    )
    parser.add_argument(
        "--use-input",
        help="Prepare a new input JSON and continue to live execution when complete.",
    )
    parser.add_argument(
        "--apply-safe-suggestions",
        action="store_true",
        help="Apply deterministic safe defaults during input preparation.",
    )
    parser.add_argument(
        "--use-aia-mapping",
        action="store_true",
        help="Use Dell AIA to supplement input mapping or change analysis.",
    )
    parser.add_argument(
        "--change-request",
        help="User/Dev change request text, or a path to a text file.",
    )
    parser.add_argument(
        "--apply-change",
        action="store_true",
        help="Apply an approved change proposal to input/config.",
    )
    parser.add_argument("--kg-status", action="store_true")
    parser.add_argument("--export-kg", action="store_true")
    parser.add_argument("--sync-neo4j", action="store_true")
    parser.add_argument("--agentq-status", action="store_true")
    parser.add_argument(
        "--restore-uhal-baseline",
        action="store_true",
        help="Restore the Dev-approved U-HAUL input and configuration.",
    )
    parser.add_argument(
        "--execution-plan-status",
        action="store_true",
        help="Show the current input-bound API execute/skip plan without calling APIs.",
    )
    parser.add_argument(
        "--clear-execution-plan",
        action="store_true",
        help="Clear all user-approved API skips for the current package.",
    )
    parser.add_argument(
        "--execution-flow-status",
        action="store_true",
        help="Show current API execution order and wait-after timing.",
    )
    parser.add_argument(
        "--reset-execution-flow",
        action="store_true",
        help="Restore the safe default API order and wait timings.",
    )
    parser.add_argument(
        "--payload-overrides-status",
        action="store_true",
        help="Show user-approved payload/query overrides without calling APIs.",
    )
    parser.add_argument(
        "--clear-payload-overrides",
        action="store_true",
        help="Remove all user-approved payload/query overrides.",
    )
    parser.add_argument(
        "--preview-request",
        help="Preview one logical API step request without calling the API.",
    )
    args = parser.parse_args()

    adaptive = AdaptiveHipEngine(ROOT)

    # MCP inspection/self-test commands are intentionally handled before
    # credential/preflight construction. They never call live HIP APIs and are
    # useful for diagnosing the tool layer even when OAuth is not configured.
    if args.mcp_status or args.mcp_self_test or args.mcp_contract:
        bridge = MCPBridge(
            ROOT,
            enabled=str(os.getenv("MCP_ENABLED", "true")).strip().lower() in {"1", "true", "yes", "on"},
            required=str(os.getenv("MCP_REQUIRED", "false")).strip().lower() in {"1", "true", "yes", "on"},
        )
        input_data = json.loads(INPUT_JSON.read_text(encoding="utf-8")) if INPUT_JSON.exists() else {}
        config_data = json.loads(OVERRIDES.read_text(encoding="utf-8")) if OVERRIDES.exists() else {}
        if args.mcp_contract:
            print(json.dumps(
                bridge.get_api_contract_summary(args.mcp_contract),
                indent=2,
                default=str,
            ))
            return

        status_output = {
            "buildId": BUILD_ID,
            "mcp": bridge.status(),
            "interfaces": bridge.list_interface_profiles(),
            "inputValidation": bridge.validate_uhal_input(input_data, config_data),
            "executionPolicy": bridge.validate_execution_policy(),
            "readiness": bridge.assess_execution_readiness(input_data, config_data),
        }
        if args.mcp_self_test:
            objects = input_data.get("objects") or {}
            source_tp = objects.get("source_transport_profile") or {}
            target_tp = objects.get("target_transport_profile") or {}
            profiles = status_output["interfaces"].get("interfaces") or []
            by_type = {
                str(row.get("apiInterfaceType") or "").upper(): row.get("key")
                for row in profiles
            }
            src_type = str(source_tp.get("interface_type") or "SFTP HAFT").upper()
            tgt_type = str(target_tp.get("interface_type") or "SFTP HAFT").upper()
            src_key = by_type.get(src_type) or "SFTP"
            tgt_key = by_type.get(tgt_type) or "SFTP"
            status_output["interfacePlan"] = bridge.plan_interface_configuration(
                baseline_input=input_data,
                source_interface=src_key,
                target_interface=tgt_key,
                source_parameters=source_tp.get("interface_parameters") or {},
                target_parameters=target_tp.get("interface_parameters") or {},
            )
            status_output["knowledgeGraph"] = bridge.query_knowledge_graph(limit=5)
            status_output["agentq"] = bridge.agentq_memory_status()
            status_output["selfTestPass"] = bool(
                status_output["inputValidation"].get("valid", True)
                and status_output["executionPolicy"].get("valid", True)
                and status_output["readiness"].get("valid", True)
                and status_output["interfacePlan"].get("critic", {}).get("status") in {"PASS", "BLOCKED"}
            )
        print(json.dumps(status_output, indent=2, default=str))
        if args.mcp_self_test and not status_output.get("selfTestPass"):
            raise SystemExit(5)
        return

    if args.execution_plan_status:
        print(json.dumps(
            ApiExecutionPlan(ROOT, INPUT_JSON).summary(),
            indent=2,
            default=str,
        ))
        return

    if args.clear_execution_plan:
        print(json.dumps(
            clear_execution_plan(ROOT, INPUT_JSON),
            indent=2,
            default=str,
        ))
        return

    if args.execution_flow_status:
        print(json.dumps(
            ExecutionFlowConfig(ROOT).summary(),
            indent=2,
            default=str,
        ))
        return

    if args.reset_execution_flow:
        print(json.dumps(
            reset_execution_flow(ROOT),
            indent=2,
            default=str,
        ))
        return

    if args.payload_overrides_status:
        print(json.dumps(
            PayloadOverrideStore(ROOT).summary(),
            indent=2,
            default=str,
        ))
        return

    if args.clear_payload_overrides:
        print(json.dumps(
            clear_all_overrides(ROOT),
            indent=2,
            default=str,
        ))
        return

    if args.preview_request:
        runner = Runner(llm_enabled=False)
        print(json.dumps(
            runner.preview_step_request(args.preview_request),
            indent=2,
            default=str,
        ))
        return

    if args.restore_uhal_baseline:
        baseline_dir = ROOT / "dev_approved"
        input_source = baseline_dir / "UHAL_input_dev_approved.json"
        config_source = baseline_dir / "UHAL_config_dev_approved.json"
        if not input_source.exists() or not config_source.exists():
            raise FileNotFoundError(
                "Dev-approved U-HAUL baseline files are missing."
            )
        INPUT_JSON.write_text(
            input_source.read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        OVERRIDES.write_text(
            config_source.read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        print(json.dumps({
            "status": "ok",
            "input": str(INPUT_JSON),
            "config": str(OVERRIDES),
            "message": "Dev-approved U-HAUL baseline restored.",
        }, indent=2))
        return

    if args.kg_status:
        print(json.dumps(adaptive.kg.stats(), indent=2, default=str))
        return
    if args.export_kg:
        print(json.dumps({
            "json": str(adaptive.kg.export_json()),
            "graphml": str(adaptive.kg.export_graphml()),
        }, indent=2))
        return
    if args.sync_neo4j:
        print(json.dumps(adaptive.kg.sync_to_neo4j(), indent=2, default=str))
        return
    if args.agentq_status:
        print(json.dumps({
            "stats": adaptive.agentq.stats(),
            "recent": adaptive.agentq.recent_trajectories(limit=30),
            "devChangeCandidates": adaptive.agentq.ranked_candidates("dev_change", limit=10),
        }, indent=2, default=str))
        return

    input_path = args.prepare_input or args.use_input
    if input_path:
        raw_path = Path(input_path).expanduser().resolve()
        if not raw_path.exists():
            raise FileNotFoundError(raw_path)
        raw_input = load_json(raw_path, {})
        aia_callable = None
        if args.use_aia_mapping:
            config = load_json(OVERRIDES, {})
            judge = AIAJudge(config, enabled=True)
            judge.verify_connection()
            aia_callable = judge.complete_json
        prepared = adaptive.prepare_canonical_input(
            raw_input,
            apply_safe=args.apply_safe_suggestions,
            use_aia=bool(aia_callable),
            aia_complete_json=aia_callable,
        )
        preview_path = REPORTS / "prepared_canonical_input_latest.json"
        preview_path.write_text(json.dumps(prepared, indent=2, default=str), encoding="utf-8")
        print(json.dumps({
            "status": "READY" if prepared.get("ready") else "MISSING_VALUES",
            "preview": str(preview_path),
            "unresolvedQuestions": prepared.get("unresolvedQuestions"),
        }, indent=2, default=str))
        if not prepared.get("ready"):
            raise SystemExit(3)
        INPUT_JSON.write_text(json.dumps(prepared["canonicalInput"], indent=2, default=str), encoding="utf-8")
        updated_config = adaptive.derive_config_updates(
            prepared["canonicalInput"],
            load_json(OVERRIDES, {}),
        )
        OVERRIDES.write_text(json.dumps(updated_config, indent=2, default=str), encoding="utf-8")
        if args.prepare_input and not args.use_input:
            return

    if args.change_request:
        try:
            request_candidate = Path(args.change_request).expanduser()
            request_text = (
                request_candidate.read_text(encoding="utf-8")
                if request_candidate.exists()
                else args.change_request
            )
        except OSError:
            request_text = args.change_request
        input_data = load_json(INPUT_JSON, {})
        config_data = load_json(OVERRIDES, {})
        aia_callable = None
        if args.use_aia_mapping:
            judge = AIAJudge(config_data, enabled=True)
            judge.verify_connection()
            aia_callable = judge.complete_json
        proposal = adaptive.propose_change(
            request_text, input_data, config_data,
            use_aia=bool(aia_callable),
            aia_complete_json=aia_callable,
        )
        if args.apply_change:
            applied = adaptive.apply_change(proposal, input_data, config_data, approve=True)
            INPUT_JSON.write_text(json.dumps(applied["input"], indent=2, default=str), encoding="utf-8")
            OVERRIDES.write_text(json.dumps(applied["config"], indent=2, default=str), encoding="utf-8")
            print(json.dumps({"proposal": proposal, "applied": applied}, indent=2, default=str))
        else:
            print(json.dumps(proposal, indent=2, default=str))
        return

    # Final mode: live API execution and Dell AIA are mandatory.
    runner = Runner(llm_enabled=True)

    preflight = runner.production_preflight()
    if args.preflight:
        print(json.dumps(
            redact_sensitive(preflight),
            indent=2,
            default=str,
        ))
        if not preflight.get("ready", False):
            raise SystemExit(4)
        return

    if args.mcp_status:
        validation = runner.mcp.validate_uhal_input(
            runner.input,
            runner.ov,
        )
        print(json.dumps({
            "status": "ok" if validation.get("valid", True) else "invalid",
            "mcp": runner.mcp.status(),
            "inputValidation": validation,
        }, indent=2, default=str))
        return

    if args.list_pdf_docs:
        print(json.dumps(
            runner.pdf_kb.list_documents(),
            indent=2,
            default=str,
        ))
        return

    if args.ingest_pdf or args.refresh_pdf_contracts:
        runner.judge.verify_connection()
        ingested = []
        for raw_path in args.ingest_pdf:
            pdf_path = Path(raw_path).expanduser().resolve()
            if not pdf_path.exists():
                raise FileNotFoundError(pdf_path)
            result = runner.pdf_kb.ingest_bytes(
                pdf_path.name,
                pdf_path.read_bytes(),
            )
            ingested.append(result.__dict__)

        contracts = runner.pdf_kb.extract_contracts_with_aia(
            runner.judge
        )
        print(json.dumps({
            "status": "ok",
            "ingested": ingested,
            "contractCount": len(
                contracts.get("contracts", {})
            ),
            "documents": runner.pdf_kb.list_documents(),
        }, indent=2, default=str))
        return

    if args.suggest_missing:
        runner.judge.verify_connection()
        deterministic = runner.collect_missing_values()
        aia = runner.judge.suggest_missing_values(
            deterministic,
            runner.build_suggestion_context(),
        )
        output = {
            "generatedAt": dt.datetime.now().isoformat(),
            "deterministicSuggestions": deterministic,
            "dellAiaSuggestions": aia,
        }
        path = REPORTS / "missing_value_suggestions_latest.json"
        path.write_text(
            json.dumps(output, indent=2, default=str),
            encoding="utf-8",
        )
        print(json.dumps({
            "status": "ok",
            "output": str(path),
        }))
        return

    if not preflight.get("ready", False):
        print(json.dumps({
            "status": "PREFLIGHT_FAILED",
            "errors": preflight.get("errors", []),
            "warnings": preflight.get("warnings", []),
            "reportPath": preflight.get("reportPath"),
        }, indent=2, default=str))
        raise SystemExit(4)

    runner.validate_live_configuration()
    runner.validate_pdf_readiness()
    aia_result = runner.judge.verify_connection()

    if (
        runner.pdf_kb.has_documents()
        and not runner.pdf_kb.load_pdf_contracts()
    ):
        runner.pdf_kb.extract_contracts_with_aia(
            runner.judge
        )
    print(
        "Dell AIA verified: "
        + json.dumps(aia_result, default=str)
    )

    if args.check_connections:
        components: Dict[str, Any] = {
            "dellAia": {"status": "OK", "details": aia_result},
            "mcp": {
                "status": "OK",
                "transport": runner.mcp.status(),
                "inputValidation": runner.mcp.validate_uhal_input(
                    runner.input, runner.ov
                ),
            },
        }

        def check_token_component(
            name: str, kind: str, url: str, scope: str, required: bool
        ) -> None:
            if not required:
                components[name] = {
                    "status": "NOT_REQUIRED",
                    "reason": "Corresponding API is skipped as an existing object.",
                }
                return
            try:
                token = runner.get_token(kind, scope)
                components[name] = {
                    "status": "OK",
                    "tokenReceived": bool(token),
                    "tokenUrl": url,
                    "scopeSent": bool(scope),
                    "authMode": "oauth2-client-credentials-basic-auth",
                }
            except Exception as exc:
                components[name] = {
                    "status": "FAILED",
                    "tokenUrl": url,
                    "scopeSent": bool(scope),
                    "error": str(exc),
                }

        check_token_component(
            "hipOAuth", "HIP", runner.hip_token_url, runner.hip_scope, True
        )
        components["macMap"] = (
            {"status": "OK", "authentication": "uses-shared-hip-bearer-token"}
            if components["hipOAuth"].get("status") == "OK"
            else {"status": "BLOCKED", "error": "Blocked because HIP Config OAuth failed."}
        )

        account_required = runner.strict_live_pipeline_mode or not (
            runner.execution_plan.is_skipped("account_source")
            and runner.execution_plan.is_skipped("account_target")
        )
        partner_required = runner.strict_live_pipeline_mode or not runner.execution_plan.is_skipped("partner_target")
        system_required = runner.strict_live_pipeline_mode or not runner.execution_plan.is_skipped("system_source")
        check_token_component(
            "accountOAuth", "ACCOUNT", runner.account_token_url,
            runner.account_scope, account_required
        )
        check_token_component(
            "partnerOAuth", "PARTNER", runner.partner_token_url,
            runner.partner_scope, partner_required
        )
        check_token_component(
            "systemOAuth", "SYSTEM", runner.system_token_url,
            runner.system_scope, system_required
        )

        mandatory = ["dellAia", "mcp", "hipOAuth"]
        if account_required:
            mandatory.append("accountOAuth")
        if partner_required:
            mandatory.append("partnerOAuth")
        if system_required:
            mandatory.append("systemOAuth")

        overall = (
            "OK"
            if runner.execution_flow.summary().get("valid")
            and all(components.get(key, {}).get("status") == "OK" for key in mandatory)
            else "FAILED"
        )
        result = redact_sensitive({
            "status": overall,
            "components": components,
            "apiExecutionPlan": runner.execution_plan.summary(),
            "executionFlow": runner.execution_flow.summary(),
        })
        atomic_write_json(REPORTS / "connection_check_latest.json", result)
        print(json.dumps(result, indent=2, default=str))
        if overall != "OK":
            raise SystemExit(1)
        return

    with LiveRunLock(runtime_lock_path(ROOT)):
        results = runner.run()
        write_reports(results, runner)
    try:
        from uhal_report import write_final_business_report
        final_report = write_final_business_report(results, runner)
        print(f"- {final_report}")
    except Exception as exc:
        print(
            "Warning: final business report generation failed: "
            f"{exc}"
        )

    if runner.strict_live_pipeline_mode:
        coverage_complete = bool(runner.final_state.get("coverageComplete"))
        business_success = bool(runner.final_state.get("businessSuccess"))
        nonpassing = list(runner.final_state.get("strictNonPassingLiveSteps") or [])
        strict_success = bool(runner.final_state.get("success"))
        print(json.dumps({
            "status": "SUCCESS" if strict_success else "STRICT_LIVE_PIPELINE_INCOMPLETE",
            "strictWholePipeline": True,
            "assumptionFreeExecution": True,
            "coverageComplete": coverage_complete,
            "businessSuccess": business_success,
            "coverageMissingSteps": runner.final_state.get("coverageMissingSteps", []),
            "nonPassingLiveSteps": nonpassing,
            "unresolvedRequiredSteps": runner.final_state.get("unresolvedRequiredSteps", []),
            "liveApiEvidenceManifest": runner.final_state.get("liveApiEvidenceManifest"),
            "flowName": runner.flow_name(),
            "environment": runner.env,
            "runtimeIds": runner.runtime_state,
            "reportDirectory": str(REPORTS),
        }, indent=2, default=str))
        if not strict_success:
            raise SystemExit(2)
        return

    if runner.full_api_coverage_mode:
        coverage_complete = bool(runner.final_state.get("coverageComplete"))
        print(json.dumps({
            "status": "API_COVERAGE_COMPLETE" if coverage_complete else "API_COVERAGE_INCOMPLETE",
            "businessSuccess": bool(runner.final_state.get("businessSuccess")),
            "coverageComplete": coverage_complete,
            "coverageMissingSteps": runner.final_state.get("coverageMissingSteps", []),
            "unresolvedRequiredSteps": runner.final_state.get("unresolvedRequiredSteps", []),
            "flowName": runner.flow_name(),
            "environment": runner.env,
            "runtimeIds": runner.runtime_state,
            "reportDirectory": str(REPORTS),
        }, indent=2, default=str))
        if not coverage_complete:
            raise SystemExit(2)
        return

    if not runner.final_state.get("success", False):
        print(json.dumps({
            "status": "FAILED",
            "unresolvedRequiredSteps": runner.final_state.get(
                "unresolvedRequiredSteps", []
            ),
            "reportDirectory": str(REPORTS),
        }, indent=2))
        raise SystemExit(2)
    print(json.dumps({
        "status": "SUCCESS",
        "flowName": runner.flow_name(),
        "environment": runner.env,
        "runtimeIds": runner.runtime_state,
        "reportDirectory": str(REPORTS),
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
