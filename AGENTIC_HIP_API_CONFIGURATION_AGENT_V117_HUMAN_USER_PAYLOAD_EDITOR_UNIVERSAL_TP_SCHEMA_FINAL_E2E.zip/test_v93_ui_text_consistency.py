from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "webapp/frontend/src"

def test_execute_page_removes_redundant_execution_copy():
    page = (SRC / "pages/ParallelPage.tsx").read_text(encoding="utf-8")
    assert "Execution model:" not in page
    assert "Actual LIVE API execution:" not in page
    assert "autogen-stability-grid" not in page
    assert "AutoGen AgentChat 0.7.5" in page
    assert "up to 4 concurrent agents" in page
    assert "Maximum concurrent agents: 4" in page

def test_navigation_and_page_headers_use_clean_release_neutral_copy():
    sidebar = (SRC / "components/Sidebar.tsx").read_text(encoding="utf-8")
    assert "Guided HIP configuration and execution" in sidebar
    assert "Guided configuration & execution · Phase 6" not in sidebar
    for name in ["WorkspacePage.tsx", "ApiTestingPage.tsx", "OperationsPage.tsx", "SystemPage.tsx", "TemplatesPage.tsx"]:
        page = (SRC / "pages" / name).read_text(encoding="utf-8")
        assert "Phase 6 ·" not in page

def test_styles_define_one_readable_typography_scale():
    css = (SRC / "styles.css").read_text(encoding="utf-8")
    for token in ["--type-page-title:30px", "--type-section-title:19px", "--type-body:13px", "--type-control:12px", "--type-caption:11px"]:
        assert token in css
    assert ".execution-capability-note" in css
