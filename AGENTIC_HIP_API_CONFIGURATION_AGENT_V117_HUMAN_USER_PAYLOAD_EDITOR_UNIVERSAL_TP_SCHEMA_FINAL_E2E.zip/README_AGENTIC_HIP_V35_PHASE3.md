# Agentic HIP API Configuration Agent — Phase 3 (V35)

Phase 3 turns the React API Flow Game into an executable workflow contract while continuing to use the proven Python HIP engine.

## What Phase 3 adds

### Executable graph connections
A connection can carry runtime values from an upstream API result into a downstream API request. Example:

`Document Type output.documentTypeId -> Rule payload.documentTypeId`

Mappings are resolved only after the source node has completed. Missing runtime output blocks the target node before an invalid HIP request is sent.

### Connection inspector
Click an edge to add, remove, or edit `output.* -> payload.* / params.*` mappings. The agent can suggest high-confidence mappings when an upstream output name matches exactly one field in the downstream request.

### Agent preflight
`Agent preflight` validates graph structure, cycles, API keys, request applicability, block overrides, and API contracts without executing the LIVE HIP APIs. The backend writes the latest evidence to `reports/react_flow_preflight_latest.json`.

### Agent auto-wire
`Agent auto-wire` applies only safe deterministic fixes: high-confidence edge mappings and disabling blocks the current configuration marks as not applicable. It does not invent customer values, credentials, DUNS, certificates, or unknown production constants.

### LIVE execution telemetry
The canvas streams:
- node started / request / completed / failed
- exact resolved edge mappings
- HTTP attempts
- transient retries and retry delay
- response verdict
- extracted output IDs
- API time, configured wait, and total node time

### Block settings
Every API block can independently control:
- enabled / disabled
- stop-on-blocked
- wait-after-step
- merge vs replace request override

Templates preserve these settings and edge mappings.

## Safety model
- LIVE execution still requires explicit user confirmation.
- Configuration agent validation must PASS before the graph can execute LIVE.
- Graph/API-contract preflight runs again on the backend before LIVE launch.
- Missing edge output mappings block before sending the downstream API request.
- `hip-automation` remains mandatory.

## Run
First setup:

```powershell
SETUP_AGENTIC_HIP.bat
```

Normal launch:

```powershell
RUN_AGENTIC_HIP.bat
```

Frontend: `http://127.0.0.1:5173`

FastAPI docs: `http://127.0.0.1:8765/docs`

Streamlit remains packaged only as a compatibility/reference path while React migration continues.
