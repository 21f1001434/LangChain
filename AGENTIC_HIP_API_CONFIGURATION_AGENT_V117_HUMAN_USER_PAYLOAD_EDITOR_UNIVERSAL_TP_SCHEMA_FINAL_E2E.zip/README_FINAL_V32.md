# HIP Application Studio V32

V32 fixes the Input Builder so the **physical files uploaded by the user are authoritative for Source/Target Document Type format**. A business transaction code such as 850 can no longer turn an XML source payload into EDIX12.

## File-truth mapping

The builder now separates:

- physical payload format: XML / cXML / EDIX12 / EDIFACT / CSV / JSON / FlatFile
- business transaction: 850 / 855 / 856 / etc.
- business direction: Inbound / Outbound
- flow type: Translation / Passthrough

Source and target payload roles are determined from actual file content plus strong filename evidence such as `SRC` / `SOURCE` and `TGT` / `TARGET`. `output compare` files are treated as validation evidence and do not replace a stronger `TGT` file.

The generated input includes `_file_mapping`, which shows exactly which uploaded file populated each high-confidence `input.json` field.

## XML parsing hardening

XML declarations such as ISO-8859-1 are respected and XML parsing is active in the standalone builder. Source and target XML roots are separately retained, so upload order cannot cause a target XML to overwrite source XML evidence.

## Three-reference mapping learner

Every clean **existing input.json + customer files** pair can be recorded as a supervised reference. The learner stores reusable mapping structure only:

- source/target filename-role patterns
- physical format mapping
- file-to-input field rules
- format counts

It does not copy customer-specific values, OAuth credentials, DUNS, certificates, or secrets between customers.

The UI shows `Reference pairs learned`, so three supplied customer reference pairs become a visible 3-example learning set. Learned filename-role vocabulary is then used as a tie-breaker for future customer files.

## Existing V31 capabilities retained

- all 18 HIP APIs
- mandatory `hip-automation`
- Translation and strict Passthrough paths
- customer files only / Configuration Manual + files / existing input.json + files
- Dell AIA gap analysis and user-request learning
- API Testing Area
- Scratch/API Flow Game
- parallel configuration agents
- U-HAUL multi-instance parallel demonstration
- per-step API/wait/total timing
- low-latency HTTP pooling and request-validation reuse
- PASS / EXISTING / BLOCKED response verdicts
- LIVE-only Run/Test/Launch execution
