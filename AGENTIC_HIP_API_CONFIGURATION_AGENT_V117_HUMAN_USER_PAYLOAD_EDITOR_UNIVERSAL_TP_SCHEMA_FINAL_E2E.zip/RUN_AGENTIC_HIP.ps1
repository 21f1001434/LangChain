$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
python .\runtime_preflight.py --production
if ($LASTEXITCODE -ne 0) { throw 'Runtime is not ready. Run SETUP_AGENTIC_HIP.ps1 first.' }
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PSScriptRoot'; python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765"
Start-Sleep -Seconds 2
Start-Process 'http://127.0.0.1:8765'
