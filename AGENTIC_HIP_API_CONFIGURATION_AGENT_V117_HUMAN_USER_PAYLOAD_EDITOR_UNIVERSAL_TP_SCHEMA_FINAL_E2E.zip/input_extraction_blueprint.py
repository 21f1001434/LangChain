from __future__ import annotations

import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BLUEPRINT_FILE = Path(__file__).resolve().parent / "schemas" / "engineer_input_extraction_blueprint.json"
BLUEPRINT_EXECUTION_REPORT = "input_extraction_blueprint_execution_latest.json"

# These paths are safe for direct exact-path deterministic file evidence.
# Complex routing/document-identifier structures stay under the dedicated parsers;
# the blueprint must never guess their JSON shape from a scalar hint.
_SAFE_FILE_AUTOFILL_PATHS = {
    "customer", "tx_standard", "tx_code",
    "objects.data_map.map_identifier", "objects.data_map.map_name",
    "objects.data_map.map_class", "objects.data_map.map_data_file",
    "objects.data_map.contivo_version",
    "objects.source_document_type.name", "objects.source_document_type.transaction_type",
    "objects.source_document_type.data_format_type",
    "objects.target_document_type.name", "objects.target_document_type.transaction_type",
    "objects.target_document_type.data_format_type",
}
_SENSITIVE_PATH_PARTS = ("secret", "password", "token", "credential", "private_key", "client_secret")


def _clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list)):
        return "" if not value else json.dumps(value, ensure_ascii=False, default=str)
    return str(value).strip()


def _tokens(path: str) -> List[Any]:
    out: List[Any] = []
    for part in str(path or "").split("."):
        if not part:
            continue
        m = re.match(r"^([^\[]+)", part)
        if m:
            out.append(m.group(1))
        out.extend(int(x) for x in re.findall(r"\[(\d+)\]", part))
    return out


def _get(data: Any, path: str, default: Any = None) -> Any:
    cur = data
    for token in _tokens(path):
        if isinstance(token, int):
            if not isinstance(cur, list) or token >= len(cur):
                return default
            cur = cur[token]
        else:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(token)
        if cur is None:
            return default
    return cur


def _set(data: Dict[str, Any], path: str, value: Any) -> None:
    tokens = _tokens(path)
    if not tokens or any(isinstance(x, int) for x in tokens):
        return
    cur: Dict[str, Any] = data
    for token in tokens[:-1]:
        if not isinstance(cur.get(token), dict):
            cur[token] = {}
        cur = cur[token]
    cur[tokens[-1]] = value


def load_blueprint() -> Dict[str, Any]:
    return json.loads(BLUEPRINT_FILE.read_text(encoding="utf-8"))


def _translation(data: Dict[str, Any]) -> bool:
    if "requires_data_map" in data:
        return bool(data.get("requires_data_map"))
    return str(data.get("flow_type") or "").strip().lower() == "translation"


def _required(rule: Dict[str, Any], data: Dict[str, Any], source_interface: str, target_interface: str) -> bool:
    cond = str(rule.get("requiredWhen") or "always")
    if cond == "always":
        return True
    if cond == "translation":
        return _translation(data)
    if cond == "translation_or_explicit_target":
        return _translation(data) or bool(data.get("passthrough_target_document_type_required"))
    if cond == "file_interface":
        path = str(rule.get("path") or "")
        side = "source" if ".source_transport_profile." in path else "target"
        key = source_interface if side == "source" else target_interface
        return str(key or "").upper() in {"SFTP", "FTP", "FTE", "SFTP-HAFT", "SFTP HAFT"}
    return True


def _file_mapping_rows(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    fm = data.get("_file_mapping") if isinstance(data.get("_file_mapping"), dict) else {}
    rows = fm.get("fieldMappings") if isinstance(fm, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _file_evidence_for(path: str, rows: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    for row in rows:
        candidate = str(row.get("path") or row.get("field") or "")
        if candidate == path or candidate.startswith(path + ".") or path.startswith(candidate + "."):
            return row
    return None


def _human_paths(data: Dict[str, Any]) -> set[str]:
    audit = data.get("_builder_audit") if isinstance(data.get("_builder_audit"), dict) else {}
    human = audit.get("human_answers") if isinstance(audit, dict) else {}
    paths = human.get("paths") if isinstance(human, dict) else []
    return {str(x) for x in paths or []}


def _confidence_rank(value: Any) -> int:
    text = str(value or "").strip().lower()
    return {"high": 3, "confirmed": 3, "medium": 2, "inferred": 1, "low": 1}.get(text, 2)


def _exact_file_candidates(path: str, rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict) or str(row.get("path") or row.get("field") or "") != path:
            continue
        value = row.get("value")
        if not _clean(value):
            continue
        candidates.append({
            "path": path,
            "value": deepcopy(value),
            "sourceFile": str(row.get("sourceFile") or row.get("file") or row.get("filename") or "customer file evidence"),
            "rule": str(row.get("rule") or row.get("reason") or "deterministic file mapping"),
            "confidence": str(row.get("confidence") or "medium"),
        })
    candidates.sort(key=lambda x: _confidence_rank(x.get("confidence")), reverse=True)
    return candidates


_USER_SELECTION_SPECS = [
    ("customer", "customer", "customer / partner name"),
    ("direction", "direction", "flow direction"),
    ("transaction_code", "tx_code", "transaction code"),
    ("transaction_name", "tx_name", "transaction name"),
    ("flow_type", "flow_type", "flow type"),
    ("source_interface", "objects.source_transport_profile.interface_type", "source interface"),
    ("target_interface", "objects.target_transport_profile.interface_type", "target interface"),
]


def _comparison_value(path: str, value: Any) -> str:
    text = _clean(value)
    low = text.casefold().replace("_", " ").replace("-", " ")
    low = " ".join(low.split())
    if path.endswith("interface_type"):
        aliases = {
            "sftp": "sftp", "sftp haft": "sftp", "sftphaft": "sftp",
            "ftp": "ftp", "fte": "fte", "https": "https",
            "https as2": "https as2", "as2": "https as2",
        }
        return aliases.get(low, low)
    if path in {"customer", "direction", "tx_code", "tx_name", "flow_type"}:
        return low
    return text


def detect_user_selection_conflicts(canonical: Dict[str, Any], settings: Dict[str, Any]) -> Dict[str, Any]:
    """Compare explicit UI choices with deterministic customer-file evidence.

    Convenience defaults are not conflicts. Only fields that the operator actually
    touched are compared. When evidence disagrees, neither side is silently chosen:
    the conflict is persisted and Build Configuration asks the operator to choose
    File evidence, User-selected value, or a Custom value.
    """
    data = deepcopy(canonical or {})
    explicit = {str(x) for x in (settings.get("user_selected_fields") or [])}
    rows = _file_mapping_rows(data)
    conflicts: List[Dict[str, Any]] = []
    for selected_field, path, label in _USER_SELECTION_SPECS:
        if selected_field not in explicit:
            continue
        selected = settings.get(selected_field)
        if selected_field == "flow_type" and str(selected or "").strip().lower() == "auto":
            continue
        if not _clean(selected):
            continue
        candidates = _exact_file_candidates(path, rows)
        if not candidates:
            audit = data.get("_builder_audit") if isinstance(data.get("_builder_audit"), dict) else {}
            authority = audit.get("authoritative_json") if isinstance(audit, dict) and isinstance(audit.get("authoritative_json"), dict) else None
            manual = audit.get("automatic_configuration_manual") if isinstance(audit, dict) and isinstance(audit.get("automatic_configuration_manual"), dict) else None
            current = _get(data, path)
            provenance = authority or manual
            if provenance and _clean(current):
                candidates = [{
                    "path": path, "value": deepcopy(current),
                    "sourceFile": str(provenance.get("filename") or provenance.get("source") or "approved customer configuration file"),
                    "rule": "approved customer configuration/manual value", "confidence": "confirmed",
                }]
        if not candidates:
            continue
        unique: Dict[str, Dict[str, Any]] = {}
        for cand in candidates:
            key = _comparison_value(path, cand.get("value"))
            if key and key not in unique:
                unique[key] = cand
        if not unique:
            continue
        selected_key = _comparison_value(path, selected)
        if selected_key in unique:
            continue
        file_values = [deepcopy(c.get("value")) for c in unique.values()]
        file_sources = [str(c.get("sourceFile") or "customer file") for c in unique.values()]
        conflicts.append({
            "id": "selection_conflict_" + re.sub(r"[^a-z0-9]+", "_", path.lower()).strip("_"),
            "path": path,
            "label": label,
            "selectedField": selected_field,
            "selectedValue": deepcopy(selected),
            "fileValues": file_values,
            "fileSources": file_sources,
            "fileEvidence": [deepcopy(c) for c in unique.values()],
            "fileConfidence": str(candidates[0].get("confidence") or "medium"),
            "status": "UNRESOLVED",
            "recommended": "Review both values. Choose the customer-file value when the file is authoritative, keep the user-selected value when the business selection is intentional, or enter another approved value.",
        })
    data["_selection_conflicts"] = conflicts
    audit = data.setdefault("_builder_audit", {})
    audit["selection_conflict_scan"] = {
        "explicitFields": sorted(explicit),
        "conflictCount": len(conflicts),
        "policy": "No silent precedence when explicit user selection disagrees with deterministic customer-file evidence.",
    }
    return data


def _apply_file_mapping_autofill(data: Dict[str, Any], blueprint: Dict[str, Any], rows: Iterable[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Fill unresolved scalar canonical fields from exact deterministic evidence only.

    The source parser already emits file->canonical mapping rows. V75 lets the
    engineer blueprint consume those rows directly when the canonical builder
    left a safe scalar field blank. Conflicting evidence is never chosen.
    """
    resolved: List[Dict[str, Any]] = []
    conflicts: List[Dict[str, Any]] = []
    for rule in blueprint.get("fields") or []:
        if not isinstance(rule, dict):
            continue
        path = str(rule.get("path") or "")
        if path not in _SAFE_FILE_AUTOFILL_PATHS or _clean(_get(data, path)):
            continue
        candidates = _exact_file_candidates(path, rows)
        if not candidates:
            continue
        normalized: Dict[str, List[Dict[str, Any]]] = {}
        for cand in candidates:
            key = json.dumps(cand.get("value"), sort_keys=True, ensure_ascii=False, default=str)
            normalized.setdefault(key, []).append(cand)
        if len(normalized) > 1:
            conflicts.append({
                "path": path,
                "reason": "conflicting deterministic file evidence",
                "candidates": [{"value": group[0].get("value"), "sources": [x.get("sourceFile") for x in group]} for group in normalized.values()],
            })
            continue
        chosen = candidates[0]
        _set(data, path, deepcopy(chosen.get("value")))
        resolved.append({
            "path": path,
            "value": deepcopy(chosen.get("value")),
            "source": chosen.get("sourceFile"),
            "sourceType": "customer_file",
            "rule": chosen.get("rule"),
            "confidence": chosen.get("confidence"),
        })
    return resolved, conflicts


def _audit_user_request_paths(data: Dict[str, Any]) -> set[str]:
    audit = data.get("_builder_audit") if isinstance(data.get("_builder_audit"), dict) else {}
    req = audit.get("user_request") if isinstance(audit, dict) else {}
    rows = req.get("applied") if isinstance(req, dict) else []
    return {str(row.get("path")) for row in rows or [] if isinstance(row, dict) and row.get("path")}


def _is_sensitive_path(path: str) -> bool:
    low = str(path or "").lower()
    return any(token in low for token in _SENSITIVE_PATH_PARTS)


def _public_value(path: str, value: Any) -> Any:
    if _is_sensitive_path(path) and _clean(value):
        return "<secure runtime value>"
    if isinstance(value, str) and value.startswith("${HIP_RUNTIME:"):
        return "<secure runtime value>"
    return deepcopy(value)


def write_blueprint_execution_report(workspace: Path, canonical: Dict[str, Any]) -> Path:
    """Persist an auditable, non-secret field-resolution trace for the UI/report area."""
    workspace = Path(workspace)
    reports = workspace / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    bp = canonical.get("_input_extraction_blueprint") if isinstance(canonical, dict) else {}
    model = deepcopy(bp) if isinstance(bp, dict) else {}
    for row in model.get("fields") or []:
        if isinstance(row, dict):
            row["value"] = _public_value(str(row.get("path") or ""), _get(canonical, str(row.get("path") or "")))
    for row in model.get("autoResolved") or []:
        if isinstance(row, dict) and "value" in row:
            row["value"] = _public_value(str(row.get("path") or ""), row.get("value"))
    model["reportType"] = "HIP input extraction blueprint execution"
    model["canonicalInput"] = "input.json"
    model["noSecretsPersisted"] = True
    path = reports / BLUEPRINT_EXECUTION_REPORT
    path.write_text(json.dumps(model, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    return path


def _safe_derivations(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Fill only deterministic aliases already proven elsewhere in canonical input.

    The engineer blueprint is intentionally *not* allowed to invent customer
    values.  These are structural copies/aliases from already-known values.
    """
    changed: List[Dict[str, Any]] = []

    def fill(path: str, value: Any, source: str) -> None:
        if _clean(_get(data, path)) or not _clean(value):
            return
        _set(data, path, deepcopy(value))
        changed.append({"path": path, "source": source, "value": value})

    objects = data.get("objects") if isinstance(data.get("objects"), dict) else {}
    source_doc = objects.get("source_document_type") if isinstance(objects.get("source_document_type"), dict) else {}
    target_doc = objects.get("target_document_type") if isinstance(objects.get("target_document_type"), dict) else {}
    rule = objects.get("rule") if isinstance(objects.get("rule"), dict) else {}
    source_tp = objects.get("source_transport_profile") if isinstance(objects.get("source_transport_profile"), dict) else {}
    target_tp = objects.get("target_transport_profile") if isinstance(objects.get("target_transport_profile"), dict) else {}
    biz = objects.get("biz_flow") if isinstance(objects.get("biz_flow"), dict) else {}

    bf_name = _get(data, "objects.biz_flow.flow_details.business_flow_name") or biz.get("flow_name")
    fill("profile_name", bf_name, "existing BizFlow name")
    fill("tx_code", source_doc.get("transaction_type"), "Source Document Type transaction_type")
    fmt = str(source_doc.get("data_format_type") or "").upper()
    std = {"EDIX12": "X12", "EDI": "X12", "X12": "X12", "EDIFACT": "EDIFACT", "XML": "XML", "CXML": "cXML", "JSON": "JSON", "CSV": "CSV", "FLATFILE": "FlatFile"}.get(fmt)
    fill("tx_standard", std, "Source Document Type physical format")
    if "requires_data_map" not in data:
        dm = objects.get("data_map") if isinstance(objects.get("data_map"), dict) else {}
        has_map = bool(_clean(dm.get("map_name")) or _clean(dm.get("map_data_file"))) and "not applicable" not in str(dm.get("status") or "").lower()
        data["requires_data_map"] = bool(has_map)
        changed.append({"path": "requires_data_map", "source": "Data Map/JAR evidence", "value": bool(has_map)})
    fill("flow_type", "translation" if bool(data.get("requires_data_map")) else "passthrough", "requires_data_map")

    fill("objects.source_document_type.description", source_doc.get("name"), "same as Source Document Type name")
    fill("objects.target_document_type.description", target_doc.get("name"), "same as Target Document Type name")
    fill("objects.rule.description", rule.get("name"), "same as Mapping Rule name")
    fill("objects.source_transport_profile.interface_environment", source_tp.get("interface_env"), "Source Transport Profile interface_env alias")
    fill("objects.target_transport_profile.interface_environment", target_tp.get("interface_env"), "Target Transport Profile interface_env alias")

    src_name = _clean(source_doc.get("name")); src_ver = _clean(source_doc.get("version")) or "1.0"
    tgt_name = _clean(target_doc.get("name")); tgt_ver = _clean(target_doc.get("version")) or "1.0"
    if src_name:
        fill("objects.source_transport_profile.document_type", f"{src_name}({src_ver})", "Source Document Type")
        fill("objects.biz_flow.configure_source.document_type_name_version", f"{src_name}({src_ver})", "Source Document Type")
    if tgt_name:
        fill("objects.target_transport_profile.document_type", f"{tgt_name}({tgt_ver})", "Target Document Type")
        fill("objects.biz_flow.configure_targets.document_type_name_version", f"{tgt_name}({tgt_ver})", "Target Document Type")
    elif not _translation(data) and src_name:
        fill("objects.target_transport_profile.document_type", f"{src_name}({src_ver})", "Passthrough reuses Source Document Type")
        fill("objects.biz_flow.configure_targets.document_type_name_version", f"{src_name}({src_ver})", "Passthrough reuses Source Document Type")

    fill("objects.biz_flow.flow_details.business_flow_name", data.get("profile_name"), "top-level profile_name")
    fill("objects.biz_flow.configure_source.source_application", source_tp.get("partner_name") or source_tp.get("system_name"), "Source Transport Profile system/partner")
    fill("objects.biz_flow.configure_targets.target_application", target_tp.get("partner_name") or target_tp.get("system_name"), "Target Transport Profile system/partner")

    routing = _get(data, "objects.biz_flow.configure_routing")
    if isinstance(routing, dict):
        actions = routing.get("actions") if isinstance(routing.get("actions"), dict) else {}
        if not _clean(actions.get("target")):
            shared = _get(data, "objects.biz_flow.configure_targets.target_transport_profile")
            fallback = shared or target_tp.get("profile_name")
            if _clean(fallback):
                actions["target"] = fallback
                routing["actions"] = actions
                changed.append({"path": "objects.biz_flow.configure_routing.actions.target", "source": "Target Flow/Transport Profile", "value": fallback})
    return changed


def apply_input_extraction_blueprint(
    canonical: Dict[str, Any], *, source_interface: str = "", target_interface: str = "", manifest: Optional[List[str]] = None,
    workspace: Optional[Path] = None,
) -> Dict[str, Any]:
    """Execute the engineer field-source blueprint against canonical evidence.

    Resolution order is intentionally conservative:
      1. preserve existing/approved canonical values;
      2. fill only safe blank scalar paths from exact deterministic file mappings;
      3. apply safe structural aliases derived from already-proven values;
      4. classify unresolved fields for targeted human input.
    """
    data = deepcopy(canonical or {})
    blueprint = load_blueprint()
    fm_rows = _file_mapping_rows(data)
    file_resolved, conflicts = _apply_file_mapping_autofill(data, blueprint, fm_rows)
    selection_conflicts = [x for x in (data.get("_selection_conflicts") or []) if isinstance(x, dict) and str(x.get("status") or "UNRESOLVED").upper() != "RESOLVED"]
    derivations = _safe_derivations(data)
    auto_resolved = file_resolved + derivations
    human_paths = _human_paths(data)
    request_paths = _audit_user_request_paths(data)
    fields: List[Dict[str, Any]] = []
    counts = {"extracted": 0, "derived": 0, "selected_or_configured": 0, "user_required": 0, "not_applicable": 0, "conflicts": len(conflicts) + len(selection_conflicts)}
    conflict_paths = {str(x.get("path") or "") for x in conflicts}
    selection_conflict_paths = {str(x.get("path") or "") for x in selection_conflicts}

    for rule in blueprint.get("fields") or []:
        if not isinstance(rule, dict):
            continue
        path = str(rule.get("path") or "")
        required = _required(rule, data, source_interface, target_interface)
        value = _get(data, path)
        present = bool(_clean(value)) or isinstance(value, bool)
        file_row = _file_evidence_for(path, fm_rows)
        exact_file = next((x for x in file_resolved if x.get("path") == path), None)
        derivation = next((x for x in derivations if x.get("path") == path), None)
        if not required:
            status, source, confidence = "NOT_APPLICABLE", "Not required for this flow/interface", "n/a"
            counts["not_applicable"] += 1
        elif path in selection_conflict_paths:
            status, source, confidence = "CONFLICT_REQUIRES_SELECTION", "Customer-file evidence and explicit user selection disagree", "blocked"
            counts["user_required"] += 1
        elif path in conflict_paths and not present:
            status, source, confidence = "USER_REQUIRED", "Conflicting customer-file evidence; agent refused to choose", "blocked"
            counts["user_required"] += 1
        elif not present:
            status, source, confidence = "USER_REQUIRED", "Not proven by current evidence/configuration", "unresolved"
            counts["user_required"] += 1
        elif exact_file or file_row:
            row = exact_file or file_row or {}
            status = "EXTRACTED"
            source = str(row.get("source") or row.get("sourceFile") or row.get("file") or "customer file evidence")
            confidence = str(row.get("confidence") or "high")
            counts["extracted"] += 1
        elif path in human_paths or path in request_paths:
            status, source, confidence = "USER_CONFIRMED", "User answer / controlled business input", "confirmed"
            counts["selected_or_configured"] += 1
        elif derivation:
            status = "DERIVED"
            source = str(derivation.get("source") or "deterministic derivation")
            confidence = "high"
            counts["derived"] += 1
        elif str(rule.get("automation") or "").startswith("deterministic"):
            # A deterministic parser may already have populated the canonical
            # field even when its detailed file mapping row is coarser-grained.
            status, source, confidence = "DERIVED", "Deterministic customer-artifact parser", "high"
            counts["derived"] += 1
        else:
            status, source, confidence = "AVAILABLE", "Approved/current configuration or controlled selection", "configured"
            counts["selected_or_configured"] += 1
        fields.append({
            "path": path,
            "label": rule.get("label") or path,
            "status": status,
            "source": source,
            "confidence": confidence,
            "sourceOrder": list(rule.get("sourceOrder") or []),
            "automation": rule.get("automation") or "",
            "required": required,
            "valuePresent": present,
            "value": _public_value(path, value),
        })

    data["_input_extraction_blueprint"] = {
        "schemaVersion": blueprint.get("schemaVersion"),
        "source": blueprint.get("source"),
        "purpose": blueprint.get("purpose"),
        "manifest": list(manifest or []),
        "summary": counts,
        "autoResolved": auto_resolved,
        "fileAutoResolved": file_resolved,
        "conflicts": conflicts,
        "selectionConflicts": selection_conflicts,
        "fields": fields,
        "ruleCount": len(fields),
        "noInventedCustomerValues": True,
        "executionMode": "deterministic field-source resolution",
    }
    data.setdefault("_builder_audit", {})["engineer_input_blueprint"] = {
        "schema": "schemas/engineer_input_extraction_blueprint.json",
        "ruleCount": len(fields),
        "autoResolvedCount": len(auto_resolved),
        "fileAutoResolvedCount": len(file_resolved),
        "conflictCount": len(conflicts) + len(selection_conflicts),
        "selectionConflictCount": len(selection_conflicts),
        "userRequiredCount": counts["user_required"],
        "note": "Engineer field-source JSON is executed as an extraction blueprint. Existing approved values are preserved; only blank safe fields may be filled from exact deterministic evidence. Examples are never copied as customer values.",
    }
    if workspace is not None:
        write_blueprint_execution_report(Path(workspace), data)
    return data

def merge_blueprint_questions(
    canonical: Dict[str, Any], existing: List[Dict[str, Any]], *, source_interface: str = "", target_interface: str = ""
) -> List[Dict[str, Any]]:
    """Add only missing blueprint questions not already covered by app questions."""
    out = list(existing or [])
    selection_conflicts = [x for x in (canonical.get("_selection_conflicts") or []) if isinstance(x, dict) and str(x.get("status") or "UNRESOLVED").upper() != "RESOLVED"]
    existing_ids = {str(q.get("id") or "") for q in out if isinstance(q, dict)}
    for conflict in selection_conflicts:
        qid = str(conflict.get("id") or ("selection_conflict_" + re.sub(r"[^a-z0-9]+", "_", str(conflict.get("path") or "").lower()).strip("_")))
        if qid in existing_ids:
            continue
        out.insert(0, {
            "id": qid,
            "path": str(conflict.get("path") or ""),
            "label": str(conflict.get("label") or conflict.get("path") or "Conflicting value"),
            "question": "Customer evidence and your selected value are different. Which approved value should the agent use?",
            "why": "The agent will not silently prefer the file or the UI selection. Compare both values side by side, choose one, or enter another approved value before input.json and the 18 API payloads can proceed.",
            "type": "conflict",
            "secret": False,
            "options": [],
            "current": _get(canonical, str(conflict.get("path") or "")),
            "conflict": {
                "fileValues": deepcopy(conflict.get("fileValues") or []),
                "fileSources": list(conflict.get("fileSources") or []),
                "fileEvidence": deepcopy(conflict.get("fileEvidence") or []),
                "fileConfidence": conflict.get("fileConfidence") or "medium",
                "selectedValue": deepcopy(conflict.get("selectedValue")),
                "selectedField": conflict.get("selectedField") or "",
                "recommended": conflict.get("recommended") or "Review both values and select the approved one.",
            },
        })
        existing_ids.add(qid)
    # An uploaded approved/canonical HIP JSON is authoritative for ordinary missing fields.
    # Explicit UI-vs-file conflicts above still require a human decision.
    # annotates provenance for it but must not invent new mandatory questions
    # beyond the application's proven contract checks.
    audit = canonical.get("_builder_audit") if isinstance(canonical.get("_builder_audit"), dict) else {}
    if isinstance(audit, dict) and audit.get("authoritative_json"):
        return out
    existing_paths = set()
    for q in out:
        if not isinstance(q, dict):
            continue
        if q.get("path"):
            existing_paths.add(str(q["path"]))
        existing_paths.update(str(x) for x in (q.get("multi_paths") or []))
    blueprint = load_blueprint()
    scalar_fallback_paths = {
        "customer", "tx_standard", "tx_code", "direction", "flow_type",
        "objects.data_map.map_name", "objects.data_map.map_class", "objects.data_map.map_data_file", "objects.data_map.contivo_version",
        "objects.source_document_type.name", "objects.source_document_type.data_format_type",
        "objects.target_document_type.name", "objects.target_document_type.data_format_type",
        "objects.source_transport_profile.partner_name", "objects.source_transport_profile.profile_name",
        "objects.source_transport_profile.interface_type", "objects.source_transport_profile.interface_environment",
        "objects.source_transport_profile.existing_account_name", "objects.source_transport_profile.subscription_folder",
        "objects.target_transport_profile.partner_name", "objects.target_transport_profile.profile_name",
        "objects.target_transport_profile.interface_type", "objects.target_transport_profile.interface_environment",
        "objects.target_transport_profile.existing_account_name", "objects.target_transport_profile.subscription_folder",
        "objects.biz_flow.configure_source.source_application", "objects.biz_flow.configure_source.source_transport_profile",
        "objects.biz_flow.configure_targets.target_application", "objects.biz_flow.configure_targets.target_transport_profile",
    }
    for rule in blueprint.get("fields") or []:
        if not isinstance(rule, dict) or not rule.get("askIfMissing"):
            continue
        path = str(rule.get("path") or "")
        if path not in scalar_fallback_paths:
            continue
        if not path or path in existing_paths or not _required(rule, canonical, source_interface, target_interface):
            continue
        value = _get(canonical, path)
        if bool(_clean(value)) or isinstance(value, bool):
            continue
        options = list(rule.get("options") or [])
        out.append({
            "id": "blueprint_" + re.sub(r"[^a-z0-9]+", "_", path.lower()).strip("_"),
            "path": path,
            "label": rule.get("label") or path,
            "question": rule.get("question") or f"What approved value should be used for {rule.get('label') or path}?",
            "why": "The engineer extraction blueprint checked its approved source order and current customer evidence still cannot prove this value. The agent will not guess it.",
            "type": "select" if options else "text",
            "secret": False,
            "options": options,
            "current": value or "",
            "blueprint": True,
            "sourceOrder": list(rule.get("sourceOrder") or []),
            "automation": rule.get("automation") or "",
        })
        existing_paths.add(path)
    return out
