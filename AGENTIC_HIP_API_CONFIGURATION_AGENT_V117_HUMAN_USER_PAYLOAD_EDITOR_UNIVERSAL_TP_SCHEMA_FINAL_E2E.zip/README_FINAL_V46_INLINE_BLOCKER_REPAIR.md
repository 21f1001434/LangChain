# V46 — Inline API Contract Blocker Repair

This release keeps the user on **Build Configuration → Step 4** when one or more of the 18 HIP API request contracts are blocked.

## Same-screen repair flow

After **Map to 18 APIs + agent validate**:

- every blocked API is expanded below the readiness summary;
- the exact failing request field and contract error are shown;
- the agent asks the user for only the corrected value it cannot prove;
- the current generated value is displayed when available;
- the user can apply one API fix or all entered fixes;
- the backend immediately regenerates the effective request and re-runs non-mutating 18-API validation;
- when the final blocker is resolved, the normal API Flow / Parallel Run path becomes available.

The user no longer has to leave Build Configuration or guess which API is responsible for `16/18 BLOCKED`.

## Where corrections are stored

Business values that have a canonical Input Builder source are written back to `input.json`. Examples include:

- Partner `partnerIdentifierValue`;
- Partner `x-account-name` through the source HIP account;
- source/target HIP account names;
- Partner/System names;
- source/target Document Type names;
- map name / identifier / class / Contivo version / JAR filename;
- mapping-rule name;
- flow name.

These changes therefore also refresh the generated customer template.

Other safe request-content corrections are stored in the configuration-local `payload_overrides.json`. The same override is used during validation and later LIVE execution, preventing a validation/execution mismatch. Request methods, URLs, and unsupported protected headers remain agent-controlled.

`_contract_repairs` metadata is retained in canonical `input.json` so template generation can carry reusable non-secret request corrections. Configuration cloning and portable bundle export/import now preserve `payload_overrides.json` as well.

## Validation

- Full non-live regression suite: **168/168 passed**.
- Updated Python modules compile successfully.
- Updated TS/TSX sources pass TypeScript parser/transpile validation.
- A full Bun/Vite build was not run in the build container because Bun / frontend `node_modules` are not installed there; normal `bun install` + `bun run build` remains the local production build path.
