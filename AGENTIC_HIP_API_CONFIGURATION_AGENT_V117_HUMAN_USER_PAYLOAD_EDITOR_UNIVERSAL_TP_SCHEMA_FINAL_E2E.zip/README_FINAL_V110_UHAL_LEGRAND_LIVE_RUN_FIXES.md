# V110 — U-HAUL + LEGRAND LIVE Run Fixes

**Build:** `2026-08-31-agentic-hip-v110-business-final-strict-live-no-reuse-immutable-api-governed-skills-uhal-legrand-live-run-fixes`

## Live evidence analyzed

V110 is based on the new V109 LIVE runs supplied for U-HAUL and LEGRAND. It preserves all V109 governed-skill behavior and all V108 immutable-request/no-historical-reuse controls.

## U-HAUL fixes

### Exact current-DEV Rule ID resolution
The canonical Mapping Rule POST remains unchanged and is always executed. When HIP responds that the exact Rule already exists but omits `ruleId`, V110 performs a separate GET-only current-environment lookup. The resolver accepts an ID only if exact Rule name, Rule version and HIP environment match. No packaged/historical ID participates.

Default read candidates:
- `GET <HIP_CONFIG_SERVICE_BASE_URL>/api/rule/details?ruleName=...&environment=DEV&ruleVersion=...`
- `GET <HIP_CONFIG_SERVICE_BASE_URL>/api/rule/summary`

Optional API-team replacements:
- `HIP_RULE_DETAILS_API_URL`
- `HIP_RULE_SUMMARY_API_URL`

If no unique exact ID is found, the result is `LIVE_RULE_ID_UNRESOLVED` and is terminal/non-retriable. The Rule POST is not repeated with a changed body.

### TP CREATE audit semantics
The LIVE TP audit contained newer failed `edit` records before an older successful `create`. Because the canonical V110 pipeline executes TP orchestration **CREATE ONLY**, audit verification now prefers CREATE records when `operation` metadata exists. Unrelated failed edits no longer invalidate a successful create.

## LEGRAND fixes

### HIP-compliant Flow name before LIVE
HIP Flow Create enforces:
- 1–40 characters
- first character alphanumeric
- only letters, numbers, `_`, `-`

The prior generated name `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` is 43 characters. Canonical input construction now deterministically compacts it to:

`LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB`

Length: 39.

This happens while building canonical input, before LIVE request materialization. It is not a post-error request mutation. Legacy invalid inputs that somehow bypass the builder are stopped by production preflight with the proposed canonical name.

A backend Flow-name validation response is classified `FLOW_NAME_INVALID` and auto-completion will not repeat the same deterministic 400.

## Immutable contract retained

Standalone Mapping Rule continues to omit:
- `documentTypeId`
- `flowDefinitionId`
- `actions.params.mapId`

Map stays name/version referenced. The live request fingerprint guard still rejects any changed retry with `IMMUTABLE_LIVE_REQUEST_CHANGED`.

## External Dell boundary

The Account/Partner/System `Requested route (...pcf.dell.com) does not exist` responses in both supplied LIVE runs remain API/platform failures. V110 does not alter those approved payloads or falsely convert them to success. Replacement endpoint environment variables remain supported.
