from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any
from unittest.mock import patch

import run_agent
from api_execution_plan import ApiExecutionPlan
from production_integration_test import fake_response


ROOT = Path(__file__).resolve().parent


def main() -> None:
    plan = ApiExecutionPlan(ROOT, ROOT / "input.json")
    summary = plan.summary()

    assert summary["active"] is True, summary
    expected_studio_skips = {
        "account_source",
        "account_target",
        "partner_target",
        "system_source",
        "doctype_source",
        "doctype_target",
        "map",
        "rule",
        "source_tp",
        "target_tp",
        "flow_create",
        "flow_deploy",
    }
    assert set(summary["skipSteps"]) == expected_studio_skips, summary

    # Safety check: the same confirmed U-HAUL plan must become inactive for a
    # different input file.
    with tempfile.TemporaryDirectory() as tmp:
        other_input = Path(tmp) / "input.json"
        other_input.write_text(
            json.dumps({"customer": "OTHER-CUSTOMER"}),
            encoding="utf-8",
        )
        stale = ApiExecutionPlan(ROOT, other_input)
        assert stale.summary()["active"] is False
        assert stale.summary()["inputMatches"] is False

    runner = run_agent.Runner(llm_enabled=False)
    runner.ov["tpProcessingWaitSeconds"] = 0
    runner.ov["flowProcessingWaitSeconds"] = 0
    runner.runtime_state.update({
        "source_document_type_id": None,
        "target_document_type_id": None,
        "map_id": None,
        "rule_id": None,
        "flow_id": None,
    })
    for key in (
        "source_document_type_id",
        "target_document_type_id",
        "map_id",
        "rule_id",
        "existing_flow_id",
    ):
        runner.ov[key] = None

    runner.get_token = lambda token_kind, scope: "offline-token"
    runner.judge.judge = lambda result: {}
    runner.judge.available = lambda: False

    called_urls: list[str] = []

    def mocked_request(
        method: str,
        url: str,
        token_kind: str,
        scope: str,
        extra_headers: Any,
        payload: Any,
        params: Any,
    ):
        called_urls.append(url)
        return fake_response(method, url, payload, params)

    runner._request_with_retry = mocked_request

    with patch("run_agent.time.sleep", return_value=None), patch.object(
        runner.adaptive,
        "record_api_result",
        return_value=None,
    ), patch.object(
        runner.adaptive,
        "record_mapping_graph",
        return_value={"status": "mocked"},
    ):
        results = runner.run()

    skipped = [
        item
        for item in results
        if item.classification == "SKIPPED_BY_USER_EXISTING_OBJECT"
    ]

    assert len(skipped) == 12, [item.api for item in skipped]
    assert all(item.business_success for item in skipped)
    assert not any("/hip-partners/" in url for url in called_urls), called_urls
    assert not any("/hip-systems/" in url for url in called_urls), called_urls

    # The Studio processes the complete logical chain while protecting the
    # existing U-HAUL objects from duplicate create/deploy calls.
    assert not any("/api/document-type" in url for url in called_urls)
    assert not any("/api/mac-map" in url for url in called_urls)
    assert not any("/api/rule" in url for url in called_urls)
    assert not any("/transport-profiles/orchestration/create" in url for url in called_urls)
    assert not any("/flows/orchestration/create" in url for url in called_urls)
    assert not any("/flows/orchestration/deploy" in url for url in called_urls)
    assert any("validate-unique-interface-detail" in url for url in called_urls)
    assert any("/flows/deployment/history" in url for url in called_urls)
    assert sum("/transport-profiles/audits" in url for url in called_urls) == 2
    assert len(called_urls) == 6
    assert runner.final_state["success"] is True, runner.final_state

    output = {
        "status": "PASS",
        "buildId": run_agent.BUILD_ID,
        "activeSkipSteps": summary["skipSteps"],
        "skippedResults": [
            {
                "sequence": item.sequence,
                "api": item.api,
                "classification": item.classification,
                "apiCalled": False,
            }
            for item in skipped
        ],
        "executedHttpCalls": len(called_urls),
        "foundationApiCalls": [
            url
            for url in called_urls
            if "/hip-partners/" in url or "/hip-systems/" in url
        ],
        "endToEndSuccess": runner.final_state["success"],
        "flowHistoryExecuted": any(
            "/flows/deployment/history" in url
            for url in called_urls
        ),
        "inputFingerprintSafety": "PASS",
    }

    path = ROOT / "examples" / "API_SKIP_INTEGRATION_TEST.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(
        json.dumps(output, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
