from __future__ import annotations

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace

import webapp.backend.app.parallel_manager as pm
from run_agent import Runner

ROOT = Path(__file__).resolve().parent


def test_uhal_approved_duns_is_used_by_effective_partner_request():
    runner = Runner(llm_enabled=False)
    assert runner.input.get("customer") == "U-HAUL"
    assert runner.partner_identifier_value() == "12345666"
    request = runner.preview_step_request("partner_target")
    payload = request.get("payload") or {}
    assert payload.get("partnerIdentifier") == "DUNS Number"
    assert payload.get("partnerIdentifierValue") == "12345666"


def test_dev_approved_uhal_sources_persist_the_duns():
    for name in ["input.json", "dev_approved/UHAL_input_dev_approved.json", "config_overrides.json", "dev_approved/UHAL_config_dev_approved.json"]:
        data = json.loads((ROOT / name).read_text(encoding="utf-8"))
        assert data.get("partner_identifier_value") == "12345666"


def test_parallel_final_gate_runs_contract_validation_then_preflight(monkeypatch, tmp_path: Path):
    class Store:
        root = tmp_path
    manager = pm.ParallelManager(Store())
    destination = tmp_path / "exec"
    (destination / "reports").mkdir(parents=True)
    manifest = {"jobId": "q1", "label": "U-HAUL", "customer": "U-HAUL"}

    monkeypatch.setattr(pm, "validate_configuration", lambda workspace: {
        "ok": True,
        "requests": {"validCount": 18, "total": 18, "applicableCount": 18, "blockedItems": []},
    })
    calls = []
    def fake_run(command, **kwargs):
        calls.append(command)
        return SimpleNamespace(returncode=0, stdout=json.dumps({"ready": True, "approvedBusinessValues": {"uhaulDuns": {"expected": "12345666", "effective": "12345666", "valid": True}}}), stderr="")
    monkeypatch.setattr(pm.subprocess, "run", fake_run)
    monkeypatch.setattr(manager, "_publish", lambda *args, **kwargs: None)

    result = manager._final_pre_live_checks("batch1", manifest, destination, asyncio.new_event_loop())
    assert result["ready"] is True
    assert result["contractValidation"]["validCount"] == 18
    assert any(str(part).endswith("run_agent.py") for part in calls[0])
    assert "--preflight" in calls[0]
    evidence = json.loads((destination / "reports" / "final_pre_live_checks_latest.json").read_text(encoding="utf-8"))
    assert evidence["ready"] is True


def test_parallel_final_gate_blocks_before_live_when_contracts_fail(monkeypatch, tmp_path: Path):
    class Store:
        root = tmp_path
    manager = pm.ParallelManager(Store())
    destination = tmp_path / "exec"
    (destination / "reports").mkdir(parents=True)
    manifest = {"jobId": "q1", "label": "U-HAUL", "customer": "U-HAUL"}
    monkeypatch.setattr(pm, "validate_configuration", lambda workspace: {
        "ok": False,
        "requests": {"validCount": 17, "total": 18, "blockedItems": [{"stepKey": "partner_target"}]},
    })
    monkeypatch.setattr(manager, "_publish", lambda *args, **kwargs: None)
    called = {"run": False}
    def fake_run(*args, **kwargs):
        called["run"] = True
        raise AssertionError("production/live runner must not start when contract validation is blocked")
    monkeypatch.setattr(pm.subprocess, "run", fake_run)
    try:
        manager._final_pre_live_checks("batch1", manifest, destination, asyncio.new_event_loop())
        assert False, "expected final gate to block"
    except RuntimeError as exc:
        assert "No LIVE HIP API call was made" in str(exc)
    assert called["run"] is False
