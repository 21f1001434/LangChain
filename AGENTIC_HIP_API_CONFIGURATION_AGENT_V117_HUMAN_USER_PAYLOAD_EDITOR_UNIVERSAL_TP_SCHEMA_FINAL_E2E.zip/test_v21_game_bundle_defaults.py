from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import pytest

from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from input_bundle import extract_input_zip, inspect_input_zip, parse_input_json_bytes
from run_agent import Runner
from scratch_flow import component_request, new_component

ROOT = Path(__file__).resolve().parent


def _zip_bytes(files: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return buf.getvalue()


def test_global_default_deployment_group_is_hip_automation():
    assert DEFAULT_DEPLOYMENT_GROUP == "hip-automation"
    data, cfg = with_default_deployment_group({"objects": {}}, {})
    assert data["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert data["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
    assert cfg["source_deployment_group_name"] == "hip-automation"
    assert cfg["target_deployment_group_name"] == "hip-automation"


def test_explicit_user_deployment_group_is_overwritten_by_fixed_dev_rule():
    raw = {
        "objects": {
            "source_transport_profile": {"deployment_group": "custom-dev-group"},
            "target_transport_profile": {"deployment_group": "custom-dev-group"},
        }
    }
    data, _ = with_default_deployment_group(raw, {})
    assert data["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert data["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"


def test_live_source_and_target_tp_preview_use_hip_automation_default():
    runner = Runner(llm_enabled=False)
    for key in ("source_tp", "target_tp"):
        req = component_request(runner, new_component(key), {})
        details = req["payload"]["transportProfileDetails"][0]
        assert details["deploymentGroupName"] == "hip-automation"


def test_uhaul_zip_bundle_is_safely_flattened(tmp_path: Path):
    raw = _zip_bytes({
        "maps/Transform.jar": b"jar-data",
        "schemas/source.xml": b"<Source/>",
        "schemas/output.xml": b"<Output/>",
    })
    info = inspect_input_zip(raw)
    assert info["valid"] is True
    assert info["fileCount"] == 3
    destination = tmp_path / "input_files"
    extract_input_zip(raw, destination)
    assert (destination / "Transform.jar").read_bytes() == b"jar-data"
    assert (destination / "source.xml").read_text() == "<Source/>"
    assert (destination / "output.xml").read_text() == "<Output/>"


def test_uhaul_zip_bundle_blocks_zip_slip_and_duplicate_basenames():
    with pytest.raises(ValueError):
        inspect_input_zip(_zip_bytes({"../escape.txt": b"no"}))
    with pytest.raises(ValueError):
        inspect_input_zip(_zip_bytes({"a/source.xml": b"a", "b/source.xml": b"b"}))


def test_input_json_upload_parser_requires_object_and_accepts_utf8_bom():
    parsed = parse_input_json_bytes(b"\xef\xbb\xbf" + json.dumps({"customer": "U-HAUL"}).encode())
    assert parsed["customer"] == "U-HAUL"
    with pytest.raises(ValueError):
        parse_input_json_bytes(b"[]")


def test_game_board_ui_and_bundle_workspace_are_packaged():
    scratch = (ROOT / "scratch_flow_ui.py").read_text(encoding="utf-8")
    app = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    builder = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    assert "HIP Flow Arcade" in scratch
    assert "MISSION TRACK" in scratch
    assert "LAUNCH MISSION LIVE" in scratch
    assert "🧭 Build New Configuration" in app
    assert "Agent ingest + generate input.json" in builder
    assert "Map to 18 APIs + agent validate" in builder
