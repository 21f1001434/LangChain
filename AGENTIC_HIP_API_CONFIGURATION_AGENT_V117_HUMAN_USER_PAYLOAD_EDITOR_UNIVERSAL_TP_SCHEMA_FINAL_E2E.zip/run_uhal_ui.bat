@echo off
rem Compatibility launcher. RUN_HIP_STUDIO.bat performs runtime_preflight.py before opening Streamlit.
call "%~dp0RUN_HIP_STUDIO.bat"
