from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


STEP_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    "validate_source": {"label": "Validate Source TP", "group": "Validation", "dependencies": []},
    "validate_target": {"label": "Validate Target TP", "group": "Validation", "dependencies": []},
    "validate_flow": {"label": "Validate Flow Name", "group": "Validation", "dependencies": []},
    "account_source": {"label": "Source Account", "group": "Foundation", "dependencies": []},
    "account_target": {"label": "Target Account", "group": "Foundation", "dependencies": []},
    "partner_target": {"label": "Target Partner", "group": "Foundation", "dependencies": []},
    "system_source": {"label": "Source System", "group": "Foundation", "dependencies": []},
    "doctype_source": {"label": "Source Document Type", "group": "Configuration", "dependencies": []},
    "doctype_target": {"label": "Target Document Type", "group": "Configuration", "dependencies": []},
    "map": {"label": "MAC Map", "group": "Configuration", "dependencies": ["doctype_source", "doctype_target"]},
    "rule": {"label": "Mapping Rule", "group": "Configuration", "dependencies": ["doctype_source", "map"]},
    "source_tp": {"label": "Source TP Orchestration", "group": "Orchestration", "dependencies": ["doctype_source"]},
    "target_tp": {"label": "Target TP Orchestration", "group": "Orchestration", "dependencies": ["doctype_target"]},
    "source_tp_audit": {"label": "Source TP Audit", "group": "Verification", "dependencies": ["source_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
    "target_tp_audit": {"label": "Target TP Audit", "group": "Verification", "dependencies": ["target_tp"], "pollEverySeconds": 60, "timeoutSeconds": 3600},
    "flow_create": {"label": "Flow Orchestration Create", "group": "Orchestration", "dependencies": ["doctype_source", "doctype_target", "map", "rule", "source_tp_audit", "target_tp_audit"]},
    "flow_deploy": {"label": "Flow Orchestration Deploy", "group": "Orchestration", "dependencies": ["flow_create"]},
    "flow_history": {"label": "Flow Deployment Audit/History", "group": "Verification", "dependencies": ["flow_deploy"], "mandatory": True, "pollEverySeconds": 60, "timeoutSeconds": 3600},
}

DEFAULT_ORDER: List[str] = [
    "validate_source",
    "validate_target",
    "validate_flow",
    "account_source",
    "account_target",
    "partner_target",
    "system_source",
    "doctype_source",
    "doctype_target",
    "map",
    "rule",
    "source_tp",
    "target_tp",
    "source_tp_audit",
    "target_tp_audit",
    "flow_create",
    "flow_deploy",
    "flow_history",
]

# Dev feedback 2026-08-28 replaces fixed processing sleeps with terminal-state
# Audit polling. The runtime polls TP audits and Flow deployment history every
# minute for up to one hour, so no fixed wait is required here.
DEFAULT_WAIT_AFTER_SECONDS: Dict[str, float] = {key: 0.0 for key in DEFAULT_ORDER}


def default_config() -> Dict[str, Any]:
    return {
        "version": 2,
        "savedAt": None,
        "steps": [
            {
                "stepKey": key,
                "order": index + 1,
                "waitAfterSeconds": DEFAULT_WAIT_AFTER_SECONDS.get(key, 0.0),
            }
            for index, key in enumerate(DEFAULT_ORDER)
        ],
    }


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
    except Exception:
        return default
    return max(0.0, min(parsed, 3600.0))


def normalize_config(value: Any) -> Dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    rows = raw.get("steps") if isinstance(raw.get("steps"), list) else []
    try:
        source_version = int(raw.get("version") or 1)
    except Exception:
        source_version = 1
    by_key: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = str(row.get("stepKey") or "").strip()
        if key not in STEP_DEFINITIONS:
            continue
        try:
            order = int(row.get("order"))
        except Exception:
            order = DEFAULT_ORDER.index(key) + 1
        by_key[key] = {
            "stepKey": key,
            "order": max(1, order),
            "waitAfterSeconds": _as_float(row.get("waitAfterSeconds"), 0.0),
        }

    normalized = default_config()
    normalized["savedAt"] = raw.get("savedAt")
    normalized["steps"] = []
    for index, key in enumerate(DEFAULT_ORDER):
        row = by_key.get(key) or {
            "stepKey": key,
            "order": index + 1,
            "waitAfterSeconds": DEFAULT_WAIT_AFTER_SECONDS.get(key, 0.0),
        }
        # Version 1 placed TP audits after Flow deployment. That is unsafe per
        # the latest Dev guidance. Migrate legacy saved timing files to the new
        # dependency-safe order automatically while preserving custom wait values.
        if source_version < 2:
            row = {**row, "order": index + 1}
        normalized["steps"].append(row)
    return normalized


def validate_config(value: Any) -> Tuple[List[str], List[str]]:
    cfg = normalize_config(value)
    errors: List[str] = []
    warnings: List[str] = []
    steps = cfg["steps"]

    orders = [row["order"] for row in steps]
    if len(set(orders)) != len(orders):
        errors.append("Every execution step must have a unique Order value.")

    position = {
        row["stepKey"]: (row["order"], DEFAULT_ORDER.index(row["stepKey"]))
        for row in steps
    }
    for key, meta in STEP_DEFINITIONS.items():
        current = position[key]
        for dependency in meta.get("dependencies", []):
            if position[dependency] >= current:
                errors.append(
                    f"{meta['label']} must run after {STEP_DEFINITIONS[dependency]['label']}."
                )

    for row in steps:
        if row["waitAfterSeconds"] > 300:
            warnings.append(
                f"{STEP_DEFINITIONS[row['stepKey']]['label']} has a long wait of "
                f"{row['waitAfterSeconds']} seconds."
            )
    return errors, warnings


class ExecutionFlowConfig:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.path = self.root / "execution_flow.json"
        self.data = self._load()
        self.errors, self.warnings = validate_config(self.data)

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return default_config()
        try:
            return normalize_config(json.loads(self.path.read_text(encoding="utf-8")))
        except Exception:
            return default_config()

    def ordered_steps(self) -> List[str]:
        rows = list(self.data["steps"])
        rows.sort(key=lambda row: (int(row["order"]), DEFAULT_ORDER.index(row["stepKey"])))
        return [row["stepKey"] for row in rows]

    def wait_after(self, step_key: str) -> float:
        for row in self.data["steps"]:
            if row["stepKey"] == step_key:
                return _as_float(row.get("waitAfterSeconds"), 0.0)
        return 0.0

    def summary(self) -> Dict[str, Any]:
        return {
            "path": str(self.path),
            "valid": not self.errors,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "orderedSteps": self.ordered_steps(),
            "steps": [
                {
                    **row,
                    "label": STEP_DEFINITIONS[row["stepKey"]]["label"],
                    "group": STEP_DEFINITIONS[row["stepKey"]]["group"],
                    "dependencies": STEP_DEFINITIONS[row["stepKey"]].get("dependencies", []),
                }
                for row in sorted(self.data["steps"], key=lambda item: item["order"])
            ],
        }


def save_execution_flow(root: Path, rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    root = Path(root)
    payload = {
        "version": 2,
        "savedAt": dt.datetime.now().isoformat(),
        "steps": list(rows),
    }
    normalized = normalize_config(payload)
    normalized["savedAt"] = payload["savedAt"]
    errors, warnings = validate_config(normalized)
    if errors:
        raise ValueError("Invalid execution flow: " + " ".join(errors))
    path = root / "execution_flow.json"
    path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")
    result = ExecutionFlowConfig(root).summary()
    result["warnings"] = warnings
    return result


def reset_execution_flow(root: Path) -> Dict[str, Any]:
    root = Path(root)
    data = default_config()
    data["savedAt"] = dt.datetime.now().isoformat()
    (root / "execution_flow.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    return ExecutionFlowConfig(root).summary()
