from __future__ import annotations

import html
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from streamlit_navigation import request_workspace_switch

from application_studio import (
    customer_metadata,
    customer_options,
    interface_options,
    prepare_sftp_uhal_studio,
    request_inventory,
    run_local_request_checks,
)
from business_demo import build_business_demo_summary, write_business_demo_report
from execution_flow import STEP_DEFINITIONS
from payload_overrides import clear_override, save_override
from payload_ui_helpers import safe_request_for_ui
from production_guard import clear_stale_live_run, inspect_live_run, terminate_live_run


STAGES = [
    ("1", "Choose", "Pick what to run", "🧩"),
    ("2", "Look", "See what will be sent", "👀"),
    ("3", "Check", "Let the agent check it", "🤖"),
    ("4", "Run", "Call the live APIs", "▶️"),
    ("5", "Done", "See the result", "✅"),
]


def _load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _glass(title: str, body: str, icon: str = "✨", tone: str = "blue") -> None:
    st.markdown(
        f"""
        <div class="easy-glass easy-{tone}">
          <div class="easy-icon">{icon}</div>
          <div>
            <div class="easy-card-title">{html.escape(title)}</div>
            <div class="easy-card-body">{html.escape(body)}</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _stage_bar(current: int) -> None:
    items = []
    for index, (_, label, _, icon) in enumerate(STAGES, start=1):
        state = "done" if index < current else ("now" if index == current else "later")
        items.append(
            f"""
            <div class="easy-stage {state}">
              <div class="easy-stage-bubble">{icon}</div>
              <div class="easy-stage-label">{label}</div>
            </div>
            """
        )
    st.markdown(
        '<div class="easy-stage-track">' + '<div class="easy-stage-line"></div>'.join(items) + '</div>',
        unsafe_allow_html=True,
    )


def _nav(current: int, *, next_enabled: bool = True, next_label: str = "Next") -> None:
    left, _, right = st.columns([1, 3, 1])
    if current > 1 and left.button("← Back", width="stretch", key=f"easy_back_{current}"):
        st.session_state["easy_stage"] = current - 1
        st.rerun()
    if current < 5 and right.button(
        f"{next_label} →",
        type="primary",
        width="stretch",
        disabled=not next_enabled,
        key=f"easy_next_{current}",
    ):
        st.session_state["easy_stage"] = current + 1
        st.rerun()


def _simple_request_list(cards: List[Dict[str, Any]]) -> None:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for card in cards:
        groups.setdefault(str(card.get("group") or "Other"), []).append(card)

    icons = {
        "Validation": "🧪",
        "Account": "👤",
        "Partner": "🤝",
        "System": "🖥️",
        "Document Type": "📄",
        "Map": "🗺️",
        "Rule": "🧠",
        "Orchestration": "🔗",
        "History": "🕘",
    }
    for group, items in groups.items():
        st.markdown(
            f"""
            <div class="easy-api-group">
              <div class="easy-api-group-title">{icons.get(group, '🔹')} {html.escape(group)}</div>
              <div class="easy-api-group-sub">{len(items)} live API step{'s' if len(items) != 1 else ''}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        chips = " ".join(
            f'<span class="easy-api-chip">{int(item.get("order") or 0):02d} · {html.escape(str(item.get("label") or ""))}</span>'
            for item in items
        )
        st.markdown(f'<div class="easy-chip-wrap">{chips}</div>', unsafe_allow_html=True)


def _run_checks(root: Path, mcp: Any, ask_agent: Any) -> Dict[str, Any]:
    logs: List[str] = []

    connection = subprocess.run(
        [sys.executable, "connection_check.py"],
        cwd=root,
        text=True,
        capture_output=True,
    )
    logs.append((connection.stdout or "") + ("\n" + connection.stderr if connection.stderr else ""))
    connection_result = _load_json(root / "reports" / "connection_check_latest.json", {})
    connection_ok = bool(connection_result.get("secureConnectionsOk", connection.returncode == 0 and connection_result.get("overall") == "OK"))

    try:
        local = run_local_request_checks(root)
        local_ok = bool(local.get("ok"))
    except Exception as exc:
        local = {"ok": False, "error": str(exc)}
        local_ok = False

    input_data = _load_json(root / "input.json", {})
    config = _load_json(root / "config_overrides.json", {})
    try:
        mcp_readiness = mcp.assess_execution_readiness(input_data, config)
    except Exception as exc:
        mcp_readiness = {"valid": False, "liveRunBlocked": True, "error": str(exc)}
    mcp_ok = bool(mcp_readiness.get("valid", True) and not mcp_readiness.get("liveRunBlocked"))

    preflight = subprocess.run(
        [sys.executable, "run_agent.py", "--preflight"],
        cwd=root,
        text=True,
        capture_output=True,
    )
    logs.append((preflight.stdout or "") + ("\n" + preflight.stderr if preflight.stderr else ""))
    preflight_ok = preflight.returncode == 0

    all_ok = bool(connection_ok and local_ok and mcp_ok and preflight_ok)

    mapper_errors = list(((local.get("mapper") or {}).get("errors") or [])) if isinstance(local, dict) else []
    request_errors: List[str] = []
    for item in (((local.get("requests") or {}).get("items") or []) if isinstance(local, dict) else []):
        if not item.get("valid"):
            request_errors.extend(str(x) for x in (item.get("errors") or []))
    blocking_issues = [str((x or {}).get("message") or x) for x in mapper_errors] + request_errors
    blocking_issues += [str(x) for x in (mcp_readiness.get("errors") or [])]

    agent = ask_agent(
        "easy-studio-readiness",
        {
            "message": "Explain whether the active HIP live API run is ready in very simple language.",
            "next_action": (
                "Say 'You are ready to run' if every check passed. "
                "If secure connections passed, do not call a payload/configuration problem a connection problem. "
                "Name only the first real blocker and the value/action needed."
            ),
            "connectionsOk": connection_ok,
            "payloadChecksOk": local_ok,
            "mcpOk": mcp_ok,
            "preflightOk": preflight_ok,
            "blockingIssues": blocking_issues[:10],
        },
    )
    # Deterministic correction: the LLM must never mislabel a payload gap as a
    # connection failure. This was the cause of the misleading V25 screen.
    if not all_ok:
        if not connection_ok:
            agent["message"] = "The secure connection check needs attention. Open the connection details to see which OAuth/service connection failed."
        elif blocking_issues:
            agent["message"] = "Your secure connections are working. The configuration is not ready yet: " + blocking_issues[0]
            agent["nextActions"] = ["Provide or correct that value, then run Check everything again."]
        elif not preflight_ok:
            agent["message"] = "Your secure connections are working, but the final configuration preflight found a blocker."
            agent["nextActions"] = ["Open the preflight details, correct the listed configuration value, then re-check."]
    return {
        "ok": all_ok,
        "connectionsOk": connection_ok,
        "payloadChecksOk": local_ok,
        "mcpOk": mcp_ok,
        "preflightOk": preflight_ok,
        "connection": connection_result,
        "local": local,
        "mcpReadiness": mcp_readiness,
        "agent": agent,
        "blockingIssues": blocking_issues,
        "logs": "\n".join(logs),
    }


def _execute(root: Path) -> Dict[str, Any]:
    logs: List[str] = []
    error = ""

    process = subprocess.Popen(
        [sys.executable, "-u", "run_agent.py"],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
    )

    progress = st.progress(0.0)
    status_line = st.empty()
    response_line = st.empty()

    if process.stdout is not None:
        for raw in process.stdout:
            line = raw.rstrip()
            logs.append(line)
            match = re.match(r"^\[(\d+)\]\s+.*?-\s+.*?-\s+([A-Za-z0-9_]+)(?:\s+.*)?$", line)
            if match:
                seq = int(match.group(1))
                attempt = match.group(2)
                label = STEP_DEFINITIONS.get(attempt, {}).get("label") or attempt.replace("_", " ").title()
                progress.progress(min(1.0, seq / max(1, len(STEP_DEFINITIONS))))
                status_line.markdown(f"**{seq}/18 · {label}**")
            elif "-> HTTP" in line:
                response_line.success("Live response received — moving to the next API.")

    rc = process.wait()
    progress.progress(1.0)
    summary = build_business_demo_summary(root)
    report = write_business_demo_report(root, summary)
    if rc != 0:
        error = "The run finished with one or more API/configuration issues. The complete evidence is in the report."

    return {
        "summary": summary,
        "report": str(report),
        "logs": "\n".join(logs),
        "error": error,
        "returncode": rc,
    }


def render_easy_studio(root: Path, mcp: Any, ask_agent: Any) -> None:
    root = Path(root)
    stage = int(st.session_state.get("easy_stage", 1))
    stage = min(5, max(1, stage))

    st.markdown(
        """
        <div class="easy-welcome">
          <div class="easy-welcome-emoji">👋</div>
          <div>
            <div class="easy-welcome-title">Hi! I can run the HIP configuration for you.</div>
            <div class="easy-welcome-sub">You only need to make one choice at a time. I will handle the API details.</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    _stage_bar(stage)

    # ------------------------------------------------------------------
    # 1. CHOOSE
    # ------------------------------------------------------------------
    if stage == 1:
        _glass(
            "First, choose the connection",
            "For the U-HAUL live demo, choose SFTP. U-HAUL is already prepared for you.",
            "1️⃣",
        )

        interface = st.selectbox(
            "How does the customer connect?",
            interface_options(root),
            index=0,
            key="easy_interface",
        )
        customers = customer_options(interface)
        customer = st.selectbox(
            "Which customer/configuration?",
            customers,
            index=0,
            key=f"easy_customer_{interface}",
        )
        meta = customer_metadata(interface, customer)

        if interface == "SFTP" and customer == "U-HAUL":
            prepare_sftp_uhal_studio(root)
            st.session_state["easy_loaded"] = True
            st.markdown(
                f"""
                <div class="easy-selected">
                  <div class="easy-check">✓</div>
                  <div>
                    <div class="easy-selected-title">U-HAUL is ready</div>
                    <div class="easy-selected-sub">856 Ship Notice · Outbound · SFTP HAFT · hip-automation · 18 live API building blocks</div>
                  </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            _glass(
                "What do I do now?",
                "Nothing technical. Click Next. On the next screen you can see exactly what the agent will send.",
                "✨",
                "green",
            )
            _nav(stage, next_enabled=True, next_label="See the requests")
        else:
            _glass(
                "This interface needs a guided setup",
                "I can still configure it. Open the Agentic setup and I will ask only for the values that are different.",
                "🤖",
                "amber",
            )
            if st.button("Let the agent set up this interface", type="primary", width="stretch"):
                request_workspace_switch(st, "🤖 Agentic Interface Studio")
            _nav(stage, next_enabled=False)
        return

    if not st.session_state.get("easy_loaded"):
        prepare_sftp_uhal_studio(root)
        st.session_state["easy_loaded"] = True

    # ------------------------------------------------------------------
    # 2. LOOK
    # ------------------------------------------------------------------
    if stage == 2:
        inventory = request_inventory(root)
        cards = inventory.get("cards") or []

        _glass(
            "Here is what the agent will do",
            "There are 18 live HIP API steps. You do not need to read the JSON unless you want to.",
            "2️⃣",
        )

        a, b, c = st.columns(3)
        a.metric("Live API steps", inventory.get("live", 0))
        b.metric("Skipped", inventory.get("reused", 0))
        c.metric("Edited by you", inventory.get("edited", 0))

        _simple_request_list(cards)

        with st.expander("👀 I want to see one request", expanded=False):
            label_map = {
                f"{int(card.get('order') or 0):02d} · {card.get('label')}": card
                for card in cards
            }
            selected_label = st.selectbox("Choose an API step", list(label_map), key="easy_payload_select")
            selected = label_map[selected_label]
            st.markdown(
                f"""
                <div class="easy-request-head">
                  <b>{html.escape(str(selected.get('label') or ''))}</b>
                  <span>{html.escape(str(selected.get('businessMeaning') or ''))}</span>
                </div>
                """,
                unsafe_allow_html=True,
            )

            show_tabs = st.tabs(["What will be sent", "Change it"])
            with show_tabs[0]:
                st.json(selected.get("effective") or {})
            with show_tabs[1]:
                st.caption("Only use this if the Dev team asked you to change this request.")
                edit_text = st.text_area(
                    "Request JSON",
                    value=json.dumps(selected.get("effective") or {}, indent=2, ensure_ascii=False),
                    height=320,
                    key=f"easy_edit_{selected.get('stepKey')}",
                )
                try:
                    parsed = json.loads(edit_text)
                    valid_json = isinstance(parsed, dict)
                except Exception:
                    parsed = None
                    valid_json = False
                if not valid_json:
                    st.warning("The JSON is not valid yet.")
                ec1, ec2 = st.columns(2)
                if ec1.button(
                    "Save my change",
                    type="primary",
                    disabled=not valid_json,
                    width="stretch",
                    key=f"easy_save_{selected.get('stepKey')}",
                ):
                    critic = mcp.validate_payload_override(
                        selected.get("stepKey"),
                        selected.get("generated") or {},
                        safe_request_for_ui(parsed or {}),
                        interface_only=False,
                    )
                    contract = mcp.validate_api_request(
                        api_key=selected.get("urlKey") or selected.get("stepKey"),
                        method=selected.get("method") or "GET",
                        url=selected.get("url") or "",
                        headers={"x-requester-id": "easy-studio"},
                        payload=(parsed if (selected.get("requestKind") or "payload") == "payload" else None),
                        params=(parsed if (selected.get("requestKind") or "payload") == "params" else None),
                    )
                    if not critic.get("valid", True) or not contract.get("valid", True):
                        st.error("The agent blocked this change because it does not match the API rules.")
                    else:
                        save_override(
                            root,
                            selected.get("stepKey"),
                            parsed,
                            request_kind=selected.get("requestKind") or "payload",
                            mode="replace",
                            note="Easy Studio human user edit", edit_origin="USER",
                        )
                        st.session_state.pop("easy_checks", None)
                        st.success("Saved. The agent will use your edited request.")
                        st.rerun()
                if ec2.button(
                    "Undo my change",
                    width="stretch",
                    key=f"easy_reset_{selected.get('stepKey')}",
                ):
                    clear_override(root, selected.get("stepKey"))
                    st.session_state.pop("easy_checks", None)
                    st.success("Restored the agent-generated request.")
                    st.rerun()

        _glass(
            "What do I do now?",
            "If the customer, interface, and API count look right, click Next. The agent will check every request for you.",
            "✨",
            "green",
        )
        _nav(stage, next_enabled=True, next_label="Let the agent check")
        return

    # ------------------------------------------------------------------
    # 3. CHECK
    # ------------------------------------------------------------------
    if stage == 3:
        _glass(
            "Now I will check everything",
            "I will test connections, validate all 18 requests, run MCP checks, and run the safety preflight. This does not create anything yet.",
            "3️⃣",
        )

        if st.button("🤖 Check everything for me", type="primary", width="stretch", key="easy_run_checks"):
            with st.status("Checking everything...", expanded=True) as status:
                st.write("🔐 Checking secure connections")
                st.write("🧩 Checking all generated requests")
                st.write("🛡️ Running MCP safety checks")
                st.write("✅ Running final preflight")
                checks = _run_checks(root, mcp, ask_agent)
                st.session_state["easy_checks"] = checks
                status.update(
                    label="Everything is ready" if checks.get("ok") else "I found something to fix",
                    state="complete" if checks.get("ok") else "error",
                )

        checks = st.session_state.get("easy_checks") or {}
        if checks:
            rows = [
                ("Secure connections", checks.get("connectionsOk")),
                ("All API requests", checks.get("payloadChecksOk")),
                ("MCP safety check", checks.get("mcpOk")),
                ("Final preflight", checks.get("preflightOk")),
            ]
            for label, ok in rows:
                icon = "✅" if ok else "⚠️"
                tone = "green" if ok else "amber"
                _glass(label, "Ready" if ok else "Needs attention", icon, tone)

            agent = checks.get("agent") or {}
            _glass(
                "Agent says",
                str(agent.get("message") or ("You are ready to run." if checks.get("ok") else "One item needs attention.")),
                "🤖",
                "green" if checks.get("ok") else "amber",
            )

            if not checks.get("ok"):
                mapper_errors = list((((checks.get("local") or {}).get("mapper") or {}).get("errors") or []))
                partner_missing = any(str((item or {}).get("field")) == "partnerIdentifierValue" for item in mapper_errors)
                if partner_missing:
                    with st.container(border=True):
                        st.markdown("#### 🤝 One value is needed for Partner Create")
                        st.caption("Your connections can still be healthy. Enter the Dev-approved Partner Identifier / DUNS value, then I will re-check the requests.")
                        partner_value = st.text_input(
                            "Partner Identifier / DUNS",
                            value=str((_load_json(root / "input.json", {}) or {}).get("partner_identifier_value") or ""),
                            key="easy_partner_identifier_fix",
                        )
                        if st.button("Save DUNS and re-check", type="primary", disabled=not partner_value.strip(), key="easy_save_partner_identifier"):
                            active_input = _load_json(root / "input.json", {})
                            active_input["partner_identifier_value"] = partner_value.strip()
                            tmp = root / "input.json.tmp"
                            tmp.write_text(json.dumps(active_input, indent=2, ensure_ascii=False), encoding="utf-8")
                            tmp.replace(root / "input.json")
                            st.session_state.pop("easy_checks", None)
                            st.success("Saved. Run Check everything again.")
                            st.rerun()
                with st.expander("Show me what needs fixing", expanded=False):
                    st.json({
                        "connections": checks.get("connection"),
                        "requestChecks": checks.get("local"),
                        "mcp": checks.get("mcpReadiness"),
                    })

        _nav(
            stage,
            next_enabled=bool(checks.get("ok")),
            next_label="Go to live run",
        )
        return

    # ------------------------------------------------------------------
    # 4. RUN
    # ------------------------------------------------------------------
    if stage == 4:
        checks = st.session_state.get("easy_checks") or {}
        _glass(
            "Ready for the live run",
            "This will call all 18 HIP API building blocks. Nothing is skipped. Every request and response will be saved in the final report.",
            "4️⃣",
            "amber",
        )

        lock = inspect_live_run(root)
        if lock.get("stale"):
            clear_stale_live_run(root)
            lock = inspect_live_run(root)
        if lock.get("active"):
            _glass(
                "An older run is still active",
                "You can stop it safely before starting this one.",
                "🛑",
                "amber",
            )
            if st.button("Stop the old run", type="primary", width="stretch"):
                outcome = terminate_live_run(root)
                if outcome.get("stopped"):
                    st.success("Old run stopped.")
                    st.rerun()
                st.error("I could not stop it safely.")

        confirm = st.checkbox(
            "Yes — call all 18 live HIP APIs and save every response",
            value=False,
            key="easy_live_confirm",
        )

        ready = bool(checks.get("ok") and not lock.get("active") and confirm)
        if st.button(
            "▶️ Run the complete U-HAUL flow",
            type="primary",
            width="stretch",
            disabled=not ready,
            key="easy_execute",
        ):
            with st.status("Running the live HIP configuration...", expanded=True) as status:
                result = _execute(root)
                st.session_state["easy_result"] = result
                if result.get("summary", {}).get("coverageComplete"):
                    status.update(label="All live API steps were attempted", state="complete")
                else:
                    status.update(label="The run needs attention", state="error")
            st.session_state["easy_stage"] = 5
            st.rerun()

        if not checks.get("ok"):
            st.info("Go back and run the Agent Check first.")
        elif not confirm:
            st.caption("Tick the confirmation box to unlock the live run button.")

        _nav(stage, next_enabled=False)
        return

    # ------------------------------------------------------------------
    # 5. DONE
    # ------------------------------------------------------------------
    result = st.session_state.get("easy_result") or {}
    summary = result.get("summary") or build_business_demo_summary(root)
    report_path = Path(str(result.get("report") or ""))
    if not report_path.exists():
        try:
            report_path = write_business_demo_report(root, summary)
        except Exception:
            report_path = Path("")

    coverage_ok = bool(summary.get("coverageComplete"))
    business_ok = bool(summary.get("businessSuccess"))

    _glass(
        "All live API calls are finished" if coverage_ok else "The run finished, but some API calls are missing",
        (
            "Every configured API building block was attempted. The business result passed."
            if coverage_ok and business_ok
            else (
                "Every configured API building block was attempted. Some responses still need review."
                if coverage_ok
                else "The report shows exactly which API did not complete."
            )
        ),
        "✅" if coverage_ok else "⚠️",
        "green" if coverage_ok else "amber",
    )

    r1, r2, r3 = st.columns(3)
    r1.metric("Expected APIs", summary.get("expectedLogicalApis", 18))
    r2.metric("Live API calls", summary.get("liveApiCalls", 0))
    r3.metric("Skipped", summary.get("skippedApiCalls", 0))

    check_items = summary.get("checks") or []
    for check in check_items:
        _glass(
            str(check.get("label") or "Verification"),
            str(check.get("classification") or ""),
            "✅" if check.get("ok") else "⚠️",
            "green" if check.get("ok") else "amber",
        )

    if report_path.exists():
        st.download_button(
            "📥 Download the complete request + response report",
            report_path.read_bytes(),
            file_name="UHAUL_Full_Live_API_Report.html",
            mime="text/html",
            width="stretch",
        )

    with st.expander("Show technical execution details", expanded=False):
        st.code(result.get("logs") or "No technical log captured.")

    c1, c2 = st.columns(2)
    if c1.button("Run U-HAUL again", type="primary", width="stretch"):
        st.session_state["easy_stage"] = 1
        st.session_state.pop("easy_checks", None)
        st.session_state.pop("easy_result", None)
        st.rerun()
    if c2.button("Open API Testing Area", width="stretch"):
        request_workspace_switch(st, "🧪 API Testing Area")
