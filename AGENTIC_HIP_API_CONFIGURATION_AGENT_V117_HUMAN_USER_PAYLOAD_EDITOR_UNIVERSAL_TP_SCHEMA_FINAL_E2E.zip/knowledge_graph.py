from __future__ import annotations

import json
import os
import sqlite3
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class KGNode:
    node_id: str
    node_type: str
    name: str
    properties: Dict[str, Any]


@dataclass
class KGEdge:
    source_id: str
    relation: str
    target_id: str
    properties: Dict[str, Any]


class HipKnowledgeGraph:
    """Persistent local knowledge graph with optional Neo4j mirroring.

    SQLite is the authoritative local store so the agent remains usable without
    external infrastructure. When NEO4J_URI/USER/PASSWORD are configured and
    the neo4j driver is installed, `sync_to_neo4j` mirrors the graph.
    """

    def __init__(self, root: Path):
        self.root = Path(root)
        self.dir = self.root / "knowledge" / "graph"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.dir / "hip_knowledge_graph.sqlite3"
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    node_type TEXT NOT NULL,
                    name TEXT NOT NULL,
                    properties_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS edges (
                    source_id TEXT NOT NULL,
                    relation TEXT NOT NULL,
                    target_id TEXT NOT NULL,
                    properties_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(source_id, relation, target_id)
                );
                CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type);
                CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
                CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
                """
            )

    @staticmethod
    def safe_id(node_type: str, value: Any) -> str:
        raw = str(value or "unknown").strip().lower()
        clean = "".join(ch if ch.isalnum() else "_" for ch in raw).strip("_")
        return f"{node_type}:{clean or 'unknown'}"

    def upsert_node(self, node_id: str, node_type: str, name: str, properties: Optional[Dict[str, Any]] = None) -> str:
        props = properties or {}
        now = utc_now()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO nodes(node_id,node_type,name,properties_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(node_id) DO UPDATE SET
                    node_type=excluded.node_type,
                    name=excluded.name,
                    properties_json=excluded.properties_json,
                    updated_at=excluded.updated_at
                """,
                (node_id, node_type, name, json.dumps(props, default=str), now, now),
            )
        return node_id

    def upsert_edge(self, source_id: str, relation: str, target_id: str, properties: Optional[Dict[str, Any]] = None) -> None:
        props = properties or {}
        now = utc_now()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO edges(source_id,relation,target_id,properties_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(source_id,relation,target_id) DO UPDATE SET
                    properties_json=excluded.properties_json,
                    updated_at=excluded.updated_at
                """,
                (source_id, relation, target_id, json.dumps(props, default=str), now, now),
            )

    def record_input_mapping(self, customer: str, lineage: Dict[str, List[Dict[str, Any]]], normalized: Dict[str, Any]) -> None:
        customer_id = self.upsert_node(
            self.safe_id("customer", customer), "Customer", customer,
            {"normalized": normalized},
        )
        for step_key, rows in lineage.items():
            api_id = self.upsert_node(self.safe_id("api_step", step_key), "ApiStep", step_key, {})
            self.upsert_edge(customer_id, "USES_STEP", api_id)
            for row in rows:
                input_path = str(row.get("inputPath") or "unknown")
                payload_field = str(row.get("payloadField") or "unknown")
                input_id = self.upsert_node(
                    self.safe_id("input_field", input_path), "InputField", input_path,
                    {"lastValue": row.get("value")},
                )
                field_id = self.upsert_node(
                    self.safe_id("payload_field", f"{step_key}.{payload_field}"),
                    "PayloadField", payload_field,
                    {"stepKey": step_key},
                )
                self.upsert_edge(customer_id, "PROVIDES", input_id)
                self.upsert_edge(input_id, "MAPS_TO", field_id, {"stepKey": step_key})
                self.upsert_edge(field_id, "BELONGS_TO", api_id)

    def record_dependency_manifest(self, sequence: Iterable[Dict[str, Any]]) -> None:
        for item in sequence:
            key = str(item.get("key"))
            node_id = self.upsert_node(self.safe_id("api_step", key), "ApiStep", key, item)
            for dep in item.get("dependsOn") or []:
                dep_id = self.upsert_node(self.safe_id("api_step", dep), "ApiStep", str(dep), {})
                self.upsert_edge(node_id, "DEPENDS_ON", dep_id)

    def record_dev_change(self, change_id: str, request_text: str, patch: List[Dict[str, Any]], status: str, impact: Dict[str, Any]) -> None:
        change_node = self.upsert_node(
            self.safe_id("change", change_id), "DevChange", change_id,
            {"request": request_text, "patch": patch, "status": status, "impact": impact, "timestamp": utc_now()},
        )
        for step in impact.get("affectedSteps") or []:
            step_id = self.upsert_node(self.safe_id("api_step", step), "ApiStep", step, {})
            self.upsert_edge(change_node, "AFFECTS", step_id)

    def record_api_result(self, sequence: int, step_key: str, status: str, response: Any, extracted: Dict[str, Any]) -> None:
        run_id = self.safe_id("run_step", f"{utc_now()}_{sequence}_{step_key}")
        result_id = self.upsert_node(
            run_id, "ApiResult", f"{sequence}:{step_key}",
            {"sequence": sequence, "stepKey": step_key, "status": status, "response": response, "extracted": extracted},
        )
        step_id = self.upsert_node(self.safe_id("api_step", step_key), "ApiStep", step_key, {})
        self.upsert_edge(result_id, "RESULT_OF", step_id)
        for key, value in (extracted or {}).items():
            if key.startswith("_") or value in (None, "", [], {}):
                continue
            id_node = self.upsert_node(
                self.safe_id("runtime_value", f"{key}:{value}"), "RuntimeValue", str(key), {"value": value},
            )
            self.upsert_edge(result_id, "EXTRACTED", id_node)

    def query(self, text: str = "", node_type: str = "", limit: int = 100) -> Dict[str, Any]:
        clauses: List[str] = []
        params: List[Any] = []
        if text:
            clauses.append("(lower(name) LIKE ? OR lower(properties_json) LIKE ?)")
            pattern = f"%{text.lower()}%"
            params.extend([pattern, pattern])
        if node_type:
            clauses.append("node_type = ?")
            params.append(node_type)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM nodes{where} ORDER BY updated_at DESC LIMIT ?",
                (*params, int(limit)),
            ).fetchall()
            nodes = [
                {
                    "nodeId": row["node_id"],
                    "nodeType": row["node_type"],
                    "name": row["name"],
                    "properties": json.loads(row["properties_json"]),
                    "updatedAt": row["updated_at"],
                }
                for row in rows
            ]
            node_ids = [n["nodeId"] for n in nodes]
            edges: List[Dict[str, Any]] = []
            if node_ids:
                placeholders = ",".join("?" for _ in node_ids)
                edge_rows = conn.execute(
                    f"SELECT * FROM edges WHERE source_id IN ({placeholders}) OR target_id IN ({placeholders}) LIMIT ?",
                    (*node_ids, *node_ids, int(limit) * 4),
                ).fetchall()
                edges = [
                    {
                        "sourceId": row["source_id"],
                        "relation": row["relation"],
                        "targetId": row["target_id"],
                        "properties": json.loads(row["properties_json"]),
                    }
                    for row in edge_rows
                ]
        return {"nodes": nodes, "edges": edges}

    def stats(self) -> Dict[str, Any]:
        with self._connect() as conn:
            node_count = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
            types = conn.execute("SELECT node_type, COUNT(*) c FROM nodes GROUP BY node_type ORDER BY c DESC").fetchall()
        return {
            "database": str(self.db_path),
            "nodeCount": node_count,
            "edgeCount": edge_count,
            "nodeTypes": {row["node_type"]: row["c"] for row in types},
        }

    def export_json(self, path: Optional[Path] = None) -> Path:
        path = path or (self.dir / "hip_knowledge_graph.json")
        with self._connect() as conn:
            nodes = [
                {
                    "nodeId": row["node_id"], "nodeType": row["node_type"], "name": row["name"],
                    "properties": json.loads(row["properties_json"]),
                }
                for row in conn.execute("SELECT * FROM nodes").fetchall()
            ]
            edges = [
                {
                    "sourceId": row["source_id"], "relation": row["relation"], "targetId": row["target_id"],
                    "properties": json.loads(row["properties_json"]),
                }
                for row in conn.execute("SELECT * FROM edges").fetchall()
            ]
        path.write_text(json.dumps({"nodes": nodes, "edges": edges}, indent=2, default=str), encoding="utf-8")
        return path

    @staticmethod
    def _graphml_value(value: Any) -> Any:
        """Return a GraphML-safe scalar without changing the JSON knowledge graph.

        NetworkX GraphML supports only scalar primitive values. Runtime knowledge
        may legitimately contain ``None`` (unknown optional fields), containers,
        Paths, UUID-like objects, or other Python values. Those must never make a
        business-readiness/export operation fail. Containers are serialized as
        deterministic JSON, ``None`` becomes an empty string, primitive scalars
        are preserved, and all remaining values are stringified.
        """
        if value is None:
            return ""
        if isinstance(value, (dict, list, tuple, set)):
            if isinstance(value, set):
                value = sorted(value, key=str)
            return json.dumps(value, default=str, sort_keys=True)
        if isinstance(value, (str, bool, int, float)):
            return value
        return str(value)

    def export_graphml(self, path: Optional[Path] = None) -> Path:
        path = path or (self.dir / "hip_knowledge_graph.graphml")
        try:
            import networkx as nx
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("networkx is required for GraphML export") from exc
        graph = nx.MultiDiGraph()
        data = json.loads(self.export_json().read_text(encoding="utf-8"))
        for node in data["nodes"]:
            props = {k: self._graphml_value(v) for k, v in (node.get("properties") or {}).items()}
            graph.add_node(
                str(node.get("nodeId") or ""),
                node_type=self._graphml_value(node.get("nodeType")),
                name=self._graphml_value(node.get("name")),
                **props,
            )
        for edge in data["edges"]:
            props = {k: self._graphml_value(v) for k, v in (edge.get("properties") or {}).items()}
            graph.add_edge(
                str(edge.get("sourceId") or ""),
                str(edge.get("targetId") or ""),
                relation=self._graphml_value(edge.get("relation")),
                **props,
            )
        path.parent.mkdir(parents=True, exist_ok=True)
        nx.write_graphml(graph, path)
        return path

    def sync_to_neo4j(self) -> Dict[str, Any]:
        uri = os.getenv("NEO4J_URI", "").strip()
        user = os.getenv("NEO4J_USER", "").strip()
        password = os.getenv("NEO4J_PASSWORD", "").strip()
        if not all([uri, user, password]):
            return {"synced": False, "reason": "NEO4J_URI/USER/PASSWORD are not configured."}
        try:
            from neo4j import GraphDatabase
        except Exception as exc:
            return {"synced": False, "reason": f"neo4j driver unavailable: {exc}"}
        data = json.loads(self.export_json().read_text(encoding="utf-8"))
        driver = GraphDatabase.driver(uri, auth=(user, password))
        try:
            with driver.session() as session:
                for node in data["nodes"]:
                    session.run(
                        "MERGE (n:HIPNode {nodeId:$nodeId}) SET n.nodeType=$nodeType, n.name=$name, n.propertiesJson=$props",
                        nodeId=node["nodeId"], nodeType=node["nodeType"], name=node["name"], props=json.dumps(node["properties"], default=str),
                    )
                for edge in data["edges"]:
                    session.run(
                        "MATCH (a:HIPNode {nodeId:$source}), (b:HIPNode {nodeId:$target}) "
                        "MERGE (a)-[r:HIP_REL {relation:$relation}]->(b) SET r.propertiesJson=$props",
                        source=edge["sourceId"], target=edge["targetId"], relation=edge["relation"], props=json.dumps(edge["properties"], default=str),
                    )
        finally:
            driver.close()
        return {"synced": True, "nodes": len(data["nodes"]), "edges": len(data["edges"]), "uri": uri}
