from pathlib import Path

from api_pdf_ingestion import BUILTIN_CONTRACTS
from production_guard import validate_production_readiness
from run_agent import Runner
from uhal_mapper import UhalInputMapper
from work_type_catalog import hydrate_work_types, resolve_work_type


def test_flow_create_and_deploy_completely_omit_worktype_object():
    runner = Runner(llm_enabled=False)
    for step in ("flow_create", "flow_deploy"):
        request = runner.preview_step_request(step)
        payload = request.get("payload") or {}
        assert "workType" not in payload


def test_orchestration_contracts_forbid_worktype_instead_of_requiring_it():
    for key in ("orch_flow_create", "orch_flow_deploy", "orch_tp_create"):
        contract = BUILTIN_CONTRACTS[key]
        assert "workType" not in (contract.get("requiredFields") or [])
        assert not any(str(x).startswith("workType") for x in (contract.get("nestedRequiredFields") or []))
        assert "workType" in (contract.get("forbiddenFields") or [])


def test_missing_values_never_ask_for_any_worktype_field():
    runner = Runner(llm_enabled=False)
    fields = [str(item.get("field") or "") for item in runner.collect_missing_values()]
    assert not any("worktype" in field.casefold() for field in fields)


def test_legacy_worktypes_are_stripped_and_not_mapped():
    cfg = {"workTypes": {"flow_create": {"id": 3419, "type": "OLD"}}, "hipEnvironment": "DEV"}
    cleaned = hydrate_work_types(cfg, Path.cwd())
    assert "workTypes" not in cleaned
    assert resolve_work_type("flow_create", {"id": 3419}, {}) == {}
    mapper = UhalInputMapper({"objects": {}}, cfg, Path.cwd())
    lineage = mapper.lineage()
    assert all(row.get("payloadField") != "workType" for row in lineage.get("flow_deploy", []) if isinstance(row, dict))
