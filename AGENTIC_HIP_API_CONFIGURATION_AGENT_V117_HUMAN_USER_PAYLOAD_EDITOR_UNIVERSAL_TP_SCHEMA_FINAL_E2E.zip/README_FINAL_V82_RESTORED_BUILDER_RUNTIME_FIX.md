# V82 — Restored Build Configuration + Windows Runtime Recovery

## What V82 fixes

### 1. Full Build Configuration is restored
V81 displayed only the immutable U-HAUL reference screen whenever the global Active Customer was U-HAUL. The original builder was still in source but hidden by an early return.

V82 removes that takeover. When U-HAUL is globally active, Build Configuration now shows a small developer-approved reference banner **and the complete builder underneath**, including:

- Customer / partner name
- Direction
- Transaction code
- Translation / Passthrough / Auto
- Source and target interfaces
- Customer files only
- Configuration Manual + files
- Existing input.json + supporting files
- User/business instructions
- File ingestion and canonical input.json generation
- File evidence mapping
- Customer-file vs user-selection conflict resolution
- Required-values intake report
- 18-API non-mutating validation
- Inline API blocker repair
- Flow Game and Execution hand-off

The approved U-HAUL reference remains immutable. If U-HAUL is active and the user enters/uploads a new customer build, the backend creates a **new editable configuration** instead of patching U-HAUL.

### 2. WinError 5 / Access denied is hardened again
The V81 screenshot showed that `%LOCALAPPDATA%\\HIP API Agent Studio\\runtime` itself could still contain a protected/poisoned child workspace. A top-level write probe was therefore insufficient.

V82 uses a clean default runtime:

`%LOCALAPPDATA%\\HIP API Agent Studio\\runtime-v82`

and verifies the **same nested filesystem operations the application actually uses** before selecting it:

`configurations/<probe>/input_files`

The probe creates nested folders, writes a file, atomically renames it, deletes it, and removes the workspace. If any operation fails, the Studio automatically tries the next candidate and finally the OS temp location.

The optional override remains:

`HIP_STUDIO_RUNTIME_ROOT`

### 3. U-HAUL reference sync no longer deletes protected evidence folders
Reference synchronization now merges packaged evidence with `dirs_exist_ok=True` rather than deleting and recreating `input_files`. If enterprise Windows protection rejects a non-authoritative evidence directory, that filesystem condition does not downgrade the developer-approved U-HAUL reference.

The authoritative packaged `input.json` and approved API request structures remain unchanged.

## U-HAUL behavior

- Status: **DEV APPROVED · TEST READY · 18/18**
- Original baseline: immutable
- API structure: immutable
- Runtime/connectivity checks: separate from approval
- New customer from U-HAUL: use **Create from U-HAUL**
- Completely new customer: use the restored blank Build Configuration workflow

## Payload safety

V82 does not loosen the existing payload structure lock. The developer-approved 18 API request structures remain fixed. Customer-specific **values** may change on editable customer configurations; unknown/new/renamed attributes remain rejected.

## Validation performed

- Targeted V77–V82 regression: 31/31 PASS
- Application/root suite: 269/269 PASS
- FastAPI backend suite: 48/48 PASS
- Total automated tests: 317/317 PASS
- Phase 6 package checks: 38/38 PASS
- Final release checks: 16/16 PASS
- Required application self-checks: 43/43 PASS
- Adaptive package checks: 60/60 PASS
- Python compilation: PASS
- Frontend TypeScript/TSX dependency-independent transpilation: 24/24 PASS

A full Vite production bundle was not regenerated in the sandbox because frontend package dependencies are not installed. The source package intentionally does not include `node_modules`.
