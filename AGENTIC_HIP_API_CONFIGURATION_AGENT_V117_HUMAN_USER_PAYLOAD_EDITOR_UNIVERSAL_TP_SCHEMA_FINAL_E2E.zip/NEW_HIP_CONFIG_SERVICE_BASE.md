# New HIP Config Service Base URL

The final runner now uses:

`https://apigtwtst.us.dell.com/hip-config-service`

for:

- Document Type
- MAC Map
- Rule
- Transport Profile validation
- Transport Profile audits
- Transport Profile orchestration
- Flow-name validation
- Flow orchestration create
- Flow orchestration deploy
- Flow deployment history

The following services remain separate:

- Account and Partner: `https://apigtwtst.us.dell.com/hip-partners/api/authz`
- System: `https://apigtwtst.us.dell.com/hip-systems/api`
- OAuth token endpoint: unchanged
