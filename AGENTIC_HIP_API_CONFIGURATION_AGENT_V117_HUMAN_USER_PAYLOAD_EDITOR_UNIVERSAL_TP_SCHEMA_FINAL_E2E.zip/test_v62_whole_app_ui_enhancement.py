from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "webapp" / "frontend" / "src"


def test_global_operator_shell_and_responsive_navigation_present():
    app = (SRC / "App.tsx").read_text(encoding="utf-8")
    sidebar = (SRC / "components" / "Sidebar.tsx").read_text(encoding="utf-8")
    topbar = (SRC / "components" / "AppTopbar.tsx").read_text(encoding="utf-8")
    css = (SRC / "styles.css").read_text(encoding="utf-8")

    assert "AppTopbar" in app
    assert "sidebarCollapsed" in app
    assert "mobileNavOpen" in app
    assert "hip.sidebarCollapsed" in app
    assert "Run & observe" in sidebar
    assert "Administration" in sidebar
    assert "sidebar-scrim" in sidebar
    assert "Active customer" in topbar
    assert "environment-pill" in topbar
    assert "V62 · Whole-application UI/UX enhancement" in css
    assert ".sidebar-collapsed" in css
    assert ".app-topbar" in css
    assert "@media(max-width:980px)" in css
    assert "prefers-reduced-motion" in css


def test_flow_game_is_scoped_below_global_topbar():
    css = (SRC / "styles.css").read_text(encoding="utf-8")
    assert ".flow-page{height:calc(100vh - var(--topbar-height))" in css
    assert ".flow-page .inspector{position:absolute" in css
    assert ".flow-page .edge-inspector" in css


def test_ui_refresh_keeps_execution_label_and_live_safety_copy():
    sidebar = (SRC / "components" / "Sidebar.tsx").read_text(encoding="utf-8")
    assert "label:'Execute'" in sidebar
    assert "LIVE ONLY" in sidebar
