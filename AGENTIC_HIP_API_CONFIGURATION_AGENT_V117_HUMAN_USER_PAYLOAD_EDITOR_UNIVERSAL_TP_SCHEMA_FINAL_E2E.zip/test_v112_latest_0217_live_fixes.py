import json

import run_agent
from types import SimpleNamespace
from pathlib import Path
from hip_naming import normalize_input_flow_name, validate_hip_flow_name
from webapp.backend.app.parallel_manager import ParallelManager


def _rule_result():
    return run_agent.Result(
        13, "Rule", "Create mapping rule", "rule", "POST", "https://example/api/rule",
        "HIP", "rule", 500, "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 10, "", "{}",
        json.dumps({
            "error": True,
            "message": "Create failed",
            "detail": "A rule with the same name and version already exists in DEV.",
            "status": 500,
            "data": None,
        }), {}, "", "", "", "", ""
    )


def test_v112_reconciles_valid_nested_flow_name_with_stale_top_level_name():
    stale = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    valid = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB"
    cfg = {
        "profile_name": stale,
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": valid}}},
    }
    out = normalize_input_flow_name(cfg)
    assert out["profile_name"] == valid
    assert out["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == valid
    assert validate_hip_flow_name(out["profile_name"])["valid"] is True
    assert out["_flow_name_normalization"]["originalTopLevel"] == stale
    assert out["_flow_name_normalization"]["originalNested"] == valid


def test_v112_reconciles_stale_nested_flow_name_with_valid_top_level_name():
    stale = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    valid = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB"
    cfg = {
        "profile_name": valid,
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": stale}}},
    }
    out = normalize_input_flow_name(cfg)
    assert out["profile_name"] == valid
    assert out["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == valid


def test_v112_rule_resolver_uses_plain_current_live_summary_when_search_params_do_not_work(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)
    name = runner.business["mappingRuleName"]
    version = runner.business["mappingRuleVersion"]
    calls = []

    class Resp:
        def __init__(self, status, body):
            self.status_code = status
            self._body = body
            self.headers = {"content-type": "application/json"}
        def json(self):
            return self._body

    def fake_request(**kwargs):
        calls.append(kwargs)
        url = kwargs["url"]
        params = kwargs.get("params")
        # Targeted detail/search forms are deliberately rejected/empty, matching
        # the latest LIVE symptom. Only the exact plain /summary listing works.
        if url.endswith("/details"):
            return Resp(400, {"error": "unsupported query"})
        if url.endswith("/summary") and not params:
            return Resp(200, {
                "data": [{
                    "ruleName": name,
                    "environments": [
                        {"hipEnvironment": "DEV", "versions": [{"ruleId": 54321, "version": float(version)}]},
                        {"hipEnvironment": "PROD", "versions": []},
                    ],
                }]
            })
        return Resp(200, {"data": []})

    monkeypatch.setattr(runner, "_request_with_retry", fake_request)
    result = _rule_result()
    assert runner.enforce_live_id_integrity("rule", result, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    assert calls == []
    assert "liveRuleIdResolution" not in result.extracted


def test_v112_rule_summary_parser_rejects_wrong_environment_even_when_name_and_version_match():
    runner = run_agent.Runner(llm_enabled=False)
    name = runner.business["mappingRuleName"]
    body = {
        "data": [{
            "ruleName": name,
            "environments": [
                {"hipEnvironment": "PROD", "versions": [{"ruleId": 111, "version": 1.0}]},
                {"hipEnvironment": "TEST1", "versions": [{"ruleId": 222, "version": 1.0}]},
            ],
        }]
    }
    ids = runner._exact_rule_ids_from_read_response(
        body, rule_name=name, rule_version="1.0", environment="DEV", environment_scoped=False,
    )
    assert ids == []


def test_v112_rule_lookup_plain_summary_is_read_only_and_rule_post_contract_stays_immutable():
    runner = run_agent.Runner(llm_enabled=False)
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "flowDefinitionId" not in payload
    assert "mapId" not in (payload["actions"][0].get("params") or {})
    assert payload["documentTypeName"]
    assert payload["documentTypeVersion"]
    assert payload["actions"][0]["params"]["mapIdentifier"]
    assert payload["actions"][0]["params"]["mapVersion"]



def test_v112_parallel_queue_repairs_exact_latest_legrand_split_brain_snapshot(tmp_path):
    runtime = tmp_path / "runtime"
    runtime.mkdir()
    source = tmp_path / "source"
    source.mkdir()
    stale = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    valid = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB"
    (source / "input.json").write_text(json.dumps({
        "customer": "LEGRAND_NEDERLAND",
        "profile_name": stale,
        # This reproduces the 02:17 run: the nested builder value is already
        # corrected but the persisted top-level value is stale.
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": valid}}},
    }), encoding="utf-8")
    manager = ParallelManager(SimpleNamespace(root=runtime))
    queued = manager.queue_configuration(
        {"workspace": str(source), "id": "cfg-v112", "customer": "LEGRAND_NEDERLAND"},
        {"ok": True, "requests": {}},
    )
    staged = json.loads((Path(queued["workspace"]) / "input.json").read_text(encoding="utf-8"))
    assert staged["profile_name"] == valid
    assert staged["objects"]["biz_flow"]["flow_details"]["business_flow_name"] == valid
    assert queued["flow"] == valid
    assert queued["queueCanonicalization"]["effective"] == valid

def test_v112_build_identity_is_current():
    assert "v117" in run_agent.BUILD_ID
