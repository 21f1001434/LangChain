# V60 — workType null-or-omitted hardening

HIP owns the complete `workType` object. The agent does not ask for it and does not populate it.

- Preferred outbound representation: omit `workType`.
- Contract-compatible alternate representation: `"workType": null`.
- A non-null `workType` object is rejected.
- Full/merge payload overrides are sanitized so an old ID/type cannot leak back into LIVE requests.
- Flow Create, Flow Deploy, Source TP orchestration and Target TP orchestration all follow this rule.
