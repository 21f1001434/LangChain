from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSS = (ROOT / "webapp/frontend/src/styles.css").read_text(encoding="utf-8")
TOPBAR = (ROOT / "webapp/frontend/src/components/AppTopbar.tsx").read_text(encoding="utf-8")
REPORTS = (ROOT / "webapp/frontend/src/pages/ReportsPage.tsx").read_text(encoding="utf-8")


def test_v68_motion_is_css_first_and_reduced_motion_safe():
    assert "V68: lightweight motion system" in CSS
    assert "@media(prefers-reduced-motion:reduce)" in CSS
    assert "--motion-normal" in CSS
    assert "@keyframes ui-rise-in" in CSS


def test_v68_motion_covers_high_value_operator_surfaces():
    for token in (
        ".global-api-activity:after",
        ".live-job-card.live-running:before",
        ".api-test-result",
        ".validation-next.pass svg",
        ".report-content-enter",
        ".api-node.node-running .api-node-icon",
        ".nav-item.active:before",
    ):
        assert token in CSS


def test_v68_active_customer_and_report_swaps_retrigger_one_shot_motion():
    assert 'key={active.id}' in TOPBAR
    assert 'context-enter' in TOPBAR
    assert 'key={selected.name}' in REPORTS
    assert 'report-content-enter' in REPORTS


def test_v68_does_not_add_frontend_animation_intervals():
    # Existing application timers are for execution clocks, not V68 presentation motion.
    v68_comment = CSS.split("/* V68: lightweight motion system.", 1)[1]
    assert "setInterval" not in v68_comment
    assert "requestAnimationFrame" not in v68_comment
    assert ":has(" not in v68_comment
