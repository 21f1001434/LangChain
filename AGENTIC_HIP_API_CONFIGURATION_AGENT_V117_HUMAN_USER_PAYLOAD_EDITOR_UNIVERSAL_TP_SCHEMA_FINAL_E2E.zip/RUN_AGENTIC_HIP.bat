@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   Agentic HIP API Configuration Agent - Phase 6
 echo   React/FastAPI primary production runtime
 echo ============================================================
python runtime_preflight.py --production
if errorlevel 1 (
  echo.
  echo Runtime is not ready. Run SETUP_AGENTIC_HIP.bat first.
  pause
  exit /b 2
)
start "Agentic HIP Phase 6" cmd /k "python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8765
exit /b 0
