# V111 Latest LIVE Run Analysis and Fix Validation

## Supplied rerun

Batch: `batch_20260831_012421_53942f` (2 customers / 2 workers / LIVE).

### LEGRAND

The report blocked before any LIVE API call because the staged configuration still carried the 43-character Flow name `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB`. V110 had canonicalization in the input builder, but an already-persisted/queued configuration could bypass that builder path.

V111 fixes the upgrade path in two places:

1. `ParallelManager.queue_configuration()` canonicalizes the copied queue snapshot before hashing/manifest creation.
2. `_final_pre_live_checks()` defensively canonicalizes the isolated staged `input.json` before contract validation and before any LIVE request is materialized.

Effective name: `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 chars).

No post-HTTP rename is permitted.

### U-HAUL

The latest report shows strong progress: Validation, both Document Types, Source/Target TP create, Map, Rule, and both TP audit steps reached PASS/EXISTING/SUCCESS. The remaining blocker is `LIVE_RULE_ID_UNRESOLVED`, which prevents Flow Create/Deploy/History.

The canonical Rule POST still runs unchanged. When HIP returns EXISTING with no `ruleId`, V111 now resolves the exact current Rule identity through GET-only reads:

- configured Rule details/summary endpoints;
- consolidated `hip-config-service` Rule read endpoints;
- legacy Dell `hip/map-rule` Rule read surface;
- SecureLink portal Rule read surface;
- targeted name/environment queries first;
- bounded deterministic pagination for summary listings;
- exact name + version + DEV matching;
- ambiguity fails closed;
- no historical/package Rule ID is injected.

The Rule POST payload remains immutable and continues to omit `documentTypeId`, `flowDefinitionId`, and `mapId`.

### External Dell route condition

Account source/target, Partner and System still return the known upstream PCF route unavailable condition. This is an external Dell gateway/upstream deployment issue. V111 does not mutate those payloads or falsely mark those API calls as successful.

## Validation

- Top-level regression: 388/388 PASS
- FastAPI backend: 48/48 PASS
- Combined: 436/436 PASS
- Package validation: 58/58 PASS
- Adaptive package: 60/60 PASS
- Business readiness: 69/69 PASS
- Final release: 16/16 PASS
- Required self-check: 45/45 PASS
- Phase 1: 12/12 PASS
- Phase 2: 19/19 PASS
- Phase 3: 31/31 PASS
- Phase 4: 26/26 PASS
- Phase 5: 28/28 PASS
- Phase 6: 38/38 PASS
- FastAPI process smoke: `/api/health` 200, `/api/bootstrap` 200, phase 6, 18 API catalog entries.

No authenticated Dell/HIP mutation was executed during this packaging validation.
