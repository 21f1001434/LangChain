from __future__ import annotations

import json
import zipfile
from io import BytesIO
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.main import app
from webapp.backend.app.phase5_service import build_configuration_bundle, import_configuration_bundle, inspect_configuration_bundle
from webapp.backend.app.storage import JsonStore


def _payload(name='Phase5'):
    return {
        'name': name, 'customer': 'Demo', 'direction': 'Inbound', 'transaction_code': '850', 'transaction_name': 'PO',
        'flow_type': 'Translation', 'source_interface': 'SFTP', 'target_interface': 'SFTP', 'input_mode': 'files', 'user_instructions': ''
    }


def test_phase5_bootstrap_and_capabilities():
    data = TestClient(app).get('/api/bootstrap').json()
    assert data['phase'] >= 5
    assert len(data['api_catalog']) == 18
    assert data['deployment_group'] == 'hip-automation'
    assert data['capabilities']['configurationLibrary'] is True
    assert data['capabilities']['portableBundles'] is True
    assert data['capabilities']['tamperEvidentAudit'] is True


def test_phase5_audit_ledger_is_hash_chained_and_verifiable(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    a = store.append_audit('CREATE', 'configuration', 'c1', actor='Alice', metadata={'client_secret':'do-not-store'})
    b = store.append_audit('VALIDATE', 'configuration', 'c1', actor='Bob')
    assert b['previous_hash'] == a['hash']
    assert store.list_audit()[0]['actor'] == 'Bob'
    assert store.list_audit()[-1]['metadata']['client_secret'] == '[REDACTED]'
    assert store.verify_audit()['ok'] is True
    lines = store.audit_path.read_text(encoding='utf-8').splitlines()
    tampered = json.loads(lines[0]); tampered['actor'] = 'Mallory'; lines[0] = json.dumps(tampered)
    store.audit_path.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    assert store.verify_audit()['ok'] is False


def test_phase5_configuration_bundle_round_trip_and_forces_revalidation(tmp_path: Path):
    source_store = JsonStore(tmp_path / 'source')
    config = source_store.create_configuration(_payload('Portable'))
    ws = Path(config['workspace'])
    (ws / 'input.json').write_text(json.dumps({'direction':'Inbound','tx_code':'850','deployment_group':'hip-automation'}), encoding='utf-8')
    (ws / 'input_files' / 'SRC.xml').write_text('<PurchaseOrder/>', encoding='utf-8')
    bundle = build_configuration_bundle(source_store.update_configuration(config['id'], {'status':'VALIDATED','validation':{'ok':True}}))
    inspected = inspect_configuration_bundle(bundle)
    assert inspected['integrityOk'] is True
    assert any(row['path'] == 'input.json' for row in inspected['verifiedFiles'])
    target_store = JsonStore(tmp_path / 'target')
    imported = import_configuration_bundle(target_store, bundle)
    assert imported['status'] == 'READY_FOR_API_MAPPING'
    assert imported.get('validation') == {}
    assert imported['import_bundle_integrity'] is True
    assert (Path(imported['workspace']) / 'input_files' / 'SRC.xml').exists()


def test_phase5_bundle_rejects_tampered_member(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    config = store.create_configuration(_payload('Tamper'))
    ws = Path(config['workspace']); (ws/'input.json').write_text('{}', encoding='utf-8')
    raw = build_configuration_bundle(config)
    zin = zipfile.ZipFile(BytesIO(raw),'r')
    out = BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            data = zin.read(info.filename)
            if info.filename == 'input.json': data = b'{"tampered":true}'
            zout.writestr(info.filename,data)
    try:
        inspect_configuration_bundle(out.getvalue())
        assert False, 'tampered bundle should fail'
    except ValueError as exc:
        assert 'integrity check failed' in str(exc)


def test_phase5_template_lifecycle_clone_and_history(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    tpl = store.save_template({'name':'Flow','description':'','direction':'Outbound','transaction_code':'856','flow_type':'Translation','nodes':[],'edges':[],'variables':[],'tags':[]})
    assert tpl['lifecycle'] == 'DRAFT' and tpl['version'] == 1
    pub = store.set_template_lifecycle(tpl['id'],'PUBLISHED')
    assert pub['lifecycle'] == 'PUBLISHED'
    updated = store.save_template({**{k:pub.get(k) for k in ('name','description','direction','transaction_code','flow_type','nodes','edges','variables','tags')}, 'description':'v2'})
    # saving without template_id makes a new template; update the actual template instead
    updated = store.save_template({**{k:pub.get(k) for k in ('name','description','direction','transaction_code','flow_type','nodes','edges','variables','tags')}, 'description':'v2'}, template_id=tpl['id'])
    assert updated['version'] == 2 and updated['lifecycle'] == 'DRAFT'
    versions = store.list_template_versions(tpl['id'])
    assert [v['version'] for v in versions][:2] == [2,1]
    cloned = store.clone_template(tpl['id'])
    assert cloned['source_template_id'] == tpl['id'] and cloned['lifecycle'] == 'DRAFT'


def test_phase5_configuration_clone_does_not_copy_validation(tmp_path: Path):
    store = JsonStore(tmp_path / 'runtime')
    source = store.create_configuration(_payload('Original'))
    ws = Path(source['workspace']); (ws/'input.json').write_text('{"ok":true}', encoding='utf-8')
    source = store.update_configuration(source['id'], {'validation':{'ok':True}, 'status':'VALIDATED'})
    clone = store.clone_configuration(source['id'])
    assert clone['cloned_from_configuration'] == source['id']
    assert clone.get('validation') == {}
    assert clone['status'] == 'READY_FOR_API_MAPPING'
    assert (Path(clone['workspace'])/'input.json').exists()


def test_phase5_react_has_configuration_library_and_template_registry_controls():
    root = Path(__file__).resolve().parents[3]
    workspace = (root/'webapp/frontend/src/pages/WorkspacePage.tsx').read_text(encoding='utf-8')
    templates = (root/'webapp/frontend/src/pages/TemplatesPage.tsx').read_text(encoding='utf-8')
    sidebar = (root/'webapp/frontend/src/components/Sidebar.tsx').read_text(encoding='utf-8')
    operations = (root/'webapp/frontend/src/pages/OperationsPage.tsx').read_text(encoding='utf-8')
    assert 'Configuration Library' in workspace and 'Import bundle' in workspace and 'Export' in workspace
    assert 'tamper-evident' in workspace.lower() and 'Operator attribution' in workspace
    assert 'Publish' in templates and 'Archive' in templates and 'Versions' in templates
    assert "label:'Configuration Library'" in sidebar and ('Phase 5' in sidebar or 'Phase 6' in sidebar)
    assert 'Evidence bundle' in operations
