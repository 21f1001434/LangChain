from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from webapp.backend.app.main import app
from webapp.backend.app.legacy_adapter import api_catalog, api_test_request, transaction_metadata
from runtime_preflight import run_preflight

ROOT = Path(__file__).resolve().parents[3]


def test_phase6_bootstrap_is_studio_primary_and_has_18_apis():
    data = TestClient(app).get('/api/bootstrap').json()
    assert data['phase'] == 6
    assert len(data['api_catalog']) == 18
    assert all(row['reusable'] for row in data['api_catalog'])
    assert data['deployment_group'] == 'hip-automation'
    assert data['capabilities']['studioWebPrimary'] is True
    assert data['capabilities']['streamlitFallback'] is False
    assert data['capabilities']['apiTestingArea'] is True
    assert data['capabilities']['connectionCenter'] is True


def test_phase6_system_status_does_not_require_streamlit():
    response = TestClient(app).get('/api/system/status')
    assert response.status_code == 200
    data = response.json()
    assert data['phase'] == 6
    assert data['ui'] == 'HIP API Agent Studio Web UI'
    assert data['backend'] == 'FastAPI/Python'
    assert data['streamlitRequired'] is False
    assert data['apiBlocks'] == 18
    assert data['deploymentGroup'] == 'hip-automation'
    assert 'credentialEnvironment' in data
    assert all('clientSecret' in row for row in data['credentialEnvironment'].values())


def test_phase6_selected_api_preflight_uses_exact_python_engine(tmp_path: Path):
    (tmp_path / 'input.json').write_bytes((ROOT / 'input.json').read_bytes())
    result = api_test_request(tmp_path, 'validate_source', execute=False)
    assert result['stepKey'] == 'validate_source'
    assert result['executed'] is False
    assert result['request']['method'] == 'POST'
    assert result['contractValidation']['valid'] is True


def test_phase6_default_requirements_are_streamlit_free():
    req = (ROOT / 'requirements.txt').read_text(encoding='utf-8')
    legacy = (ROOT / 'requirements_legacy_streamlit.txt').read_text(encoding='utf-8')
    assert 'streamlit>=' not in req
    assert 'streamlit-sortables' not in req
    assert 'streamlit>=1.50,<2.0' in legacy
    assert 'streamlit-sortables==0.3.1' in legacy


def test_phase6_default_launchers_do_not_start_streamlit():
    normal = (ROOT / 'RUN_AGENTIC_HIP.bat').read_text(encoding='utf-8').lower()
    alias = (ROOT / 'RUN_HIP_STUDIO.bat').read_text(encoding='utf-8').lower()
    legacy = (ROOT / 'RUN_LEGACY_STREAMLIT_ARCHIVE.bat').read_text(encoding='utf-8').lower()
    assert 'streamlit run' not in normal
    assert '127.0.0.1:8765' in normal
    assert 'run_agentic_hip.bat' in alias
    assert 'streamlit run' in legacy


def test_phase6_runtime_preflight_marks_streamlit_optional():
    data = run_preflight(ui_only=True)
    assert data['phase'] == 6
    assert data['primaryUi'] == 'HIP API Agent Studio Web UI'
    assert data['streamlitRequired'] is False
    assert any(row['name'] == 'Streamlit not required' and row['ok'] for row in data['checks'])


def test_phase6_frontend_has_testing_and_system_workspaces():
    sidebar = (ROOT / 'webapp/frontend/src/components/Sidebar.tsx').read_text(encoding='utf-8')
    app_src = (ROOT / 'webapp/frontend/src/App.tsx').read_text(encoding='utf-8')
    testing = (ROOT / 'webapp/frontend/src/pages/ApiTestingPage.tsx').read_text(encoding='utf-8')
    system = (ROOT / 'webapp/frontend/src/pages/SystemPage.tsx').read_text(encoding='utf-8')
    assert "label:'API Testing Area'" in sidebar
    assert "label:'System & Connections'" in sidebar
    assert 'ApiTestingPage' in app_src and 'SystemPage' in app_src
    assert 'Run this API LIVE' in testing and 'Agent preflight' in testing
    assert 'Secure connections' in system and 'Configuration readiness' in system


def test_phase6_direction_and_transaction_policy_unchanged():
    meta = transaction_metadata()
    assert meta['editable_direction'] is True
    assert meta['default_direction'] == 'Outbound'
    assert '850' in meta['directions']['Inbound']['suggested_transactions']
    assert {'832','855','856'}.issubset(set(meta['directions']['Outbound']['suggested_transactions']))
    assert len(api_catalog()) == 18


def test_phase6_api_flow_uses_canonical_builder_flow_type_for_auto(tmp_path: Path):
    from webapp.backend.app.main import _decorate_configuration
    workspace = tmp_path / 'cfg'
    workspace.mkdir()
    (workspace / 'input.json').write_text(json.dumps({'requires_data_map': False}), encoding='utf-8')
    row = _decorate_configuration({'id':'c1','workspace':str(workspace),'flow_type':'Auto'})
    assert row['resolved_flow_type'] == 'Passthrough'
    (workspace / 'input.json').write_text(json.dumps({'requires_data_map': True}), encoding='utf-8')
    row = _decorate_configuration({'id':'c1','workspace':str(workspace),'flow_type':'Auto'})
    assert row['resolved_flow_type'] == 'Translation'


def test_phase6_react_flow_never_assumes_translation_for_unresolved_auto_and_clears_stale_template():
    flow = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    app_src = (ROOT / 'webapp/frontend/src/App.tsx').read_text(encoding='utf-8')
    assert "active?.flow_type==='Auto'?'Translation'" not in flow
    assert 'Auto is intentionally left blank' in flow
    assert 'resolved_flow_type' in flow
    assert 'setSelectedTemplate(null);setPage(\'flow\')' in app_src
    assert 'setActive(c);setSelectedTemplate(null)' in app_src
