from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List


def _node(node_id: str, api_key: str, label: str, x: int, y: int) -> Dict[str, Any]:
    return {"id": node_id, "api_key": api_key, "label": label, "x": x, "y": y, "enabled": True,
            "stop_on_blocked": True, "wait_after_seconds": 0, "override_mode": "merge", "request_override": {}}


def _chain(nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [
        {"id": f"e{i}", "source": nodes[i]["id"], "target": nodes[i + 1]["id"], "label": "", "mappings": []}
        for i in range(len(nodes) - 1)
    ]


def _norm_customer(value: Any) -> str:
    return "".join(ch for ch in str(value or "").upper() if ch.isalnum())


def is_uhal_customer(value: Any) -> bool:
    return _norm_customer(value) == "UHAUL"


def _canonical_translation_flag(canonical: Dict[str, Any]) -> bool:
    # The only approved U-HAUL reference is the validated Outbound 856
    # Translation flow. Never synthesize or persist a U-HAUL Passthrough
    # template from stale configuration metadata. Other customers retain
    # normal Translation/Passthrough behavior.
    if is_uhal_customer(canonical.get("customer")):
        return True
    return bool(canonical.get("requires_data_map")) or str(canonical.get("flow_type") or "").strip().lower() == "translation"


def is_uhal_template(template: Dict[str, Any]) -> bool:
    defaults = template.get("default_values") if isinstance(template.get("default_values"), dict) else {}
    return is_uhal_customer(defaults.get("customer")) or "UHAUL" in _norm_customer(template.get("name"))


def is_uhal_passthrough_template(template: Dict[str, Any]) -> bool:
    return is_uhal_template(template) and str(template.get("flow_type") or "").strip().lower() == "passthrough"


def approved_uhal_translation_template(canonical: Dict[str, Any]) -> Dict[str, Any]:
    """Return the one packaged, validated U-HAUL template exposed to operators."""
    payload = generated_template_from_configuration("reference:uhal", canonical)
    payload.update({
        "id": "builtin-uhal-outbound-856-translation-approved",
        "name": "U-HAUL Outbound 856 Translation · Approved",
        "description": "Validated U-HAUL Outbound 856 Translation reference. Use this as the canonical tested example; there is no U-HAUL Passthrough template.",
        "direction": "Outbound",
        "transaction_code": "856",
        "flow_type": "Translation",
        "source_configuration_id": "reference:uhal",
        "tags": ["U-HAUL", "Approved", "Outbound", "856", "Translation"],
        "version": 1,
        "lifecycle": "PUBLISHED",
        "builtin": True,
    })
    payload.setdefault("default_values", {})["flow_type"] = "translation"
    return payload


def builtin_templates() -> List[Dict[str, Any]]:
    templates: List[Dict[str, Any]] = []
    for direction, txs in (("Inbound", ["850"]), ("Outbound", ["832", "855", "856"])):
        for tx in txs:
            for flow_type in ("Translation", "Passthrough"):
                keys = ["validate_source", "validate_target", "validate_flow", "account_source", "account_target",
                        "partner_target", "system_source", "doctype_source"]
                if flow_type == "Translation":
                    keys += ["doctype_target", "map", "rule"]
                keys += ["source_tp", "target_tp", "source_tp_audit", "target_tp_audit", "flow_create", "flow_deploy", "flow_history"]
                nodes = [_node(f"{key}-{i}", key, "", 120 + (i % 4) * 250, 80 + (i // 4) * 150) for i, key in enumerate(keys)]
                templates.append({
                    "id": f"builtin-{direction.lower()}-{tx}-{flow_type.lower()}",
                    "name": f"{direction} {tx} {flow_type}",
                    "description": f"Reusable {direction.lower()} {tx} {flow_type.lower()} HIP API flow.",
                    "direction": direction,
                    "transaction_code": tx,
                    "flow_type": flow_type,
                    "nodes": nodes,
                    "edges": _chain(nodes),
                    "variables": ["customer", "transactionCode", "sourceDocumentType", "targetDocumentType", "partner", "sourceAccount", "targetAccount"],
                    "default_values": {},
                    "source_configuration_id": "",
                    "tags": [direction, tx, flow_type],
                    "version": 1,
                    "lifecycle": "PUBLISHED",
                    "builtin": True,
                })
    return templates


_SENSITIVE_TEMPLATE_KEYS = (
    "secret", "password", "access_token", "refresh_token", "private_key", "credential", "authorization"
)


def _safe_value(value: Any) -> Any:
    """Return a template-safe copy of received configuration values.

    Templates should learn/reuse business configuration, never runtime secrets.
    """
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            low = str(key).lower()
            if any(token in low for token in _SENSITIVE_TEMPLATE_KEYS):
                continue
            out[str(key)] = _safe_value(item)
        return out
    if isinstance(value, list):
        return [_safe_value(item) for item in value]
    return deepcopy(value)


def _first_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, list):
        return next((item for item in value if isinstance(item, dict)), {})
    return {}


def template_default_values(canonical: Dict[str, Any]) -> Dict[str, Any]:
    """Project the final input.json into reusable, non-secret template defaults."""
    objects = canonical.get("objects") if isinstance(canonical.get("objects"), dict) else {}
    src_doc = _first_dict(objects.get("source_document_type"))
    tgt_doc = _first_dict(objects.get("target_document_type"))
    data_map = _first_dict(objects.get("data_map"))
    rule = _first_dict(objects.get("rule"))
    src_tp = _first_dict(objects.get("source_transport_profile"))
    tgt_tp = _first_dict(objects.get("target_transport_profile"))
    biz = _first_dict(objects.get("biz_flow"))
    source_cfg = _first_dict(biz.get("configure_source"))
    target_cfg = _first_dict(biz.get("configure_targets"))
    flow_details = _first_dict(biz.get("flow_details"))
    values = {
        "customer": canonical.get("customer", ""),
        "direction": canonical.get("direction", ""),
        "transaction_code": canonical.get("tx_code", ""),
        "transaction_name": canonical.get("tx_name", ""),
        "transaction_standard": canonical.get("tx_standard", ""),
        "flow_type": "translation" if _canonical_translation_flag(canonical) else "passthrough",
        "business_flow_name": canonical.get("profile_name") or flow_details.get("business_flow_name", ""),
        "source_document_type": src_doc.get("name", ""),
        "target_document_type": tgt_doc.get("name", ""),
        "map_identifier": data_map.get("map_identifier", ""),
        "map_name": data_map.get("map_name", ""),
        "map_class": data_map.get("map_class", ""),
        "map_data_file": data_map.get("map_data_file", ""),
        "rule_name": rule.get("name", ""),
        "source_transport_profile": src_tp.get("profile_name", ""),
        "target_transport_profile": tgt_tp.get("profile_name", ""),
        "source_interface": src_tp.get("interface_type", ""),
        "target_interface": tgt_tp.get("interface_type", ""),
        "source_account": src_tp.get("existing_account_name", ""),
        "target_account": tgt_tp.get("existing_account_name", ""),
        "source_folder": src_tp.get("subscription_folder", ""),
        "target_folder": tgt_tp.get("subscription_folder", ""),
        "source_application": source_cfg.get("source_application") or src_tp.get("partner_name", ""),
        "target_application": target_cfg.get("target_application") or tgt_tp.get("partner_name", ""),
        "partner_identifier_value": canonical.get("partner_identifier_value", ""),
        "api_contract_repairs": canonical.get("_contract_repairs", {}) if isinstance(canonical.get("_contract_repairs"), dict) else {},
    }
    return _safe_value(values)


def generated_template_from_configuration(configuration_id: str, canonical: Dict[str, Any]) -> Dict[str, Any]:
    """Build/update a customer template from the final received/extracted values."""
    direction = str(canonical.get("direction") or "Outbound").title()
    tx = str(canonical.get("tx_code") or "").strip().upper() or "CUSTOM"
    translation = _canonical_translation_flag(canonical)
    flow_type = "Translation" if translation else "Passthrough"
    keys = ["validate_source", "validate_target", "validate_flow", "account_source", "account_target",
            "partner_target", "system_source", "doctype_source"]
    if translation:
        keys += ["doctype_target", "map", "rule"]
    keys += ["source_tp", "target_tp", "source_tp_audit", "target_tp_audit", "flow_create", "flow_deploy", "flow_history"]
    nodes = [_node(f"{key}-{i}", key, "", 120 + (i % 4) * 250, 80 + (i // 4) * 150) for i, key in enumerate(keys)]
    repairs = canonical.get("_contract_repairs") if isinstance(canonical.get("_contract_repairs"), dict) else {}
    for node in nodes:
        repair = repairs.get(str(node.get("api_key") or "")) if isinstance(repairs, dict) else None
        if not isinstance(repair, dict) or not isinstance(repair.get("value"), dict):
            continue
        node["request_override"] = _safe_value(repair.get("value") or {})
        node["override_mode"] = str(repair.get("mode") or "merge") if str(repair.get("mode") or "merge") in {"merge", "replace"} else "merge"
    customer = str(canonical.get("customer") or "Customer").strip() or "Customer"
    defaults = template_default_values(canonical)
    variables = [key for key, value in defaults.items() if value not in (None, "", [], {})]
    return {
        "name": f"{customer} {direction} {tx} {flow_type}",
        "description": "Auto-updated from the final canonical input.json values received/extracted by Input Builder.",
        "direction": direction if direction in {"Inbound", "Outbound"} else "Outbound",
        "transaction_code": tx,
        "flow_type": flow_type,
        "nodes": nodes,
        "edges": _chain(nodes),
        "variables": variables,
        "default_values": defaults,
        "source_configuration_id": str(configuration_id or ""),
        "tags": ["Generated", customer, direction, tx, flow_type],
    }
