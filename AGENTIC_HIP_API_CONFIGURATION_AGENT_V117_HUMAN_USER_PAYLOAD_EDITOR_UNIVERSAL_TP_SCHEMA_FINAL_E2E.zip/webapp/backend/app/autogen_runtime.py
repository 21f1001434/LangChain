from __future__ import annotations

"""Microsoft AutoGen AgentChat 0.7.5 adapter for governed HIP LIVE execution.

Architecture
------------
* One selected customer/instance == one fresh ``AssistantAgent``.
* The AgentChat agent uses Dell AIA ``gpt-oss-120b`` through Dell's
  OpenAI-compatible ``/chat/completions`` endpoint.
* The only tool exposed to the agent is the already-governed HIP execution
  callable supplied by ``ParallelManager``.
* The tool itself performs immutable-snapshot checks, final validation,
  production preflight, dependency-aware HIP API fan-out, stop handling and
  evidence/report generation.
* A fresh AssistantAgent/model client is created per job because AgentChat
  agents are stateful and must not be shared concurrently.

This module intentionally targets the modern Microsoft AutoGen packages:
``autogen-agentchat==0.7.5``, ``autogen-core==0.7.5`` and
``autogen-ext[openai]==0.7.5``.  It does NOT use the legacy ``pyautogen`` /
``ConversableAgent`` API.
"""

import asyncio
import contextlib
import importlib.metadata
import json
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Tuple, Type

import requests

from .skill_governance import SkillGovernanceError, select_vet_and_pack


AUTOGEN_REQUIRED_VERSION = "0.7.5"


class AutoGenUnavailable(RuntimeError):
    """Raised when the required AgentChat runtime is absent or incompatible."""


class AutoGenExecutionError(RuntimeError):
    """Raised when AgentChat does not invoke the governed HIP execution tool."""


class AutoGenCancelled(RuntimeError):
    """Raised when Stop Batch / Stop Instance cancels AgentChat before tool completion."""


@dataclass(frozen=True)
class AutoGenAgentMetadata:
    framework: str = "Microsoft AutoGen AgentChat"
    api: str = "AgentChat"
    version: str = AUTOGEN_REQUIRED_VERSION


_TOKEN_LOCK = threading.Lock()
_TOKEN_CACHE: Tuple[str, float] | None = None


def _truthy(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _load_agentchat() -> tuple[Type[Any], Type[Any], Type[Any]]:
    """Load the exact AgentChat 0.7.5 API used by this application."""
    try:
        installed = importlib.metadata.version("autogen-agentchat")
        if installed != AUTOGEN_REQUIRED_VERSION and not _truthy(
            os.getenv("HIP_AUTOGEN_ALLOW_VERSION_DRIFT"), False
        ):
            raise AutoGenUnavailable(
                f"HIP API Agent Studio requires autogen-agentchat=={AUTOGEN_REQUIRED_VERSION}; "
                f"installed version is {installed}. Run the project setup again."
            )
        from autogen_agentchat.agents import AssistantAgent  # type: ignore
        from autogen_core import CancellationToken  # type: ignore
        from autogen_ext.models.openai import OpenAIChatCompletionClient  # type: ignore
        return AssistantAgent, OpenAIChatCompletionClient, CancellationToken
    except AutoGenUnavailable:
        raise
    except Exception as exc:  # pragma: no cover - depends on deployment packages
        if _truthy(os.getenv("HIP_AUTOGEN_REQUIRED", "1"), True):
            raise AutoGenUnavailable(
                "Microsoft AutoGen AgentChat 0.7.5 is required for LIVE parallel execution. "
                "Install requirements.txt and restart HIP API Agent Studio. Required packages: "
                "autogen-agentchat==0.7.5, autogen-core==0.7.5, autogen-ext[openai]==0.7.5."
            ) from exc
        raise


def _verify_setting() -> bool | str:
    if not _truthy(os.getenv("HIP_VERIFY_SSL", "true"), True):
        return False
    ca_bundle = str(os.getenv("HIP_CA_BUNDLE") or "").strip()
    return ca_bundle or True


def _token_from_explicit_oauth_url(token_url: str, client_id: str, client_secret: str, scope: str) -> tuple[str, float]:
    timeout = float(os.getenv("AIA_TIMEOUT_SECONDS", "90") or "90")
    data: Dict[str, str] = {"grant_type": "client_credentials"}
    if scope:
        data["scope"] = scope
    headers = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}
    response = requests.post(
        token_url,
        headers=headers,
        data=data,
        auth=(client_id, client_secret),
        timeout=timeout,
        verify=_verify_setting(),
    )
    if response.status_code in {400, 401, 403}:
        body = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }
        if scope:
            body["scope"] = scope
        response = requests.post(
            token_url,
            headers=headers,
            data=body,
            timeout=timeout,
            verify=_verify_setting(),
        )
    response.raise_for_status()
    payload = response.json()
    token = str(payload.get("access_token") or payload.get("token") or payload.get("id_token") or "").strip()
    if not token:
        raise AutoGenUnavailable("Dell AIA OAuth response did not contain access_token/token/id_token.")
    expires_in = float(payload.get("expires_in", 1800) or 1800)
    return token, time.time() + max(120.0, expires_in)


def _token_from_internal_aia_auth(client_id: str, client_secret: str) -> tuple[str, float]:
    try:
        from aia_auth import auth  # type: ignore
    except Exception as exc:  # pragma: no cover - internal Dell package
        raise AutoGenUnavailable(
            "Dell AIA client credentials are configured but the internal aia_auth package is unavailable. "
            "Configure DELL_AIA_TOKEN_URL/AIA_TOKEN_URL, provide a short-lived bearer token, or install aia_auth."
        ) from exc
    token_response = auth.client_credentials(client_id, client_secret)
    token = (
        getattr(token_response, "token", "")
        or getattr(token_response, "access_token", "")
        or (token_response.get("token") if isinstance(token_response, dict) else "")
        or (token_response.get("access_token") if isinstance(token_response, dict) else "")
    )
    token = str(token or "").strip()
    if not token:
        raise AutoGenUnavailable("Dell aia_auth.client_credentials returned no token/access_token.")
    return token, time.time() + 1800.0


def _get_dell_aia_token() -> str:
    """Get one cached Dell AIA bearer token shared safely by concurrent agents."""
    static_token = (
        os.getenv("AIA_STATIC_BEARER_TOKEN")
        or os.getenv("DELL_AIA_TOKEN")
        or os.getenv("AIA_BEARER_TOKEN")
        or os.getenv("DELL_AIA_BEARER_TOKEN")
        or os.getenv("BEARER_TOKEN")
        or ""
    )
    if static_token:
        return str(static_token).strip().removeprefix("Bearer ").strip()

    global _TOKEN_CACHE
    with _TOKEN_LOCK:
        if _TOKEN_CACHE and _TOKEN_CACHE[1] > time.time() + 60:
            return _TOKEN_CACHE[0]

        client_id = str(os.getenv("AIA_CLIENT_ID") or os.getenv("DELL_AIA_CLIENT_ID") or os.getenv("CLIENT_ID") or "").strip()
        client_secret = str(os.getenv("AIA_CLIENT_SECRET") or os.getenv("DELL_AIA_CLIENT_SECRET") or os.getenv("CLIENT_SECRET") or "").strip()
        token_url = str(os.getenv("AIA_TOKEN_URL") or os.getenv("DELL_AIA_TOKEN_URL") or os.getenv("DELL_TOKEN_URL") or os.getenv("OAUTH_TOKEN_URL") or "").strip()
        scope = str(os.getenv("AIA_SCOPE") or os.getenv("DELL_AIA_SCOPE") or "").strip()
        if not client_id or not client_secret:
            raise AutoGenUnavailable(
                "Dell AIA credentials are missing. Configure DELL_AIA_CLIENT_ID and DELL_AIA_CLIENT_SECRET "
                "(or AIA_CLIENT_ID/AIA_CLIENT_SECRET)."
            )
        if token_url:
            _TOKEN_CACHE = _token_from_explicit_oauth_url(token_url, client_id, client_secret, scope)
        else:
            _TOKEN_CACHE = _token_from_internal_aia_auth(client_id, client_secret)
        return _TOKEN_CACHE[0]


def _build_model_client(OpenAIChatCompletionClient: Type[Any]) -> Any:
    base_url = str(
        os.getenv("AIA_BASE_URL")
        or os.getenv("DELL_AIA_BASE_URL")
        or os.getenv("BASE_URL")
        or "https://aia.gateway.dell.com/genai/dev/v1"
    ).rstrip("/")
    model = str(
        os.getenv("AIA_MODEL")
        or os.getenv("DELL_AIA_MODEL")
        or os.getenv("AIA_TEXT_MODEL")
        or os.getenv("MODEL_NAME")
        or "gpt-oss-120b"
    ).strip()
    chat_path = str(os.getenv("AIA_CHAT_PATH") or os.getenv("CHAT_PATH") or "/chat/completions").strip()
    if "/" + chat_path.lstrip("/") != "/chat/completions":
        raise AutoGenUnavailable(
            "AutoGen AgentChat 0.7.5 Dell AIA integration expects the OpenAI-compatible /chat/completions path. "
            f"Current AIA_CHAT_PATH={chat_path!r}."
        )
    try:
        extra_headers = json.loads(os.getenv("AIA_EXTRA_HEADERS_JSON", "{}"))
        if not isinstance(extra_headers, dict):
            extra_headers = {}
    except Exception:
        extra_headers = {}

    # AutoGen's OpenAI-compatible client will send Authorization: Bearer <api_key>.
    # Dell's OAuth access token is therefore passed as the client api_key.
    return OpenAIChatCompletionClient(
        model=model,
        base_url=base_url,
        api_key=_get_dell_aia_token(),
        temperature=float(os.getenv("AIA_TEMPERATURE") or os.getenv("DELL_AIA_TEMPERATURE") or "0.2"),
        timeout=float(os.getenv("AIA_TIMEOUT_SECONDS", "90") or "90"),
        max_retries=max(0, int(os.getenv("HIP_AUTOGEN_MODEL_MAX_RETRIES", "1") or "1")),
        parallel_tool_calls=False,
        include_name_in_message=False,
        default_headers={str(k): str(v) for k, v in extra_headers.items()},
        model_info={
            "vision": False,
            "function_calling": True,
            "json_output": True,
            "family": "unknown",
            "structured_output": False,
        },
    )


async def _run_agentchat_async(
    *,
    agent_name: str,
    task: Dict[str, Any],
    executor: Callable[[], Dict[str, Any]],
    cancel_check: Callable[[], bool] | None = None,
) -> Dict[str, Any]:
    AssistantAgent, OpenAIChatCompletionClient, CancellationToken = _load_agentchat()

    # V109 skill gate: the task description triggers a declarative skill. The
    # manifest is vetted *before* the model is allowed to run, and the model
    # receives only the skill-specific bounded context. No skill can dynamically
    # import code or alter the governed executor.
    try:
        skill_decision = select_vet_and_pack(task)
    except SkillGovernanceError as exc:
        raise AutoGenExecutionError(f"HIP skill preflight failed: {exc}") from exc
    selected_skill = skill_decision["skill"]
    if selected_skill.name != "hip_live_execution":
        raise AutoGenExecutionError(
            f"LIVE AgentChat selected unexpected skill {selected_skill.name!r}; refusing to guess or execute."
        )
    if selected_skill.allowed_tool != "execute_validated_hip_configuration":
        raise AutoGenExecutionError(
            f"Vetted LIVE skill does not authorize the governed execution tool: {selected_skill.allowed_tool!r}."
        )

    model_client = _build_model_client(OpenAIChatCompletionClient)
    cancellation_token = CancellationToken()
    result_box: Dict[str, Dict[str, Any]] = {}
    error_box: Dict[str, BaseException] = {}
    invocation_lock = asyncio.Lock()

    async def execute_validated_hip_configuration() -> str:
        """Execute the selected immutable HIP configuration snapshot LIVE exactly once."""
        async with invocation_lock:
            if "result" in result_box:
                return json.dumps({"status": "ALREADY_EXECUTED", "jobId": result_box["result"].get("jobId")})
            try:
                result = await asyncio.to_thread(executor)
            except BaseException as exc:
                error_box["error"] = exc
                raise
            if not isinstance(result, dict):
                raise AutoGenExecutionError("Governed HIP execution tool returned a non-object result.")
            result_box["result"] = result
            return json.dumps(
                {
                    "jobId": result.get("jobId"),
                    "status": result.get("status"),
                    "agentVerdict": result.get("agentVerdict"),
                    "executionMode": result.get("executionMode", "LIVE"),
                    "instruction": "Execution is complete. Do not call the tool again.",
                },
                default=str,
            )

    agent = AssistantAgent(
        name=agent_name,
        model_client=model_client,
        tools=[execute_validated_hip_configuration],
        # Point 1: the skill description is the trigger and is also the agent's
        # externally visible specialization description.
        description=selected_skill.description,
        system_message=(
            "You are a HIP API LIVE execution agent running inside Microsoft AutoGen AgentChat 0.7.5. "
            f"A deterministic pre-run router selected and vetted skill {selected_skill.name!r}. "
            "For every task you MUST call execute_validated_hip_configuration exactly once before producing any final answer. "
            "Never invent, add, remove or rename payload fields. Never modify the developer-approved API request structures. "
            "Do not ask for human input. The tool is the sole authority for validation, preflight, API dependency scheduling, "
            "LIVE mutation, cancellation and reporting. Do not load or execute any other skill, script or tool. "
            "After the tool returns, stop."
        ),
        reflect_on_tool_use=False,
        max_tool_iterations=1,
        model_client_stream=False,
    )
    monitor_task: asyncio.Task[Any] | None = None
    if cancel_check is not None:
        async def monitor_cancel() -> None:
            while True:
                if cancel_check():
                    cancellation_token.cancel()
                    return
                await asyncio.sleep(0.10)
        monitor_task = asyncio.create_task(monitor_cancel())
    try:
        try:
            bounded_task = skill_decision["context"]["task"]
            await agent.run(
                task=(
                    "Execute this already-selected HIP LIVE task now by calling the registered governed tool exactly once. "
                    "Do not merely describe what you would do. This is the complete skill-approved task context; omitted "
                    "fields are intentionally unavailable to the model. Task JSON:\n" + json.dumps(bounded_task, default=str)
                ),
                cancellation_token=cancellation_token,
            )
        except asyncio.CancelledError as exc:
            raise AutoGenCancelled(f"AutoGen AgentChat agent {agent_name} was stopped by the user.") from exc
    finally:
        if monitor_task is not None:
            monitor_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await monitor_task
        close = getattr(model_client, "close", None)
        if close is not None:
            maybe = close()
            if asyncio.iscoroutine(maybe):
                await maybe

    if "error" in error_box:
        raise error_box["error"]
    if "result" not in result_box:
        raise AutoGenExecutionError(
            f"AutoGen AgentChat agent {agent_name} completed without invoking execute_validated_hip_configuration. "
            "Check Dell AIA function/tool-calling support and the model deployment configuration."
        )
    result = result_box["result"]
    result["agentFramework"] = "AUTOGEN"
    result["autoGenApi"] = "AgentChat"
    result["autoGenVersion"] = AUTOGEN_REQUIRED_VERSION
    result["autoGenAgentType"] = "AssistantAgent"
    result["autoGenAgentName"] = agent_name
    result["autoGenModel"] = str(os.getenv("AIA_MODEL") or os.getenv("DELL_AIA_MODEL") or os.getenv("MODEL_NAME") or "gpt-oss-120b")
    result["skillGovernance"] = {
        "selectedSkill": selected_skill.name,
        "description": selected_skill.description,
        "selection": skill_decision["selection"],
        "vetted": True,
        "deterministicEntrypoint": selected_skill.deterministic_entrypoint,
        "expertiseDigest": skill_decision["vetting"]["expertiseDigest"],
        "expertiseSources": skill_decision["vetting"]["expertiseSources"],
        "contextBudget": skill_decision["context"]["budget"],
    }
    return result


def _run_coroutine_sync(coro_factory: Callable[[], Any]) -> Any:
    """Run a coroutine from either a normal worker thread or an existing event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro_factory())

    result_box: Dict[str, Any] = {}
    error_box: Dict[str, BaseException] = {}

    def target() -> None:
        try:
            result_box["result"] = asyncio.run(coro_factory())
        except BaseException as exc:  # pragma: no cover - defensive path
            error_box["error"] = exc

    thread = threading.Thread(target=target, name="autogen-agentchat-sync-bridge", daemon=False)
    thread.start()
    thread.join()
    if "error" in error_box:
        raise error_box["error"]
    return result_box.get("result")


def run_with_autogen_agent(
    *,
    agent_name: str,
    task: Dict[str, Any],
    executor: Callable[[], Dict[str, Any]],
    cancel_check: Callable[[], bool] | None = None,
) -> Dict[str, Any]:
    """Run one customer/instance using a fresh AutoGen AgentChat 0.7.5 AssistantAgent.

    This public adapter is LIVE-only by architecture, so legacy/internal callers
    that omit the explicit intent fields receive the same canonical LIVE intent.
    That keeps description-triggered skill routing deterministic without asking
    the LLM to infer execution mode from sparse metadata.
    """
    normalized_task = dict(task or {})
    normalized_task.setdefault("executionMode", "LIVE")
    normalized_task.setdefault(
        "intentDescription",
        "Execute the selected immutable HIP configuration LIVE end-to-end through the governed developer-approved API pipeline.",
    )
    return _run_coroutine_sync(
        lambda: _run_agentchat_async(
            agent_name=agent_name, task=normalized_task, executor=executor, cancel_check=cancel_check
        )
    )
