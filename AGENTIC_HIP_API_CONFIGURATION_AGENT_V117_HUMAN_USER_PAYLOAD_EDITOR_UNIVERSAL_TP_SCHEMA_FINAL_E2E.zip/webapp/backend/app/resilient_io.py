from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any


def atomic_write_text(path: Path, text: str, *, retries: int = 8, encoding: str = "utf-8") -> None:
    """Write text without sharing one fixed .tmp file across threads/processes.

    Windows endpoint security/indexers can briefly hold a destination or temp file open.
    A unique sibling temp file plus retrying os.replace avoids the summary.json.tmp race
    seen during high-concurrency parallel runs.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    last: Exception | None = None
    for attempt in range(max(1, int(retries))):
        tmp = path.with_name(f".{path.name}.{os.getpid()}.{thread_id()}.{uuid.uuid4().hex[:8]}.tmp")
        try:
            with tmp.open("w", encoding=encoding, newline="") as fh:
                fh.write(text)
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
            os.replace(tmp, path)
            return
        except (PermissionError, OSError) as exc:
            last = exc
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
            if attempt + 1 < retries:
                time.sleep(min(0.6, 0.025 * (2 ** attempt)))
    if last is not None:
        raise last
    raise OSError(f"Could not write {path}")


def atomic_write_json(path: Path, value: Any, *, retries: int = 8) -> None:
    atomic_write_text(path, json.dumps(value, indent=2, ensure_ascii=False, default=str), retries=retries)


def thread_id() -> int:
    try:
        import threading
        return threading.get_ident()
    except Exception:
        return 0
