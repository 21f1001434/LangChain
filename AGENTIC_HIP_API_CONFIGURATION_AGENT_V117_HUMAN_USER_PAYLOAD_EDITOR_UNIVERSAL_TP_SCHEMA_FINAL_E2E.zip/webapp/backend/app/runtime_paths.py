from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Mapping

APP_DIR_NAME = "HIP API Agent Studio"
RUNTIME_ENV = "HIP_STUDIO_RUNTIME_ROOT"
RUNTIME_DIR_NAME = "runtime-v82"


def _writable(path: Path) -> bool:
    """Probe the exact nested operations used by configuration workspaces.

    A top-level file write is not enough on enterprise Windows machines: policy
    can permit the runtime root but deny creation/deletion inside a child folder.
    This probe mirrors the real layout (configurations/<id>/input_files), writes
    and atomically replaces a file, then removes the temporary workspace.
    """
    probe_root = path / "configurations" / f".__probe_{uuid.uuid4().hex}"
    try:
        (probe_root / "input_files").mkdir(parents=True, exist_ok=False)
        (probe_root / "uploads").mkdir()
        source = probe_root / "input_files" / "probe.json.tmp"
        target = probe_root / "input_files" / "probe.json"
        source.write_text('{"ok":true}', encoding="utf-8")
        source.replace(target)
        target.unlink()
        shutil.rmtree(probe_root)
        return True
    except Exception:
        try:
            if probe_root.exists():
                shutil.rmtree(probe_root, ignore_errors=True)
        except Exception:
            pass
        return False


def resolve_runtime_root(
    legacy_root: Path,
    *,
    environ: Mapping[str, str] | None = None,
    platform_name: str | None = None,
    temp_root: Path | None = None,
) -> Path:
    """Return a mutable runtime folder that is outside the packaged source tree.

    Priority:
      1. HIP_STUDIO_RUNTIME_ROOT explicit override.
      2. Windows: %LOCALAPPDATA%/HIP API Agent Studio/runtime-v82.
      3. Other platforms: ~/.hip_api_agent_studio/runtime-v82.
      4. OS temp directory fallback.

    The source tree may live under OneDrive/Desktop and is treated as read-only.
    """
    env = dict(os.environ if environ is None else environ)
    explicit = str(env.get(RUNTIME_ENV) or "").strip()
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())

    platform_value = (platform_name or os.name).lower()
    if platform_value in {"nt", "windows", "win32"}:
        local = str(env.get("LOCALAPPDATA") or "").strip()
        if local:
            candidates.append(Path(local) / APP_DIR_NAME / RUNTIME_DIR_NAME)
        profile = str(env.get("USERPROFILE") or "").strip()
        if profile:
            candidates.append(Path(profile) / "AppData" / "Local" / APP_DIR_NAME / RUNTIME_DIR_NAME)
    else:
        home = str(env.get("HOME") or "").strip()
        if home:
            candidates.append(Path(home) / ".hip_api_agent_studio" / RUNTIME_DIR_NAME)

    temp_base = Path(temp_root) if temp_root is not None else Path(tempfile.gettempdir())
    candidates.append(temp_base / "hip_api_agent_studio" / RUNTIME_DIR_NAME)

    for candidate in candidates:
        if _writable(candidate):
            return candidate.resolve()

    # This is exceptionally unlikely, but returning the old root would recreate
    # the exact OneDrive failure we are trying to avoid.
    raise PermissionError(
        "HIP API Agent Studio could not find a writable runtime directory. "
        f"Set {RUNTIME_ENV} to a writable local folder. Packaged source: {legacy_root}"
    )


def migrate_legacy_runtime(source: Path, destination: Path) -> dict[str, int | str]:
    """Best-effort one-time migration from the old source-tree runtime.

    It never overwrites newer destination files and never prevents startup.
    Individual protected files/folders are skipped, which is important for
    OneDrive Controlled Folder Access scenarios.
    """
    source = Path(source)
    destination = Path(destination)
    stats: dict[str, int | str] = {"copied": 0, "skipped": 0, "source": str(source), "destination": str(destination)}
    if not source.exists() or source.resolve() == destination.resolve():
        return stats
    try:
        for item in source.rglob("*"):
            try:
                rel = item.relative_to(source)
                target = destination / rel
                if item.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                if not item.is_file():
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    stats["skipped"] = int(stats["skipped"]) + 1
                    continue
                shutil.copy2(item, target)
                stats["copied"] = int(stats["copied"]) + 1
            except Exception:
                stats["skipped"] = int(stats["skipped"]) + 1
    except Exception:
        # Source enumeration itself may be blocked by enterprise policy.
        stats["skipped"] = int(stats["skipped"]) + 1
    return stats
