from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import shutil
import subprocess
import tempfile
import threading
import time
import queue as thread_queue
import re
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List

from production_guard import redact_sensitive
from hip_naming import normalize_input_flow_name
from runtime_payload_values import load_runtime_payload_values, save_runtime_payload_values
from parallel_configurations import _SNAPSHOT_DIRS, _SNAPSHOT_FILES, _load_step_timings

from .legacy_adapter import LEGACY_ROOT
from .phase2_service import validate_configuration
from .report_renderer import render_parallel_batch_html
from .resilient_io import atomic_write_json
from .autogen_runtime import (
    AUTOGEN_REQUIRED_VERSION,
    AutoGenCancelled,
    AutoGenExecutionError,
    AutoGenUnavailable,
    run_with_autogen_agent,
)


AUTOGEN_MAX_STABLE_AGENTS = min(4, max(1, int(os.getenv("HIP_AUTOGEN_MAX_STABLE_AGENTS", "4") or "4")))
AUTOGEN_KNOWN_UNSTABLE_AT = 5


class ParallelCancelled(RuntimeError):
    pass


class ParallelBlocked(RuntimeError):
    """Structured non-mutating/pre-LIVE blocker that is safe to surface to users."""

    def __init__(self, message: str, diagnostic: Dict[str, Any] | None = None):
        super().__init__(message)
        self.diagnostic = diagnostic or {}


def _safe(value: Any, fallback: str = "job") -> str:
    text = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in str(value or "")).strip("._-")
    return text[:80] or fallback


def _utf8_env(workspace: Path, **extra: str) -> Dict[str, str]:
    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(Path(workspace).resolve())
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env.update({str(k): str(v) for k, v in extra.items()})
    return env


def _json_read(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def _latest_agent_report(reports_dir: Path) -> Dict[str, Any]:
    """Load the newest structured end-to-end report for one execution workspace."""
    try:
        candidates = sorted(reports_dir.glob("*_final_end_to_end_report_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for path in candidates:
            data = _json_read(path, {})
            if isinstance(data, dict) and data:
                data["_report_file"] = path.name
                return data
    except Exception:
        pass
    return {}


def _latest_agent_summary(reports_dir: Path) -> Dict[str, Any]:
    return (_latest_agent_report(reports_dir).get("agent_summary") or {})


def _attention_diagnostics(report: Dict[str, Any], limit: int = 5) -> List[Dict[str, Any]]:
    """Return safe, compact API-level diagnostics for FAIL/BLOCKED/WARNING rows."""
    rows = report.get("results") or [] if isinstance(report, dict) else []
    out: List[Dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        verdict = str(row.get("final_status") or row.get("agent_verdict") or row.get("classification") or "").upper()
        if verdict not in {"FAIL", "BLOCKED", "WARNING"}:
            continue
        api = str(row.get("api") or row.get("group") or f"API step {row.get('sequence') or '?'}")
        group = str(row.get("group") or "")
        reason = str(row.get("agent_reason") or row.get("issue") or row.get("error") or "The API did not complete successfully.")
        next_action = str(row.get("agent_next_action") or row.get("action_required") or "Review the HIP response and correct the indicated value before retrying.")
        response = str(row.get("response_preview") or "")
        request_id = str(row.get("request_id") or row.get("requestId") or row.get("correlation_id") or row.get("correlationId") or "")
        out.append(redact_sensitive({
            "sequence": row.get("sequence"),
            "api": api,
            "group": group,
            "verdict": verdict,
            "httpStatus": row.get("status_code"),
            "classification": row.get("classification"),
            "method": row.get("method"),
            "url": row.get("url"),
            "reason": reason[:3000],
            "nextAction": next_action[:3000],
            "hipResponse": response[:6000],
            "requestId": request_id[:500],
        }))
        if len(out) >= max(1, int(limit)):
            break
    return out


def _preflight_diagnostic(stage: str, message: str, *, http_status: Any = None, response: Any = None, next_action: str = "") -> Dict[str, Any]:
    return redact_sensitive({
        "api": "Final pre-LIVE safety gate",
        "group": "Preflight",
        "stage": stage,
        "verdict": "BLOCKED",
        "httpStatus": http_status,
        "reason": str(message or "Preflight did not pass.")[:3000],
        "hipResponse": str(response or "")[:6000],
        "nextAction": str(next_action or "Resolve this pre-LIVE blocker, revalidate the selected payload, then retry RUN LIVE EXECUTION.")[:3000],
    })



def _primary_attention_diagnostic(attention_items: List[Dict[str, Any]], end_to_end_state: Dict[str, Any]) -> Dict[str, Any]:
    """Choose the real end-to-end blocker for the summary panel.

    BLOCKED dependency/API rows outrank independent FAIL rows. When the detailed
    report has no compact attention row but the strict pipeline records a
    non-passing canonical step, expose that step instead of a generic runner
    safety-gate message.
    """
    primary = next((x for x in attention_items if str(x.get("verdict") or "").upper() == "BLOCKED"), None)
    if primary is None:
        primary = next((x for x in attention_items if str(x.get("verdict") or "").upper() == "FAIL"), None)
    if primary is None and attention_items:
        primary = attention_items[0]
    if primary is not None:
        return primary
    non_passing = list((end_to_end_state or {}).get("strictNonPassingLiveSteps") or [])
    if non_passing:
        step = str(non_passing[0])
        primary = _preflight_diagnostic(
            "end-to-end-dependency",
            f"LIVE pipeline did not progress because canonical step {step!r} is non-passing.",
            next_action="Open the API summary for this exact step and resolve its current LIVE dependency/error before retrying.",
        )
        primary["api"] = f"Canonical API step: {step}"
        return primary
    return {}

def _parse_json_stdout(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else {}
    except Exception:
        for idx in reversed([i for i, ch in enumerate(raw) if ch == "{"]):
            try:
                value = json.loads(raw[idx:])
                if isinstance(value, dict):
                    return value
            except Exception:
                continue
    return {}


def _json_write(path: Path, value: Any) -> None:
    atomic_write_json(path, value)


def _sha256(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _snapshot_hashes(workspace: Path) -> Dict[str, str]:
    """Hash every execution-critical file copied into a queue snapshot.

    Reports/payload outputs are intentionally excluded because they are generated
    after execution. This prevents a queued payload/configuration from being
    silently edited after validation while still appearing READY.
    """
    workspace = Path(workspace)
    rows: Dict[str, str] = {}
    for name in _SNAPSHOT_FILES:
        path = workspace / name
        if path.is_file():
            rows[name] = _sha256(path)
    for name in _SNAPSHOT_DIRS:
        root = workspace / name
        if not root.is_dir():
            continue
        for path in sorted(p for p in root.rglob("*") if p.is_file()):
            rel = str(path.relative_to(workspace)).replace("\\", "/")
            rows[rel] = _sha256(path)
    return rows


def _snapshot_digest(hashes: Dict[str, str]) -> str:
    payload = json.dumps(sorted(hashes.items()), separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _live_batch_counts(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarize completed jobs while a batch is still running."""
    statuses = [str((row or {}).get("status") or "").upper() for row in results]
    pass_count = statuses.count("PASS")
    warning_count = statuses.count("WARNING")
    fail_count = statuses.count("FAIL")
    blocked_count = statuses.count("BLOCKED")
    cancelled_count = statuses.count("CANCELLED")
    skipped_count = statuses.count("SKIPPED")
    if fail_count:
        overall = "FAIL"
    elif blocked_count:
        overall = "BLOCKED"
    elif cancelled_count:
        overall = "CANCELLED"
    elif warning_count:
        overall = "WARNING"
    elif pass_count and pass_count == len(statuses):
        overall = "PASS"
    else:
        overall = "IN_PROGRESS"
    return {
        "passCount": pass_count,
        "warningCount": warning_count,
        "failCount": fail_count,
        "blockedCount": blocked_count,
        "cancelledCount": cancelled_count,
        "skippedCount": skipped_count,
        "completedCount": len(results),
        "overallVerdict": overall,
    }


def _final_status_from_runner(
    *,
    return_code: int,
    agent_verdict: str,
    hard_agent_failures: int,
    stopped_by_user: bool = False,
    timed_out: bool = False,
) -> str:
    """Resolve process policy vs. the freshly generated API evidence report.

    A non-zero runner code can represent a conservative coverage/final-state
    policy rather than an API failure.  When the current execution workspace's
    structured report proves there are zero FAIL/BLOCKED API rows, preserve its
    PASS/WARNING verdict.  This prevents a false "Final pre-LIVE safety gate"
    blocker while retaining hard failure and timeout/cancel precedence.
    """
    verdict = str(agent_verdict or "").upper()
    if stopped_by_user:
        return "CANCELLED"
    if timed_out:
        return "BLOCKED"
    if int(return_code or 0) != 0:
        if verdict in {"PASS", "WARNING"} and int(hard_agent_failures or 0) == 0:
            return verdict
        return "FAIL" if verdict == "FAIL" else "BLOCKED"
    if verdict in {"PASS", "WARNING", "FAIL", "BLOCKED"}:
        return verdict
    return "PASS"


class ParallelManager:
    """Global React/FastAPI parallel runner over isolated validated configuration snapshots."""

    def __init__(self, store):
        self.store = store
        self.root = Path(store.root)
        self.queue_root = self.root / "parallel_queue"
        self.run_root = self.root / "parallel_runs"
        self.queue_root.mkdir(parents=True, exist_ok=True)
        self.run_root.mkdir(parents=True, exist_ok=True)
        # V52: execute customer jobs from a deliberately short physical path.
        # The UI/project may live under a very deep OneDrive folder on Windows; copying
        # input_files into runtime/parallel_runs/<batch>/jobs/<job>/... can cross the
        # classic Windows path limit and surface as a misleading FileNotFoundError.
        project_key = hashlib.sha256(str(self.root.resolve()).lower().encode()).hexdigest()[:10]
        configured_exec_root = str(os.environ.get("HIP_PARALLEL_EXEC_ROOT") or "").strip()
        exec_base = Path(configured_exec_root).expanduser() if configured_exec_root else Path(tempfile.gettempdir()) / "hip_exec"
        self.exec_root = exec_base / project_key
        self.exec_root.mkdir(parents=True, exist_ok=True)
        self._queues: Dict[str, List[asyncio.Queue]] = defaultdict(list)
        self._lock = threading.RLock()
        # V84: batch state is authoritative in memory while a LIVE batch runs.
        # Disk persistence is evidence/recovery and must never be able to stop HIP work.
        self._batch_state: Dict[str, Dict[str, Any]] = {}
        self._batch_stop: Dict[str, threading.Event] = {}
        self._job_stop: Dict[tuple[str, str], threading.Event] = {}
        self._processes: Dict[tuple[str, str], subprocess.Popen] = {}
        self.pipeline_root = self.root / "pipelines"
        self.pipeline_root.mkdir(parents=True, exist_ok=True)


    def _execution_workspace(self, batch_id: str, job_id: str) -> Path:
        """Return a short, isolated physical workspace for one LIVE job.

        Batch/job IDs stay unchanged in the API and report metadata, while the
        on-disk execution path remains short enough for Windows/OneDrive hosts.
        """
        batch_key = hashlib.sha256(str(batch_id).encode("utf-8")).hexdigest()[:10]
        job_key = hashlib.sha256(str(job_id).encode("utf-8")).hexdigest()[:10]
        return self.exec_root / batch_key / job_key

    @staticmethod
    def _path_diagnostic(path: Path) -> Dict[str, Any]:
        text = str(Path(path))
        return {"path": text, "length": len(text), "exists": Path(path).exists()}

    def _secret_path(self, job_id: str) -> Path:
        base = Path(tempfile.gettempdir()) / "agentic_hip_react_parallel_secrets"
        base.mkdir(parents=True, exist_ok=True)
        key = hashlib.sha256(str(self.root.resolve()).lower().encode()).hexdigest()[:16]
        return base / f"{key}_{_safe(job_id)}.json"

    def _secret_ready(self, job_id: str, max_age_seconds: int = 4 * 60 * 60) -> bool:
        path = self._secret_path(job_id)
        if not path.exists():
            return False
        try:
            return (time.time() - path.stat().st_mtime) <= max_age_seconds
        except Exception:
            return False

    def _copy_snapshot(self, source: Path, destination: Path) -> None:
        destination.mkdir(parents=True, exist_ok=False)
        for name in _SNAPSHOT_FILES:
            src = source / name
            if src.exists() and src.is_file():
                shutil.copy2(src, destination / name)
        for name in _SNAPSHOT_DIRS:
            src = source / name
            if src.exists() and src.is_dir():
                shutil.copytree(src, destination / name)
        (destination / "payloads").mkdir(exist_ok=True)
        (destination / "reports").mkdir(exist_ok=True)

    def queue_configuration(self, configuration: Dict[str, Any], validation: Dict[str, Any], label: str = "", demo_instance: int | None = None, demo_count: int | None = None, instance_group_id: str = "") -> Dict[str, Any]:
        if not validation.get("ok"):
            raise ValueError("Only an agent-validated configuration can be queued for LIVE parallel execution.")
        source = Path(configuration["workspace"]).resolve()
        input_path = source / "input.json"
        if not input_path.exists():
            raise ValueError("input.json is missing.")
        data = _json_read(input_path, {})
        # Opaque short IDs keep new queue paths compact; createdAt carries the timestamp.
        job_id = "q" + uuid.uuid4().hex[:10]
        folder = self.queue_root / job_id
        workspace = folder / "workspace"
        folder.mkdir(parents=True, exist_ok=False)
        self._copy_snapshot(source, workspace)

        # V113: normalize the queued snapshot itself, not only newly built inputs.
        # This closes the upgrade case where a configuration created under V109/V110
        # still carries a >40-character Flow name in persistent storage. The change
        # happens before LIVE request materialization and is recorded in the queue
        # manifest; it is never a retry-time API payload mutation.
        queue_input_path = workspace / "input.json"
        queued_data = _json_read(queue_input_path, {})
        before_flow = str(queued_data.get("profile_name") or ((((queued_data.get("objects") or {}).get("biz_flow") or {}).get("flow_details") or {}).get("business_flow_name")) or "")
        normalized_data = normalize_input_flow_name(queued_data) if isinstance(queued_data, dict) else queued_data
        after_flow = str((normalized_data or {}).get("profile_name") or (((((normalized_data or {}).get("objects") or {}).get("biz_flow") or {}).get("flow_details") or {}).get("business_flow_name")) or "")
        queue_normalization = {}
        if isinstance(normalized_data, dict) and normalized_data != queued_data:
            _json_write(queue_input_path, normalized_data)
            queue_normalization = dict(normalized_data.get("_flow_name_normalization") or {})
        elif before_flow != after_flow and isinstance(normalized_data, dict):
            _json_write(queue_input_path, normalized_data)
            queue_normalization = dict(normalized_data.get("_flow_name_normalization") or {})
        data = _json_read(queue_input_path, {})

        runtime_values = load_runtime_payload_values(source)
        if runtime_values:
            secret_path = self._secret_path(job_id)
            secret_path.write_text(json.dumps(runtime_values, indent=2), encoding="utf-8")
            try: os.chmod(secret_path, 0o600)
            except Exception: pass
        customer = str(data.get("customer") or configuration.get("customer") or "CUSTOMER")
        flow = str(data.get("profile_name") or (((data.get("objects") or {}).get("biz_flow") or {}).get("flow_details") or {}).get("business_flow_name") or configuration.get("name") or "FLOW")
        manifest = {
            "jobId": job_id,
            "configurationId": configuration.get("id"),
            "label": label or f"{customer} · {flow}",
            "customer": customer,
            "flow": flow,
            "direction": data.get("direction") or configuration.get("direction"),
            "flowType": data.get("flow_type") or configuration.get("flow_type"),
            "transactionCode": data.get("tx_code") or configuration.get("transaction_code"),
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "status": "READY", "validated": True, "validationOk": True,
            "inputSha256": _sha256(workspace / "input.json"),
            "snapshotHashes": _snapshot_hashes(workspace),
            "queueCanonicalization": queue_normalization,
            "runtimeValuesEphemeral": bool(runtime_values),
            "demoInstance": demo_instance, "demoInstanceCount": demo_count, "instanceGroupId": str(instance_group_id or ""),
            "workspace": str(workspace),
            "validation": redact_sensitive({
                "generatedAt": validation.get("generatedAt"), "ok": validation.get("ok"),
                "mapper": validation.get("mapper"), "requests": validation.get("requests"),
                "mcpSupervisor": validation.get("mcpSupervisor"),
            }),
        }
        manifest["snapshotSha256"] = _snapshot_digest(manifest.get("snapshotHashes") or {})
        _json_write(folder / "manifest.json", manifest)
        return manifest

    def list_queue(self) -> List[Dict[str, Any]]:
        rows = []
        for folder in sorted(self.queue_root.iterdir(), reverse=True):
            if not folder.is_dir(): continue
            manifest = _json_read(folder / "manifest.json", {})
            if not manifest: continue
            workspace = folder / "workspace"
            current_hashes = _snapshot_hashes(workspace)
            expected_hashes = manifest.get("snapshotHashes") if isinstance(manifest.get("snapshotHashes"), dict) else {}
            if expected_hashes:
                integrity = current_hashes == expected_hashes and _snapshot_digest(current_hashes) == manifest.get("snapshotSha256")
            else:
                # Backward compatibility for queue entries created before V51.
                integrity = _sha256(workspace / "input.json") == manifest.get("inputSha256")
            secret_ready = (not manifest.get("runtimeValuesEphemeral")) or self._secret_ready(str(manifest.get("jobId")))
            row = dict(manifest)
            row["integrityOk"] = integrity
            row["runtimeValuesReady"] = secret_ready
            row["ready"] = bool(manifest.get("validated") and manifest.get("validationOk") and integrity and secret_ready)
            if not integrity:
                row["readinessReason"] = "Queued snapshot changed after validation. Re-queue this customer before LIVE execution."
            elif not secret_ready:
                row["readinessReason"] = "Ephemeral runtime values expired or are missing. Re-queue this customer."
            rows.append(redact_sensitive(row))
        return rows

    def _reindex_instance_group(self, instance_group_id: str) -> None:
        """Keep 1/N, 2/N labels accurate immediately after queue deletion."""
        group_id = str(instance_group_id or "").strip()
        if not group_id:
            return
        rows: List[tuple[Path, Dict[str, Any]]] = []
        for folder in self.queue_root.iterdir():
            if not folder.is_dir():
                continue
            manifest_path = folder / "manifest.json"
            manifest = _json_read(manifest_path, {})
            if str(manifest.get("instanceGroupId") or "") == group_id:
                rows.append((manifest_path, manifest))
        rows.sort(key=lambda pair: (int(pair[1].get("demoInstance") or 999999), str(pair[1].get("createdAt") or "")))
        total = len(rows)
        for index, (manifest_path, manifest) in enumerate(rows, start=1):
            manifest["demoInstance"] = index
            manifest["demoInstanceCount"] = total
            label = str(manifest.get("label") or "")
            if re.search(r"\bInstance\s+\d+/\d+\b", label, flags=re.I):
                label = re.sub(r"\bInstance\s+\d+/\d+\b", f"Instance {index}/{total}", label, flags=re.I)
            elif total > 1:
                label = f"{label} · Instance {index}/{total}"
            manifest["label"] = label
            try:
                _json_write(manifest_path, manifest)
            except Exception:
                pass

    def delete_job(self, job_id: str) -> bool:
        target = (self.queue_root / _safe(job_id)).resolve()
        if target.parent != self.queue_root.resolve() or not target.exists():
            return False
        manifest = _json_read(target / "manifest.json", {})
        group_id = str(manifest.get("instanceGroupId") or "")
        shutil.rmtree(target)
        self._secret_path(job_id).unlink(missing_ok=True)
        if group_id:
            self._reindex_instance_group(group_id)
        return True

    def delete_jobs(self, job_ids: Iterable[str]) -> Dict[str, Any]:
        deleted: List[str] = []
        not_found: List[str] = []
        for raw in job_ids:
            job_id = str(raw or "").strip()
            if not job_id:
                continue
            if self.delete_job(job_id):
                deleted.append(job_id)
            else:
                not_found.append(job_id)
        return {"deleted": deleted, "notFound": not_found, "deletedCount": len(deleted)}

    def create_demo_instances(self, configuration: Dict[str, Any], validation: Dict[str, Any], count: int) -> List[Dict[str, Any]]:
        """Clone any validated active configuration into one reindexable instance group.

        This compatibility helper now uses the same instance-group semantics as
        the source-aware React queue path.  Deleting any member therefore updates
        the remaining ``1/N .. N/N`` labels immediately for legacy/API callers too.
        """
        count = max(2, min(int(count), 8))
        if not validation.get("ok"):
            raise ValueError("The active configuration must pass agent validation before instances can be created.")
        input_data = _json_read(Path(configuration["workspace"]) / "input.json", {})
        customer = str(input_data.get("customer") or configuration.get("customer") or configuration.get("name") or "Configuration").strip() or "Configuration"
        group_id = "ig" + uuid.uuid4().hex[:10]
        return [
            self.queue_configuration(
                configuration,
                validation,
                f"{customer} Parallel Instance {i}/{count}",
                i,
                count,
                instance_group_id=group_id,
            )
            for i in range(1, count + 1)
        ]

    def _persist_batch_best_effort(self, batch_id: str, record: Dict[str, Any]) -> bool:
        """Persist telemetry without ever failing a running customer execution."""
        path = self.run_root / _safe(batch_id) / "summary.json"
        try:
            _json_write(path, redact_sensitive(record))
            return True
        except Exception as exc:
            # Endpoint security on managed Windows devices can briefly lock JSON files.
            # Keep the authoritative in-memory state and leave a diagnostic sidecar only
            # when possible; the LIVE worker must not be marked BLOCKED for report I/O.
            try:
                diagnostic = path.parent / "summary_persistence_warning.txt"
                diagnostic.write_text(f"{datetime.now(timezone.utc).isoformat()} {type(exc).__name__}: {exc}\n", encoding="utf-8")
            except Exception:
                pass
            return False

    def _current_batch(self, batch_id: str) -> Dict[str, Any]:
        with self._lock:
            current = self._batch_state.get(batch_id)
            if current:
                return json.loads(json.dumps(current, default=str))
        return _json_read(self.run_root / _safe(batch_id) / "summary.json", {})

    async def subscribe(self, batch_id: str) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue()
        self._queues[batch_id].append(queue)
        current = self._current_batch(batch_id)
        for event in current.get("events", []) if current else []:
            await queue.put(event)
        return queue

    def unsubscribe(self, batch_id: str, queue: asyncio.Queue) -> None:
        try:
            self._queues[batch_id].remove(queue)
        except Exception:
            pass

    def _publish(self, batch_id: str, event: Dict[str, Any], loop: asyncio.AbstractEventLoop) -> None:
        # V84: update memory first and publish the WebSocket event even when Windows
        # temporarily locks summary.json. Report persistence is best-effort telemetry.
        with self._lock:
            record = self._batch_state.get(batch_id)
            if not record:
                record = _json_read(self.run_root / _safe(batch_id) / "summary.json", {"batchId": batch_id, "events": []})
            record = dict(record or {"batchId": batch_id, "events": []})
            clean_event = redact_sensitive(event)
            record.setdefault("events", []).append(clean_event)
            record["updatedAt"] = datetime.now(timezone.utc).isoformat()
            event_type = str(event.get("type") or "")
            if event_type == "batch.started":
                record["status"] = "RUNNING"
                record["startedAt"] = event.get("startedAt") or record["updatedAt"]
            elif event_type == "batch.preflight_all_started":
                record["status"] = "PREFLIGHTING"
                record["preflightAll"] = True
            elif event_type == "batch.preflight_all_passed":
                record["status"] = "RUNNING"
                record["allPayloadsValidated"] = True
            elif event_type == "batch.stop_requested":
                record["status"] = "STOPPING"
                record["stopRequestedAt"] = record["updatedAt"]
            elif event_type in {"batch.concurrency_wave", "batch.concurrency_adjusted", "batch.concurrency_recommendation"}:
                if event.get("recommendedConcurrency") is not None:
                    record["recommendedConcurrency"] = event.get("recommendedConcurrency")
                if event.get("peakStableWorkers") is not None:
                    record["peakStableWorkers"] = event.get("peakStableWorkers")
                if event_type == "batch.concurrency_adjusted":
                    record["concurrencyLimited"] = True
                    record["concurrencyReductionReason"] = event.get("reason")
                record["currentWave"] = event.get("wave", record.get("currentWave"))
                record["currentWaveWorkers"] = event.get("workers", event.get("nextWaveWorkers", record.get("currentWaveWorkers")))
            elif event_type in {"job.final_checks_started", "job.final_checks_progress", "job.final_checks_passed", "job.final_checks_blocked", "job.started", "job.heartbeat", "job.stop_requested", "job.cancelled", "job.completed"}:
                job_id = str(event.get("jobId") or "")
                if job_id:
                    jobs = record.setdefault("jobs", {})
                    current = dict(jobs.get(job_id) or {})
                    current.update({k: v for k, v in clean_event.items() if k != "type"})
                    if event_type in {"job.final_checks_started", "job.final_checks_progress"}:
                        current["status"] = "CHECKING"
                    elif event_type == "job.final_checks_passed":
                        current["status"] = "CHECKED"
                    elif event_type == "job.final_checks_blocked":
                        current["status"] = "BLOCKED"
                    elif event_type == "job.started":
                        current["status"] = "RUNNING"
                    elif event_type == "job.heartbeat":
                        current["status"] = current.get("status") or "RUNNING"
                    elif event_type == "job.stop_requested":
                        current["status"] = "STOPPING"
                    elif event_type == "job.cancelled":
                        current["status"] = "CANCELLED"
                    elif event_type == "job.completed":
                        current["status"] = event.get("status") or "COMPLETED"
                    jobs[job_id] = current
                    if event_type in {"job.completed", "job.cancelled"}:
                        results = list(record.get("results") or [])
                        result_row = {k: v for k, v in clean_event.items() if k != "type"}
                        result_row.setdefault("status", "CANCELLED" if event_type == "job.cancelled" else "COMPLETED")
                        replaced = False
                        for index, row in enumerate(results):
                            if str((row or {}).get("jobId") or "") == job_id:
                                results[index] = result_row
                                replaced = True
                                break
                        if not replaced:
                            results.append(result_row)
                        record["results"] = results
                        record.update(_live_batch_counts(results))
                started_at = record.get("startedAt")
                if started_at:
                    try:
                        started_dt = datetime.fromisoformat(str(started_at).replace("Z", "+00:00"))
                        record["elapsedSeconds"] = round(max(0.0, (datetime.now(timezone.utc) - started_dt).total_seconds()), 3)
                    except Exception:
                        pass
            elif event_type == "batch.completed":
                record.update(event.get("summary") or {})
                record["status"] = "COMPLETED"
                record["finishedAt"] = record["updatedAt"]
            self._batch_state[batch_id] = record
            persisted = self._persist_batch_best_effort(batch_id, record)
            if not persisted:
                record["persistenceWarning"] = "Live state is safe in memory; Windows temporarily blocked summary.json persistence."
        for queue in list(self._queues.get(batch_id, [])):
            try:
                asyncio.run_coroutine_threadsafe(queue.put(redact_sensitive(event)), loop)
            except Exception:
                pass

    def _batch_stop_event(self, batch_id: str) -> threading.Event:
        with self._lock:
            return self._batch_stop.setdefault(batch_id, threading.Event())

    def _job_stop_event(self, batch_id: str, job_id: str) -> threading.Event:
        with self._lock:
            return self._job_stop.setdefault((batch_id, job_id), threading.Event())

    def stop_batch(self, batch_id: str, loop: asyncio.AbstractEventLoop) -> Dict[str, Any]:
        record = self._current_batch(batch_id)
        if not record:
            raise ValueError("Parallel batch not found.")
        if str(record.get("status") or "").upper() == "COMPLETED":
            return record
        self._batch_stop_event(batch_id).set()
        self._publish(batch_id, {"type": "batch.stop_requested", "batchId": batch_id, "reason": "Stopped by user"}, loop)
        with self._lock:
            running = [(key, proc) for key, proc in self._processes.items() if key[0] == batch_id]
        for (bid, job_id), process in running:
            self._job_stop_event(bid, job_id).set()
            self._publish(batch_id, {"type": "job.stop_requested", "jobId": job_id, "reason": "Batch stopped by user"}, loop)
            if process.poll() is None:
                try:
                    process.terminate()
                except Exception:
                    pass
        return self._current_batch(batch_id)

    def stop_job(self, batch_id: str, job_id: str, loop: asyncio.AbstractEventLoop) -> Dict[str, Any]:
        record = self._current_batch(batch_id)
        jobs = record.get("jobs") or {} if record else {}
        if not record or job_id not in jobs:
            raise ValueError("Parallel job not found in this batch.")
        self._job_stop_event(batch_id, job_id).set()
        self._publish(batch_id, {"type": "job.stop_requested", "jobId": job_id, "reason": "Stopped by user"}, loop)
        with self._lock:
            process = self._processes.get((batch_id, job_id))
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        return self._current_batch(batch_id)

    def _final_pre_live_checks(self, batch_id: str, manifest: Dict[str, Any], destination: Path, loop: asyncio.AbstractEventLoop) -> Dict[str, Any]:
        """Revalidate the exact staged workspace immediately before LIVE execution."""
        job_id = str(manifest.get("jobId") or "")
        base = {"jobId": job_id, "label": manifest.get("label"), "customer": manifest.get("customer")}
        self._publish(batch_id, {"type": "job.final_checks_started", **base, "stage": "api-contracts"}, loop)

        # V113 defensive generalized upgrade gate: old queue entries may survive an application
        # upgrade. Canonicalize the isolated staged input before contract validation
        # and before any LIVE API call. This is deterministic input normalization,
        # never post-response payload mutation.
        staged_input_path = destination / "input.json"
        staged_before_hash = _sha256(staged_input_path) if staged_input_path.exists() else ""
        staged_data = _json_read(staged_input_path, {})
        staged_normalized = normalize_input_flow_name(staged_data) if isinstance(staged_data, dict) else staged_data
        if isinstance(staged_normalized, dict) and staged_normalized != staged_data:
            _json_write(staged_input_path, staged_normalized)
        staged_after_hash = _sha256(staged_input_path) if staged_input_path.exists() else ""
        effective_flow_name = ""
        if isinstance(staged_normalized, dict):
            effective_flow_name = str(
                staged_normalized.get("profile_name")
                or (((staged_normalized.get("objects") or {}).get("biz_flow") or {}).get("flow_details") or {}).get("business_flow_name")
                or staged_normalized.get("flow_name")
                or ""
            ).strip()
        if effective_flow_name:
            # Old queue manifests can retain a pre-upgrade display value even after
            # the isolated input is correctly canonicalized. Keep operator-facing
            # telemetry aligned with the exact staged input that will be executed.
            manifest["flow"] = effective_flow_name
            base["flow"] = effective_flow_name
        if staged_before_hash != staged_after_hash:
            _json_write(destination / "reports" / "flow_name_pre_live_normalization.json", {
                "stage": "pre-live-before-contract-validation",
                "inputChanged": True,
                "beforeSha256": staged_before_hash,
                "afterSha256": staged_after_hash,
                "flowNameNormalization": (staged_normalized or {}).get("_flow_name_normalization") if isinstance(staged_normalized, dict) else {},
                "apiRequestAlreadyMaterialized": False,
            })
            self._publish(batch_id, {
                "type": "job.input_canonicalized", **base,
                "stage": "pre-live-before-contract-validation",
                "flowNameNormalization": redact_sensitive((staged_normalized or {}).get("_flow_name_normalization") or {}),
            }, loop)

        validation = validate_configuration(destination)
        requests = validation.get("requests") or {}
        contract_ok = bool(validation.get("ok"))
        if not contract_ok:
            evidence = {
                "ready": False,
                "contractValidation": {
                    "ok": False,
                    "validCount": requests.get("validCount"),
                    "total": requests.get("total"),
                    "applicableCount": requests.get("applicableCount"),
                    "blockedItems": requests.get("blockedItems") or [],
                },
                "productionPreflight": {},
            }
            _json_write(destination / "reports" / "final_pre_live_checks_latest.json", redact_sensitive(evidence))
            self._publish(batch_id, {
                "type": "job.final_checks_blocked", **base, "stage": "api-contracts",
                "validCount": requests.get("validCount"), "total": requests.get("total"),
            }, loop)
            blocked_items = requests.get("blockedItems") or []
            first = blocked_items[0] if blocked_items and isinstance(blocked_items[0], dict) else {}
            diagnostic = _preflight_diagnostic(
                "api-contracts",
                str(first.get("reason") or first.get("error") or f"Only {requests.get('validCount', 0)}/{requests.get('total', 18)} API contracts are ready."),
                response=first,
                next_action=str(first.get("nextAction") or "Open Build Configuration/API Testing, fix the blocked contract value, then revalidate."),
            )
            if first.get("label") or first.get("api") or first.get("stepKey"):
                diagnostic["api"] = str(first.get("label") or first.get("api") or first.get("stepKey"))
            raise ParallelBlocked(
                "Final pre-LIVE contract validation failed "
                f"({requests.get('validCount', 0)}/{requests.get('total', 18)} ready). "
                "No LIVE HIP API call was made.",
                diagnostic,
            )

        self._publish(batch_id, {
            "type": "job.final_checks_progress", **base, "stage": "production-preflight",
            "validCount": requests.get("validCount"), "total": requests.get("total"),
        }, loop)
        # V97 final audit: the safety gate must use the exact same strict
        # whole-pipeline requirements as the mutating worker. Otherwise a
        # persisted skip plan could hide a credential/business prerequisite in
        # preflight even though V96 strict LIVE will call that API moments later.
        env = _utf8_env(
            destination,
            HIP_LIVE_API_EXECUTION="1",
            HIP_STRICT_LIVE_PIPELINE="1",
            HIP_LIVE_AUTO_COMPLETE="1",
            HIP_FULL_API_COVERAGE_MODE="0",
        )
        if self._batch_stop_event(batch_id).is_set() or self._job_stop_event(batch_id, job_id).is_set():
            raise ParallelCancelled("Stopped before production preflight.")
        timeout_seconds = max(30, int(os.environ.get("HIP_PARALLEL_PREFLIGHT_TIMEOUT_SECONDS", "300") or 300))
        try:
            proc = subprocess.run(
                [os.environ.get("PYTHON", os.sys.executable), "-u", str(LEGACY_ROOT / "run_agent.py"), "--preflight"],
                cwd=str(LEGACY_ROOT), env=env, text=True, encoding="utf-8", errors="replace", capture_output=True, timeout=timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            raise ParallelBlocked(
                f"Production preflight exceeded {timeout_seconds}s timeout. No LIVE API call was made.",
                _preflight_diagnostic("production-preflight", f"Preflight timed out after {timeout_seconds}s.", response=str(exc), next_action="Check HIP/OAuth connectivity or reduce capacity-test concurrency, then retry."),
            ) from exc
        if self._batch_stop_event(batch_id).is_set() or self._job_stop_event(batch_id, job_id).is_set():
            raise ParallelCancelled("Stopped during production preflight. No LIVE API call was made.")
        preflight = _parse_json_stdout(proc.stdout)
        preflight_ok = bool(proc.returncode == 0 and preflight.get("ready"))
        if proc.stderr and not preflight_ok and not preflight.get("errors"):
            preflight["errors"] = [str(proc.stderr)[-3000:]]
        evidence = {
            "ready": bool(contract_ok and preflight_ok),
            "effectiveFlowName": effective_flow_name or str(manifest.get("flow") or ""),
            "contractValidation": {
                "ok": contract_ok,
                "validCount": requests.get("validCount"),
                "total": requests.get("total"),
                "applicableCount": requests.get("applicableCount"),
            },
            "productionPreflight": preflight,
        }
        _json_write(destination / "reports" / "final_pre_live_checks_latest.json", redact_sensitive(evidence))
        if not preflight_ok:
            self._publish(batch_id, {
                "type": "job.final_checks_blocked", **base, "stage": "production-preflight",
                "errors": redact_sensitive(preflight.get("errors") or []),
            }, loop)
            errors = redact_sensitive(preflight.get("errors") or [])
            first_error = errors[0] if isinstance(errors, list) and errors else errors
            diagnostic = _preflight_diagnostic(
                "production-preflight",
                str(first_error or "Production connectivity/OAuth preflight did not pass."),
                http_status=preflight.get("statusCode") or preflight.get("status_code"),
                response=preflight.get("response") or preflight.get("details") or errors,
                next_action=str(preflight.get("nextAction") or "Check System & Connections, OAuth credentials, HIP endpoint connectivity and required runtime values, then retry."),
            )
            raise ParallelBlocked(
                "Final production preflight failed. No LIVE HIP API call was made. "
                + json.dumps(errors, default=str)[:3000],
                diagnostic,
            )

        self._publish(batch_id, {
            "type": "job.final_checks_passed", **base,
            "validCount": requests.get("validCount"), "total": requests.get("total"),
        }, loop)
        return evidence

    def _run_one(self, batch_id: str, manifest: Dict[str, Any], loop: asyncio.AbstractEventLoop, execution_mode: str = "LIVE") -> Dict[str, Any]:
        job_id = str(manifest["jobId"])
        batch_stop = self._batch_stop_event(batch_id)
        job_stop = self._job_stop_event(batch_id, job_id)
        if batch_stop.is_set() or job_stop.is_set():
            raise ParallelCancelled("Stopped before this queued instance started.")
        source = self.queue_root / job_id / "workspace"
        destination = self._execution_workspace(batch_id, job_id)
        if destination.exists():
            shutil.rmtree(destination, ignore_errors=True)
        try:
            self._copy_snapshot(source, destination)
        except Exception as exc:
            raise RuntimeError(
                "Could not stage the validated customer snapshot for LIVE execution. "
                f"Source={self._path_diagnostic(source)}; destination={self._path_diagnostic(destination)}; "
                f"{type(exc).__name__}: {exc}"
            ) from exc
        # Verify that every execution-critical file survived staging before run_agent starts.
        source_hashes = _snapshot_hashes(source)
        destination_hashes = _snapshot_hashes(destination)
        if not source_hashes or source_hashes != destination_hashes:
            missing = sorted(set(source_hashes) - set(destination_hashes))
            changed = sorted(k for k in set(source_hashes) & set(destination_hashes) if source_hashes[k] != destination_hashes[k])
            raise RuntimeError(
                "Parallel staging integrity check failed before LIVE execution. "
                f"missing={missing[:8]} changed={changed[:8]}. Re-queue the customer."
            )
        secret_path = self._secret_path(job_id)
        if manifest.get("runtimeValuesEphemeral"):
            if not secret_path.exists():
                raise RuntimeError("Ephemeral runtime payload values are no longer available; re-queue the configuration.")
            values = _json_read(secret_path, {})
            save_runtime_payload_values(destination, values, merge=False)
        # Mandatory final gate: re-run all contract checks and production preflight
        # in the exact short staged workspace before the mutating runner starts.
        if batch_stop.is_set() or job_stop.is_set():
            raise ParallelCancelled("Stopped before final pre-LIVE checks.")
        final_checks = self._final_pre_live_checks(batch_id, manifest, destination, loop)
        effective_flow_name = str(final_checks.get("effectiveFlowName") or manifest.get("flow") or "")
        if effective_flow_name:
            manifest["flow"] = effective_flow_name
        if batch_stop.is_set() or job_stop.is_set():
            raise ParallelCancelled("Stopped after preflight and before LIVE API execution.")

        started = datetime.now(timezone.utc)
        self._publish(batch_id, {"type":"job.started","jobId":job_id,"label":manifest.get("label"),"customer":manifest.get("customer"),"startedAt":started.isoformat()}, loop)
        env = _utf8_env(
            destination,
            HIP_PARALLEL_BATCH_ID=batch_id,
            HIP_PARALLEL_JOB_ID=job_id,
            HIP_API_PARALLEL_ENABLED="1",
            HIP_API_MAX_PARALLEL=str(os.environ.get("HIP_API_MAX_PARALLEL", "18") or "18"),
            HIP_LLM_AGENT_SLOT=job_id,
            HIP_LIVE_API_EXECUTION="1",
            HIP_STRICT_LIVE_PIPELINE="1",
            HIP_LIVE_AUTO_COMPLETE="1",
            HIP_LIVE_AUTO_COMPLETE_ROUNDS=str(os.environ.get("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "3") or "3"),
            HIP_STRICT_COVERAGE_ROUNDS=str(os.environ.get("HIP_STRICT_COVERAGE_ROUNDS", "3") or "3"),
            # Production LIVE stays dependency-safe, but V96 ignores persisted
            # skip plans and requires real HTTP evidence from every applicable API.
            HIP_FULL_API_COVERAGE_MODE="0",
        )
        process = subprocess.Popen(
            [os.environ.get("PYTHON", os.sys.executable), "-u", str(LEGACY_ROOT / "run_agent.py")],
            cwd=str(LEGACY_ROOT), env=env, text=True, encoding="utf-8", errors="replace", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1,
        )
        with self._lock:
            self._processes[(batch_id, job_id)] = process
        logs: List[str] = []
        line_queue: thread_queue.Queue[str] = thread_queue.Queue()
        def _reader() -> None:
            if process.stdout is None:
                return
            for raw in process.stdout:
                line_queue.put(raw.rstrip())
        reader = threading.Thread(target=_reader, name=f"parallel-log-{job_id}", daemon=True)
        reader.start()
        timeout_seconds = max(60, int(os.environ.get("HIP_PARALLEL_JOB_TIMEOUT_SECONDS", "1800") or 1800))
        heartbeat_at = time.monotonic()
        started_monotonic = time.monotonic()
        timed_out = False
        stopped_by_user = False
        while process.poll() is None or not line_queue.empty():
            try:
                line = line_queue.get(timeout=0.25)
                if len(logs) < 20000:
                    logs.append(line)
            except thread_queue.Empty:
                pass
            now = time.monotonic()
            if now - heartbeat_at >= 2.0:
                self._publish(batch_id, {"type":"job.heartbeat","jobId":job_id,"lines":len(logs),"elapsedSeconds":round(now-started_monotonic,1)}, loop)
                heartbeat_at = now
            if process.poll() is None and (batch_stop.is_set() or job_stop.is_set()):
                stopped_by_user = True
                try:
                    process.terminate()
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait(timeout=10)
                except Exception:
                    pass
            if process.poll() is None and now - started_monotonic > timeout_seconds:
                timed_out = True
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait(timeout=10)
        reader.join(timeout=1)
        rc = process.wait()
        with self._lock:
            self._processes.pop((batch_id, job_id), None)
        finished = datetime.now(timezone.utc)
        reports_dir = destination / "reports"
        html_candidates = sorted(reports_dir.glob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True) if reports_dir.exists() else []
        latest_html = html_candidates[0] if html_candidates else None
        agent_report = _latest_agent_report(reports_dir)
        agent_summary = agent_report.get("agent_summary") or {}
        end_to_end_state = agent_report.get("end_to_end_state") if isinstance(agent_report.get("end_to_end_state"), dict) else {}
        api_coverage = {
            "strict": bool(end_to_end_state.get("strictLivePipelineMode")),
            "complete": bool(end_to_end_state.get("coverageComplete")),
            "called": len(end_to_end_state.get("logicalStepsWithHttpResponse") or []),
            "missing": list(end_to_end_state.get("coverageMissingSteps") or []),
            "nonPassing": list(end_to_end_state.get("strictNonPassingLiveSteps") or []),
        }
        attention_items = _attention_diagnostics(agent_report, limit=20)
        # Show the API/dependency that actually blocked end-to-end progression
        # before independent FAILs such as an unavailable Account/System route.
        primary_attention = _primary_attention_diagnostic(attention_items, end_to_end_state)
        agent_verdict = str(agent_summary.get("overallVerdict") or "").upper()
        agent_counts = agent_summary.get("counts") if isinstance(agent_summary.get("counts"), dict) else {}
        hard_agent_failures = int(agent_counts.get("FAIL") or 0) + int(agent_counts.get("BLOCKED") or 0)
        final_status = _final_status_from_runner(
            return_code=rc,
            agent_verdict=agent_verdict,
            hard_agent_failures=hard_agent_failures,
            stopped_by_user=stopped_by_user,
            timed_out=timed_out,
        )
        result = {
            "jobId": job_id, "label": manifest.get("label"), "customer": manifest.get("customer"),
            "flow": manifest.get("flow"), "demoInstance": manifest.get("demoInstance"),
            "status": final_status, "returnCode": rc,
            "agentVerdict": agent_verdict or final_status, "agentSummary": redact_sensitive(agent_summary),
            "apiCoverage": redact_sensitive(api_coverage),
            "attentionItems": attention_items,
            "blockerDiagnostic": (primary_attention if primary_attention and final_status in {"BLOCKED", "FAIL"} else (
                _preflight_diagnostic("live-runner", f"Parallel job exceeded {timeout_seconds}s timeout and was terminated.", next_action="Reduce concurrency or increase HIP_PARALLEL_JOB_TIMEOUT_SECONDS after confirming the HIP endpoint is healthy.") if timed_out else {}
            )),
            "executionMode": str(execution_mode or "LIVE").upper(),
            "error": "Stopped by user." if stopped_by_user else (f"Parallel job exceeded {timeout_seconds}s timeout and was terminated." if timed_out else ""),
            "startedAt": started.isoformat(), "finishedAt": finished.isoformat(),
            "elapsedSeconds": round((finished-started).total_seconds(),3),
            "stepTimings": _load_step_timings(destination), "reportDirectory": str(reports_dir),
            "executionWorkspace": str(destination), "executionWorkspacePathLength": len(str(destination)),
            "finalPreLiveChecks": redact_sensitive(final_checks),
            "htmlReport": latest_html.name if latest_html else "",
        }
        if final_status in {"BLOCKED", "FAIL"} and not result.get("blockerDiagnostic"):
            tail = "\n".join(logs[-30:])
            result["blockerDiagnostic"] = _preflight_diagnostic(
                "live-runner",
                str(agent_summary.get("reason") or "LIVE runner ended without a passing final verdict."),
                response=tail,
                next_action="Open the full customer report for API-level evidence. Check the first non-passing API response before retrying.",
            )
        # Persist each job HTML under the batch directory too. The execution workspace
        # intentionally lives in the OS temp area to keep Windows paths short.
        if latest_html:
            try:
                persistent_job_reports = self.run_root / batch_id / "job_reports"
                persistent_job_reports.mkdir(parents=True, exist_ok=True)
                persisted_name = f"{_safe(job_id)}_{latest_html.name}"
                shutil.copy2(latest_html, persistent_job_reports / persisted_name)
                result["persistentHtmlReport"] = persisted_name
                result["persistentReportDirectory"] = str(persistent_job_reports)
            except Exception:
                pass
        # Keep the familiar final HTML report visible in the source customer's Reports page.
        config_id = str(manifest.get("configurationId") or "")
        if latest_html and config_id and config_id != "reference:uhal":
            try:
                config = self.store.get_configuration(config_id)
                target_reports = Path(config["workspace"]) / "reports"
                target_reports.mkdir(parents=True, exist_ok=True)
                copied_name = f"parallel_{_safe(batch_id)}_{_safe(job_id)}_{latest_html.name}"
                shutil.copy2(latest_html, target_reports / copied_name)
                result["sourceReportName"] = copied_name
            except Exception:
                pass
        _json_write(destination / "parallel_job_result.json", redact_sensitive(result | {"logs":"\n".join(logs)}))
        self._publish(batch_id, {"type":"job.completed", **result}, loop)
        return result

    def _run_autogen_agent(self, batch_id: str, manifest: Dict[str, Any], loop: asyncio.AbstractEventLoop, execution_mode: str = "LIVE") -> Dict[str, Any]:
        """One real AutoGen agent owns one customer/instance LIVE execution."""
        job_id = str(manifest.get("jobId") or "job")
        agent_name = "hip_autogen_" + _safe(job_id, "job").replace("-", "_")[:48]
        task = {
            # V109: concise intent description is deliberately first-class. The
            # deterministic skill router uses the description as the trigger.
            "intentDescription": "Execute the selected immutable HIP configuration LIVE end-to-end through the governed developer-approved API pipeline.",
            "batchId": batch_id,
            "jobId": job_id,
            "customer": manifest.get("customer"),
            "label": manifest.get("label"),
            "executionMode": execution_mode,
            "rules": {
                "payloadSchemaLocked": True,
                "apiParallelism": "DEPENDENCY_READY",
                "strictWholePipeline": True,
                "allApplicableApisMustReturnHttpEvidence": True,
                "live": True,
            },
        }
        run_one = self._run_one
        parameters = inspect.signature(run_one).parameters

        # Historical/integration tests replace ``_run_one`` on the manager instance
        # with a plain callable.  Keep that explicit hook usable without weakening
        # production: the real bound ``ParallelManager._run_one`` always goes through
        # Microsoft AutoGen AgentChat 0.7.5.  An instance-level injected callable is
        # treated as a test harness and executed directly.
        injected_test_runner = not inspect.ismethod(run_one)

        def execute_governed() -> Dict[str, Any]:
            if "execution_mode" in parameters:
                return run_one(batch_id, manifest, loop, execution_mode=execution_mode)
            # Compatibility for test/integration hooks that replace _run_one with
            # the historical 3-argument callable. Production _run_one always
            # accepts execution_mode.
            return run_one(batch_id, manifest, loop)
        try:
            if injected_test_runner:
                return execute_governed()
            return run_with_autogen_agent(
                agent_name=agent_name,
                task=task,
                executor=execute_governed,
                cancel_check=lambda: (
                    self._batch_stop_event(batch_id).is_set()
                    or self._job_stop_event(batch_id, job_id).is_set()
                ),
            )
        except (ParallelCancelled, ParallelBlocked):
            raise
        except AutoGenCancelled as exc:
            raise ParallelCancelled(str(exc)) from exc
        except (AutoGenUnavailable, AutoGenExecutionError) as exc:
            diagnostic = _preflight_diagnostic(
                "autogen_agentchat",
                str(exc),
                next_action=(
                    f"Verify Microsoft AutoGen AgentChat {AUTOGEN_REQUIRED_VERSION} packages and Dell AIA gpt-oss-120b "
                    "tool/function-calling connectivity, then retry RUN LIVE EXECUTION."
                ),
            )
            diagnostic.update({
                "api": f"Microsoft AutoGen AgentChat {AUTOGEN_REQUIRED_VERSION}",
                "group": "Agent Orchestration",
            })
            raise ParallelBlocked(str(exc), diagnostic) from exc
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            if "429" in message or "rate limit" in message.lower() or "too many requests" in message.lower():
                diagnostic = _preflight_diagnostic(
                    "autogen_model_rate_limit",
                    message,
                    http_status=429,
                    next_action=(
                        "Dell AIA throttled an AutoGen model request. Keep the LIVE scheduler at no more than four "
                        "concurrent AgentChat agents; additional customer/instance jobs will continue in later waves."
                    ),
                )
                diagnostic.update({
                    "api": "Dell AIA model call via AutoGen AgentChat",
                    "group": "Agent Orchestration",
                })
                raise ParallelBlocked(message, diagnostic) from exc
            raise

    def _preflight_only_one(self, batch_id: str, manifest: Dict[str, Any], loop: asyncio.AbstractEventLoop) -> Dict[str, Any]:
        """Stage and preflight one immutable payload snapshot without making LIVE calls."""
        job_id = str(manifest["jobId"])
        if self._batch_stop_event(batch_id).is_set() or self._job_stop_event(batch_id, job_id).is_set():
            raise ParallelCancelled("Stopped before pipeline preflight.")
        source = self.queue_root / job_id / "workspace"
        batch_key = hashlib.sha256(str(batch_id).encode("utf-8")).hexdigest()[:10]
        job_key = hashlib.sha256(str(job_id).encode("utf-8")).hexdigest()[:10]
        destination = self.exec_root / batch_key / f"pre_{job_key}"
        if destination.exists():
            shutil.rmtree(destination, ignore_errors=True)
        self._copy_snapshot(source, destination)
        source_hashes = _snapshot_hashes(source)
        destination_hashes = _snapshot_hashes(destination)
        if not source_hashes or source_hashes != destination_hashes:
            raise RuntimeError("Pipeline preflight staging integrity check failed. Re-queue this payload.")
        if manifest.get("runtimeValuesEphemeral"):
            secret_path = self._secret_path(job_id)
            if not secret_path.exists():
                raise RuntimeError("Ephemeral runtime payload values are no longer available; re-queue this customer.")
            save_runtime_payload_values(destination, _json_read(secret_path, {}), merge=False)
        return self._final_pre_live_checks(batch_id, manifest, destination, loop)

    def _finalize_batch(self, batch_id: str, jobs: List[Dict[str, Any]], results: List[Dict[str, Any]], workers: int, started: float, loop: asyncio.AbstractEventLoop, *, batch_kind: str = "PARALLEL", pipeline_id: str = "", execution_mode: str = "LIVE") -> Dict[str, Any]:
        counts = _live_batch_counts(results)
        current = self._current_batch(batch_id)
        summary = {
            "batchId": batch_id, "parallelWorkers": workers, "configurationCount": len(jobs),
            **counts, "elapsedSeconds": round(time.perf_counter() - started, 3), "results": results,
            "batchKind": batch_kind, "pipelineId": pipeline_id, "executionMode": str(execution_mode or "LIVE").upper(),
            "nonMutating": False,
            "liveApiExecution": True, "autoCompleteMissing": True,
            "autoGenAgentLimit": AUTOGEN_MAX_STABLE_AGENTS, "agentFramework": "AUTOGEN", "autoGenApi": "AgentChat", "autoGenVersion": AUTOGEN_REQUIRED_VERSION, "apiParallelism": "DEPENDENCY_SAFE_AUTOMATIC",
        }
        batch_dir = self.run_root / batch_id
        batch_reports = batch_dir / "reports"
        try:
            batch_reports.mkdir(parents=True, exist_ok=True)
            report_meta = []
            for r in results:
                report_name = r.get("htmlReport") or r.get("sourceReportName") or ""
                report_html = ""
                try:
                    if r.get("persistentHtmlReport") and r.get("persistentReportDirectory"):
                        candidate = Path(str(r.get("persistentReportDirectory"))) / str(r.get("persistentHtmlReport"))
                    elif r.get("htmlReport") and r.get("reportDirectory"):
                        candidate = Path(str(r.get("reportDirectory"))) / str(r.get("htmlReport"))
                    else:
                        candidate = None
                    if candidate is not None and candidate.exists() and candidate.is_file():
                        report_html = candidate.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    report_html = ""
                report_meta.append({"jobId": r.get("jobId"), "reportName": report_name, "reportHtml": report_html})
            combined_name = f"HIP_parallel_final_report_{_safe(batch_id)}.html"
            combined_path = batch_reports / combined_name
            combined_path.write_text(render_parallel_batch_html(summary, report_meta), encoding="utf-8")
            summary["htmlReport"] = combined_name
            for job in jobs:
                config_id = str(job.get("configurationId") or "")
                if not config_id or config_id == "reference:uhal":
                    continue
                try:
                    config = self.store.get_configuration(config_id)
                    target_reports = Path(config["workspace"]) / "reports"
                    target_reports.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(combined_path, target_reports / combined_name)
                except Exception:
                    pass
        except Exception as exc:
            # A report write problem must not change the API execution verdict.
            summary["reportWarning"] = f"{type(exc).__name__}: {exc}"
        self._publish(batch_id, {"type": "batch.completed", "summary": summary}, loop)
        return summary

    def start_batch(self, job_ids: Iterable[str], workers: int, loop: asyncio.AbstractEventLoop, *, batch_kind: str = "PARALLEL", preflight_all: bool = False, stop_on_error: bool = False, pipeline_id: str = "") -> Dict[str, Any]:
        wanted = [str(x) for x in job_ids if str(x).strip()]
        queue = {str(x.get("jobId")): x for x in self.list_queue()}
        jobs: List[Dict[str, Any]] = []
        for job_id in wanted:
            item = queue.get(job_id)
            if not item:
                raise ValueError(f"Unknown queued configuration: {job_id}")
            if not item.get("ready"):
                raise ValueError(f"Configuration {job_id} is not ready.")
            jobs.append(item)
        if not jobs:
            raise ValueError("Select at least one validated configuration.")
        batch_kind = str(batch_kind or "PARALLEL").upper()
        execution_mode = "PIPELINE_LIVE" if batch_kind == "PIPELINE" else "LIVE"

        # V92: each customer/instance is owned by a fresh Microsoft AutoGen AgentChat 0.7.5
        # AssistantAgent. Production observations show 1-4 concurrent agents
        # are stable and 5 produces HTTP 429, so the server never schedules more
        # than four agents at once. Any number of payloads are drained in waves
        # of <=4. Inside each agent, dependency-ready HIP APIs fan out in parallel.
        requested_workers = max(1, int(workers))
        if batch_kind == "PIPELINE":
            workers = 1
            preflight_all = True
            stop_on_error = True
        else:
            workers = max(1, min(requested_workers, AUTOGEN_MAX_STABLE_AGENTS, len(jobs)))
        batch_id = datetime.now().strftime("batch_%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
        batch_dir = self.run_root / batch_id
        batch_dir.mkdir(parents=True, exist_ok=False)
        record = {
            "batchId": batch_id, "status": "QUEUED", "parallelWorkers": workers,
            "configurationCount": len(jobs), "createdAt": datetime.now(timezone.utc).isoformat(),
            "events": [], "results": [], "batchKind": batch_kind, "pipelineId": pipeline_id,
            "executionMode": execution_mode, "nonMutating": False,
            "liveApiExecution": True, "autoCompleteMissing": True,
            "preflightAll": bool(preflight_all), "stopOnError": bool(stop_on_error),
            "requestedWorkers": requested_workers,
            "autoGenAgentLimit": AUTOGEN_MAX_STABLE_AGENTS, "agentFramework": "AUTOGEN",
            "autoGenApi": "AgentChat", "autoGenVersion": AUTOGEN_REQUIRED_VERSION,
            "knownUnstableAgentCount": AUTOGEN_KNOWN_UNSTABLE_AT, "knownUnstableReason": "HTTP 429",
            "apiParallelism": "DEPENDENCY_SAFE_AUTOMATIC",
            "jobs": {str(job.get("jobId")): {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "status": "QUEUED"} for job in jobs},
        }
        with self._lock:
            self._batch_state[batch_id] = record
            self._batch_stop[batch_id] = threading.Event()
            for job in jobs:
                self._job_stop[(batch_id, str(job.get("jobId")))] = threading.Event()
        self._persist_batch_best_effort(batch_id, record)

        def cancelled_row(job: Dict[str, Any], reason: str = "Stopped by user") -> Dict[str, Any]:
            return {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "CANCELLED", "agentVerdict": "CANCELLED", "error": reason, "elapsedSeconds": 0}

        def runner() -> None:
            started = time.perf_counter()
            results: List[Dict[str, Any]] = []
            self._publish(batch_id, {"type": "batch.started", "batchId": batch_id, "parallelWorkers": workers, "configurationCount": len(jobs), "startedAt": datetime.now(timezone.utc).isoformat(), "batchKind": batch_kind, "executionMode": execution_mode, "nonMutating": False, "liveApiExecution": True, "autoCompleteMissing": True, "autoGenAgentLimit": AUTOGEN_MAX_STABLE_AGENTS, "agentFramework": "AUTOGEN", "autoGenApi": "AgentChat", "autoGenVersion": AUTOGEN_REQUIRED_VERSION, "apiParallelism": "DEPENDENCY_SAFE_AUTOMATIC"}, loop)
            if preflight_all:
                self._publish(batch_id, {"type": "batch.preflight_all_started", "batchId": batch_id, "configurationCount": len(jobs)}, loop)
                preflight_failed = False
                for index, job in enumerate(jobs):
                    if self._batch_stop_event(batch_id).is_set():
                        for remaining in jobs[index:]:
                            row = cancelled_row(remaining, "Pipeline stopped before execution.")
                            results.append(row); self._publish(batch_id, {"type": "job.cancelled", **row}, loop)
                        return self._finalize_batch(batch_id, jobs, results, workers, started, loop, batch_kind=batch_kind, pipeline_id=pipeline_id, execution_mode=execution_mode)
                    try:
                        self._preflight_only_one(batch_id, job, loop)
                    except ParallelCancelled as exc:
                        row = cancelled_row(job, str(exc)); results.append(row); self._publish(batch_id, {"type": "job.cancelled", **row}, loop); preflight_failed = True; break
                    except Exception as exc:
                        failed = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "BLOCKED", "agentVerdict": "BLOCKED", "error": f"Preflight-all gate: {type(exc).__name__}: {exc}", "elapsedSeconds": 0}
                        results.append(failed); self._publish(batch_id, {"type": "job.completed", **failed}, loop); preflight_failed = True; break
                if preflight_failed:
                    done = {str(r.get("jobId")) for r in results}
                    for job in jobs:
                        if str(job.get("jobId")) in done:
                            continue
                        skipped = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "SKIPPED", "agentVerdict": "SKIPPED", "error": "Pipeline did not start because every payload/preflight must pass before the first LIVE API call.", "elapsedSeconds": 0}
                        results.append(skipped); self._publish(batch_id, {"type": "job.completed", **skipped}, loop)
                    return self._finalize_batch(batch_id, jobs, results, workers, started, loop, batch_kind=batch_kind, pipeline_id=pipeline_id, execution_mode=execution_mode)
                self._publish(batch_id, {"type": "batch.preflight_all_passed", "batchId": batch_id, "configurationCount": len(jobs)}, loop)

            if batch_kind == "PIPELINE":
                for index, job in enumerate(jobs):
                    if self._batch_stop_event(batch_id).is_set():
                        for remaining in jobs[index:]:
                            row = cancelled_row(remaining, "Pipeline stopped by user.")
                            results.append(row); self._publish(batch_id, {"type": "job.cancelled", **row}, loop)
                        break
                    try:
                        result = self._run_autogen_agent(batch_id, job, loop, execution_mode=execution_mode)
                    except ParallelCancelled as exc:
                        result = cancelled_row(job, str(exc)); self._publish(batch_id, {"type": "job.cancelled", **result}, loop)
                    except ParallelBlocked as exc:
                        result = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "BLOCKED", "agentVerdict": "BLOCKED", "error": str(exc), "elapsedSeconds": 0, "blockerDiagnostic": redact_sensitive(exc.diagnostic), "attentionItems": [redact_sensitive(exc.diagnostic)] if exc.diagnostic else [], "executionMode": execution_mode}
                        self._publish(batch_id, {"type": "job.completed", **result}, loop)
                    except Exception as exc:
                        diagnostic = _preflight_diagnostic("execution", f"{type(exc).__name__}: {exc}")
                        result = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "BLOCKED", "agentVerdict": "BLOCKED", "error": f"{type(exc).__name__}: {exc}", "elapsedSeconds": 0, "blockerDiagnostic": diagnostic, "attentionItems": [diagnostic], "executionMode": execution_mode}
                        self._publish(batch_id, {"type": "job.completed", **result}, loop)
                    results.append(result)
                    if stop_on_error and str(result.get("status") or "").upper() not in {"PASS", "WARNING"}:
                        for remaining in jobs[index + 1:]:
                            skipped = {"jobId": remaining.get("jobId"), "label": remaining.get("label"), "customer": remaining.get("customer"), "flow": remaining.get("flow"), "status": "SKIPPED", "agentVerdict": "SKIPPED", "error": "Pipeline stopped after an earlier stage did not pass.", "elapsedSeconds": 0}
                            results.append(skipped); self._publish(batch_id, {"type": "job.completed", **skipped}, loop)
                        break
            else:
                def execute_wave(wave_jobs: List[Dict[str, Any]], wave_workers: int) -> List[Dict[str, Any]]:
                    wave_results: List[Dict[str, Any]] = []
                    with ThreadPoolExecutor(max_workers=wave_workers, thread_name_prefix="autogen-hip-agent") as pool:
                        futures = {pool.submit(self._run_autogen_agent, batch_id, job, loop, execution_mode): job for job in wave_jobs}
                        for future in as_completed(futures):
                            job = futures[future]
                            try:
                                wave_results.append(future.result())
                            except ParallelCancelled as exc:
                                row = cancelled_row(job, str(exc)); wave_results.append(row); self._publish(batch_id, {"type": "job.cancelled", **row}, loop)
                            except ParallelBlocked as exc:
                                failed = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "BLOCKED", "agentVerdict": "BLOCKED", "error": str(exc), "elapsedSeconds": 0, "blockerDiagnostic": redact_sensitive(exc.diagnostic), "attentionItems": [redact_sensitive(exc.diagnostic)] if exc.diagnostic else [], "executionMode": execution_mode}
                                wave_results.append(failed); self._publish(batch_id, {"type": "job.completed", **failed}, loop)
                            except Exception as exc:
                                diagnostic = _preflight_diagnostic("execution", f"{type(exc).__name__}: {exc}")
                                failed = {"jobId": job.get("jobId"), "label": job.get("label"), "customer": job.get("customer"), "flow": job.get("flow"), "status": "BLOCKED", "agentVerdict": "BLOCKED", "error": f"{type(exc).__name__}: {exc}", "elapsedSeconds": 0, "blockerDiagnostic": diagnostic, "attentionItems": [diagnostic], "executionMode": execution_mode}
                                wave_results.append(failed); self._publish(batch_id, {"type": "job.completed", **failed}, loop)
                    return wave_results

                results.extend(execute_wave(jobs, workers))
            self._finalize_batch(batch_id, jobs, results, workers, started, loop, batch_kind=batch_kind, pipeline_id=pipeline_id, execution_mode=execution_mode)

        threading.Thread(target=runner, name=f"parallel-{batch_id}", daemon=True).start()
        return record

    def batch_report_path(self, batch_id: str) -> Path | None:
        safe = _safe(batch_id)
        reports = (self.run_root / safe / "reports").resolve()
        candidates = sorted(reports.glob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True) if reports.exists() else []
        return candidates[0] if candidates else None

    def get_batch(self, batch_id: str) -> Dict[str, Any]:
        return self._current_batch(batch_id)

    def list_batches(self) -> List[Dict[str, Any]]:
        rows: Dict[str, Dict[str, Any]] = {}
        with self._lock:
            for batch_id, record in self._batch_state.items():
                rows[batch_id] = json.loads(json.dumps(record, default=str))
        for folder in sorted(self.run_root.iterdir(), reverse=True):
            if folder.is_dir() and folder.name not in rows:
                record = _json_read(folder / "summary.json", {})
                if record:
                    rows[folder.name] = record
        return sorted(rows.values(), key=lambda r: str(r.get("createdAt") or r.get("batchId") or ""), reverse=True)
