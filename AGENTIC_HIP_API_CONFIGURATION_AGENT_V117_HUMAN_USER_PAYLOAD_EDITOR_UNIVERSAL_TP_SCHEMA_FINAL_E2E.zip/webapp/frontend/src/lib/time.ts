export function formatDuration(secondsValue?:number|null):string{
  const seconds=Math.max(0,Number(secondsValue||0));
  if(!Number.isFinite(seconds))return '—';
  if(seconds<1)return `${Math.round(seconds*1000)} ms`;
  if(seconds<60)return seconds<10?`${seconds.toFixed(2)} s`:`${seconds.toFixed(1)} s`;
  const total=Math.round(seconds);
  const hours=Math.floor(total/3600);
  const minutes=Math.floor((total%3600)/60);
  const secs=total%60;
  if(hours>0)return `${hours}h ${String(minutes).padStart(2,'0')}m ${String(secs).padStart(2,'0')}s`;
  return `${minutes}m ${String(secs).padStart(2,'0')}s`;
}

export function formatDurationMs(msValue?:number|null):string{
  return formatDuration(Number(msValue||0)/1000);
}
