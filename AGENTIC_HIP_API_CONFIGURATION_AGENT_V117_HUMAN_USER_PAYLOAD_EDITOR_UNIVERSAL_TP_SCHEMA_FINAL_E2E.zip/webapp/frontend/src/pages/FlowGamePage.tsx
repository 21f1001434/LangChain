import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ReactFlow, Background, Controls, MiniMap, Panel, addEdge, useEdgesState, useNodesState,
  MarkerType, type Connection, type Edge, type Node, type ReactFlowInstance
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Boxes, CirclePlay, Eraser, LayoutTemplate, Save, Sparkles, WandSparkles, ShieldCheck, Activity, Link2, CheckCircle2, AlertTriangle, Square, PanelLeft, PanelRight, Maximize2, Search } from 'lucide-react';
import type { ApiFlowNodeData, Bootstrap, Configuration, EdgeMapping, FlowPreflight, FlowTemplate, ParallelSource, SerializableEdge, SerializableNode, SuggestedMapping } from '../types';
import { ApiNode } from '../components/ApiNode';
import { NodeInspector } from '../components/NodeInspector';
import { EdgeInspector } from '../components/EdgeInspector';
import { ConfigurationFixModal } from '../components/ConfigurationFixModal';
import { api } from '../lib/api';
import { formatDurationMs } from '../lib/time';

type HipNode = Node<ApiFlowNodeData, 'apiNode'>;
type HipEdgeData = { mappings: EdgeMapping[]; resolvedMappings?:Array<Record<string,unknown>> };
type HipEdge = Edge<HipEdgeData>;
const nodeTypes = { apiNode: ApiNode };

function templateNodes(template: FlowTemplate, catalog: Bootstrap['api_catalog']): HipNode[] {
  return template.nodes.map(n => {
    const meta = catalog.find(x=>x.key===n.api_key);
    return { id:n.id, type:'apiNode', position:{x:n.x,y:n.y}, data:{
      apiKey:n.api_key,label:n.label||meta?.label||n.api_key,group:meta?.group||'API',status:n.enabled===false?'SKIPPED':'READY',requestOverride:{},
      enabled:n.enabled!==false,stopOnBlocked:n.stop_on_blocked!==false,waitAfterSeconds:n.wait_after_seconds||0,overrideMode:'merge',approvalRequired:n.approval_required===true,approvalMessage:n.approval_message||'',retries:[]
    } };
  });
}
function templateEdges(template: FlowTemplate): HipEdge[] { return template.edges.map(e=>({id:e.id,source:e.source,target:e.target,label:e.label,animated:true,type:'smoothstep',className:'hip-flow-edge hip-flow-edge-idle',markerEnd:{type:MarkerType.ArrowClosed},data:{mappings:e.mappings||[]}})); }

function isUhal(active: Configuration | null){return String(active?.customer||active?.name||'').toUpperCase().replace(/[^A-Z0-9]/g,'')==='UHAUL'}

function canonicalFlowType(active: Configuration | null): 'Translation'|'Passthrough'|null {
  if(!active) return null;
  if(isUhal(active)) return 'Translation';
  if(active.resolved_flow_type) return active.resolved_flow_type;
  if(active.flow_type==='Translation'||active.flow_type==='Passthrough') return active.flow_type;
  const input:any = active.input_json || {};
  if(Object.prototype.hasOwnProperty.call(input,'requires_data_map')) return input.requires_data_map ? 'Translation' : 'Passthrough';
  return null;
}

function bestTemplate(bootstrap: Bootstrap, active: Configuration | null, initialTemplate?: FlowTemplate | null): FlowTemplate | null {
  if(initialTemplate && !(isUhal(active)&&initialTemplate.flow_type==='Passthrough')) return initialTemplate;
  if(!active) return bootstrap.templates[0] || null;
  if(isUhal(active)){const approved=bootstrap.templates.find(t=>t.id==='builtin-uhal-outbound-856-translation-approved');if(approved)return approved;}
  const generated = bootstrap.templates.find(t=>t.source_configuration_id===active.id);
  if(generated && !(isUhal(active)&&generated.flow_type==='Passthrough')) return generated;
  const resolved = canonicalFlowType(active);
  // Auto is intentionally left blank until the Input Builder has deterministically
  // resolved Translation vs Passthrough. Never assume Translation.
  if(!resolved) return null;
  return bootstrap.templates.find(t=>t.direction===active.direction && t.transaction_code===active.transaction_code && t.flow_type===resolved)
    || bootstrap.templates.find(t=>t.direction===active.direction && t.flow_type===resolved)
    || null;
}

function applyEffectiveRequests(nds:HipNode[],rows:any[]):HipNode[]{
  return nds.map(n=>{const r=rows.find((x:any)=>x.stepKey===n.data.apiKey);if(!r)return n;const request=r.payload??r.params??{};const status:any=r.contractStatus==='BLOCKED'?'NEEDS_INPUT':r.contractStatus==='READY'?'VALIDATED':r.applicable===false?'SKIPPED':'READY';return {...n,data:{...n.data,payload:request,generatedRequest:request,status,response:r.error?{error:r.error}:n.data.response,agentCheck:undefined,validation:r.contractValidation||{}}}});
}

export function FlowGamePage({ bootstrap, active, initialTemplate, onActive }: { bootstrap: Bootstrap; active: Configuration | null; initialTemplate?: FlowTemplate | null; onActive:(configuration:Configuration)=>void }) {
  const resolvedFlowType = canonicalFlowType(active);
  const defaultTemplate = bestTemplate(bootstrap, active, initialTemplate);
  const [nodes,setNodes,onNodesChange]=useNodesState<HipNode>(defaultTemplate?templateNodes(defaultTemplate,bootstrap.api_catalog):[]);
  const [edges,setEdges,onEdgesChange]=useEdgesState<HipEdge>(defaultTemplate?templateEdges(defaultTemplate):[]);
  const [instance,setInstance]=useState<ReactFlowInstance<HipNode, HipEdge>|null>(null);
  const [selected,setSelected]=useState<string|null>(null);
  const [selectedEdge,setSelectedEdge]=useState<string|null>(null);
  const [templateName,setTemplateName]=useState(defaultTemplate?.name||'My HIP Flow');
  const [executionId,setExecutionId]=useState('');
  const [message,setMessage]=useState(defaultTemplate?'Drag API blocks onto the board. Connections carry executable runtime mappings.':active?.flow_type==='Auto'?'Flow type is Auto. Build/validate the customer evidence first so the agent can resolve Translation vs Passthrough, or drag blocks manually.':'Drag API blocks onto the board. Connections carry executable runtime mappings.');
  const [preflight,setPreflight]=useState<FlowPreflight|null>(null);
  const [suggestions,setSuggestions]=useState<SuggestedMapping[]>([]);
  const [trace,setTrace]=useState<Array<Record<string,any>>>([]);
  const [busy,setBusy]=useState(false);
  const [nodeAction,setNodeAction]=useState<{id:string;action:'check'|'run'}|null>(null);
  const [blockFilter,setBlockFilter]=useState('');
  const [deckOpen,setDeckOpen]=useState(()=>typeof window==='undefined'||window.innerWidth>980);
  const [railOpen,setRailOpen]=useState(()=>typeof window==='undefined'||window.innerWidth>1320);
  const [customerSources,setCustomerSources]=useState<ParallelSource[]>([]);
  const [customerBusy,setCustomerBusy]=useState(false);
  const [repairSource,setRepairSource]=useState<ParallelSource|null>(null);
  const wrapper=useRef<HTMLDivElement>(null);
  const activeSourceId=active?.flow_source_id||active?.managed_reference_source||active?.id||'';
  useEffect(()=>{let cancelled=false;api.parallelSources().then(rows=>{if(!cancelled)setCustomerSources(rows)}).catch(()=>{});return()=>{cancelled=true}},[active?.id]);
  useEffect(()=>{
    const statusById=new Map(nodes.map(n=>[n.id,String(n.data.status||'READY').toUpperCase()]));
    setEdges(current=>current.map(edge=>{
      const sourceStatus=statusById.get(edge.source)||'READY';
      const targetStatus=statusById.get(edge.target)||'READY';
      const blocked=['BLOCKED','NEEDS_INPUT'].includes(sourceStatus)||['BLOCKED','NEEDS_INPUT'].includes(targetStatus);
      const activeEdge=['RUNNING','AWAITING_APPROVAL','RESUMED'].includes(sourceStatus)||['RUNNING','AWAITING_APPROVAL','RESUMED'].includes(targetStatus);
      const completed=['PASS','EXISTING'].includes(sourceStatus)&&['PASS','EXISTING','VALIDATED'].includes(targetStatus);
      const state=blocked?'blocked':activeEdge?'active':completed?'complete':'idle';
      return {...edge,animated:!blocked,className:`hip-flow-edge hip-flow-edge-${state}`,markerEnd:edge.markerEnd||{type:MarkerType.ArrowClosed}};
    }));
  },[nodes,setEdges]);
  useEffect(()=>{
    const transient = /selected · effective API payloads loaded|selected · switching the Flow Game|^Loaded .* flow · .*Loading this customer's effective API payloads|^Loading validated customer payload workspace/.test(message);
    if(!transient||customerBusy)return;
    const timer=window.setTimeout(()=>setMessage(''),3200);
    return()=>window.clearTimeout(timer);
  },[message,customerBusy]);
  useEffect(()=>{
    let cancelled=false;
    const next=bestTemplate(bootstrap,active,initialTemplate);
    const freshNodes=next?templateNodes(next,bootstrap.api_catalog):[];
    if(next){setNodes(freshNodes);setEdges(templateEdges(next));setTemplateName(next.name);setMessage(`Loaded ${active?.customer||active?.name||'customer'} flow · ${next.name}. Loading this customer's effective API payloads…`)}
    else{setNodes([]);setEdges([]);setTemplateName(active?`${active.customer||active.name} HIP Flow`:'My HIP Flow');setMessage(active?.flow_type==='Auto'?'Flow type is Auto. Build/validate the customer evidence first so the agent can resolve Translation vs Passthrough.':'Select a validated customer payload or drag blocks manually.')}
    setPreflight(null);setSuggestions([]);setTrace([]);setExecutionId('');setSelected(null);setSelectedEdge(null);
    if(active?.id&&active.input_built&&freshNodes.length){api.apiRequests(active.id).then(preview=>{if(cancelled)return;setNodes(current=>applyEffectiveRequests(current,preview.items||[]));setMessage(`${active.customer||active.name} selected · effective API payloads loaded. Run Agent preflight or check an individual block before LIVE.`)}).catch(e=>{if(!cancelled)setMessage(e.message)})}
    return()=>{cancelled=true};
  },[active?.id,initialTemplate?.id]);
  const selectedNode = selected ? nodes.find(n=>n.id===selected) : undefined;
  const edgeValue = selectedEdge ? edges.find(e=>e.id===selectedEdge) : undefined;
  const edgeSource = edgeValue ? nodes.find(n=>n.id===edgeValue.source)?.data.label || edgeValue.source : '';
  const edgeTarget = edgeValue ? nodes.find(n=>n.id===edgeValue.target)?.data.label || edgeValue.target : '';

  const connect=useCallback((params:Connection)=>setEdges(eds=>addEdge({
    ...params,id:`edge-${params.source}-${params.target}-${crypto.randomUUID().slice(0,6)}`,animated:true,type:'smoothstep',className:'hip-flow-edge hip-flow-edge-idle',markerEnd:{type:MarkerType.ArrowClosed},data:{mappings:[]}
  },eds)),[setEdges]);
  const onDrop=useCallback((event:React.DragEvent)=>{
    event.preventDefault(); if(!instance) return; const apiKey=event.dataTransfer.getData('application/hip-api'); if(!apiKey)return;
    const meta=bootstrap.api_catalog.find(x=>x.key===apiKey); if(!meta)return;
    const position=instance.screenToFlowPosition({x:event.clientX,y:event.clientY});
    const id=`${apiKey}-${crypto.randomUUID().slice(0,6)}`;
    setNodes(nds=>[...nds,{id,type:'apiNode',position,data:{apiKey,label:meta.label,group:meta.group,status:'READY',requestOverride:{},enabled:true,stopOnBlocked:true,waitAfterSeconds:0,overrideMode:'merge',approvalRequired:false,approvalMessage:'',retries:[]}}]);
    setPreflight(null);
  },[instance,bootstrap.api_catalog,setNodes]);
  const serialize = () => ({
    id:'', name:templateName, direction:active?.direction||'Outbound', transaction_code:active?.transaction_code||'850', flow_type:resolvedFlowType||active?.flow_type||'Auto', template_id:'',
    nodes:nodes.map(n=>({id:n.id,api_key:n.data.apiKey,label:n.data.label,x:n.position.x,y:n.position.y,enabled:n.data.enabled!==false,stop_on_blocked:n.data.stopOnBlocked!==false,wait_after_seconds:Number(n.data.waitAfterSeconds||0),override_mode:'merge',request_override:{},approval_required:n.data.approvalRequired===true,approval_message:String(n.data.approvalMessage||'')} as SerializableNode)),
    edges:edges.map(e=>({id:e.id,source:e.source,target:e.target,label:String(e.label||''),mappings:e.data?.mappings||[]} as SerializableEdge))
  });
  const hydrateFlow=(flow:any)=>{
    const faux:FlowTemplate={...flow,id:flow.id||'',description:'',variables:[],tags:[],version:1,builtin:false};
    setNodes(templateNodes(faux,bootstrap.api_catalog));setEdges(templateEdges(faux));setPreflight(null);setSelected(null);setSelectedEdge(null);
  };
  const loadPayloadsFor=async(configuration:Configuration,quiet=false)=>{const preview=await api.apiRequests(configuration.id);setNodes(nds=>applyEffectiveRequests(nds,preview.items||[]));if(!quiet)setMessage(`Loaded ${configuration.customer||configuration.name} effective requests. Click a block to inspect or run it.`);return preview};
  const loadPayloads=async()=>{ if(!active){setMessage('Build or select a configuration first.');return} try{setBusy(true);await loadPayloadsFor(active);}catch(e:any){setMessage(e.message)}finally{setBusy(false)} };
  const selectCustomerPayload=async(sourceId:string)=>{
    if(!sourceId)return;
    const source=customerSources.find(row=>row.sourceId===sourceId);
    if(source&&!source.validated){
      setRepairSource(source);
      setMessage(`${source.customer} needs attention. The agent has opened the exact issue so you can fix it here.`);
      return;
    }
    if(sourceId===activeSourceId)return;
    try{
      setCustomerBusy(true);setMessage('Loading validated customer payload workspace…');
      const configuration=await api.materializeFlowSource(sourceId);
      onActive(configuration);
      setMessage(`${configuration.customer||configuration.name} selected · switching the Flow Game to this validated payload set…`);
      const refreshed=await api.parallelSources();setCustomerSources(refreshed);
    }catch(e:any){if(source)setRepairSource(source);setMessage(e.message)}finally{setCustomerBusy(false)}
  };
  const runPreflight=async()=>{if(!active){setMessage('Build and validate a configuration first.');return}try{setBusy(true);const result=await api.preflightFlow(active.id,serialize());setPreflight(result);setSuggestions(result.suggestedMappings||[]);const contracts=new Map((result.contractValidation?.items||[]).map((x:any)=>[x.nodeId,x]));setNodes(nds=>nds.map(n=>{const c:any=contracts.get(n.id);const p=result.nodePreviews?.[n.id]||{};return {...n,data:{...n.data,status:n.data.enabled===false?'SKIPPED':c?.valid?'VALIDATED':'NEEDS_INPUT',generatedRequest:c?.request?.payload??c?.request?.params??p.payload??p.params??n.data.generatedRequest,validation:c?.contractValidation??c??{},response:c?.error?{error:c.error}:n.data.response}}}));setMessage(result.readyForLive?`Agent preflight PASS · ${result.executionOrder.length} executable blocks · ready for LIVE.`:`Preflight needs attention · ${result.errors.length} graph errors · ${(result.contractValidation?.items||[]).filter((x:any)=>!x.valid).length} request blockers.`);}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  const autoFix=async()=>{if(!active){setMessage('Select a configuration first.');return}try{setBusy(true);const result=await api.autofixFlow(active.id,serialize());hydrateFlow(result.flow);setSuggestions(result.after?.suggestedMappings||[]);setMessage(`Agent applied ${result.fixesApplied?.length||0} safe graph fixes. Run preflight again before LIVE execution.`);}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  const saveTemplate=async()=>{ try{const flow=serialize();await api.saveTemplate({name:templateName,description:'Saved from the Agentic HIP API Flow Game',direction:flow.direction,transaction_code:flow.transaction_code,flow_type:flow.flow_type,nodes:flow.nodes,edges:flow.edges,variables:['customer','direction','transaction_code','flow_type'],default_values:{customer:active?.customer||'',direction:active?.direction||'',transaction_code:active?.transaction_code||'',transaction_name:active?.transaction_name||'',flow_type:resolvedFlowType||active?.flow_type||'Auto'},source_configuration_id:active?.id||'',tags:['Custom','Phase 6']});setMessage('Template saved with block settings, approval gates and runtime connection mappings.');}catch(e:any){setMessage(e.message)} };
  const appendTrace=(event:Record<string,any>)=>setTrace(rows=>[...rows.slice(-199),event]);
  const approveStep=async(nodeId:string)=>{if(!executionId)return;try{await api.approveNode(executionId,nodeId);setMessage(`Approved ${nodeId}. The LIVE execution will continue.`);}catch(e:any){setMessage(e.message)}};
  const stopExecution=async()=>{if(!executionId)return;if(!confirm('Stop the current LIVE execution? Completed steps remain in execution history and can be resumed later.'))return;try{await api.cancelExecution(executionId);setMessage(`Execution ${executionId} cancelled. You can resume it from Operations.`);setBusy(false);}catch(e:any){setMessage(e.message)}};
  const run=async()=>{ if(!active){setMessage('Build or select a configuration first.');return} if(!active.validation?.ok){setMessage('Run agent validation in Build Configuration before LIVE execution.');return} try{
    setBusy(true);
    let checked=preflight;
    if(!checked?.readyForLive){
      checked=await api.preflightFlow(active.id,serialize());setPreflight(checked);setSuggestions(checked.suggestedMappings||[]);
      if(!checked.readyForLive){setMessage(`LIVE blocked by preflight · ${checked.errors.length} graph errors · ${(checked.contractValidation?.items||[]).filter((x:any)=>!x.valid).length} request blockers.`);setBusy(false);return}
      setMessage('Automatic preflight PASS. Ready for LIVE confirmation.');
    }
    if(!confirm(`LIVE execution will run ${checked.executionOrder.length} validated API block(s) against HIP. Continue?`)){setBusy(false);return}
    setTrace([]);setNodes(nds=>nds.map(n=>({...n,data:{...n.data,retries:[],resolvedMappings:[],timing:undefined,response:undefined,output:undefined,verdict:undefined,status:n.data.enabled===false?'SKIPPED':'READY'}})));
    const record=await api.startExecution(active.id,serialize());setExecutionId(record.id);setMessage(`Execution ${record.id} started.`);const protocol=location.protocol==='https:'?'wss':'ws';const ws=new WebSocket(`${protocol}://${location.host}/ws/executions/${record.id}`);
    ws.onmessage=(ev)=>{const event=JSON.parse(ev.data);appendTrace(event);if(event.nodeId){setNodes(nds=>nds.map(n=>{if(n.id!==event.nodeId)return n;const retries=[...(n.data.retries||[])];if(event.type==='node.retry'||event.type==='node.http_attempt')retries.push(event);const status=event.type==='node.awaiting_approval'?'AWAITING_APPROVAL':event.type==='node.approval_received'?'RUNNING':event.type==='node.resumed'?'RESUMED':event.type==='node.started'?'RUNNING':event.type==='node.completed'?(event.verdict?.outcome==='EXISTING'?'EXISTING':event.verdict?.verdict==='PASS'?'PASS':event.verdict?.verdict==='WARNING'?'WARNING':'BLOCKED'):event.type==='node.failed'||event.type==='node.mapping_blocked'?'BLOCKED':event.type==='node.skipped'?'SKIPPED':n.data.status;return {...n,data:{...n.data,status,payload:event.request?.payload??event.request?.params??n.data.payload,generatedRequest:event.request?.payload??event.request?.params??n.data.generatedRequest,response:event.result?.response_preview??event.error??n.data.response,output:event.output??n.data.output,approvalMessage:event.message??n.data.approvalMessage,verdict:event.verdict??n.data.verdict,timing:event.timing??n.data.timing,retries,resolvedMappings:event.resolvedMappings??n.data.resolvedMappings}}}));if(event.incomingEdgeIds){setEdges(eds=>eds.map(edge=>event.incomingEdgeIds.includes(edge.id)?{...edge,animated:true,data:{...(edge.data||{mappings:[]}),resolvedMappings:event.resolvedMappings||[]}}:edge));}}if(event.type==='execution.completed'){setMessage(`Execution ${event.status||'completed'} in ${formatDurationMs(event.elapsedMs||0)} · ${event.completedNodes||0}/${event.nodeCount||nodes.length} blocks completed.`);setBusy(false)}if(event.type==='node.awaiting_approval'){setSelected(event.nodeId);setMessage(`Approval required at ${event.nodeId}: ${event.message||'review the request and approve to continue'}`)}if(event.type==='execution.blocked')setMessage(`Execution blocked at ${event.nodeId}: ${event.reason||'review node details'}`);if(event.type==='execution.cancelled'){setMessage('LIVE execution cancelled. Completed steps are preserved for resume.');setBusy(false)}if(event.type==='execution.error'){setMessage('Execution process failed. Review the execution trace.');setBusy(false)}};
    ws.onerror=()=>{setMessage('Execution WebSocket disconnected. The backend execution record is still available in Operations.');setBusy(false)};
  }catch(e:any){setMessage(e.message);setBusy(false)} };
  const applyBlockCheck=(id:string,result:any)=>{
    const request=result?.request?.payload??result?.request?.params;
    setNodes(nds=>nds.map(n=>n.id===id?{...n,data:{...n.data,agentCheck:result?.agentCheck,validation:result?.contractValidation??{},generatedRequest:request??n.data.generatedRequest,status:result?.applicable===false?'SKIPPED':result?.readyForLive?'VALIDATED':'NEEDS_INPUT'}}:n));
  };
  const checkIndividualBlock=async(id:string)=>{
    if(!active){setMessage('Build or select a configuration first.');return}
    try{
      setNodeAction({id,action:'check'});
      const result=await api.preflightFlowNode(active.id,id,serialize());
      applyBlockCheck(id,result);
      setSelected(id);
      setMessage(result.agentCheck?.summary||'Individual block agent check completed.');
    }catch(e:any){setMessage(e.message)}finally{setNodeAction(null)}
  };
  const runIndividualBlock=async(id:string)=>{
    if(!active){setMessage('Build or select a configuration first.');return}
    try{
      setNodeAction({id,action:'run'});
      const checked=await api.preflightFlowNode(active.id,id,serialize());
      applyBlockCheck(id,checked);
      if(!checked.readyForLive){setMessage(checked.agentCheck?.summary||'Agent check blocked this individual API block.');return}
      const node=nodes.find(n=>n.id===id);
      if(!confirm(`LIVE individual API call: ${node?.data.label||id}. The agent check just passed and will be repeated server-side immediately before the call. Continue?`))return;
      setNodes(nds=>nds.map(n=>n.id===id?{...n,data:{...n.data,status:'RUNNING'}}:n));
      const result=await api.executeFlowNode(active.id,id,serialize());
      const verdict=String(result.verdict?.verdict||'').toUpperCase();
      const outcome=String(result.verdict?.outcome||'').toUpperCase();
      const status:any=outcome==='EXISTING'?'EXISTING':verdict==='PASS'?'PASS':verdict==='WARNING'?'WARNING':'BLOCKED';
      setNodes(nds=>nds.map(n=>n.id===id?{...n,data:{...n.data,status,agentCheck:result.agentCheck,generatedRequest:result.request?.payload??result.request?.params??n.data.generatedRequest,response:result.response??result.result?.response_preview??n.data.response,output:result.output??n.data.output,verdict:result.verdict??n.data.verdict,timing:result.timing??n.data.timing,retries:result.attempts??n.data.retries}}:n));
      setSelected(id);
      setMessage(`${node?.data.label||id} · ${status} · ${result.verdict?.reason||result.verdict?.outcome||'LIVE call completed'} · ${formatDurationMs(result.timing?.totalMs||0)}`);
    }catch(e:any){setNodes(nds=>nds.map(n=>n.id===id?{...n,data:{...n.data,status:'BLOCKED'}}:n));setMessage(e.message)}finally{setNodeAction(null)}
  };
  const applyTemplate=(t:FlowTemplate)=>{if(isUhal(active)&&t.flow_type==='Passthrough'){setMessage('U-HAUL Passthrough is not an approved flow. Use the validated U-HAUL Outbound 856 Translation template.');return;}setNodes(templateNodes(t,bootstrap.api_catalog));setEdges(templateEdges(t));setTemplateName(t.name);setPreflight(null);setSuggestions([]);setMessage(`Loaded template: ${t.name}`)};
  const updateEdgeMappings=(mappings:EdgeMapping[])=>{if(!selectedEdge)return;setEdges(eds=>eds.map(e=>e.id===selectedEdge?{...e,data:{...(e.data||{mappings:[]}),mappings}}:e));setPreflight(null)};
  const applyEdgeSuggestion=(mapping:EdgeMapping)=>{if(!selectedEdge)return;setEdges(eds=>eds.map(e=>e.id===selectedEdge?{...e,data:{...(e.data||{mappings:[]}),mappings:[...((e.data?.mappings)||[]),mapping]}}:e));setPreflight(null)};
  const traceSummary=useMemo(()=>({attempts:trace.filter(x=>x.type==='node.http_attempt').length,retries:trace.filter(x=>x.type==='node.retry').length,completed:trace.filter(x=>x.type==='node.completed').length}),[trace]);
  const flowSummary=useMemo(()=>({checked:nodes.filter(n=>!!n.data.agentCheck).length,validated:nodes.filter(n=>n.data.status==='VALIDATED').length,passed:nodes.filter(n=>['PASS','EXISTING'].includes(n.data.status)).length,warnings:nodes.filter(n=>n.data.status==='WARNING').length,blocked:nodes.filter(n=>['BLOCKED','NEEDS_INPUT'].includes(n.data.status)).length}),[nodes]);
  const activeCustomerSource=customerSources.find(source=>source.sourceId===activeSourceId||source.configurationId===active?.id);
  return <div className={`flow-page fade-in ${deckOpen?'deck-open':'deck-closed'} ${railOpen?'rail-open':'rail-closed'}`}>
    <section className="flow-customer-bar">
      <div className="flow-customer-copy"><span className="eyebrow">CUSTOMER PAYLOAD</span><strong>{active?.customer||active?.name||'No customer selected'}</strong><small>Validated payload workspace · customer payloads and edits stay isolated.</small></div>
      <div className="flow-customer-picker"><label htmlFor="flow-customer-source">Validated customer / configuration</label><select id="flow-customer-source" value={activeSourceId} disabled={customerBusy||busy} onChange={e=>selectCustomerPayload(e.target.value)}><option value="">Select customer configuration…</option>{customerSources.map(source=><option key={source.sourceId} value={source.sourceId}>{source.customer} · {source.direction||'—'} {source.transactionCode||''} · {source.flowType||'—'}{source.approvedReference?' · DEV APPROVED · TEST READY':''}{!source.approvedReference&&!source.validated?' · NEEDS FIX':''}</option>)}</select>{customerBusy?<span className="customer-loading">Loading payloads…</span>:activeCustomerSource&&!activeCustomerSource.approvedReference&&!activeCustomerSource.validated?<button className="customer-not-ready customer-fix-inline" onClick={()=>setRepairSource(activeCustomerSource)}>Fix configuration</button>:<span className={active?.validation?.ok?'customer-ready':'customer-not-ready'}>{activeCustomerSource?.approvedReference?'DEV APPROVED · TEST READY':active?.validation?.ok?'Ready for Flow Game':'Select a customer that needs attention to fix it here'}</span>}</div>
    </section>
    <header className="flow-toolbar"><div><span className="eyebrow"><Sparkles size={14}/> API Flow Game · Phase 6</span><input value={templateName} onChange={e=>setTemplateName(e.target.value)}/><span>{active?`${active.direction} · ${active.transaction_code} · ${active.flow_type==='Auto'?(resolvedFlowType?`Auto → ${resolvedFlowType}`:'Auto · unresolved'):active.flow_type}`:'No active configuration'}</span></div><div className="flow-toolbar-actions"><button className="primary flow-live-button" disabled={busy} onClick={run}><CirclePlay size={17}/>Run LIVE</button>{busy&&executionId&&<button className="danger" onClick={stopExecution}><Square size={16}/>Stop LIVE</button>}<button className="secondary" disabled={busy} onClick={runPreflight}><Activity size={16}/>Agent preflight</button><button className="secondary" disabled={busy} onClick={loadPayloads}><ShieldCheck size={16}/>Load payloads</button><button className="secondary" disabled={busy} onClick={autoFix}><WandSparkles size={16}/>Agent auto-wire</button><button className="secondary" onClick={saveTemplate}><Save size={16}/>Save template</button><button className="ghost icon-label" title="Show or hide API block deck" onClick={()=>setDeckOpen(v=>!v)}><PanelLeft size={16}/>{deckOpen?'Hide blocks':'Blocks'}</button><button className="ghost icon-label" title="Fit all workflow blocks on the canvas" onClick={()=>instance?.fitView({padding:.2,duration:300})}><Maximize2 size={16}/>Fit</button><button className="ghost icon-label" title="Show or hide quick templates" onClick={()=>setRailOpen(v=>!v)}><PanelRight size={16}/>{railOpen?'Hide templates':'Templates'}</button><button className="ghost" onClick={()=>{setNodes([]);setEdges([]);setPreflight(null)}}><Eraser size={16}/>Clear</button></div></header>
    <div className="phase3-statusbar flow-healthbar">
      <span className={preflight?.readyForLive?'preflight-pill pass':'preflight-pill'}>{preflight?.readyForLive?<><CheckCircle2 size={13}/>FLOW PREFLIGHT PASS</>:<><AlertTriangle size={13}/>FLOW PREFLIGHT REQUIRED</>}</span>
      <span className="health-chip"><ShieldCheck size={13}/><b>{flowSummary.checked}</b> block checks</span>
      <span className="health-chip health-good"><CheckCircle2 size={13}/><b>{flowSummary.validated+flowSummary.passed}</b> ready/pass</span>
      {flowSummary.warnings>0&&<span className="health-chip health-warn"><AlertTriangle size={13}/><b>{flowSummary.warnings}</b> warning</span>}
      {flowSummary.blocked>0&&<span className="health-chip health-bad"><AlertTriangle size={13}/><b>{flowSummary.blocked}</b> needs attention</span>}
      <span className="health-chip"><Link2 size={13}/><b>{edges.reduce((n,e)=>n+(e.data?.mappings?.length||0),0)}</b> runtime mappings</span>
      <span className="health-chip"><Activity size={13}/><b>{traceSummary.completed}</b> completed · {traceSummary.attempts} HTTP · {traceSummary.retries} retries</span>
    </div>
    <div className="flow-shell">
      <aside className="block-deck"><div className="deck-title"><Boxes size={18}/><div><strong>API Block Deck</strong><span>Drag any API multiple times</span></div></div><label className="deck-search"><Search size={13}/><input value={blockFilter} onChange={e=>setBlockFilter(e.target.value)} placeholder="Find API block..."/></label>{['Validation','Foundation','Configuration','Orchestration','Verification'].map(group=>{const items=bootstrap.api_catalog.filter(x=>x.group===group&&(!blockFilter||`${x.label} ${x.key}`.toLowerCase().includes(blockFilter.toLowerCase())));return items.length?<div key={group} className="deck-group"><span>{group}</span>{items.map(apiItem=><div className="deck-block" draggable key={apiItem.key} onDragStart={e=>{e.dataTransfer.setData('application/hip-api',apiItem.key);e.dataTransfer.effectAllowed='copy'}}><b>{apiItem.label}</b><small>{apiItem.key}</small></div>)}</div>:null})}</aside>
      <div className="flow-board" ref={wrapper} onDrop={onDrop} onDragOver={e=>{e.preventDefault();e.dataTransfer.dropEffect='copy'}}>
        <ReactFlow<HipNode, HipEdge> nodes={nodes} edges={edges} onNodesChange={changes=>{onNodesChange(changes);setPreflight(null)}} onEdgesChange={changes=>{onEdgesChange(changes);setPreflight(null)}} onConnect={connect} nodeTypes={nodeTypes} onInit={setInstance} fitView onNodeClick={(_,node)=>{setSelected(node.id);setSelectedEdge(null)}} onEdgeClick={(_,edge)=>{setSelectedEdge(edge.id);setSelected(null)}} onPaneClick={()=>{setSelected(null);setSelectedEdge(null)}} deleteKeyCode={['Backspace','Delete']}>
          <Background gap={24} size={1}/><Controls/><MiniMap zoomable pannable/>{message&&<Panel position="top-left" className="canvas-hud transient-hud" aria-live="polite"><WandSparkles size={14}/>{message}</Panel>}<Panel position="bottom-center" className="canvas-footer"><span>{nodes.length} blocks</span><span>{edges.length} connections</span>{executionId&&<span>Execution {executionId}</span>}</Panel>
        </ReactFlow>
      </div>
      <aside className="template-rail"><div className="rail-title"><LayoutTemplate size={17}/><strong>Quick templates</strong></div>{bootstrap.templates.slice(0,10).map(t=><button key={t.id} onClick={()=>applyTemplate(t)}><strong>{t.name}</strong><span>v{t.version}{t.builtin?' · built-in':''}</span></button>)}{trace.length>0&&<details className="trace-mini"><summary>Live execution trace ({trace.length})</summary>{trace.slice(-12).reverse().map((e,i)=><div key={i}><b>{e.type}</b><span>{e.nodeId||e.status||''}</span></div>)}</details>}</aside>
    </div>
    <NodeInspector node={selectedNode?{id:selectedNode.id,data:selectedNode.data}:null} onClose={()=>setSelected(null)} onApprove={approveStep} actionBusy={nodeAction?.id===selectedNode?.id?(nodeAction?.action??''):''} onAgentCheck={checkIndividualBlock} onRunLive={runIndividualBlock} onOverride={(_id,_value)=>setMessage('API payload mutation is disabled. Update Build Configuration values and revalidate instead.')} onSettings={(id,value)=>{setNodes(nds=>nds.map(n=>n.id===id?{...n,data:{...n.data,...value,agentCheck:undefined,status:value.enabled===false?'SKIPPED':'READY'}}:n));setPreflight(null)}}/>
    <EdgeInspector edge={edgeValue?{id:edgeValue.id,mappings:edgeValue.data?.mappings||[]}:null} sourceLabel={edgeSource} targetLabel={edgeTarget} suggestions={suggestions} onClose={()=>setSelectedEdge(null)} onChange={updateEdgeMappings} onApplySuggestion={applyEdgeSuggestion}/>
    {repairSource&&<ConfigurationFixModal source={repairSource} onClose={()=>setRepairSource(null)} onResolved={async(configuration)=>{onActive(configuration);const refreshed=await api.parallelSources();setCustomerSources(refreshed);setRepairSource(null);setMessage(`${configuration.customer||configuration.name} is fixed, validated and loaded into the Flow Game.`)}}/>}
  </div>;
}
