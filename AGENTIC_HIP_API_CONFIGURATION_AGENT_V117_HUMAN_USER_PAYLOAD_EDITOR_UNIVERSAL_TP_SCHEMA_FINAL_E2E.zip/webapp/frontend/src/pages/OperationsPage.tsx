import { useEffect, useMemo, useState } from 'react';
import { Activity, Download, GitCompareArrows, History, PauseCircle, PlayCircle, RefreshCw, ShieldCheck, TimerReset } from 'lucide-react';
import type { Configuration, ExecutionComparison, ExecutionRecord } from '../types';
import { api } from '../lib/api';
import { formatDurationMs } from '../lib/time';

const terminal = new Set(['PASS','BLOCKED','ERROR','CANCELLED']);
const resumable = new Set(['BLOCKED','ERROR','CANCELLED']);

function nodeTimeline(record:ExecutionRecord|null){
  const rows:Record<string,any>[]=[];
  for(const e of record?.events||[]){
    if(!e.nodeId)continue;
    if(['node.completed','node.failed','node.mapping_blocked','node.resumed','node.awaiting_approval'].includes(String(e.type))) rows.push(e);
  }
  return rows;
}

export function OperationsPage({active}:{active:Configuration|null}){
  const [runs,setRuns]=useState<ExecutionRecord[]>([]),[selected,setSelected]=useState<ExecutionRecord|null>(null),[left,setLeft]=useState(''),[right,setRight]=useState(''),[comparison,setComparison]=useState<ExecutionComparison|null>(null),[message,setMessage]=useState('Execution history, recovery and comparison live here.'),[busy,setBusy]=useState(false);
  const load=async()=>{if(!active){setRuns([]);setSelected(null);return}try{setBusy(true);const rows=await api.executions(active.id);setRuns(rows);if(rows.length&&!selected)setSelected(rows[0]);setMessage(`${rows.length} execution record${rows.length===1?'':'s'} loaded for ${active.name}.`)}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  useEffect(()=>{setSelected(null);setComparison(null);setLeft('');setRight('');load()},[active?.id]);
  const timeline=useMemo(()=>nodeTimeline(selected),[selected]);
  const resume=async(id:string)=>{if(!confirm('Resume this LIVE execution from its last successful checkpoint? Previously successful API nodes will not be re-sent.'))return;try{setBusy(true);const r=await api.resumeExecution(id);setMessage(`Resume execution ${r.id} started from ${id}.`);await load()}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  const cancel=async(id:string)=>{if(!confirm('Cancel this LIVE execution? Completed steps will remain available for resume.'))return;try{setBusy(true);await api.cancelExecution(id);setMessage(`Execution ${id} cancelled.`);await load()}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  const compare=async()=>{if(!left||!right||left===right){setMessage('Choose two different executions to compare.');return}try{setBusy(true);setComparison(await api.compareExecutions(left,right));setMessage(`Compared ${left} with ${right}.`)}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  if(!active)return <div className="page fade-in"><div className="empty-state"><History size={30}/><h2>No active configuration</h2><p>Build or select a configuration to see its operational history.</p></div></div>;
  return <div className="page fade-in operations-page">
    <div className="page-title"><div><span className="eyebrow"><Activity size={14}/> Execution Control Center</span><h1>Operations</h1><p>Monitor LIVE runs, stop safely, resume from checkpoints, and compare execution results.</p></div><button className="secondary" disabled={busy} onClick={load}><RefreshCw size={15}/>Refresh</button></div>
    <div className="notice-card"><ShieldCheck size={17}/><div><strong>{active.name}</strong><span>{active.direction} · {active.transaction_code} · {active.flow_type} · {message}</span></div></div>
    <div className="operations-grid">
      <section className="panel-card"><div className="section-head"><div><span className="eyebrow">Execution history</span><h2>Recent runs</h2></div><span className="count-pill">{runs.length}</span></div>
        <div className="run-list">{runs.length===0?<div className="empty-mini">No API Flow executions yet.</div>:runs.map(r=><button key={r.id} className={selected?.id===r.id?'run-row active':'run-row'} onClick={()=>setSelected(r)}><div><strong>{r.id}</strong><span>{new Date(r.created_at).toLocaleString()}</span></div><div><b className={`mini-status st-${String(r.status).toLowerCase()}`}>{r.status}</b><span>{r.elapsedMs?formatDurationMs(r.elapsedMs):'—'}</span></div></button>)}</div>
      </section>
      <section className="panel-card"><div className="section-head"><div><span className="eyebrow">Selected run</span><h2>{selected?.id||'Choose an execution'}</h2></div>{selected&&<span className="count-pill">{selected.status}</span>}</div>
        {selected&&<><div className="operation-actions">{!terminal.has(String(selected.status).toUpperCase())&&<button className="danger" onClick={()=>cancel(selected.id)}><PauseCircle size={15}/>Stop LIVE</button>}{resumable.has(String(selected.status).toUpperCase())&&<button className="primary" onClick={()=>resume(selected.id)}><PlayCircle size={15}/>Resume from checkpoint</button>}<button className="secondary" onClick={()=>api.exportExecutionEvidence(selected.id)}><Download size={15}/>Evidence bundle</button></div>
          {selected.resume_from_execution&&<div className="resume-banner"><TimerReset size={15}/>Resumed from <b>{selected.resume_from_execution}</b> · {selected.resumed_node_count||0} successful nodes restored</div>}
          <div className="timeline-list">{timeline.map((e,i)=><div className="timeline-row" key={`${e.type}-${e.nodeId}-${i}`}><div className="timeline-dot"/><div><strong>{e.nodeId}</strong><span>{e.type.replace('node.','')}</span></div><div><b>{e.verdict?.outcome||e.verdict?.verdict||e.status||''}</b><span>{e.timing?.totalMs!=null?`${(e.timing.totalMs/1000).toFixed(2)}s`:''}</span></div></div>)}</div>
          <details className="raw-execution"><summary>Full execution evidence</summary><pre>{JSON.stringify(selected,null,2)}</pre></details></>}
      </section>
    </div>
    <section className="panel-card compare-card"><div className="section-head"><div><span className="eyebrow"><GitCompareArrows size={13}/> Run comparison</span><h2>Compare verdicts and timing</h2></div></div>
      <div className="compare-controls"><select value={left} onChange={e=>setLeft(e.target.value)}><option value="">Left execution</option>{runs.map(r=><option key={r.id} value={r.id}>{r.id} · {r.status}</option>)}</select><span>vs</span><select value={right} onChange={e=>setRight(e.target.value)}><option value="">Right execution</option>{runs.map(r=><option key={r.id} value={r.id}>{r.id} · {r.status}</option>)}</select><button className="secondary" onClick={compare}><GitCompareArrows size={15}/>Compare</button></div>
      {comparison&&<><div className="compare-summary"><span>Left {formatDurationMs(comparison.left.elapsedMs)}</span><b>{comparison.elapsedMsDelta>=0?'+':''}{formatDurationMs(Math.abs(comparison.elapsedMsDelta))}</b><span>Right {formatDurationMs(comparison.right.elapsedMs)}</span></div><div className="compare-table"><div className="compare-head"><b>API block</b><b>Left</b><b>Right</b><b>Δ time</b></div>{comparison.nodes.map(row=><div className={row.statusChanged?'compare-row changed':'compare-row'} key={row.nodeId}><strong>{row.nodeId}</strong><span>{String(row.left?.status||'—')}</span><span>{String(row.right?.status||'—')}</span><span>{row.totalMsDelta>=0?'+':''}{formatDurationMs(Math.abs(row.totalMsDelta))}</span></div>)}</div></>}
    </section>
  </div>;
}
