import { useEffect, useState } from 'react';
import { Download, FileBarChart2, FileJson2, RefreshCcw } from 'lucide-react';
import type { Configuration, ReportRecord } from '../types';
import { api } from '../lib/api';

export function ReportsPage({active}:{active:Configuration|null}){
  const [rows,setRows]=useState<ReportRecord[]>([]),[selected,setSelected]=useState<any>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
  const refresh=async()=>{if(active)setRows(await api.reports(active.id))};
  useEffect(()=>{refresh().catch(()=>{});setSelected(null)},[active?.id]);
  const open=async(row:ReportRecord)=>{if(!active)return;setBusy(true);setMessage('');try{setSelected(await api.report(active.id,row.name))}catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}};
  const download=async()=>{if(!active||!selected?.name)return;setBusy(true);try{await api.downloadReport(active.id,selected.name)}catch(e:any){setMessage(e.message||String(e))}finally{setBusy(false)}};
  return <div className="page fade-in">
    <div className="page-title"><div><span className="eyebrow"><FileBarChart2 size={14}/> Runtime evidence</span><h1>Reports</h1><p>Review execution evidence, validation output, timing, requests, responses, and audit history.</p></div><button className="ghost" disabled={busy} onClick={()=>refresh().catch((e:any)=>setMessage(e.message))}><RefreshCcw size={16}/>Refresh</button></div>
    {message&&<div className="agent-message"><span>{message}</span></div>}
    {!active?<div className="empty-state large">Select or build a configuration first.</div>:<div className="report-layout">
      <section className="section-card report-list"><div className="section-head"><h2>{active.customer||active.name}</h2><span>{rows.length} files</span></div>{rows.length===0?<div className="empty-state">No reports generated yet. Validate or execute the flow first.</div>:rows.map(r=><button key={r.name} onClick={()=>open(r)} className={selected?.name===r.name?'selected':''}><FileJson2 size={17}/><div><strong>{r.name}</strong><span>{r.kind.toUpperCase()} · {(r.size/1024).toFixed(1)} KB</span></div></button>)}</section>
      <section className="section-card report-viewer"><div className="section-head"><h2>{selected?.name||'Select a report'}</h2><div className="button-row">{busy&&<span>Loading…</span>}{selected&&<button className="secondary" disabled={busy} onClick={download}><Download size={15}/>Download</button>}</div></div>
        {selected?.format==='html'?<iframe key={selected.name} className="html-report-frame report-content-enter" sandbox="" srcDoc={String(selected.content||'')} title={selected.name}/>:selected?<pre key={selected.name} className="report-content-enter">{typeof selected.content==='string'?selected.content:JSON.stringify(selected.content,null,2)}</pre>:<div className="chat-empty"><FileBarChart2 size={38}/><p>Choose a generated report to inspect it.</p></div>}
      </section>
    </div>}
  </div>
}
