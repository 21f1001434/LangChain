import { Handle, Position, type Node, type NodeProps } from '@xyflow/react';
import { AlertTriangle, Check, CircleAlert, Clock3, PlugZap, Star, ShieldCheck, SkipForward, RotateCw, TimerReset } from 'lucide-react';
import type { ApiFlowNodeData, FlowNodeAgentCheck } from '../types';
import { StatusBadge } from './StatusBadge';
import { formatDurationMs } from '../lib/time';

const iconFor = (status: string) => {
  if (status === 'PASS') return <Check size={15}/>;
  if (status === 'WARNING') return <AlertTriangle size={15}/>;
  if (status === 'EXISTING') return <Star size={15}/>;
  if (status === 'VALIDATED') return <ShieldCheck size={15}/>;
  if (status === 'SKIPPED') return <SkipForward size={15}/>;
  if (status === 'AWAITING_APPROVAL') return <ShieldCheck size={15}/>;
  if (status === 'RESUMED') return <TimerReset size={15}/>;
  if (status === 'BLOCKED' || status === 'NEEDS_INPUT') return <CircleAlert size={15}/>;
  return <PlugZap size={15}/>;
};

type ApiFlowNode = Node<ApiFlowNodeData, 'apiNode'>;

export function ApiNode({ data: node, selected }: NodeProps<ApiFlowNode>) {
  const retryCount = node.retries?.length || 0;
  const agentCheck = node.agentCheck as FlowNodeAgentCheck | undefined;
  return <div className={`api-node ${selected ? 'selected' : ''} node-${node.status.toLowerCase()} ${node.enabled===false?'node-disabled':''}`}>
    <Handle type="target" position={Position.Left} className="node-handle"/>
    <div className="api-node-top">
      <div className="api-node-icon">{iconFor(node.status)}</div>
      <div className="api-node-title"><span>{node.group}</span><strong>{node.label}</strong></div>
      <StatusBadge status={node.status}/>
    </div>
    <div className="api-node-bottom">
      <span><Clock3 size={12}/>{node.timing?.totalMs ? formatDurationMs(node.timing.totalMs) : 'not run'}</span>
      {agentCheck&&<span className={agentCheck.ready?'node-agent-mini ready':'node-agent-mini blocked'}><ShieldCheck size={10}/>{agentCheck.ready?'checked':'fix'}</span>}
      {retryCount>0&&<span className="retry-chip"><RotateCw size={10}/>{retryCount}</span>}
      <span className="node-key">{node.apiKey}</span>
    </div>
    <Handle type="source" position={Position.Right} className="node-handle"/>
  </div>;
}
