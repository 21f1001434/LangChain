import { AlertTriangle, CheckCircle2, ChevronRight, Menu, Radio, ShieldCheck } from 'lucide-react';
import type { Configuration } from '../types';
import type { PageKey } from './Sidebar';

const labels:Record<PageKey,{group:string;label:string}>={
  dashboard:{group:'Studio',label:'Home'},
  workspace:{group:'Configure',label:'Configuration Library'},
  builder:{group:'Configure',label:'Build Configuration'},
  flow:{group:'Configure',label:'API Flow Game'},
  testing:{group:'Configure',label:'API Testing Area'},
  parallel:{group:'Run & observe',label:'Execute'},
  operations:{group:'Run & observe',label:'Operations'},
  reports:{group:'Run & observe',label:'Reports'},
  templates:{group:'Knowledge',label:'Templates'},
  learn:{group:'Knowledge',label:'Learn'},
  system:{group:'Administration',label:'System & Connections'},
};

function configName(config:Configuration){
  return config.name||config.customer||config.id||'Active configuration';
}
function isApprovedUhal(config:Configuration|null|undefined){
  return Boolean(config&&(config.approved_reference||config.managed_reference_source==='reference:uhal'));
}
function optionLabel(config:Configuration){
  const customer=config.customer||config.name||'Customer';
  const tx=[config.direction,config.transaction_code,config.resolved_flow_type||config.flow_type].filter(Boolean).join(' ');
  const state=isApprovedUhal(config)?'DEV APPROVED':config.validation?.ok?'VALIDATED':config.status==='NEEDS_INPUT'||config.status==='VALIDATION_BLOCKED'?'NEEDS ATTENTION':config.status||'DRAFT';
  return `${customer}${tx?` · ${tx}`:''} · ${state}`;
}

export function AppTopbar({page,active,configs,onMenu,onOpenWorkspace,onSelectCustomer}:{page:PageKey;active:Configuration|null;configs:Configuration[];onMenu:()=>void;onOpenWorkspace:()=>void;onSelectCustomer:(c:Configuration)=>void}){
  const meta=labels[page];
  const approved=isApprovedUhal(active);
  const validated=Boolean(approved||active?.validation?.ok);
  return <header className="app-topbar">
    <div className="topbar-left">
      <button className="mobile-menu-button" onClick={onMenu} aria-label="Open navigation"><Menu size={19}/></button>
      <div className="topbar-path"><span>{meta.group}</span><ChevronRight size={13}/><strong>{meta.label}</strong></div>
    </div>
    <div className="topbar-right">
      {active?<div key={active.id} className="global-customer-picker has-selection context-enter">
        <span className={`context-status ${validated?'validated':'attention'}`}>{approved?<ShieldCheck size={13}/>:validated?<CheckCircle2 size={13}/>:<AlertTriangle size={13}/>}</span>
        <label htmlFor="global-active-customer"><small>Active customer</small></label>
        <select id="global-active-customer" value={active.id} onChange={e=>{const next=configs.find(c=>c.id===e.target.value);if(next)onSelectCustomer(next)}} aria-label="Select active customer configuration">
          {configs.map(c=><option key={c.id} value={c.id}>{optionLabel(c)}</option>)}
        </select>
        <button className="global-customer-open" onClick={onOpenWorkspace} title={`Open ${configName(active)} in Configuration Library`} aria-label="Open active configuration in Configuration Library"><ChevronRight size={15}/></button>
      </div>:<div className="global-customer-picker is-empty">
        <span className="context-status attention"><AlertTriangle size={13}/></span>
        <label htmlFor="global-active-customer"><small>Active customer</small></label>
        <select id="global-active-customer" value="" onChange={e=>{const next=configs.find(c=>c.id===e.target.value);if(next)onSelectCustomer(next)}} aria-label="Select active customer configuration">
          <option value="">Select customer…</option>
          {configs.map(c=><option key={c.id} value={c.id}>{optionLabel(c)}</option>)}
        </select>
      </div>}
      <div className="environment-pill"><Radio size={12}/><span>LIVE</span></div>
    </div>
  </header>;
}
