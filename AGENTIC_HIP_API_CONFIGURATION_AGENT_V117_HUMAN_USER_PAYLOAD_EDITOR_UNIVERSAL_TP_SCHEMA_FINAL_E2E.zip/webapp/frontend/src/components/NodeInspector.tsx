import { AlertTriangle, Braces, CheckCircle2, Clock3, FileOutput, Link2, LoaderCircle, MessageSquareText, Play, RotateCw, Send, Settings2, ShieldCheck, X } from 'lucide-react';
import type { ApiFlowNodeData, FlowNodeAgentCheck } from '../types';
import { useState } from 'react';

export function NodeInspector({ node, onClose, onOverride, onSettings, onApprove, onAgentCheck, onRunLive, actionBusy }: {
  node: { id: string; data: ApiFlowNodeData } | null;
  onClose: () => void;
  onOverride: (id: string, value: Record<string, unknown>) => void;
  onSettings: (id: string, value: Partial<ApiFlowNodeData>) => void;
  onApprove?: (id: string) => void;
  onAgentCheck?: (id: string) => void;
  onRunLive?: (id: string) => void;
  actionBusy?: ''|'check'|'run';
}) {
  const [tab, setTab] = useState<'payload'|'response'|'agent'|'output'|'timing'|'settings'>('payload');
  if (!node) return null;
  const d = node.data;
  const agentCheck = d.agentCheck as FlowNodeAgentCheck | undefined;
  const tabs = [
    ['payload','Payload',Braces], ['response','Response',MessageSquareText], ['agent','Agent',Send], ['output','Output',FileOutput], ['timing','Timing',Clock3], ['settings','Settings',Settings2]
  ] as const;
  const value = tab === 'response' ? d.response : tab === 'agent' ? (d.verdict ?? d.agentCheck) : tab === 'output' ? d.output : d.timing;
  return <aside className="inspector">
    <div className="inspector-head"><div><span>{d.group}</span><strong>{d.label}</strong></div><button onClick={onClose}><X size={18}/></button></div>
    <div className="node-live-actions">
      <div className="node-live-copy">
        <span>INDIVIDUAL BLOCK</span>
        <strong>{agentCheck?.ready?'Agent checked · ready for LIVE':'Agent check required before LIVE'}</strong>
        <small>{agentCheck?.summary||'The agent will validate the latest effective payload, customer validation state, API applicability and standalone runtime dependencies.'}</small>
      </div>
      <div className="node-live-buttons">
        <button className="secondary" disabled={!!actionBusy||d.enabled===false} onClick={()=>onAgentCheck?.(node.id)}>{actionBusy==='check'?<LoaderCircle className="spin" size={14}/>:<ShieldCheck size={14}/>}Agent check</button>
        <button className="danger node-run-live" disabled={!!actionBusy||d.enabled===false} onClick={()=>onRunLive?.(node.id)}>{actionBusy==='run'?<LoaderCircle className="spin" size={14}/>:<Play size={14}/>}Check & run this block LIVE</button>
      </div>
      {agentCheck&&<div className={`node-agent-check ${agentCheck.ready?'ready':'blocked'}`}>
        <div className="node-agent-check-head">{agentCheck.ready?<CheckCircle2 size={15}/>:<AlertTriangle size={15}/>}<strong>{agentCheck.verdict}</strong><span>{agentCheck.checks.filter(x=>x.status==='PASS').length}/{agentCheck.checks.length} checks passed</span></div>
        <div className="node-agent-check-list">{agentCheck.checks.map(item=><div key={item.key} className={`check-${item.status.toLowerCase()}`}><b>{item.status}</b><span><strong>{item.label}</strong><small>{item.reason}</small></span></div>)}</div>
      </div>}
    </div>
    <div className="inspector-tabs">{tabs.map(([key,label,Icon]) => <button key={key} className={tab===key?'active':''} onClick={()=>setTab(key)}><Icon size={14}/>{label}</button>)}</div>
    <div className="inspector-body">
      {d.status==='AWAITING_APPROVAL'&&<div className="approval-callout"><ShieldCheck size={16}/><div><strong>LIVE approval required</strong><span>{String(d.approvalMessage||'Review this API request before continuing.')}</span></div><button className="primary" onClick={()=>onApprove?.(node.id)}>Approve step</button></div>}
      {tab === 'payload' && <>
        <p className="hint">Immutable API policy: this block uses the developer-approved canonical request. Ad-hoc payload/parameter mutation is disabled. Change customer business values in Build Configuration, then revalidate; runtime edge mappings may only populate existing approved attributes.</p>
        <div className="inspector-section-title">Generated/effective request · read only</div>
        <pre className="json-view compact-json">{JSON.stringify(d.generatedRequest ?? d.payload ?? {}, null, 2)}</pre>
      </>}
      {tab === 'timing' && <>
        <pre className="json-view">{JSON.stringify(d.timing ?? {}, null, 2)}</pre>
        <div className="inspector-section-title"><RotateCw size={12}/> HTTP attempts / retries</div>
        <pre className="json-view compact-json">{JSON.stringify(d.retries ?? [], null, 2)}</pre>
        <div className="inspector-section-title"><Link2 size={12}/> Resolved connection mappings</div>
        <pre className="json-view compact-json">{JSON.stringify(d.resolvedMappings ?? [], null, 2)}</pre>
      </>}
      {tab === 'settings' && <div className="node-settings-grid">
        <label><span>Enabled</span><input type="checkbox" checked={d.enabled!==false} onChange={e=>onSettings(node.id,{enabled:e.target.checked})}/></label>
        <label><span>Stop flow if blocked</span><input type="checkbox" checked={d.stopOnBlocked!==false} onChange={e=>onSettings(node.id,{stopOnBlocked:e.target.checked})}/></label>
        <label><span>Manual approval before LIVE API</span><input type="checkbox" checked={d.approvalRequired===true} onChange={e=>onSettings(node.id,{approvalRequired:e.target.checked})}/></label>
        {d.approvalRequired&&<label className="wide-setting"><span>Approval message</span><input value={String(d.approvalMessage||'')} placeholder="Example: Approve Flow Deploy" onChange={e=>onSettings(node.id,{approvalMessage:e.target.value})}/></label>}
        <label><span>Wait after step (seconds)</span><input type="number" min="0" step="0.1" value={Number(d.waitAfterSeconds||0)} onChange={e=>onSettings(node.id,{waitAfterSeconds:Math.max(0,Number(e.target.value)||0)})}/></label>
      </div>}
      {!['payload','timing','settings'].includes(tab) && <pre className="json-view">{JSON.stringify(value ?? {}, null, 2)}</pre>}
    </div>
  </aside>;
}
