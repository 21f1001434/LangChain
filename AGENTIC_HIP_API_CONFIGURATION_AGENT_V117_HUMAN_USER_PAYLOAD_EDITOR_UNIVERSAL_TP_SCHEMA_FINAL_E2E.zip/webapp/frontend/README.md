# Agentic HIP Web Frontend — Phase 6

The frontend is the primary product UI. It includes Configuration Library, Input Builder evidence, API Testing Area, executable API Flow Game, Operations/recovery, Templates, Parallel Runs, Learn, Reports and System & Connections.

Development: `RUN_AGENTIC_HIP_DEV.bat`.
Production/default: `RUN_AGENTIC_HIP.bat` after `SETUP_AGENTIC_HIP.bat`.
