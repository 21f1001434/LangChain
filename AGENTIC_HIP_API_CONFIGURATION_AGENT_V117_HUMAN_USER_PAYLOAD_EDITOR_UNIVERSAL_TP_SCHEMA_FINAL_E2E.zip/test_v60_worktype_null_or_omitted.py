from pathlib import Path
import json

from payload_overrides import save_override
from run_agent import Runner
from api_pdf_ingestion import PdfApiKnowledgeBase


def _runner():
    return Runner(llm_enabled=False)


def test_generated_orchestration_payloads_omit_worktype():
    r = _runner()
    for step in ("source_tp", "target_tp", "flow_create", "flow_deploy"):
        req = r.preview_step_request(step)
        if req.get("applicable") is False:
            continue
        assert "workType" not in (req.get("payload") or {})


def test_full_payload_override_cannot_reintroduce_non_null_worktype(tmp_path):
    # Build a minimal override store test independent of the shipped workspace.
    from payload_overrides import PayloadOverrideStore
    base = {
        "group": "Orchestration",
        "api": "Flow orchestration create ONLY",
        "payload": {"flowName": "X", "user": {"userId": 1, "emailId": "a@b.com"}},
    }
    save_override(tmp_path, "flow_create", {
        "flowName": "X",
        "user": {"userId": 1, "emailId": "a@b.com"},
        "workType": {"id": 3419, "type": "SHOULD_NOT_BE_SENT"},
    }, request_kind="payload", mode="replace", edit_origin="USER")
    effective, _ = PayloadOverrideStore(tmp_path).apply("flow_create", base, {})
    assert "workType" not in effective["payload"]


def test_contract_accepts_worktype_null_but_rejects_object():
    store = PdfApiKnowledgeBase(Path.cwd())
    base = {
        "method": "POST",
        "url": "https://example/api/flows/orchestration/deploy",
        "headers": {"x-requester-id": "x"},
        "payload": {
            "flowName": "F",
            "flowVersion": "1.0",
            "environment": "DEV",
            "user": {"userId": 1, "emailId": "a@b.com"},
            "workType": None,
        },
    }
    ok = store.validate_request("orch_flow_deploy", base["method"], base["url"], base["headers"], payload=base["payload"])
    assert ok["valid"], ok
    bad = json.loads(json.dumps(base))
    bad["payload"]["workType"] = {"id": 4694}
    result = store.validate_request("orch_flow_deploy", bad["method"], bad["url"], bad["headers"], payload=bad["payload"])
    assert not result["valid"]
    assert any(i.get("field") == "workType" for i in result.get("errors", []))
