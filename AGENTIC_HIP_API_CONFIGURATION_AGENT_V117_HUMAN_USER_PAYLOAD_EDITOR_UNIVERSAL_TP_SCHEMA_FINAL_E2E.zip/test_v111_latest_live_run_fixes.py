import json
from pathlib import Path
from types import SimpleNamespace

import run_agent
from hip_naming import validate_hip_flow_name
from webapp.backend.app.parallel_manager import ParallelManager


def _rule_result():
    return run_agent.Result(
        13, "Rule", "Create mapping rule", "rule", "POST", "https://example/api/rule",
        "HIP", "rule", 500, "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 10, "", "{}",
        json.dumps({
            "error": True,
            "message": "Create failed",
            "detail": "A rule with the same name and version already exists in DEV.",
            "status": 500,
            "data": None,
        }), {}, "", "", "", "", ""
    )


def test_v111_queue_canonicalizes_stale_legrand_snapshot_before_live(tmp_path):
    root = tmp_path / "runtime"
    root.mkdir()
    source = tmp_path / "source"
    source.mkdir()
    old = "LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB"
    (source / "input.json").write_text(json.dumps({
        "customer": "LEGRAND_NEDERLAND",
        "profile_name": old,
        "objects": {"biz_flow": {"flow_details": {"business_flow_name": old}}},
    }), encoding="utf-8")
    manager = ParallelManager(SimpleNamespace(root=root))
    queued = manager.queue_configuration(
        {"workspace": str(source), "id": "cfg1", "customer": "LEGRAND_NEDERLAND"},
        {"ok": True, "requests": {}},
    )
    queued_input = json.loads((Path(queued["workspace"]) / "input.json").read_text(encoding="utf-8"))
    assert queued_input["profile_name"] == "LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB"
    assert validate_hip_flow_name(queued_input["profile_name"])["valid"] is True
    assert queued["queueCanonicalization"]["original"] == old
    assert queued["queueCanonicalization"]["effective"] == queued_input["profile_name"]


def test_v111_rule_parser_accepts_current_rules_portal_summary_shape():
    runner = run_agent.Runner(llm_enabled=False)
    name = runner.business["mappingRuleName"]
    body = {
        "data": [{
            "ruleName": name,
            "environments": [
                {"hipEnvironment": "DEV", "versions": [{"ruleId": 927, "version": 1.0}]},
                {"hipEnvironment": "PROD", "versions": []},
            ],
        }]
    }
    ids = runner._exact_rule_ids_from_read_response(
        body, rule_name=name, rule_version="1.0", environment="DEV", environment_scoped=False,
    )
    assert ids == [927]


def test_v111_rule_resolver_scans_paginated_current_live_summary_without_historical_id(monkeypatch):
    runner = run_agent.Runner(llm_enabled=False)
    name = runner.business["mappingRuleName"]
    calls = []

    class Resp:
        def __init__(self, body, status=200):
            self.status_code = status
            self._body = body
            self.headers = {"content-type": "application/json"}
        def json(self):
            return self._body

    def fake_request(**kwargs):
        calls.append(kwargs)
        url = kwargs["url"]
        params = kwargs.get("params") or {}
        if url.endswith("/details"):
            return Resp({"data": []}, 404)
        # Targeted summary forms deliberately return no match, reproducing V110.
        if any(k in params for k in ("ruleName", "search", "searchText")):
            return Resp({"data": []})
        # First broad page misses the U-HAUL row; second page finds the exact DEV identity.
        if params.get("page") == 1:
            return Resp({"data": [{
                "ruleName": name,
                "environments": [{"hipEnvironment": "DEV", "versions": [{"ruleId": 927, "version": 1.0}]}],
            }]})
        return Resp({"data": [{"ruleName": "OTHER", "hipEnvironment": "DEV", "ruleId": 1, "version": 1.0}]})

    monkeypatch.setattr(runner, "_request_with_retry", fake_request)
    result = _rule_result()
    assert runner.enforce_live_id_integrity("rule", result, require_dependency_ids=True) is True
    assert runner.rule_id() == 0
    assert calls == []
    assert "liveRuleIdResolution" not in result.extracted


def test_v111_build_identity_is_current():
    assert "v117" in run_agent.BUILD_ID
