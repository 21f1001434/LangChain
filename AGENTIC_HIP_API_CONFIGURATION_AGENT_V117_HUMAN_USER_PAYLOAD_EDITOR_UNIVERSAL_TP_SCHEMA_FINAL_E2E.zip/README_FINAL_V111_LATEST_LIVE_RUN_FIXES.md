# V111 — Latest U-HAUL + LEGRAND LIVE Run Fixes

## Latest rerun findings

The 2026-08-31 rerun proved V110 TP CREATE-audit handling is correct, but exposed two remaining upgrade/runtime gaps.

### LEGRAND
The queued customer snapshot still contained `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` (43 chars), so production preflight correctly stopped before any LIVE API call. V111 canonicalizes both newly queued and already-staged isolated input before final contract validation/request materialization. The effective Flow name is `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 chars). This never occurs after an API failure.

### U-HAUL
The canonical Rule POST ran and HIP returned EXISTING, but no `ruleId`. V110's first read attempts did not find the Rule, so Flow remained blocked by `LIVE_RULE_ID_UNRESOLVED`. V111 keeps the POST immutable and adds robust GET-only exact identity resolution:

- configured Rule details/summary read URLs;
- consolidated HIP Config Service Rule reads;
- legacy Dell Rule API read surface;
- Dell SecureLink portal Rule read surface;
- targeted name/environment queries first;
- bounded deterministic summary pagination if the target Rule is not on the first page;
- exact name + version + DEV match required;
- more than one exact ID is rejected as ambiguous;
- no packaged/historical ID is ever used.

Known Rules KB evidence shows the U-HAUL Rule is present in DEV and exposes a numeric Rule ID through the live Rules read inventory. That prior value is used only as regression-shape evidence and is never injected into runtime execution.

## Unchanged safety

- Rule POST payload remains developer-approved and immutable.
- No `documentTypeId`, `flowDefinitionId`, or `mapId` is added to Rule Create.
- No post-error Flow rename.
- No cross-step `EXISTING_REUSED` inference.
- Account/Partner/System upstream PCF 404 remains an external Dell platform error and is reported truthfully.
