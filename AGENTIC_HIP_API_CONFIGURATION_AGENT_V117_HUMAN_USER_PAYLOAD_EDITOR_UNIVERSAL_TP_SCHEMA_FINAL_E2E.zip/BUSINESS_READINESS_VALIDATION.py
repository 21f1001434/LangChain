#!/usr/bin/env python3
"""Non-mutating business-handoff smoke for HIP API Agent Studio V104.

This validator exercises the real FastAPI application against an isolated local
runtime directory. It never enables LIVE execution and never calls Dell HIP
mutation endpoints. Local CRUD is disposable test state only.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNTIME = Path(tempfile.mkdtemp(prefix="hip_v104_business_smoke_"))
os.environ["HIP_STUDIO_RUNTIME_ROOT"] = str(RUNTIME)
os.environ.setdefault("HIP_BACKEND_HOT_RELOAD", "0")

from fastapi.testclient import TestClient
from webapp.backend.app.main import app

checks=[]
def check(name, ok, detail=""):
    checks.append({"name":name,"ok":bool(ok),"detail":str(detail or "")})
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f": {detail}" if detail else ""))
    return bool(ok)

def j(resp):
    try:return resp.json()
    except Exception:return {}

def main():
    with TestClient(app) as c:
        r=c.get('/api/health'); check('Health endpoint',r.status_code==200 and j(r).get('ok') is True)
        r=c.get('/api/bootstrap'); boot=j(r); check('Bootstrap endpoint',r.status_code==200); check('Phase 6 bootstrap',boot.get('phase')==6)
        catalog=boot.get('api_catalog') or []; check('Exactly 18 reusable APIs',len(catalog)==18 and all(x.get('reusable') for x in catalog))
        check('Default deployment group hip-automation',boot.get('deployment_group')=='hip-automation')
        check('Interface catalogue available',len(boot.get('interfaces') or [])>=3)
        tx=boot.get('transactions') or {}; check('Direction editable',tx.get('editable_direction') is True)
        check('Inbound 850 offered','850' in ((((tx.get('directions') or {}).get('Inbound') or {}).get('suggested_transactions')) or []))
        out=set(((((tx.get('directions') or {}).get('Outbound') or {}).get('suggested_transactions')) or [])); check('Outbound 832/855/856 offered',{'832','855','856'}.issubset(out))
        r=c.get('/api/system/status'); check('System status endpoint',r.status_code==200 and j(r).get('ui')=='HIP API Agent Studio Web UI')

        r=c.get('/api/configurations'); rows=j(r); check('Configuration Library loads',r.status_code==200 and isinstance(rows,list))
        ref=next((x for x in rows if x.get('approved_reference') or x.get('managed_reference_source')=='reference:uhal'),None)
        check('Approved U-HAUL reference present',bool(ref))
        if not ref:
            raise SystemExit(2)
        cid=str(ref['id'])
        check('Approved U-HAUL immutable',bool(ref.get('immutable_reference') or ref.get('immutableReference')))
        check('Approved U-HAUL test ready',bool(ref.get('test_ready') or ref.get('testReady') or ref.get('approved_reference')))
        r=c.get(f'/api/configurations/{cid}'); detail=j(r); check('Approved configuration opens',r.status_code==200)
        inp=detail.get('input_json') or detail.get('input') or {}; objs=inp.get('objects') or {}; dm=objs.get('data_map') or {}
        check('U-HAUL is Translation/map flow',bool(inp.get('requires_data_map')))
        check('Customer MAP identifier present',bool(dm.get('map_identifier')))
        check('Customer MAP class present',bool(dm.get('map_class')))
        check('Customer MAP file present',bool(dm.get('map_data_file') or dm.get('map_file_name') or dm.get('map_file')))
        src=objs.get('source_transport_profile') or {}; tgt=objs.get('target_transport_profile') or {}
        check('Source deployment group normalized',src.get('deployment_group')=='hip-automation')
        check('Target deployment group normalized',tgt.get('deployment_group')=='hip-automation')

        r=c.get(f'/api/configurations/{cid}/api-requests'); reqs=j(r).get('items') or []; check('All 18 API requests preview',r.status_code==200 and len(reqs)==18)
        by={x.get('stepKey'):x for x in reqs if isinstance(x,dict)}
        mapreq=(by.get('map') or {}).get('payload') or {}; check('MAP identifier flows into API payload',mapreq.get('mapIdentifier')==dm.get('map_identifier'))
        check('MAP class flows into API payload',mapreq.get('mapClassName')==dm.get('map_class'))
        map_file=dm.get('map_data_file') or dm.get('map_file_name') or dm.get('map_file'); check('MAP file flows into API payload',not map_file or mapreq.get('mapFileName')==map_file)
        sreq=(by.get('source_tp') or {}).get('payload') or {}; treq=(by.get('target_tp') or {}).get('payload') or {}
        def group_name(payload):
            rows=payload.get('transportProfileDetails') or []
            return (rows[0] if rows else {}).get('deploymentGroupName')
        check('Source TP deploymentGroupName hip-automation',group_name(sreq)=='hip-automation')
        check('Target TP deploymentGroupName hip-automation',group_name(treq)=='hip-automation')

        r=c.post(f'/api/configurations/{cid}/api-tests/doctype_source/preflight',json={}); check('Document Type API preflight route works',r.status_code==200)
        r=c.post(f'/api/configurations/{cid}/api-tests/rule/preflight',json={}); rulepf=j(r)
        rule_payload=(by.get('rule') or {}).get('payload') or {}
        rule_actions=rule_payload.get('actions') or []
        rule_params=((rule_actions[0] if rule_actions else {}).get('params') or {})
        check('Standalone Rule preflight follows developer-approved contract',r.status_code==200 and rulepf.get('contractValid') is not False)
        check('Rule payload omits documentTypeId', 'documentTypeId' not in rule_payload and 'documentTypeId' not in rule_params)
        check('Rule payload omits mapId', 'mapId' not in rule_payload and 'mapId' not in rule_params)
        r=c.put(f'/api/configurations/{cid}/payload-overrides/account_source',json={'value':{'description':'MUTATE'}}); check('Ad-hoc payload edit without explicit human action is blocked',r.status_code==403)

        r=c.post(f'/api/configurations/{cid}/clone',json={'name':'Business Review Clone'}); clone=j(r); check('Approved reference clone works',r.status_code==200 and clone.get('id'))
        clone_id=str(clone.get('id') or '')
        r=c.patch(f'/api/configurations/{clone_id}',json={'name':'Business Review Clone Updated'}); check('Editable clone patch works',r.status_code==200 and j(r).get('name')=='Business Review Clone Updated')
        # V117: only an explicit HUMAN action may edit existing canonical values.
        r=c.get(f'/api/configurations/{clone_id}/api-requests'); clone_reqs=j(r).get('items') or []
        clone_by={x.get('stepKey'):x for x in clone_reqs if isinstance(x,dict)}
        account_payload=dict((clone_by.get('account_source') or {}).get('generatedPayload') or {})
        editable_key=next((k for k,v in account_payload.items() if isinstance(v,str)),None)
        if editable_key:
            account_payload[editable_key]='BUSINESS-HUMAN-EDIT'
            r=c.put(
                f'/api/configurations/{clone_id}/payload-overrides/account_source',
                headers={'X-HIP-Actor':'Business Human User','X-HIP-User-Action':'payload-value-edit-v1'},
                json={'value':account_payload,'request_kind':'payload','mode':'paths','note':'business readiness human value edit'},
            )
            check('Explicit human payload value edit works',r.status_code==200 and j(r).get('agentEditAllowed') is False and j(r).get('userEditAllowed') is True)
        else:
            check('Explicit human payload value edit works',False,'No editable scalar in account_source fixture')

        r=c.get(f'/api/configurations/{clone_id}/bundle'); bundle=r.content; check('Configuration bundle export works',r.status_code==200 and bundle[:2]==b'PK')
        files={'bundle':('business_bundle.zip',bundle,'application/zip')}
        r=c.post('/api/configuration-bundles/inspect',files=files); check('Configuration bundle inspect works',r.status_code==200 and bool(j(r)))
        r=c.post('/api/configuration-bundles/import',files={'bundle':('business_bundle.zip',bundle,'application/zip')}); check('Configuration bundle import works',r.status_code==200 and bool(j(r).get('id') or j(r).get('configuration')))

        r=c.get('/api/templates'); check('Template Library loads',r.status_code==200 and isinstance(j(r),list))
        tpl={'name':'Business Smoke Template','description':'non-mutating validation','direction':'Outbound','transaction_code':'856','flow_type':'Translation','nodes':[],'edges':[],'variables':[],'default_values':{},'tags':['business-smoke']}
        r=c.post('/api/templates',json=tpl); t=j(r); tid=str(t.get('id') or ''); check('Template create works',r.status_code==200 and bool(tid))
        if tid:
            r=c.get(f'/api/templates/{tid}/versions'); check('Template versions work',r.status_code==200 and isinstance(j(r),list))
            r=c.post(f'/api/templates/{tid}/clone',json={'name':'Business Smoke Template Copy'}); check('Template clone works',r.status_code==200 and bool(j(r).get('id')))
            r=c.post(f'/api/templates/{tid}/publish',json={'note':'smoke'}); check('Template publish works',r.status_code==200)
            r=c.post(f'/api/templates/{tid}/archive',json={'note':'smoke'}); check('Template archive works',r.status_code==200)
            r=c.delete(f'/api/templates/{tid}'); check('Template delete works',r.status_code==200)

        r=c.get('/api/parallel/sources'); sources=j(r); check('Parallel customer sources load',r.status_code==200 and any(x.get('sourceId')=='reference:uhal' for x in sources))
        r=c.post('/api/parallel/queue-sources',json={'source_ids':['reference:uhal']*3}); q=j(r); items=q.get('items') or []; check('Repeated customer queue creates 3 instances',r.status_code==200 and len(items)==3)
        labels=[str(x.get('instanceLabel') or x.get('label') or '') for x in items]; check('Repeated instance numbering created',any('1/3' in x for x in labels) and any('3/3' in x for x in labels))
        if len(items)==3:
            middle=str(items[1].get('jobId') or ''); r=c.delete(f'/api/parallel/queue/{middle}'); check('Single queue delete works',r.status_code==200 and j(r).get('deleted') is True)
            r=c.get('/api/parallel/queue'); queue=j(r); group=str(items[0].get('instanceGroupId') or items[0].get('instance_group_id') or '')
            related=[x for x in queue if (not group or str(x.get('instanceGroupId') or x.get('instance_group_id') or '')==group)]
            rel_labels=[str(x.get('instanceLabel') or x.get('label') or '') for x in related]
            check('Delete immediately renumbers remaining instances',any('1/2' in x for x in rel_labels) and any('2/2' in x for x in rel_labels))
            r=c.post('/api/parallel/queue/delete-many',json={'job_ids':[str(x.get('jobId') or '') for x in related]}); check('Bulk queue delete works',r.status_code==200)

        r=c.post('/api/pipelines',json={'name':'Business Smoke Pipeline','source_ids':['reference:uhal']}); pipe=j(r); pid=str(pipe.get('id') or ''); check('Pipeline create works',r.status_code==200 and bool(pid))
        if pid:
            r=c.post(f'/api/pipelines/{pid}/validate'); check('Pipeline validation works',r.status_code==200 and j(r).get('validation',{}).get('ok') is True)
            r=c.put(f'/api/pipelines/{pid}',json={'name':'Business Smoke Pipeline Updated','source_ids':['reference:uhal']}); check('Pipeline update works',r.status_code==200)
            r=c.post(f'/api/pipelines/{pid}/run',json={'confirm_live':False}); check('Pipeline cannot run without LIVE confirmation',r.status_code==400)
            r=c.delete(f'/api/pipelines/{pid}'); check('Pipeline delete works',r.status_code==200 and j(r).get('deleted') is True)

        flow={'id':'smoke','name':'Business Smoke Flow','direction':'Outbound','transaction_code':'856','flow_type':'Translation','nodes':[{'id':'n1','api_key':'doctype_source','label':'Source Document Type','x':0,'y':0,'enabled':True,'stop_on_blocked':True,'wait_after_seconds':0,'override_mode':'merge','request_override':{},'approval_required':False,'approval_message':''}],'edges':[],'template_id':''}
        r=c.post(f'/api/configurations/{cid}/flow/preflight',json=flow); check('Flow Game preflight works',r.status_code==200 and 'readyForLive' in j(r))
        r=c.post(f'/api/configurations/{cid}/flow/autofix',json=flow); check('Flow Game auto-fix works',r.status_code==200)
        r=c.post(f'/api/configurations/{cid}/flow/nodes/n1/preflight',json={'flow':flow,'confirm_live':False}); check('Individual block agent check works',r.status_code==200 and 'agentCheck' in j(r))
        r=c.post(f'/api/configurations/{cid}/flow/nodes/n1/execute',json={'flow':flow,'confirm_live':False}); check('Individual LIVE block requires confirmation',r.status_code==400)
        r=c.post('/api/executions',json={'configuration_id':cid,'flow':flow,'confirm_live':False}); check('Flow LIVE execution requires confirmation',r.status_code==400)
        r=c.post('/api/parallel/batches',json={'job_ids':[],'workers':1,'confirm_live':False}); check('Parallel LIVE batch requires confirmation',r.status_code==400)

        r=c.get('/api/mapping-learning'); check('Mapping learner status works',r.status_code==200 and isinstance(j(r),dict))
        r=c.get(f'/api/configurations/{cid}/evidence'); check('Configuration evidence works',r.status_code==200)
        r=c.get(f'/api/configurations/{cid}/readiness'); check('Connection readiness route works',r.status_code==200)
        r=c.get(f'/api/configurations/{cid}/extraction-blueprint'); check('Extraction blueprint route works',r.status_code==200)
        r=c.get(f'/api/configurations/{cid}/intake-report'); check('Customer intake report route works',r.status_code==200)
        r=c.get(f'/api/configurations/{cid}/reports'); check('Reports route works',r.status_code==200 and isinstance(j(r),list))
        r=c.get('/api/audit'); check('Audit log route works',r.status_code==200 and isinstance(j(r),list))
        r=c.get('/api/audit/verify'); check('Audit verification works',r.status_code==200 and isinstance(j(r),dict))

    failed=[x for x in checks if not x['ok']]
    result={'status':'PASS' if not failed else 'FAIL','passed':len(checks)-len(failed),'failed':len(failed),'checks':checks,'runtime':str(RUNTIME),'scope':'Non-mutating local business workflow smoke; no Dell HIP LIVE API mutations.'}
    (ROOT/'BUSINESS_READINESS_VALIDATION_RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'status':result['status'],'passed':result['passed'],'failed':result['failed']},indent=2))
    raise SystemExit(1 if failed else 0)

if __name__=='__main__': main()
