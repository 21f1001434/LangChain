from __future__ import annotations

import inspect
from pathlib import Path

from run_agent import Result, Runner

ROOT = Path(__file__).resolve().parent


def _pass_result(*args, **kwargs):
    seq, group, api, attempt, method, url_key = args[:6]
    return Result(
        seq, group, api, attempt, method, f"https://mock.local/{url_key}",
        str(kwargs.get("token_kind") or "HIP"), "", 200, "PASS", True, 1,
        "", "{}", '{"success": true}', {}, "", "", "", "", ""
    )


def test_runner_constructor_has_no_alternate_execution_flag():
    params = inspect.signature(Runner).parameters
    assert set(params) == {"llm_enabled"}


def test_scratch_cli_is_live_only():
    text = (ROOT / "scratch_flow_runner.py").read_text(encoding="utf-8")
    assert "Runner(llm_enabled=True)" in text
    assert "production_preflight()" in text
    assert "validate_live_configuration()" in text
    assert "judge.verify_connection()" in text


def test_api_testing_single_step_uses_call_path(monkeypatch):
    runner = Runner(llm_enabled=False)
    invoked = []

    def fake_call(*args, **kwargs):
        invoked.append((args, kwargs))
        return _pass_result(*args, **kwargs)

    monkeypatch.setattr(runner, "call", fake_call)
    result = runner.run_single_step("validate_flow")
    assert result.status_code == 200
    assert result.business_success is True
    assert len(invoked) == 1


def test_main_ui_labels_execution_as_live():
    text = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    assert "Test {selected_card.get('label')} live" in text
    assert "Run the live HIP configuration" in text
    assert "Full live API coverage" in text
