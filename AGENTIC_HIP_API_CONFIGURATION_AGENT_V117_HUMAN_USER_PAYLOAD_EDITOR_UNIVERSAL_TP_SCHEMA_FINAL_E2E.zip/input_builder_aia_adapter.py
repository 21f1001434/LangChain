from __future__ import annotations

import json
import os
from typing import Any, Dict

DELL_AIA_BASE_DEFAULT = "https://aia.gateway.dell.com/genai/dev/v1"
DELL_AIA_MODEL_DEFAULT = "gpt-oss-120b"
VALID_MODES = ("off", "fallback", "supervisor", "full")


def resolve_base_url() -> str:
    for name in ("AIA_BASE_URL", "DELL_AIA_BASE_URL", "BASE_URL", "OPENAI_BASE_URL"):
        value = str(os.getenv(name, "") or "").strip()
        if value:
            if "api.openai.com" in value.lower():
                return DELL_AIA_BASE_DEFAULT
            return value.rstrip("/")
    return DELL_AIA_BASE_DEFAULT


def get_model_name() -> str:
    return (
        os.getenv("AIA_MODEL") or os.getenv("DELL_AIA_MODEL") or os.getenv("AIA_TEXT_MODEL")
        or os.getenv("MODEL_NAME") or os.getenv("AGENT_LLM_MODEL") or DELL_AIA_MODEL_DEFAULT
    )


def get_mode() -> str:
    mode = str(os.getenv("AGENT_LLM_MODE", "full") or "full").strip().lower()
    return mode if mode in VALID_MODES else "full"


def diagnostics() -> Dict[str, Any]:
    try:
        from run_agent import AIAJudge
        judge = AIAJudge({}, enabled=get_mode() != "off")
        return {
            "provider": "Dell AIA", "base_url": judge.base_url, "model": judge.model,
            "mode": get_mode(), "ready": bool(judge.available()), "auth_status": judge.auth_status(),
        }
    except Exception as exc:
        return {
            "provider": "Dell AIA", "base_url": resolve_base_url(), "model": get_model_name(),
            "mode": get_mode(), "ready": False, "note": f"{type(exc).__name__}: {exc}",
        }


def extract_builder_hints(analysis: Dict[str, Any], file_excerpts: Dict[str, str]) -> Dict[str, Any]:
    if get_mode() == "off":
        return {}
    from run_agent import AIAJudge
    judge = AIAJudge({}, enabled=True)
    if not judge.available():
        return {}
    slim_files = []
    for name, text in list((file_excerpts or {}).items())[:8]:
        if text:
            slim_files.append({"name": name, "excerpt": str(text)[:1800]})
    tx = analysis.get("detected_tx", {}) if isinstance(analysis, dict) else {}
    cfg = analysis.get("cfg", {}) if isinstance(analysis, dict) else {}
    xml = analysis.get("xml_data", {}) if isinstance(analysis, dict) else {}
    evidence = {
        "customer": analysis.get("customer", ""), "detected_tx": tx, "cfg": cfg, "xml_data": xml,
        "has_jar": analysis.get("has_jar"), "map_name": analysis.get("map_name", ""),
        "map_class": analysis.get("map_class", ""), "map_data_file": analysis.get("map_data_file", ""),
        "files": slim_files,
    }
    return judge.complete_json(
        system=(
            "You are the Dell HIP Input Builder extraction supervisor. Deterministic parser evidence is authoritative. "
            "Infer only missing/ambiguous metadata. Never invent credentials, IDs, deployment groups, certificates, "
            "account names, folder paths, or partner-owned security values. Return JSON only."
        ),
        user=(
            "Evidence:\n" + json.dumps(evidence, ensure_ascii=False, indent=2)[:18000] +
            "\nReturn keys: customer, partner_id, map_name, buyer_name, seller_name, country, currency, "
            "po_number, tx_code, direction, confidence, notes. Use empty strings when unverified. "
            "direction must be Inbound or Outbound only when supported."
        ),
        temperature=0.05,
    )


def test_connection() -> Dict[str, Any]:
    try:
        from run_agent import AIAJudge
        judge = AIAJudge({}, enabled=True)
        if not judge.available():
            return {"ok": False, "diagnostics": diagnostics(), "error": judge.auth_status()}
        result = judge.complete_json(
            system="Return JSON only.", user='Return exactly {"status":"ok","provider":"Dell AIA"}.', temperature=0.0
        )
        return {"ok": str(result.get("status", "")).lower() == "ok", "diagnostics": diagnostics(), "response": result}
    except Exception as exc:
        return {"ok": False, "diagnostics": diagnostics(), "error": f"{type(exc).__name__}: {exc}"}


def extract_user_request_patch(request_text: str, canonical: Dict[str, Any]) -> Dict[str, Any]:
    """Interpret explicit user instructions for input.json without inventing values.

    The caller still enforces a strict path allow-list and deployment-group rule.
    Dell AIA is used only to map values explicitly stated in the user's request.
    """
    text = str(request_text or "").strip()
    if not text or get_mode() == "off":
        return {"changes": [], "questions": []}
    try:
        from run_agent import AIAJudge
        judge = AIAJudge({}, enabled=True)
        if not judge.available():
            return {"changes": [], "questions": [], "note": judge.auth_status()}
        slim = {
            "customer": canonical.get("customer"),
            "direction": canonical.get("direction"),
            "flow_type": canonical.get("flow_type"),
            "tx_code": canonical.get("tx_code"),
            "tx_name": canonical.get("tx_name"),
            "profile_name": canonical.get("profile_name"),
            "objects": canonical.get("objects", {}),
        }
        return judge.complete_json(
            system=(
                "You extract ONLY values explicitly stated in a user's Dell HIP input.json request. "
                "Do not infer or invent credentials, account names, folder paths, DUNS, certificates, IDs, "
                "routing constants, document names, map names, or deployment groups. Deployment group is fixed "
                "elsewhere to hip-automation. Return JSON only with changes:[{path,value,confidence,reason}] and "
                "questions:[string]. Use canonical dotted paths. If a value is ambiguous, put it in questions instead."
            ),
            user=(
                "User request:\n" + text[:8000] + "\n\nCurrent canonical input:\n" +
                json.dumps(slim, ensure_ascii=False, default=str)[:16000]
            ),
            temperature=0.0,
        )
    except Exception as exc:
        return {"changes": [], "questions": [], "note": f"{type(exc).__name__}: {exc}"}
