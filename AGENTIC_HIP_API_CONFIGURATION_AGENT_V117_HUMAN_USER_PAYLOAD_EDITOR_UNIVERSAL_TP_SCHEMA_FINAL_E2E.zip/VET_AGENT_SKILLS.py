from __future__ import annotations

import json
from pathlib import Path

from webapp.backend.app.skill_governance import select_vet_and_pack, vet_all_skills

ROOT = Path(__file__).resolve().parent


def main() -> int:
    result = vet_all_skills(ROOT)
    live_probe = select_vet_and_pack(
        {
            "intentDescription": "Execute the selected immutable HIP configuration LIVE end-to-end using the governed API pipeline.",
            "executionMode": "LIVE",
            "batchId": "preflight",
            "jobId": "preflight",
            "customer": "PREFLIGHT",
            "rules": {"payloadSchemaLocked": True, "strictWholePipeline": True},
        },
        ROOT,
    )
    payload = {
        "status": "PASS",
        "skills": result,
        "liveSelection": live_probe["selection"],
        "liveVetting": live_probe["vetting"],
        "contextBudget": live_probe["context"]["budget"],
    }
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
