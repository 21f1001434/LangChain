
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import run_agent
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
from report_insights import analyze_api_response

ROOT = Path(__file__).resolve().parent


def _ok(seq, group, api, attempt, method, url_key, token_kind="HIP"):
    extracted = {}
    if api == "Create source document type":
        extracted["documentTypeId"] = 92001
    elif api == "Create target document type":
        extracted["documentTypeId"] = 92002
    elif api == "Create/resolve MAC Map":
        extracted["mapId"] = 1670
    elif api == "Create mapping rule":
        extracted["ruleId"] = 33001
    elif api == "Flow orchestration create ONLY":
        extracted.update({"flowId": 44001, "flowVersion": "1.0"})
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}",
        token_kind, "", 200, "PASS_SUCCESS", True, 1,
        "", "{}", '{"success":true}', extracted, "WORKING", "", "WORKING", "", "",
    )


def test_v99_default_deployment_group_is_hip_automation_end_to_end(monkeypatch):
    assert DEFAULT_DEPLOYMENT_GROUP == "hip-automation"
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.source_tp()["deployment_group"] == "hip-automation"
    assert runner.target_tp()["deployment_group"] == "hip-automation"
    assert runner.ov["source_deployment_group_name"] == "hip-automation"
    assert runner.ov["target_deployment_group_name"] == "hip-automation"
    assert runner.tp_orch_payload(runner.source_tp(), "source")["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"
    assert runner.tp_orch_payload(runner.target_tp(), "target")["transportProfileDetails"][0]["deploymentGroupName"] == "hip-automation"


def test_v99_map_identifier_unique_response_is_existing_not_terminal_failure():
    result = {
        "group": "Map",
        "api": "Create/resolve MAC Map",
        "status_code": 500,
        "classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD",
        "business_success": False,
        "response_preview": '{"error":true,"message":"Failed to create map DELLCoXMLASNXX08C","detail":"Map identifier should be unique in an Environment. Please select other.","status":500}',
    }
    verdict = analyze_api_response(result)
    assert verdict["verdict"] == "PASS"
    assert verdict["outcome"] == "EXISTING"


def test_v99_strict_pipeline_executes_duplicate_map_without_preseeded_map_id(monkeypatch):
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "2")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    seen = []

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        payload = kwargs.get("payload")
        seen.append((api, payload))
        if api == "Create/resolve MAC Map":
            return run_agent.Result(
                seq, group, api, attempt, method, f"https://mock/{url_key}",
                str(kwargs.get("token_kind") or "MAP"), "", 500,
                "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 1,
                "", "{}", '{"error":true,"message":"Failed to create map DELLCoXMLASNXX08C","detail":"Map identifier should be unique in an Environment. Please select other.","status":500}',
                {}, "EXPECTED_DUPLICATE_FROM_RETEST", "", "EXPECTED_DUPLICATE_FROM_RETEST",
                "HIP reports that this MAC Map identifier already exists in the environment.",
                "The MAP create API was executed; keep explicit EXISTING evidence without injecting a packaged mapId.",
            )
        return _ok(seq, group, api, attempt, method, url_key, str(kwargs.get("token_kind") or "HIP"))

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None):
        results = runner.run()

    rule_calls = [payload for api, payload in seen if api == "Create mapping rule"]
    assert rule_calls, [api for api, _ in seen]
    assert "documentTypeId" not in rule_calls[0]
    assert "mapId" not in rule_calls[0]["actions"][0]["params"]
    assert rule_calls[0]["actions"][0]["params"]["mapIdentifier"]
    assert runner.runtime_state["map_id"] is None
    assert runner.final_state["coverageComplete"] is True
    assert runner.final_state["unresolvedRequiredSteps"] == []
    assert runner.final_state["strictNonPassingLiveSteps"] == []
    assert runner.final_state["success"] is True
