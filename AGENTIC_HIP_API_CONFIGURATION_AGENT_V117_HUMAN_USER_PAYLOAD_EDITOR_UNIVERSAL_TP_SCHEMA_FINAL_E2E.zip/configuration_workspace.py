from __future__ import annotations

import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Tuple

from runtime_payload_values import placeholder


FLOW_TP_PRESETS = {
    "DCE common SFTP / FTP": {
        "source": "da-sender-sftphaft-dce-common",
        "target": "pt-receiver-sftphaft-dce-common",
    },
    "DCE common HTTPS": {
        "source": "da-sender-https-dce-common",
        "target": "pt-receiver-https-dce-common",
    },
    "Custom": {"source": "", "target": ""},
}


INTERFACE_OPTIONS = ["SFTP", "FTP", "HTTPS", "HTTPS-AS2"]

INTERFACE_HELP = {
    "SFTP": "File transfer using the SFTP HAFT-style Transport Profile.",
    "FTP": "FTP uses the same guided file/folder fields as SFTP; the API interface type remains FTP.",
    "HTTPS": "REST/HTTPS Transport Profile. Sender and Receiver use different interfaceDetails parameters.",
    "HTTPS-AS2": (
        "HTTPS-AS2 is supported through an editable parameter template. "
        "Because the exact AS2 fields are contract-specific, upload the API PDF "
        "or provide the interface parameters and the agent will validate them."
    ),
}


def normalize_interface_type(value: Any) -> str:
    text = _clean(value).upper().replace("_", "-")
    if text in {"SFTP", "SFTP HAFT", "SFTP-HAFT"}:
        return "SFTP HAFT"
    if text == "FTP":
        return "FTP"
    if text in {"HTTPS", "REST", "HTTPS REST"}:
        return "HTTPS"
    if text in {"HTTPS-AS2", "AS2", "HTTPS AS2"}:
        return "HTTPS-AS2"
    return _clean(value) or "SFTP HAFT"


def interface_display_name(value: Any) -> str:
    normalized = normalize_interface_type(value)
    return "SFTP" if normalized == "SFTP HAFT" else normalized


def default_flow_tp_references(interface_type: Any) -> Dict[str, str]:
    normalized = normalize_interface_type(interface_type)
    if normalized in {"SFTP HAFT", "FTP"}:
        return dict(FLOW_TP_PRESETS["DCE common SFTP / FTP"])
    if normalized == "HTTPS":
        return dict(FLOW_TP_PRESETS["DCE common HTTPS"])
    # HTTPS-AS2 shared profile names were not supplied in the Dev screenshots.
    # Keep them explicit/contract-driven instead of guessing.
    return {"source": "", "target": ""}


def _replace_customer_tokens(node: Any, customer: str) -> Any:
    """Clone the U-HAUL template while renaming customer-specific strings."""
    display = _clean(customer)
    compact = re.sub(r"[^A-Za-z0-9]+", "", display)
    upper_display = display.upper()
    upper_compact = compact.upper()
    lower_compact = compact.lower()

    if isinstance(node, dict):
        return {key: _replace_customer_tokens(value, customer) for key, value in node.items()}
    if isinstance(node, list):
        return [_replace_customer_tokens(value, customer) for value in node]
    if not isinstance(node, str) or not display:
        return node

    value = node
    # Order matters: replace the hyphenated form first.
    value = value.replace("U-HAUL", upper_display)
    value = value.replace("UHAUL", upper_compact)
    value = value.replace("uhaul", lower_compact)
    value = value.replace("U-Haul", display)
    return value


def clone_uhaul_template(
    template_input: Dict[str, Any],
    *,
    customer: str,
    changes: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """
    Reuse U-HAUL as a working configuration template.

    The user can say "everything is the same except these values". We clone the
    canonical U-HAUL model, rename customer-specific strings, then apply only
    the explicitly supplied differences. Secrets are never accepted here.
    """
    cloned = deepcopy(template_input)
    if _clean(customer):
        cloned = _replace_customer_tokens(cloned, customer)
        cloned["customer"] = _clean(customer)
        cloned["folder"] = _clean(customer)

    changes = changes or {}
    objects = cloned.setdefault("objects", {})
    source_tp = objects.setdefault("source_transport_profile", {})
    target_tp = objects.setdefault("target_transport_profile", {})
    biz = objects.setdefault("biz_flow", {})
    configure_source = biz.setdefault("configure_source", {})
    configure_targets = biz.setdefault("configure_targets", {})

    def set_if(mapping: Dict[str, Any], key: str, change_key: str) -> None:
        value = changes.get(change_key)
        if value not in (None, ""):
            mapping[key] = value

    set_if(cloned, "tx_code", "tx_code")
    set_if(cloned, "tx_name", "tx_name")
    set_if(cloned, "direction", "direction")
    set_if(source_tp, "profile_name", "source_tp_profile")
    set_if(target_tp, "profile_name", "target_tp_profile")
    set_if(source_tp, "existing_account_name", "source_account")
    set_if(target_tp, "existing_account_name", "target_account")
    set_if(source_tp, "subscription_folder", "source_folder")
    set_if(target_tp, "subscription_folder", "target_folder")
    set_if(target_tp, "partner_name", "target_partner")
    set_if(configure_targets, "target_application", "target_partner")
    set_if(configure_source, "source_transport_profile", "source_flow_tp")
    set_if(configure_targets, "target_transport_profile", "target_flow_tp")

    if changes.get("source_interface_type"):
        source_tp["interface_type"] = normalize_interface_type(changes["source_interface_type"])
        if source_tp["interface_type"] not in {"SFTP HAFT", "FTP"}:
            # Do not leak U-HAUL HAFT account/folder values into an HTTPS/AS2 clone.
            source_tp["existing_account"] = "No"
            source_tp["existing_account_name"] = ""
            source_tp["subscription_folder"] = ""
            configure_source["source_transport_profile"] = _clean(changes.get("source_flow_tp"))
    if changes.get("target_interface_type"):
        target_tp["interface_type"] = normalize_interface_type(changes["target_interface_type"])
        if target_tp["interface_type"] not in {"SFTP HAFT", "FTP"}:
            target_tp["existing_account"] = "No"
            target_tp["existing_account_name"] = ""
            target_tp["subscription_folder"] = ""
            configure_targets["target_transport_profile"] = _clean(changes.get("target_flow_tp"))

    if isinstance(changes.get("source_interface_parameters"), dict):
        source_tp["interface_parameters"] = deepcopy(changes["source_interface_parameters"])
    if isinstance(changes.get("target_interface_parameters"), dict):
        target_tp["interface_parameters"] = deepcopy(changes["target_interface_parameters"])

    if changes.get("flow_name"):
        cloned["profile_name"] = changes["flow_name"]
        biz.setdefault("flow_details", {})["business_flow_name"] = changes["flow_name"]

    cloned["_creation_source"] = {
        "mode": "UHAL_TEMPLATE_CLONE",
        "template": "U-HAUL",
        "note": (
            "Created by cloning the approved U-HAUL canonical configuration and "
            "applying only the user-approved differences."
        ),
        "changedFields": sorted(
            key for key, value in changes.items()
            if value not in (None, "", {}, [])
        ),
    }
    return cloned


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _version(value: Any) -> str:
    text = _clean(value) or "1"
    return text[:-2] if text.endswith(".0") else text


def _doc_attributes(
    receiver_expression: str,
    sender_expression: str,
    business_expression: str,
    alternate_business_expression: str,
) -> List[Dict[str, Any]]:
    usage = "Flow Identifier Expression, Logging, Mapping, Routing"
    return [
        {
            "attribute_name": "Receiver",
            "derived_from": "ELEMENT_IN_PAYLOAD",
            "usage": usage,
            "expression": _clean(receiver_expression),
        },
        {
            "attribute_name": "Sender",
            "derived_from": "ELEMENT_IN_PAYLOAD",
            "usage": usage,
            "expression": _clean(sender_expression),
        },
        {
            "attribute_name": "Transaction Type",
            "derived_from": "TRANSACTION_ROOT_ELEMENT",
            "usage": usage,
            "expression": "",
        },
        {
            "attribute_name": "Business Identifier",
            "derived_from": "ELEMENT_IN_PAYLOAD",
            "usage": usage,
            "expression": _clean(business_expression),
        },
        {
            "attribute_name": "Alternate Business Identifier",
            "derived_from": "ELEMENT_IN_PAYLOAD",
            "usage": usage,
            "expression": _clean(alternate_business_expression),
        },
    ]


def _document_type(
    *,
    name: str,
    tx_code: str,
    version: str,
    data_format: str,
    description: str,
    root: str,
    api_transaction_type: str,
    receiver_expression: str,
    sender_expression: str,
    business_expression: str,
    alternate_business_expression: str,
) -> Dict[str, Any]:
    return {
        "name": _clean(name),
        "transaction_type": _clean(tx_code),
        "version": _version(version),
        "data_format_type": _clean(data_format) or "XML",
        "status": "Enable",
        "description": _clean(description) or _clean(name),
        "validation_type": "Structure",
        "document_identifier": {
            "operation": "All conditions are satisfied",
            "rows": [
                {
                    "derived_from": "TRANSACTION_ROOT_ELEMENT",
                    "value": _clean(root),
                }
            ],
        },
        "attributes_to_configure": _doc_attributes(
            receiver_expression,
            sender_expression,
            business_expression,
            alternate_business_expression,
        ),
        "operation": "All conditions are satisfied",
        "status_disabled": False,
        "api_transaction_type": api_transaction_type,
        "api_document_identifier": {
            "operator": "ALL",
            "attributeList": [
                {
                    "derivedFrom": "TRANSACTION_ROOT_ELEMENT",
                    "value": _clean(root),
                }
            ],
        },
        "last_modified_by": "",
    }



def _interface_parameters_from_fields(fields: Dict[str, Any], side: str) -> Dict[str, Any]:
    selected = normalize_interface_type(fields.get(f"{side}_interface_type"))
    role = "Sender" if side == "source" else "Receiver"

    if selected in {"SFTP HAFT", "FTP"}:
        return {}

    if selected == "HTTPS":
        if side == "source":
            params: Dict[str, Any] = {
                "Protocol": _clean(fields.get("source_protocol")) or "REST",
                "HIP URL": _clean(fields.get("source_hip_url")) or "URL will be shared later after API Publish is successful.",
                "Proxy URI": _clean(fields.get("source_proxy_uri")) or "dce-common-sv1",
                "Request Method": _clean(fields.get("source_request_method")) or "POST",
                "Request Format": _clean(fields.get("source_request_format")) or "Request Body",
                "Sender Authentication Type": _clean(fields.get("source_authentication_type")) or "OAuth2",
                "Are Input Files Compressed?": _clean(fields.get("source_are_input_files_compressed")) or "False",
                "Sender Grant Type": _clean(fields.get("source_grant_type")) or "client_credentials",
            }
            if _clean(fields.get("source_token_endpoint")):
                params["Sender Token Endpoint"] = _clean(fields.get("source_token_endpoint"))
            if _clean(fields.get("source_client_id")):
                params["Sender Client Id"] = _clean(fields.get("source_client_id"))
            # Partner/interface secret is part of the API payload, not a new
            # application credential. Keep a runtime placeholder in the
            # canonical payload and inject the entered value only for the live
            # HTTP request.
            if fields.get("source_client_secret_configured"):
                params["Sender Client Secret"] = placeholder("source.sender_client_secret")
            return params

        params = {
            "Protocol": _clean(fields.get("target_protocol")) or "REST",
            "Partner URL": _clean(fields.get("target_partner_url")),
            "Request Method": _clean(fields.get("target_request_method")) or "POST",
            "Request Format": _clean(fields.get("target_request_format")) or "Request Body",
            "Receiver Authentication Type": _clean(fields.get("target_authentication_type")) or "OAuth2",
            "Gateway URL": _clean(fields.get("target_gateway_url")) or "URL will be shared later after API Publish is successful.",
            "Are Input Files Compressed?": _clean(fields.get("target_are_input_files_compressed")) or "False",
            "Receiver Grant Type": _clean(fields.get("target_grant_type")),
            "Receiver Token Endpoint": _clean(fields.get("target_token_endpoint")),
            "Receiver Client Id": _clean(fields.get("target_client_id")),
        }
        if fields.get("target_client_secret_configured"):
            params["Receiver Client Secret"] = placeholder("target.receiver_client_secret")
        return {key: value for key, value in params.items() if value not in ("", None)}

    # HTTPS-AS2 exact parameters differ by the API contract. Preserve only what
    # the user/PDF/agent supplied instead of inventing undocumented fields.
    raw = fields.get(f"{side}_interface_parameters")
    if isinstance(raw, dict):
        return deepcopy(raw)
    return {}



def build_guided_input(fields: Dict[str, Any]) -> Dict[str, Any]:
    """Build the canonical HIP input from the UI wizard.

    The user never needs to author or upload input.json; the wizard writes the
    canonical model that the existing mapper, MCP tools and agent use.
    """
    customer = _clean(fields.get("customer"))
    tx_code = _clean(fields.get("tx_code"))
    tx_name = _clean(fields.get("tx_name"))
    direction = _clean(fields.get("direction")) or "Outbound"
    version = _version(fields.get("version") or "1")
    source_doc_name = _clean(fields.get("source_doc_name"))
    target_doc_name = _clean(fields.get("target_doc_name"))
    map_identifier = _clean(fields.get("map_identifier"))
    map_name = _clean(fields.get("map_name"))
    rule_name = _clean(fields.get("rule_name"))
    flow_name = _clean(fields.get("flow_name"))
    receiver_operator = _clean(fields.get("receiver_operator")) or "Equals"
    sender_operator = _clean(fields.get("sender_operator")) or "Contains"
    receiver_value = _clean(fields.get("receiver_value"))
    sender_value = _clean(fields.get("sender_value")) or "DELL"
    source_tp_profile = _clean(fields.get("source_tp_profile"))
    target_tp_profile = _clean(fields.get("target_tp_profile"))
    source_flow_tp = _clean(fields.get("source_flow_tp"))
    target_flow_tp = _clean(fields.get("target_flow_tp"))
    source_system = _clean(fields.get("source_system")) or "AIC - DCE"
    target_partner = _clean(fields.get("target_partner"))
    source_account = _clean(fields.get("source_account"))
    target_account = _clean(fields.get("target_account"))
    source_folder = _clean(fields.get("source_folder"))
    target_folder = _clean(fields.get("target_folder"))
    deployment_group_source = "hip-automation"
    deployment_group_target = "hip-automation"
    data_format = _clean(fields.get("data_format")) or "XML"

    source_doc = _document_type(
        name=source_doc_name,
        tx_code=tx_code,
        version=version,
        data_format=data_format,
        description=_clean(fields.get("source_doc_description")) or source_doc_name,
        root=_clean(fields.get("source_root")),
        api_transaction_type="INBOUND",
        receiver_expression=_clean(fields.get("source_receiver_expression")),
        sender_expression=_clean(fields.get("source_sender_expression")),
        business_expression=_clean(fields.get("source_business_expression")),
        alternate_business_expression=_clean(fields.get("source_alt_business_expression")),
    )
    target_doc = _document_type(
        name=target_doc_name,
        tx_code=tx_code,
        version=version,
        data_format=data_format,
        description=_clean(fields.get("target_doc_description")) or target_doc_name,
        root=_clean(fields.get("target_root")),
        api_transaction_type="OUTBOUND",
        receiver_expression=_clean(fields.get("target_receiver_expression")),
        sender_expression=_clean(fields.get("target_sender_expression")),
        business_expression=_clean(fields.get("target_business_expression")),
        alternate_business_expression=_clean(fields.get("target_alt_business_expression")),
    )

    input_data: Dict[str, Any] = {
        "profile_name": flow_name,
        "customer": customer,
        "folder": _clean(fields.get("folder")) or customer,
        "tx_standard": _clean(fields.get("tx_standard")) or "X12",
        "tx_code": tx_code,
        "tx_name": tx_name,
        "direction": direction,
        "requires_data_map": True,
        "dell_app": _clean(fields.get("dell_app")) or "ANS",
        "_creation_source": {
            "mode": "GUIDED_UI",
            "note": "Canonical input generated by the HIP Configuration Workspace; no input.json upload was required.",
        },
        "objects": {
            "data_map": {
                "map_identifier": map_identifier,
                "map_identifier_version": version,
                "status": "Enable",
                "map_name": map_name,
                "map_class": _clean(fields.get("map_class")) or map_name,
                "contivo_version": _clean(fields.get("contivo_version")) or "6.7",
                "map_data_file": _clean(fields.get("map_data_file")),
                "cross_reference_file": _clean(fields.get("cross_reference_file")),
            },
            "source_document_type": source_doc,
            "target_document_type": target_doc,
            "rule": {
                "name": rule_name,
                "version": version,
                "document_type_name_version": f"{source_doc_name}({version}.0)",
                "rule_type": "Mapping",
                "rule_scope": "GLOBAL",
                "status": "Enable",
                "description": _clean(fields.get("rule_description")) or rule_name,
                "conditions": {
                    "execute_actions_when": "one or more conditions are satisfied",
                    "rows": [
                        {
                            "condition_type": "Attributes",
                            "operator": receiver_operator,
                            "value": receiver_value,
                            "attribute_name_unit": "Receiver",
                        },
                        {
                            "condition_type": "Attributes",
                            "operator": sender_operator,
                            "value": sender_value,
                            "attribute_name_unit": "Sender",
                        },
                    ],
                },
                "actions": {
                    "action_name": _clean(fields.get("rule_action_name")) or f"{rule_name}_ROUTE",
                    "action_type": "Route Document",
                    "mapping_identifier_name_version": f"{map_identifier}({version}.0)",
                },
            },
            "source_transport_profile": {
                "system_type": "Dell Application",
                "partner_name": source_system,
                "profile_name": source_tp_profile,
                "profile_usage": "Sender",
                "deployment_group": deployment_group_source,
                "interface_type": normalize_interface_type(fields.get("source_interface_type")),
                "interface_parameters": _interface_parameters_from_fields(fields, "source"),
                "interface_environment": _clean(fields.get("interface_environment")) or "UAT",
                "existing_account": "Yes" if source_account else "No",
                "existing_account_name": source_account,
                "use_existing_folder": _clean(fields.get("source_use_existing_folder")) or "No",
                "post_transfer_action": "Move to Archive",
                "is_compression_required": "FALSE",
                "document_type": f"{source_doc_name}({version}.0)",
                "subscription_folder": source_folder,
                "file_filtering_pattern": _clean(fields.get("source_file_pattern")) or ".*\\*.",
            },
            "target_transport_profile": {
                "system_type": "Partner",
                "partner_name": target_partner,
                "profile_name": target_tp_profile,
                "profile_usage": "Receiver",
                "deployment_group": deployment_group_target,
                "interface_type": normalize_interface_type(fields.get("target_interface_type")),
                "interface_parameters": _interface_parameters_from_fields(fields, "target"),
                "interface_environment": _clean(fields.get("interface_environment")) or "UAT",
                "existing_account": "Yes" if target_account else "No",
                "existing_account_name": target_account,
                "use_existing_folder": _clean(fields.get("target_use_existing_folder")) or "No",
                "post_transfer_action": "Move to Archive",
                "is_compression_required": "FALSE",
                "document_type": f"{target_doc_name}({version}.0)",
                "file_filtering_pattern": _clean(fields.get("target_file_pattern")) or ".*\\*.",
                "subscription_folder": target_folder,
            },
            "biz_flow": {
                "flow_details": {
                    "current_flow_version": version,
                    "business_flow_name": flow_name,
                    "flow_description": _clean(fields.get("flow_description")) or f"{direction} {tx_code} {tx_name} — DELL to {customer}",
                },
                "configure_source": {
                    "source_type": "Dell Application",
                    "source_application": source_system,
                    "source_transport_profile": source_flow_tp,
                    "document_type_name_version": f"{source_doc_name}({version}.0)",
                },
                "flow_identifiers": {
                    "operator": "one or more conditions are satisfied",
                    "conditions": [
                        {
                            "document_type_name_version": f"{source_doc_name}({version}.0)",
                            "attribute_name": "Receiver",
                            "operator": receiver_operator,
                            "value": receiver_value,
                        },
                        {
                            "document_type_name_version": f"{source_doc_name}({version}.0)",
                            "attribute_name": "Sender",
                            "operator": sender_operator,
                            "value": sender_value,
                        },
                    ],
                },
                "configure_targets": {
                    "target_type": "Partner",
                    "target_application": target_partner,
                    "target_transport_profile": target_flow_tp,
                    "document_type_name_version": f"{target_doc_name}({version}.0)",
                },
                "process_steps": [
                    {
                        "step_number": 1,
                        "step_type": "Mapping Transformer",
                        "step_name": "Mapping-1",
                        "configuration": {
                            "source_document_type": "Disabled(All/Other)",
                            "action": "Mapping",
                            "target_document_type_version": f"{target_doc_name}({version}.0)",
                            "rule_version": f"{rule_name}({version}.0)",
                            "add_rule_if_not_listed": "Not Enabled",
                        },
                    }
                ],
                "configure_routing": {
                    "rule": {
                        "name": _clean(fields.get("flow_routing_rule_name")) or f"FLOWROUTE_{re.sub(r'[^A-Za-z0-9]+', '_', flow_name).strip('_')}",
                    }
                },
            },
        },
    }
    return input_data


def guided_questions(fields: Dict[str, Any]) -> List[Dict[str, str]]:
    required = [
        ("customer", "Customer / partner business name"),
        ("flow_name", "Business Flow name"),
        ("tx_code", "Transaction code"),
        ("tx_name", "Transaction name"),
        ("source_doc_name", "Source Document Type name"),
        ("source_root", "Source XML/root identifier"),
        ("target_doc_name", "Target Document Type name"),
        ("target_root", "Target XML/root identifier"),
        ("map_identifier", "MAC Map identifier"),
        ("map_name", "MAC Map name"),
        ("map_data_file", "Mapping JAR file name"),
        ("rule_name", "Mapping Rule name"),
        ("receiver_value", "Receiver routing value"),
        ("source_system", "Source Dell system/application"),
        ("target_partner", "Target Partner name"),
        ("source_tp_profile", "Source Transport Profile create name"),
        ("target_tp_profile", "Target Transport Profile create name"),
        ("source_flow_tp", "Source Transport Profile reference used by Flow"),
        ("target_flow_tp", "Target Transport Profile reference used by Flow"),
    ]
    out = []
    for key, label in required:
        if not _clean(fields.get(key)):
            out.append({
                "field": key,
                "question": f"What should I use for {label}?",
                "why": "Required to build and validate the corresponding HIP API payload.",
            })

    source_interface = normalize_interface_type(fields.get("source_interface_type"))
    target_interface = normalize_interface_type(fields.get("target_interface_type"))

    if source_interface == "HTTPS":
        for key, label in [
            ("source_proxy_uri", "the Dell HTTPS Proxy URI"),
        ]:
            if not _clean(fields.get(key)):
                out.append({
                    "field": key,
                    "question": f"What should I use for {label}?",
                    "why": "The HTTPS Sender interfaceDetails payload needs this value.",
                })

    if target_interface == "HTTPS":
        for key, label in [
            ("target_partner_url", "the Partner URL"),
            ("target_grant_type", "the Receiver Grant Type"),
            ("target_token_endpoint", "the Receiver OAuth token endpoint"),
            ("target_client_id", "the Receiver OAuth Client ID"),
        ]:
            if not _clean(fields.get(key)):
                out.append({
                    "field": key,
                    "question": f"What should I use for {label}?",
                    "why": "Latest Dev guidance says this value must be supplied by the Partner; the agent will not invent or default it.",
                })
        # Certificate fields are intentionally not treated as mandatory here.
        # Latest Dev message says certificate-related details are still being
        # confirmed with the internal team. PDF/API contract validation can
        # promote them to required later when that contract is known.
        if not fields.get("target_client_secret_configured"):
            out.append({
                "field": "target_client_secret",
                "question": "Please enter the Receiver OAuth Client Secret in the secure field.",
                "why": "It is required by the HTTPS Receiver payload. Enter it as a secure transient payload value; it is not an application/.env credential.",
            })

    for side, interface in [("source", source_interface), ("target", target_interface)]:
        if interface == "HTTPS-AS2" and not isinstance(fields.get(f"{side}_interface_parameters"), dict):
            out.append({
                "field": f"{side}_interface_parameters",
                "question": f"Please provide or teach me the exact HTTPS-AS2 {side} interface parameters.",
                "why": (
                    "The screenshots define HTTPS REST fields, not the full HTTPS-AS2 contract. "
                    "Upload the API PDF or paste the AS2 interfaceDetails so the agent can validate without inventing fields."
                ),
            })
    return out


def infer_fields_from_payload_bundle(bundle: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministic best-effort extraction before Dell AIA is used."""
    fields: Dict[str, Any] = {}
    if not isinstance(bundle, dict):
        return fields

    source_doc = bundle.get("doctype_source") or {}
    target_doc = bundle.get("doctype_target") or {}
    rule = bundle.get("rule") or {}
    source_tp = bundle.get("source_tp") or {}
    target_tp = bundle.get("target_tp") or {}
    flow = bundle.get("flow_create") or {}

    if isinstance(source_doc, dict):
        fields["source_doc_name"] = source_doc.get("name")
        fields["data_format"] = source_doc.get("dataFormatType")
        fields["version"] = source_doc.get("version")
        ident = source_doc.get("documentIdentifier") or {}
        attrs = ident.get("attributeList") if isinstance(ident, dict) else None
        if isinstance(attrs, list) and attrs and isinstance(attrs[0], dict):
            fields["source_root"] = attrs[0].get("value")
    if isinstance(target_doc, dict):
        fields["target_doc_name"] = target_doc.get("name")
        ident = target_doc.get("documentIdentifier") or {}
        attrs = ident.get("attributeList") if isinstance(ident, dict) else None
        if isinstance(attrs, list) and attrs and isinstance(attrs[0], dict):
            fields["target_root"] = attrs[0].get("value")
    if isinstance(rule, dict):
        fields["rule_name"] = rule.get("name")
    if isinstance(source_tp, dict):
        details = source_tp.get("transportProfileDetails") or []
        if isinstance(details, list) and details and isinstance(details[0], dict):
            fields["source_tp_profile"] = details[0].get("transportProfileName") or details[0].get("name")
            fields["source_system"] = details[0].get("systemName")
            fields["source_deployment_group"] = details[0].get("deploymentGroupName")
    if isinstance(target_tp, dict):
        details = target_tp.get("transportProfileDetails") or []
        if isinstance(details, list) and details and isinstance(details[0], dict):
            fields["target_tp_profile"] = details[0].get("transportProfileName") or details[0].get("name")
            fields["target_deployment_group"] = details[0].get("deploymentGroupName")
    if isinstance(flow, dict):
        definition = flow.get("flowDefinition")
        if isinstance(definition, str):
            try:
                definition = json.loads(definition)
            except Exception:
                definition = {}
        if isinstance(definition, dict):
            details = definition.get("flowDetails") or {}
            fields["flow_name"] = details.get("businessFlowName")
            fields["flow_description"] = details.get("flowDescription")
            src = definition.get("sourceDetails") or {}
            if isinstance(src.get("sourceTransportProfile"), list) and src.get("sourceTransportProfile"):
                fields["source_flow_tp"] = src["sourceTransportProfile"][0]
            targets = (definition.get("targetDetails") or {}).get("targets") or []
            if targets and isinstance(targets[0], dict):
                fields["target_flow_tp"] = targets[0].get("targetTransportProfile")
                fields["target_partner"] = targets[0].get("targetApplication")
    return {key: value for key, value in fields.items() if value not in (None, "")}
