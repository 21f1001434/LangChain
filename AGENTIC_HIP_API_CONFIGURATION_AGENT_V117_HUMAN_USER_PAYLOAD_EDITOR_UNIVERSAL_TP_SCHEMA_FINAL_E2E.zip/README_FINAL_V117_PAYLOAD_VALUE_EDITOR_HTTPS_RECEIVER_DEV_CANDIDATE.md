# V117 — Human-only Payload Value Editing + Universal Transport Profile Schema

## Governance

- AI/AutoGen/Dell-AIA **cannot save or apply payload value edits**. It may inspect, explain, preflight and report only.
- Only an explicit **HUMAN USER** action may edit an existing canonical payload/parameter value before LIVE.
- Human users may edit values in **any applicable API request**, not only Transport Profile or HTTPS.
- Method, URL, request kind, protected headers, attribute names, nesting and array cardinality remain immutable.
- Once the user-approved effective request is materialized for LIVE, the request fingerprint prevents retry-time changes.

## Transport Profile contract

The Source/Target Transport Profile orchestration payload uses one fixed outer structure for every interface. SFTP HAFT, FTP, HTTPS, HTTPS-AS2 and future Dev-approved interfaces differ only under:

`transportProfileDetails[0].interfaceDetails`

Customer/business values such as Transport Profile name, system/partner name and Document Type values may naturally differ per customer; switching the interface itself must not add/remove outer TP attributes.

A HUMAN edit to Source/Target `transportProfileName` is synchronized back to canonical configuration so validation, create, audit/history and downstream references use the same name.

## Plain HTTPS Receiver Dev-validation candidate

Omitted from plain HTTPS Receiver `parameters`:

- `SSL Certificate`
- `SSL Certificate CN - Expiry`
- `SSL Certificate Id`

HTTPS-AS2 certificate/encryption/verification fields are a separate contract and are **not** removed.

Files to send to Dev:

- `HTTPS_RECEIVER_TARGET_TP_VALIDATE_DEV_VALIDATION.json`
- `HTTPS_RECEIVER_TARGET_TP_ORCHESTRATION_DEV_VALIDATION.json`
- `V117_HTTPS_RECEIVER_DEV_VALIDATION_BUNDLE.json`
