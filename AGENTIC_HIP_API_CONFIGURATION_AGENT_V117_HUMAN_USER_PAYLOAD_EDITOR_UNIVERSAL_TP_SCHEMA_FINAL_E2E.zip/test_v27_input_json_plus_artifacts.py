from copy import deepcopy
from pathlib import Path
import io
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from input_bundle import inspect_individual_files, replace_input_files_from_pairs
from input_builder_core import build_from_raw_files, combine_existing_input_with_artifact_evidence


def _make_legrand_files(tmp_path: Path):
    """Create cross-platform, self-contained artifacts with the same filenames used in the Legrand flow."""
    xbm = tmp_path / 'DELLCiPMRPOXX10C.xbm'
    xbm.write_text(
        '<transformMap logicalName="DELLCiPMRPOXX10C" analystVersionLastSaved="6.7.2">'
        '<sources><schemaRoot logicalName="PurchaseOrderCollection"/></sources>'
        '<targets><schemaRoot logicalName="PurchaseOrder"/></targets>'
        '</transformMap>',
        encoding='utf-8',
    )
    jar = tmp_path / 'Transform_DELLCiPMRPOXX10C.jar'
    with zipfile.ZipFile(jar, 'w') as zf:
        zf.writestr('com/dell/Transform_DELLCiPMRPOXX10C.class', b'fixture')
    (tmp_path / 'SRC_200_1730_5834.XML').write_text(
        '<?xml version="1.0"?><PurchaseOrderCollection><PurchaseOrderItem><Buyer>LEGRAND_NEDERLAND</Buyer></PurchaseOrderItem></PurchaseOrderCollection>',
        encoding='utf-8',
    )
    (tmp_path / 'TGT_o.2x16.2605062107373931.XML').write_text(
        '<?xml version="1.0"?><PurchaseOrder><OrderHeader><POIssuedDate>20260505</POIssuedDate></OrderHeader></PurchaseOrder>',
        encoding='utf-8',
    )
    (tmp_path / 'output compare.xml').write_text(
        '<?xml version="1.0"?><PurchaseOrder><OrderHeader><OrderCurrency>EUR</OrderCurrency></OrderHeader></PurchaseOrder>',
        encoding='utf-8',
    )
    return [
        xbm,
        tmp_path / 'output compare.xml',
        tmp_path / 'SRC_200_1730_5834.XML',
        tmp_path / 'TGT_o.2x16.2605062107373931.XML',
        jar,
    ]


def _pairs(paths):
    return [(p.name, p.read_bytes()) for p in paths]


def test_individual_related_files_are_accepted_and_replaced(tmp_path):
    fixture_dir = tmp_path / 'fixtures'
    fixture_dir.mkdir()
    files = _make_legrand_files(fixture_dir)
    summary = inspect_individual_files(_pairs(files))
    assert summary['fileCount'] == 5
    assert any(x['name'].endswith('.jar') for x in summary['files'])
    dest = tmp_path / 'input_files'
    result = replace_input_files_from_pairs(_pairs(files), dest)
    assert result['fileCount'] == 5
    assert (dest / 'DELLCiPMRPOXX10C.xbm').is_file()
    assert (dest / 'Transform_DELLCiPMRPOXX10C.jar').is_file()


def test_existing_input_json_and_legrand_artifacts_are_ingested_together(tmp_path):
    fixture_dir = tmp_path / 'fixtures'
    fixture_dir.mkdir()
    files = _make_legrand_files(fixture_dir)
    evidence = build_from_raw_files(
        files, customer='LEGRAND_NEDERLAND', direction='Inbound',
        flow_type='translation', use_dell_aia=False,
    )
    existing = deepcopy(evidence)
    existing['objects']['data_map']['map_data_file'] = ''
    combined = combine_existing_input_with_artifact_evidence(
        existing, evidence, manifest=[p.name for p in files],
    )
    av = combined['_artifact_validation']
    assert av['fileCount'] == 5
    assert not av['blockers']
    assert combined['objects']['data_map']['map_data_file'] == 'Transform_DELLCiPMRPOXX10C.jar'
    assert combined['flow_type'] == 'translation'
    assert combined['_source'] == 'existing input.json + supporting customer artifacts'


def test_manifest_can_recover_single_mapping_jar_when_evidence_field_is_blank(tmp_path):
    fixture_dir = tmp_path / 'fixtures'
    fixture_dir.mkdir()
    files = _make_legrand_files(fixture_dir)
    evidence = build_from_raw_files(
        files, customer='LEGRAND_NEDERLAND', direction='Inbound',
        flow_type='translation', use_dell_aia=False,
    )
    existing = deepcopy(evidence)
    existing['objects']['data_map']['map_data_file'] = ''
    evidence['objects']['data_map']['map_data_file'] = ''
    combined = combine_existing_input_with_artifact_evidence(
        existing, evidence, manifest=[p.name for p in files],
    )
    assert combined['objects']['data_map']['map_data_file'] == 'Transform_DELLCiPMRPOXX10C.jar'
    assert not combined['_artifact_validation']['blockers']


def test_missing_referenced_mapping_jar_blocks_before_api_mapping(tmp_path):
    fixture_dir = tmp_path / 'fixtures'
    fixture_dir.mkdir()
    files = _make_legrand_files(fixture_dir)
    evidence = build_from_raw_files(
        files, customer='LEGRAND_NEDERLAND', direction='Inbound',
        flow_type='translation', use_dell_aia=False,
    )
    existing = deepcopy(evidence)
    existing['objects']['data_map']['map_data_file'] = 'WRONG.jar'
    combined = combine_existing_input_with_artifact_evidence(
        existing, evidence, manifest=[p.name for p in files],
    )
    assert any('WRONG.jar' in str(x.get('message')) for x in combined['_artifact_validation']['blockers'])


def test_streamlit_workspaces_expose_both_zip_and_direct_related_file_modes():
    builder = (ROOT / 'input_builder_ui.py').read_text(encoding='utf-8')
    bundle = (ROOT / 'input_bundle_ui.py').read_text(encoding='utf-8')
    assert 'Existing input.json + supporting artifacts' in builder
    assert 'ZIP bundle' in builder and 'Individual files' in builder
    assert 'input.json and the related files together' in builder
    assert 'ZIP bundle' in bundle and 'Individual files' in bundle
    assert 'Ingest + validate input.json + related files' in bundle
