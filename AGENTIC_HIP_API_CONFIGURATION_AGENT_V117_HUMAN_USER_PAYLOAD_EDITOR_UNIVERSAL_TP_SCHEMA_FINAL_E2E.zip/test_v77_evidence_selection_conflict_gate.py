from __future__ import annotations

from pathlib import Path

from input_extraction_blueprint import detect_user_selection_conflicts, apply_input_extraction_blueprint, merge_blueprint_questions
from input_builder_integration import apply_answers

ROOT = Path(__file__).resolve().parent


def base() -> dict:
    return {
        "customer": "LEGRAND_NEDERLAND",
        "direction": "Inbound",
        "tx_code": "850",
        "tx_name": "Purchase Order",
        "flow_type": "translation",
        "requires_data_map": True,
        "objects": {
            "data_map": {"map_name": "MAP", "map_data_file": "map.jar", "map_class": "Transform_MAP"},
            "source_document_type": {"name": "SRC", "data_format_type": "XML", "version": "1.0"},
            "target_document_type": {"name": "TGT", "data_format_type": "XML", "version": "1.0"},
            "rule": {"name": "RULE"},
            "source_transport_profile": {"interface_type": "SFTP HAFT", "profile_name": "SRC_TP"},
            "target_transport_profile": {"interface_type": "SFTP HAFT", "profile_name": "TGT_TP"},
            "biz_flow": {"flow_details": {"business_flow_name": "FLOW"}, "configure_source": {}, "configure_targets": {}, "configure_routing": {}},
        },
        "_file_mapping": {"fieldMappings": [
            {"path": "tx_code", "value": "850", "sourceFile": "customer_po.xml", "rule": "payload semantics", "confidence": "high"},
            {"path": "direction", "value": "Inbound", "sourceFile": "customer_po.xml", "rule": "payload semantics", "confidence": "high"},
            {"path": "customer", "value": "LEGRAND_NEDERLAND", "sourceFile": "customer_po.xml", "rule": "partner identity", "confidence": "medium"},
            {"path": "flow_type", "value": "translation", "sourceFile": "map.xbm", "rule": "mapping artifact", "confidence": "high"},
        ]},
    }


def test_untouched_ui_defaults_do_not_create_conflict():
    out = detect_user_selection_conflicts(base(), {"transaction_code": "856", "direction": "Outbound", "user_selected_fields": []})
    assert out["_selection_conflicts"] == []


def test_explicit_ui_vs_customer_file_creates_side_by_side_question():
    data = detect_user_selection_conflicts(base(), {"transaction_code": "856", "user_selected_fields": ["transaction_code"]})
    assert len(data["_selection_conflicts"]) == 1
    c = data["_selection_conflicts"][0]
    assert c["path"] == "tx_code"
    assert c["fileValues"] == ["850"]
    assert c["selectedValue"] == "856"
    data = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP")
    qs = merge_blueprint_questions(data, [], source_interface="SFTP", target_interface="SFTP")
    q = next(q for q in qs if q["type"] == "conflict")
    assert q["conflict"]["fileValues"] == ["850"]
    assert q["conflict"]["fileEvidence"][0]["sourceFile"] == "customer_po.xml"
    assert q["conflict"]["fileEvidence"][0]["confidence"] == "high"
    assert q["conflict"]["selectedValue"] == "856"
    assert q["path"] == "tx_code"


def test_operator_can_choose_file_value_and_conflict_is_persistently_resolved(tmp_path: Path):
    data = detect_user_selection_conflicts(base(), {"transaction_code": "856", "user_selected_fields": ["transaction_code"]})
    data = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP")
    qs = merge_blueprint_questions(data, [], source_interface="SFTP", target_interface="SFTP")
    q = next(q for q in qs if q["type"] == "conflict")
    resolved, applied = apply_answers(tmp_path, data, qs, {q["id"]: "850"}, "SFTP", "SFTP")
    assert resolved["tx_code"] == "850"
    assert resolved.get("_selection_conflicts") == []
    audit = resolved["_builder_audit"]["selection_conflict_resolutions"][-1]
    assert audit["chosenSource"] == "customer_file"
    assert audit["fileValues"] == ["850"]
    assert audit["selectedValue"] == "856"
    assert "tx_code" in applied


def test_operator_can_keep_selected_or_enter_custom_value(tmp_path: Path):
    for chosen, source in [("856", "user_selected"), ("855", "custom_user_value")]:
        data = detect_user_selection_conflicts(base(), {"transaction_code": "856", "user_selected_fields": ["transaction_code"]})
        data = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP")
        qs = merge_blueprint_questions(data, [], source_interface="SFTP", target_interface="SFTP")
        q = next(q for q in qs if q["type"] == "conflict")
        resolved, _ = apply_answers(tmp_path, data, qs, {q["id"]: chosen}, "SFTP", "SFTP")
        assert resolved["tx_code"] == chosen
        assert resolved["_builder_audit"]["selection_conflict_resolutions"][-1]["chosenSource"] == source


def test_equivalent_sftp_aliases_do_not_create_false_conflict():
    data = base()
    data["_file_mapping"]["fieldMappings"].append({"path": "objects.source_transport_profile.interface_type", "value": "SFTP HAFT", "sourceFile": "manual.xlsx", "confidence": "high"})
    out = detect_user_selection_conflicts(data, {"source_interface": "SFTP", "user_selected_fields": ["source_interface"]})
    assert not any(c["selectedField"] == "source_interface" for c in out["_selection_conflicts"])


def test_frontend_tracks_explicit_selection_and_has_three_way_conflict_ui():
    page = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    models = (ROOT / "webapp/backend/app/models.py").read_text(encoding="utf-8")
    assert "user_selected_fields" in models
    assert "selectedFields" in page
    assert "CUSTOMER FILE EVIDENCE" in page
    assert "YOUR SELECTED VALUE" in page
    assert "OTHER APPROVED VALUE" in page
    assert "Use file value" in page
    assert "Keep selected value" in page
    assert "Use custom value" in page

def test_approved_json_interface_conflict_is_surfaced_when_operator_explicitly_changes_it():
    data = base()
    data["objects"]["source_transport_profile"]["interface_type"] = "HTTPS"
    data["_builder_audit"] = {"authoritative_json": {"filename": "approved_customer.json", "source": "uploaded canonical HIP JSON"}}
    out = detect_user_selection_conflicts(data, {"source_interface": "SFTP", "user_selected_fields": ["source_interface"]})
    conflict = next(c for c in out["_selection_conflicts"] if c["selectedField"] == "source_interface")
    assert conflict["fileValues"] == ["HTTPS"]
    assert conflict["selectedValue"] == "SFTP"
    assert conflict["fileSources"] == ["approved_customer.json"]
