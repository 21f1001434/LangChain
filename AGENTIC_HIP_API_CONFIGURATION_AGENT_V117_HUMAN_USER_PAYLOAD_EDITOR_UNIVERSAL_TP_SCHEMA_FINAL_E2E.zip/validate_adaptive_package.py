from __future__ import annotations

import atexit
import json
import shutil
import tempfile
import py_compile
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent

# Keep package validation from polluting the persistent Knowledge Graph and
# AgentQ memory with synthetic test customers.
_KNOWLEDGE_DIR = ROOT / "knowledge"
_KNOWLEDGE_BACKUP_ROOT = Path(tempfile.mkdtemp(prefix="hip_knowledge_validation_"))
_KNOWLEDGE_BACKUP = _KNOWLEDGE_BACKUP_ROOT / "knowledge"
if _KNOWLEDGE_DIR.exists():
    shutil.copytree(_KNOWLEDGE_DIR, _KNOWLEDGE_BACKUP)


def _restore_knowledge_after_validation() -> None:
    if _KNOWLEDGE_DIR.exists():
        shutil.rmtree(_KNOWLEDGE_DIR)
    if _KNOWLEDGE_BACKUP.exists():
        shutil.copytree(_KNOWLEDGE_BACKUP, _KNOWLEDGE_DIR)
    else:
        _KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(_KNOWLEDGE_BACKUP_ROOT, ignore_errors=True)


atexit.register(_restore_knowledge_after_validation)


def check(name: str, condition: bool, details: Any = None) -> Dict[str, Any]:
    return {"name": name, "passed": bool(condition), "details": details}


def main() -> None:
    checks: List[Dict[str, Any]] = []
    modules = [
        "run_agent.py", "adaptive_engine.py", "knowledge_graph.py",
        "agentq_memory.py", "adaptive_uhal_app.py", "uhal_mapper.py",
        "uhal_mcp_server.py", "mcp_bridge.py", "uhal_report.py",
        "api_execution_plan.py", "legacy_pages/90_Advanced_Technical_Workspace.py", "execution_flow.py",
        "payload_overrides.py", "configuration_workspace.py",
    ]
    for name in modules:
        try:
            py_compile.compile(str(ROOT / name), doraise=True)
            checks.append(check(f"compile:{name}", True))
        except Exception as exc:
            checks.append(check(f"compile:{name}", False, str(exc)))

    base = subprocess.run(
        [sys.executable, "validate_package.py"], cwd=ROOT,
        text=True, capture_output=True,
    )
    checks.append(check("base package validation", base.returncode == 0, base.stdout[-3000:] + base.stderr[-1000:]))

    from adaptive_engine import AdaptiveHipEngine
    from mcp_bridge import MCPBridge
    from uhal_mapper import UhalInputMapper

    engine = AdaptiveHipEngine(ROOT)
    current = json.loads((ROOT / "input.json").read_text(encoding="utf-8"))
    config = json.loads((ROOT / "config_overrides.json").read_text(encoding="utf-8"))
    current_prepared = engine.prepare_canonical_input(current, apply_safe=True)
    current_questions = current_prepared.get("unresolvedQuestions") or []
    checks.append(check(
        "current U-HAUL baseline carries the Dev-approved DUNS before live execution",
        bool(current_prepared.get("ready"))
        and str((current_prepared.get("canonicalInput") or {}).get("partner_identifier_value") or current.get("partner_identifier_value") or "") == "12345666"
        and not [q for q in current_questions if q.get("canonical_path") == "partner_identifier_value"],
        {"questions": current_questions, "partner_identifier_value": (current_prepared.get("canonicalInput") or {}).get("partner_identifier_value") or current.get("partner_identifier_value")},
    ))

    synthetic = {
        "client": "ACME", "flow_direction": "outbound", "edi_standard": "X12",
        "message_type": "856", "transaction_name": "Ship Notice", "source_app": "ANS",
        "source_doc_type": "XML_ACME_ASN_IB", "source_root": "DellAutoASN", "source_format": "XML",
        "source_attributes": current["objects"]["source_document_type"]["attributes_to_configure"],
        "target_doc_type": "XML_ACME_SHIPNOTICE_OB", "target_root": "SHIPMENT_NOTICE", "target_format": "XML",
        "target_attributes": current["objects"]["target_document_type"]["attributes_to_configure"],
        "mapping_identifier": "ACME_ASN_MAP", "mapping_name": "ACME_ASN",
        "jar_file": "Transform_DELLCoXMLASNXX08C.jar", "mapping_rule_name": "ACME_ASN_RULE",
        "conditions": [
            {"condition_type": "Attributes", "operator": "Equals", "value": "acme", "attribute_name_unit": "Receiver"},
            {"condition_type": "Attributes", "operator": "Contains", "value": "DELL", "attribute_name_unit": "Sender"},
        ],
        "source_system_name": "AIC - DCE", "source_tp_name": "SFTP_ACME_SRC",
        "source_role": "Sender", "source_protocol": "SFTP HAFT",
        "source_haft_account": "acct_src", "source_folder": "/src",
        "target_partner_name": "acme-partner", "target_tp_name": "SFTP_ACME_TGT",
        "target_role": "Receiver", "target_protocol": "SFTP HAFT",
        "target_haft_account": "acct_tgt", "target_folder": "/tgt",
        # Validation-only fixture proving the live Partner Create contract once
        # the user supplies the real Dev-approved identifier. Never persisted.
        "partner_identifier_value": "VALIDATION-ONLY-ACME",
    }
    prepared = engine.prepare_canonical_input(synthetic, apply_safe=True)
    checks.append(check("arbitrary alias-based input becomes canonical", prepared.get("ready"), prepared.get("unresolvedQuestions")))
    canonical = prepared["canonicalInput"]
    derived_config = engine.derive_config_updates(canonical, config)
    mapper = UhalInputMapper(canonical, derived_config, ROOT)
    mapper_errors = [item.__dict__ for item in mapper.validate() if item.severity == "ERROR"]
    checks.append(check("new-customer canonical input passes mapper", not mapper_errors, mapper_errors))
    checks.append(check("new-customer runtime IDs are cleared", all(derived_config.get(k) is None for k in ["source_document_type_id","target_document_type_id","map_id","rule_id","existing_flow_id"]), {k:derived_config.get(k) for k in ["source_document_type_id","target_document_type_id","map_id","rule_id","existing_flow_id"]}))

    input_path = ROOT / "input.json"
    config_path = ROOT / "config_overrides.json"
    plan_path = ROOT / "api_execution_plan.json"
    original_input = input_path.read_text(encoding="utf-8")
    original_config = config_path.read_text(encoding="utf-8")
    original_plan = (
        plan_path.read_text(encoding="utf-8")
        if plan_path.exists()
        else None
    )
    payload_dir = ROOT / "payloads"
    report_dir = ROOT / "reports"
    payload_backup = {
        p.name: p.read_bytes()
        for p in payload_dir.glob("*")
        if p.is_file()
    }
    report_backup = {
        p.name: p.read_bytes()
        for p in report_dir.glob("*")
        if p.is_file()
    }
    try:
        input_path.write_text(json.dumps(canonical, indent=2), encoding="utf-8")
        config_path.write_text(json.dumps(derived_config, indent=2), encoding="utf-8")
        # A saved U-HAUL skip plan must never carry into a synthetic customer.
        # Disable it explicitly for this non-mutating request-contract validation.
        plan_path.write_text(
            json.dumps({
                "version": 1,
                "confirmed": False,
                "inputSha256": "",
                "skipSteps": [],
                "existingIds": {},
                "reason": "validator temporary plan",
            }, indent=2),
            encoding="utf-8",
        )
        from run_agent import Runner
        runner = Runner(llm_enabled=False)
        request_checks = []
        for seq, step_key in enumerate(runner.execution_flow.ordered_steps(), start=1):
            preview = runner.preview_step_request(step_key)
            contract = runner.validate_request_contract(
                seq=seq,
                api_key=preview.get("urlKey") or step_key,
                method=preview.get("method") or "GET",
                url=preview.get("url") or "",
                extra_headers=preview.get("extraHeaders") or {},
                payload=preview.get("payload"),
                params=preview.get("params"),
            )
            request_checks.append({"stepKey": step_key, "valid": bool(contract.get("valid")), "errors": contract.get("errors") or []})
        blocked = [row for row in request_checks if not row["valid"]]
        checks.append(check("new-customer full payload chain has 18 steps", len(request_checks) == 18, len(request_checks)))
        checks.append(check("new-customer full payload chain has no contract blocks", not blocked, blocked))
        checks.append(check("flow naming is dynamic", runner.flow_name().startswith("ACME_"), runner.flow_name()))
        checks.append(check("flow description is dynamic", "ACME" in runner.flow_description(), runner.flow_description()))
    finally:
        input_path.write_text(original_input, encoding="utf-8")
        config_path.write_text(original_config, encoding="utf-8")
        if original_plan is None:
            plan_path.unlink(missing_ok=True)
        else:
            plan_path.write_text(original_plan, encoding="utf-8")
        for path in payload_dir.glob("*"):
            if path.is_file():
                path.unlink()
        for name, content in payload_backup.items():
            (payload_dir / name).write_bytes(content)
        for path in report_dir.glob("*"):
            if path.is_file():
                path.unlink()
        for name, content in report_backup.items():
            (report_dir / name).write_bytes(content)

    proposal = engine.propose_change(
        "Use deployment group hip-automation for both and change base URL to https://apigtwtst.us.dell.com/hip-config-service",
        current, config,
    )
    checks.append(check("Dev change request creates approval-gated patch", bool(proposal.get("patch")) and proposal.get("impact", {}).get("requiresApproval"), proposal))
    applied = engine.apply_change(proposal, current, config, approve=True)
    checks.append(check("approved patch applies to input/config", applied.get("applied") and len(applied.get("appliedOperations") or []) >= 3, applied.get("appliedOperations")))

    mcp = MCPBridge(ROOT, enabled=True, required=False)
    mcp_analysis = mcp.analyze_new_input(synthetic)
    checks.append(check("MCP analyzes new input", "canonicalPreview" in mcp_analysis, mcp_analysis))
    mcp_prepared = mcp.prepare_canonical_input(synthetic, apply_safe=True)
    checks.append(check("MCP prepares canonical input", mcp_prepared.get("ready"), mcp_prepared.get("unresolvedQuestions")))
    mcp_change = mcp.propose_change_patch("Use deployment group hip-automation", current, config)
    checks.append(check("MCP proposes change patch", bool(mcp_change.get("patch")), mcp_change))
    kg_query = mcp.query_knowledge_graph("flow", limit=20)
    checks.append(check("MCP queries knowledge graph", "stats" in kg_query and "results" in kg_query, kg_query.get("stats")))
    aq_status = mcp.agentq_memory_status()
    checks.append(check("MCP exposes AgentQ memory", "stats" in aq_status, aq_status.get("stats")))

    manifest = UhalInputMapper(current, config, ROOT).execution_manifest()
    kg_status = engine.record_mapping_graph(manifest)
    checks.append(check("Knowledge Graph stores mapping/dependencies", kg_status.get("nodeCount", 0) > 0 and kg_status.get("edgeCount", 0) > 0, kg_status))
    json_export = engine.kg.export_json()
    graphml_export = engine.kg.export_graphml()
    checks.append(check("Knowledge Graph exports JSON and GraphML", json_export.exists() and graphml_export.exists(), [str(json_export), str(graphml_export)]))
    checks.append(check("AgentQ trajectory memory records experience", engine.agentq.stats().get("trajectoryCount", 0) > 0, engine.agentq.stats()))

    ui_text = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8") + "\n" + (ROOT / "legacy_pages" / "90_Advanced_Technical_Workspace.py").read_text(encoding="utf-8")
    for feature in [
        "Guided new configuration (no JSON)",
        "Upload input.json",
        "Start from API payloads",
        "Agent questions and missing values",
        "Payload Studio",
        "API documentation PDF(s)",
        "User / Dev Team Change Agent",
        "Knowledge Graph and AgentQ-inspired learning",
        "API Execution Plan",
        "SKIP — EXISTING",
        "Execution Flow & Timing",
        "Wait after (seconds)",
        "Account token URL",
        "Partner token URL",
        "System token URL",
        "Ask Dell AIA to suggest order/timing",
        "Execute live end-to-end configuration",
    ]:
        checks.append(check(f"adaptive UI:{feature}", feature in ui_text))

    run_text = (ROOT / "run_agent.py").read_text(encoding="utf-8")
    checks.append(check("new consolidated base URL retained", "https://apigtwtst.us.dell.com/hip-config-service" in run_text))
    checks.append(check("run_agent supports new input preparation", "--prepare-input" in run_text and "--use-input" in run_text))
    checks.append(check("run_agent supports change requests", "--change-request" in run_text and "--apply-change" in run_text))
    checks.append(check("run_agent supports KG and AgentQ status", "--kg-status" in run_text and "--agentq-status" in run_text))
    checks.append(check("run_agent supports execution flow status/reset", "--execution-flow-status" in run_text and "--reset-execution-flow" in run_text))
    checks.append(check("dedicated Account/Partner/System OAuth profiles implemented", all(token in run_text for token in ["ACCOUNT_CLIENT_ID", "PARTNER_CLIENT_ID", "SYSTEM_CLIENT_ID", 'token_kind == "ACCOUNT"', 'token_kind == "PARTNER"', 'token_kind == "SYSTEM"'])))
    checks.append(check("run_agent supports payload override status/clear", "--payload-overrides-status" in run_text and "--clear-payload-overrides" in run_text))
    checks.append(check("run_agent exposes payload request preview", "preview_step_request" in run_text and "--preview-request" in run_text))
    checks.append(check(
        "human payload edits are pre-LIVE only and immutable once materialized",
        "interface_only=False" in run_text
        and "generated_factory = json.loads(json.dumps(call_factory" in run_text
        and "immutable_override_meta" in run_text,
    ))

    secret_pattern = re.compile(r"(?i)(client_secret|clientsecret)\s*[:=]\s*[\"'][^\"']{16,}[\"']")
    secret_hits: List[str] = []
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".py", ".json", ".md", ".txt", ".ps1", ".bat"}:
            content = path.read_text(encoding="utf-8", errors="ignore")
            if secret_pattern.search(content) and "REPLACE_" not in content:
                secret_hits.append(str(path.relative_to(ROOT)))
    checks.append(check("no hardcoded real client secrets", not secret_hits, secret_hits))

    failed = [item for item in checks if not item["passed"]]
    output = {
        "status": "PASS" if not failed else "FAIL",
        "passed": len(checks) - len(failed),
        "failed": len(failed),
        "checks": checks,
        "liveApisExecuted": False,
        "note": "Validation covers adaptive mapping, change patches, MCP tools, Knowledge Graph, AgentQ-inspired memory, payload contracts and dependency logic. Live DEV execution still requires valid credentials and backend access.",
    }
    report_path = ROOT / "reports" / "adaptive_package_validation_latest.json"
    report_path.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"status": output["status"], "passed": output["passed"], "failed": output["failed"]}, indent=2))
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
