# V96 — Strict Whole-Pipeline LIVE Execution + Per-API Evidence

## Requirement implemented

`RUN LIVE EXECUTION` now means **execute the whole applicable HIP pipeline against the LIVE HIP endpoints and capture the result of each API**. It is not a validation-only action, does not use dry-run behavior, and does not accept an existing-object skip plan as proof that an API succeeded.

For the developer-approved U-HAUL Translation configuration, the canonical pipeline contains **18 applicable HIP API blocks** and strict LIVE requires **18/18 live HTTP results** before the execution can pass.

## Canonical 18-API sequence

1. Validate Source TP
2. Validate Target TP
3. Validate Flow Name
4. Create/resolve Source Account
5. Create/resolve Target Account
6. Create/resolve Target Partner
7. Create/resolve Source System
8. Create/resolve Source Document Type
9. Create/resolve Target Document Type
10. Create/resolve MAC Map
11. Create/resolve Mapping Rule
12. Source TP Orchestration Create
13. Target TP Orchestration Create
14. Flow Orchestration Create
15. Flow Orchestration Deploy
16. Flow Deployment History
17. Source TP Audit
18. Target TP Audit

## Strict LIVE rules

- `HIP_STRICT_LIVE_PIPELINE=1` is forced by the React/FastAPI LIVE execution backend.
- Persisted API skip plans are ignored in strict mode.
- An object is considered existing only when the corresponding LIVE API response proves it (`already exists`, duplicate/unique evidence, or another response classified as EXISTING).
- A failed API is not marked resolved merely because a later dependent API succeeded.
- Dependency order is retained. If a prerequisite fails before HTTP or transiently, V96 performs bounded auto-completion/retry passes.
- After business-object recovery, V96 performs strict coverage passes for any applicable API that still has no HTTP response, including validation and TP audit APIs.
- If an API still cannot be safely called because a prerequisite remains unresolved, coverage stays incomplete and the run is BLOCKED rather than fabricated.
- V96 never invents OAuth secrets, passwords, certificate values, DUNS/partner identifiers, or other customer-owned/security-sensitive values.

## LIVE evidence captured

Each API attempt writes:

- full redacted request payload/query evidence under `payloads/`;
- standalone redacted response/result evidence under `reports/live_api_evidence/`;
- HTTP status;
- business classification;
- business-success flag;
- elapsed milliseconds;
- extracted runtime IDs;
- error/diagnostic evidence when the request did not reach HTTP.

V96 also writes:

`reports/live_api_evidence_manifest_latest.json`

The manifest contains one canonical row per API with:

- `stepKey`
- `label`
- `applicable`
- `apiCalled`
- `httpStatus`
- `classification`
- `businessSuccess`
- `sequence`
- `requestEvidenceFile`
- `responseEvidenceFile`
- `elapsedMs`
- `error`

Top-level coverage fields include:

- `assumptionFree: true`
- `skipPlanIgnored: true`
- `expectedApplicableApiCount`
- `calledApplicableApiCount`
- `coverageComplete`
- `coverageMissingSteps`
- `nonPassingLiveSteps`

## Success criteria

In strict mode, runner success requires all of the following:

1. all required business prerequisites are resolved by their own LIVE API evidence;
2. every applicable canonical API has a real HTTP result;
3. no latest canonical LIVE result remains non-passing;
4. Flow Deploy completes;
5. Flow Deployment History proves a successful deployment state;
6. required TP audit calls execute and return valid responses.

For U-HAUL Translation this is therefore a true **18/18 LIVE pipeline**.

## Parallel execution

- Microsoft AutoGen AgentChat 0.7.5 remains the agent framework.
- Up to four customer/instance AutoGen agents execute concurrently.
- Inside each agent, dependency-ready HIP APIs can run in parallel.
- OAuth token acquisition remains single-flight per worker and serialized across worker processes to prevent token-endpoint stampedes.
- Additional customer instances wait for the next agent wave rather than starting a fifth concurrent AutoGen agent.

## Previous production fixes retained

V96 includes all V93/V94/V95 hardening:

- Windows `WinError 5` token-diagnostic persistence cannot fail an OAuth/API call.
- OAuth transient connection/proxy/timeout failures retry with bounded backoff.
- OAuth 408/425/429/500/502/503/504 are retryable.
- OAuth 400/401/403 remain hard authentication/configuration errors.
- Existing-object responses are classified as successful reusable state when the API itself proves them.
- Stale `unresolvedRequiredSteps` are recalculated from direct API evidence and successful same-step retries.
- Same-customer repeated instances remain isolated and instant delete/renumber behavior is preserved.

## Validation evidence

V96 regression coverage includes:

- persisted skip plan forced to `skip` for every API while strict LIVE still calls all 18;
- Source Account forced to fail before HTTP on attempt 1, then recovered by retry before downstream completion;
- final strict coverage of 18/18 APIs after dependency repair;
- response evidence persistence;
- React/FastAPI forcing strict LIVE mode;
- V93 WinError5 and V95 OAuth single-flight regression suites.

A real Dell HIP production mutation still requires the customer's Dell network, OAuth credential profiles, Dell AIA credentials, and runtime payload secrets. Those are intentionally not embedded in this release.
