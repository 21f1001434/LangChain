# HIP API Agent Studio V90
## Real AutoGen 4-Agent LIVE Execution + Immediate Grouped Delete

Build ID: `2026-08-25-agentic-hip-v90-autogen-4-agent-live-instant-delete`

## 1. Execution model

V90 uses Microsoft AutoGen for the customer/instance worker layer.

- One selected customer/instance = one AutoGen `ConversableAgent`.
- 1-4 AutoGen agents may execute concurrently.
- 5 concurrent agents are not scheduled because the observed stability test returned HTTP 429 at 5 while 1-4 were stable.
- Selecting more than four payload snapshots is supported; the queue is drained in waves of at most four AutoGen agents.
- Within each AutoGen agent, `run_agent.py` retains dependency-aware API parallelism. All dependency-ready HIP API calls in a wave may execute concurrently using the API thread pool.
- The 18 developer-approved HIP request schemas remain locked. Parallelism does not add/remove/rename payload attributes.

Observed concurrency envelope supplied during V90 validation:

| Parallel AutoGen agents | Result |
|---:|---|
| 1 | Stable |
| 2 | Stable |
| 3 | Stable |
| 4 | 100% stable |
| 5 | Unstable - HTTP 429 |

V90 therefore uses four as the server-side concurrency ceiling. If 8 instances are selected, the normal behavior is 4 + 4, not 8 simultaneously.

## 2. AutoGen is real, not a UI label

The implementation is in:

`webapp/backend/app/autogen_runtime.py`

It imports `autogen.ConversableAgent` from Microsoft AutoGen 0.2 / `pyautogen`. The agent is deterministic (`llm_config=False`) and owns one governed HIP execution task through a registered AutoGen reply function. The already-existing Dell AIA model remains available inside `run_agent.py` for its judgement/explanation responsibilities; V90 does not spend an extra LLM request merely to schedule deterministic execution.

`requirements.txt` contains:

`pyautogen>=0.2.35,<0.3`

Production behavior defaults to `HIP_AUTOGEN_REQUIRED=1`. If AutoGen is not installed, LIVE parallel execution fails clearly instead of pretending ordinary Python threads are AutoGen agents. `HIP_AUTOGEN_REQUIRED=0` exists only as an emergency/test compatibility switch.

## 3. Same customer and different customers use the same scheduler

The same **RUN LIVE EXECUTION** action handles:

- one customer once;
- the same customer multiple times;
- multiple different customers;
- any mixed selection of validated customer snapshots.

The scheduler does not create a separate stress/capacity workflow. It executes the real validated payloads LIVE after final revalidation and production preflight.

## 4. API parallelism inside each AutoGen agent

The AutoGen worker starts the governed HIP runner with:

- `HIP_API_PARALLEL_ENABLED=1`
- `HIP_API_MAX_PARALLEL=18` by default (environment-overridable)

`run_agent.py` calculates API dependencies and uses `ThreadPoolExecutor` only for dependency-ready API calls. Dependent APIs wait until prerequisites complete.

This means four AutoGen agents can run four customer/instance configurations concurrently, while each agent can independently fan out multiple safe HIP API calls.

## 5. Immediate deletion fix

V90 fixes the queue behavior where deleting `1/3`, `2/3`, or `3/3` did not visibly update until browser refresh.

### Frontend tombstone

When Delete is confirmed:

1. the row disappears immediately;
2. the selection is cleared immediately;
3. the job ID is placed in a client tombstone set;
4. any refresh/event response is filtered through that tombstone, so a stale server response cannot resurrect the deleted row;
5. after the backend confirms the job is gone, the tombstone is released;
6. if deletion fails, the previous rows/selections are restored immediately and a rollback message is shown.

### Delete selected

The queue now includes **Delete selected**, allowing multiple queued instances to disappear immediately in one user action. Backend endpoint:

`POST /api/parallel/queue/delete-many`

### Instance reindexing

Repeated snapshots created together have an `instanceGroupId`. When a member is deleted, remaining manifests are reindexed.

Example:

Before: `1/3`, `2/3`, `3/3`

Delete `2/3`

After: `1/2`, `2/2`

This changes queue metadata only; it does not mutate the validated customer payload snapshot.

## 6. Safety retained

V90 retains all prior protections:

- U-HAUL remains developer-approved, immutable, and 18/18.
- U-HAUL can be cloned but the approved baseline cannot be edited/deleted.
- Create New / Clone Existing / Edit Existing with confirmation.
- Customer-file vs user-selection conflict gate.
- Global customer selector.
- Stop Batch / Stop Instance.
- Pipeline all-stage validation/preflight before first LIVE mutation.
- Windows writable runtime location and resilient report persistence.
- Exact first-blocker diagnostics.
- Canonical 18-API payload structure lock.
- Only approved customer-specific values are editable.

## 7. Installation / run

Use a fresh extracted folder.

Python environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Or install using your approved `uv` workflow if that is the local standard.

Then use the packaged launcher:

```powershell
.\RUN_AGENTIC_HIP.bat
```

The AutoGen dependency must be installed before LIVE parallel execution.

## 8. V90 validation

Executed in the packaging environment:

- Root/application pytest: 290/290 PASS
- FastAPI/backend pytest: 48/48 PASS
- Total automated pytest: 338/338 PASS
- V73-V90 focused regression: 65/65 PASS
- V90 targeted tests including fake AutoGen `ConversableAgent` invocation: PASS
- Frontend TS/TSX transpilation: 24/24 PASS
- Python compileall: PASS
- Phase 6 validation: 38/38 PASS
- Final release validation: 16/16 PASS
- Package validation: 57/57 PASS
- Adaptive compatibility validation: 60/60 PASS
- Required self-check: 43/43 PASS

### AutoGen package test limitation

The packaging sandbox has no outbound PyPI network access. `pyautogen` was therefore not installable in this environment. The real AutoGen integration path is covered by a test that injects a compatible `autogen.ConversableAgent` and proves that its registered reply invokes the governed HIP execution function exactly once. Production requires the pinned `pyautogen` dependency by default.

## 9. Important runtime interpretation

A V90 PASS means the actual HIP runner completed and the response/verdict logic classified the execution as successful. External HIP services can still return legitimate HTTP 4xx/5xx/rate-limit/business errors. V90 surfaces those as their real blocker rather than hiding them.
