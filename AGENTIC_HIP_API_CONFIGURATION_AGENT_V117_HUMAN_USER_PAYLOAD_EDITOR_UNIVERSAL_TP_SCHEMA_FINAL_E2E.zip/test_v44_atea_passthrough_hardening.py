import json
import zipfile
from copy import deepcopy
from pathlib import Path

from input_builder_core import (
    _canonical_input_json_candidate,
    build_from_zip,
)
from input_builder_integration import apply_selected_interfaces
from webapp.backend.app.legacy_adapter import build_configuration


def _atea_approved():
    # Reconstructed from the ATEA_NORWAY_dev_approved.json reference screenshots.
    return {
        "profile_name": "ATEA_NORWAY_PC_PO_PREMIER_PASSTHROUGH_IB",
        "customer": "ATEA_NORWAY",
        "folder": "ATEA_NORWAY",
        "tx_standard": "XML",
        "tx_code": "850",
        "tx_name": "Purchase Order",
        "direction": "Inbound",
        "flow_type": "passthrough",
        "requires_data_map": False,
        "objects": {
            "data_map": {
                "map_identifier": "", "map_identifier_version": "", "status": "",
                "map_name": "", "map_class": "", "contivo_version": "", "map_data_file": "",
                "_passthrough": True,
            },
            "source_document_type": {
                "name": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P",
                "transaction_type": "PO",
                "data_format_type": "XML",
                "version": "1.0",
                "description": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P",
                "validation_type": "Structure",
                "document_identifier": {
                    "operation": "All conditions are satisfied",
                    "rows": [{"derived_from": "TRANSACTION_ROOT_ELEMENT", "value": "cXML"}],
                },
                "attributes_to_configure": [
                    {"attribute_name": "Receiver", "derived_from": "FILE_NAME", "usage": "Flow Identifier Expression, Logging, Mapping, Routing", "expression": "parts[1-2]"},
                    {"attribute_name": "Sender", "derived_from": "ELEMENT_IN_PAYLOAD", "usage": "Flow Identifier Expression, Logging, Mapping, Routing", "expression": "/cXML/Header/From/Credential/Identity"},
                    {"attribute_name": "Transaction Type", "derived_from": "TRANSACTION_ROOT_ELEMENT", "usage": "Flow Identifier Expression, Logging, Mapping, Routing", "expression": ""},
                    {"attribute_name": "Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "usage": "Flow Identifier Expression, Logging, Mapping, Routing", "expression": "/cXML/Request/OrderRequest/OrderRequestHeader/@orderID"},
                    {"attribute_name": "Alternate Business Identifier", "derived_from": "ELEMENT_IN_PAYLOAD", "usage": "Flow Identifier Expression, Logging, Mapping, Routing", "expression": "/cXML/Header/Sender/Credential/Identity"},
                ],
                "status": "Enable",
                "operation": "One or more conditions are satisfied",
            },
            "target_document_type": {
                "name": "", "transaction_type": "", "version": "", "data_format_type": "",
                "status": "", "description": "", "validation_type": "",
                "document_identifier": {"operation": "", "rows": []},
                "attributes_to_configure": [], "_passthrough": True,
            },
            "rule": {
                "name": "NA", "version": "NA", "document_type_name_version": "NA",
                "rule_type": "NA", "rule_scope": "NA", "status": "NA", "description": "NA",
                "_passthrough": True,
            },
            "source_transport_profile": {
                "system_type": "Partner", "partner_name": "dce-test-partner",
                "profile_name": "SFTP_ATEA_NORWAY_PO_PC_SRC_IB", "profile_usage": "Sender",
                "deployment_group": "hip-automation", "interface_type": "SFTP HAFT",
                "existing_account": "Yes", "existing_account_name": "haftatap10251594",
                "use_existing_folder": "No", "post_transfer_action": "Move to Archive",
                "is_compression_required": "FALSE", "subscription_folder": "/SFTP_ATEA_NORWAY_PO_PC_SRC_IB",
                "document_type": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)", "interface_environment": "UAT",
            },
            "target_transport_profile": {
                "system_type": "Dell Application", "system_name": "AIC - DCE", "partner_name": "AIC - DCE",
                "profile_name": "SFTP_ATEA_NORWAY_PO_PC_TGT_OB", "profile_usage": "Receiver",
                "deployment_group": "hip-automation", "interface_type": "SFTP HAFT",
                "interface_environment": "UAT", "existing_account": "Yes", "existing_account_name": "haftatap10251593",
                "use_existing_folder": "No", "subscription_folder": "/SFTP_ATEA_NORWAY_PO_PC_TGT_OB",
                "post_transfer_action": "Move to Archive", "is_compression_required": "FALSE",
                "document_type": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)",
            },
            "biz_flow": {
                "flow_details": {
                    "current_flow_version": "1",
                    "business_flow_name": "ATEA_NORWAY_PC_850_cXML_DELL_PASSTHROUGH_IB",
                    "flow_description": "Inbound cXML 850 passthrough from ATEA NORWAY to Dell",
                },
                "configure_source": {
                    "source_type": "Partner", "source_application": "dce-test-partner",
                    "source_transport_profile": "SFTP_ATEA_NORWAY_PO_PC_SRC_IB",
                    "document_type_name_version": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)",
                },
                "flow_identifiers": {
                    "operator": "one or more conditions are satisfied",
                    "conditions": [
                        {"document_type_name_version": "SFTP_ATEA_NORWAY_PO_PC_SRC_IB(1.0)", "attribute_name": "Receiver", "operator": "Contains", "value": "DELL_ORDERS"},
                        {"document_type_name_version": "SFTP_ATEA_NORWAY_PO_PC_SRC_IB(1.0)", "attribute_name": "Sender", "operator": "Equals", "value": "B2B_ATEA_NO"},
                    ],
                },
                "configure_targets": {
                    "target_type": "Dell Application", "target_application": "AIC - DCE",
                    "target_transport_profile": "SFTP_ATEA_NORWAY_PO_PC_TGT_OB",
                    "document_type_name_version": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)",
                },
                "process_steps": [],
                "configure_routing": {
                    "rule": {
                        "name": "FLOWROUTE_ATEA_NORWAY_PC_850_cXML_DELL_cXML_IB", "version": "3",
                        "document_type_name_version": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)",
                        "rule_type": "Target Routing", "rule_scope": "LOCAL", "status": "Enabled",
                        "execute_always": "Not Enabled",
                    },
                    "conditions": {
                        "execute_actions_when": "all conditions are satisfied",
                        "rows": [
                            {"condition_type": "Attributes", "operator": "Contains", "value": "DELL_ORDERS", "attribute_name": "Receiver"},
                            {"condition_type": "Attributes", "operator": "Equals", "value": "B2B_ATEA_NO", "attribute_name": "Sender"},
                        ],
                    },
                    "actions": {
                        "name": "FLOWACTION_ATEA_NORWAY_PC_850_cXML_DELL_cXML_IB_ROUTE",
                        "type": "Route Document", "target": "XML_cXML_PO_10_ATEA_NORWAY_PRM_P",
                    },
                },
            },
        },
    }


def test_atea_reference_passthrough_is_preserved_and_needs_no_questions(tmp_path: Path):
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    (uploads / "ATEA_NORWAY_dev_approved.json").write_text(json.dumps(_atea_approved()), encoding="utf-8")

    result = build_configuration(
        tmp_path,
        {
            "input_mode": "files",
            "direction": "Outbound",       # deliberately conflicting fresh-card defaults
            "transaction_code": "999",
            "source_interface": "SFTP",
            "target_interface": "SFTP",
        },
        use_dell_aia=False,
    )
    data = result["input"]
    assert data["direction"] == "Inbound"
    assert data["tx_code"] == "850"
    assert data["flow_type"] == "passthrough"
    assert data["requires_data_map"] is False
    assert data["partner_identifier_value"] == "B2B_ATEA_NO"
    assert data["objects"]["target_document_type"]["name"] == ""
    assert data["objects"]["rule"]["name"] == "NA"
    assert data["objects"]["biz_flow"]["process_steps"] == []
    assert data["objects"]["source_transport_profile"]["document_type"] == "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)"
    assert data["objects"]["target_transport_profile"]["document_type"] == "XML_cXML_PO_10_ATEA_NORWAY_PRM_P(1.0)"
    assert data["objects"]["biz_flow"]["configure_routing"]["actions"]["type"] == "Route Document"
    assert result["questions"] == []


def test_core_zip_builder_treats_approved_json_as_authoritative(tmp_path: Path):
    zpath = tmp_path / "customer_bundle.zip"
    with zipfile.ZipFile(zpath, "w") as zf:
        zf.writestr("reference/ATEA_NORWAY_dev_approved.json", json.dumps(_atea_approved()))
    data = build_from_zip(zpath, direction="Outbound", flow_type="", use_dell_aia=False)
    assert data["customer"] == "ATEA_NORWAY"
    assert data["direction"] == "Inbound"
    assert data["tx_code"] == "850"
    assert data["flow_type"] == "passthrough"
    assert data["objects"]["biz_flow"]["flow_identifiers"]["conditions"][1]["value"] == "B2B_ATEA_NO"
    assert data["_builder_audit"]["authoritative_json"]["inputJsonAuthoritative"] is True


def test_approved_interface_type_wins_over_ui_default(tmp_path: Path):
    data = _atea_approved()
    data["objects"]["source_transport_profile"]["interface_type"] = "FTP"
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    (uploads / "ATEA_NORWAY_dev_approved.json").write_text(json.dumps(data), encoding="utf-8")
    result = build_configuration(
        tmp_path,
        {"input_mode": "files", "source_interface": "SFTP", "target_interface": "SFTP"},
        use_dell_aia=False,
    )
    assert result["input"]["objects"]["source_transport_profile"]["interface_type"] == "FTP"
    assert result["effective_source_interface"] == "FTP"
    assert result["effective_target_interface"] == "SFTP"


def test_canonical_detector_accepts_wrapped_and_list_shaped_sections():
    data = _atea_approved()
    data["objects"]["source_transport_profile"] = [
        deepcopy(data["objects"]["source_transport_profile"]),
        {**deepcopy(data["objects"]["source_transport_profile"]), "profile_name": "SECOND_SOURCE"},
    ]
    score, candidate = _canonical_input_json_candidate({"input": data, "status": "ok"})
    assert score > 0
    assert candidate["customer"] == "ATEA_NORWAY"
    assert isinstance(candidate["objects"]["source_transport_profile"], list)


def test_interface_application_is_list_safe_for_multi_branch_inputs(tmp_path: Path):
    data = _atea_approved()
    src = deepcopy(data["objects"]["source_transport_profile"])
    src2 = deepcopy(src)
    src2["profile_name"] = "SECOND_SOURCE"
    src2["interface_type"] = "FTP"
    data["objects"]["source_transport_profile"] = [src, src2]
    data["objects"]["biz_flow"]["configure_source"] = [
        deepcopy(data["objects"]["biz_flow"]["configure_source"]),
        {**deepcopy(data["objects"]["biz_flow"]["configure_source"]), "source_transport_profile": "SECOND_SOURCE"},
    ]
    out = apply_selected_interfaces(tmp_path, data, "SFTP", "SFTP", preserve_existing=True)
    assert isinstance(out["objects"]["source_transport_profile"], list)
    assert [x["interface_type"] for x in out["objects"]["source_transport_profile"]] == ["SFTP HAFT", "FTP"]
    assert isinstance(out["objects"]["biz_flow"]["configure_source"], list)


def test_atea_passthrough_api_plan_marks_non_mapping_steps_not_applicable_not_blocked(tmp_path: Path):
    from webapp.backend.app.legacy_adapter import preview_api_requests
    from uhal_mapper import UhalInputMapper

    uploads = tmp_path / "uploads"
    uploads.mkdir()
    (uploads / "ATEA_NORWAY_dev_approved.json").write_text(json.dumps(_atea_approved()), encoding="utf-8")
    result = build_configuration(
        tmp_path,
        {"input_mode": "files", "source_interface": "SFTP", "target_interface": "SFTP"},
        use_dell_aia=False,
    )
    mapper = UhalInputMapper(result["input"], {}, tmp_path)
    assert [issue for issue in mapper.validate() if issue.severity == "ERROR"] == []

    preview = preview_api_requests(tmp_path)
    items = preview["items"]
    assert len(items) == 18
    by_key = {item["stepKey"]: item for item in items}
    assert by_key["doctype_target"]["applicable"] is False
    assert by_key["map"]["applicable"] is False
    assert by_key["rule"]["applicable"] is False
    assert sum(bool(item.get("applicable", True)) for item in items) == 15
