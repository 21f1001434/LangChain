# V112 Latest 02:17 LIVE Run — Fix & Validation Report

## Evidence analyzed

Supplied batch screenshots: `batch_20260831_021044_ef0ddb`.

### LEGRAND

The instance was stopped by the final pre-LIVE gate with the stale top-level Flow name `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` (43 chars), even though the suggested/canonical nested name was `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB` (39 chars). No LIVE HIP call was made.

**Root cause fixed:** V111's normalizer returned early when the nested BizFlow name was already valid, leaving a stale top-level `profile_name` untouched. V112 reconciles both representations and the actual parallel queue snapshot regression now covers this exact split-brain state.

### U-HAUL

The supplied report shows the following progression:

- Validate source TP: PASS
- Validate target TP: PASS
- Validate Flow name: PASS / EXISTING
- Source/Target Document Type: PASS / EXISTING
- Source/Target TP Create: PASS / EXISTING
- MAC Map: PASS / EXISTING
- Mapping Rule: PASS / EXISTING
- Source TP audit: PASS
- Target TP audit: PASS
- Flow Create: BLOCKED by `LIVE_RULE_ID_UNRESOLVED`

**Root cause fixed:** after the immutable Rule POST reports EXISTING with no numeric ID, V111 tried targeted Rule reads and parameterized pagination but omitted the ordinary plain Rules listing request. V112 now executes GET-only current-LIVE plain `/api/rule/summary` reads as well as exact targeted reads, environment-only reads, and bounded pagination. An ID is accepted only for exact Rule name + version + DEV.

No known/historical U-HAUL Rule ID is hardcoded or injected.

## Payload integrity

The developer-approved Mapping Rule POST remains unchanged and omits:

- `documentTypeId`
- `flowDefinitionId`
- `actions[].params.mapId`

Rule identity resolution occurs only after that POST and uses GET with no body. The POST is never rewritten or retried with another payload.

## External Dell route errors

The same Account source/target, Partner and System HTTP 404 upstream-PCF-route failures remain external Dell gateway/upstream deployment conditions. V112 does not classify them as customer-payload defects and does not change their approved payloads.

## V112 validation results

- V112 exact latest-run regressions: **7/7 PASS**
- V110/V111/V109/V108/V106 compatibility focus: **41/41 PASS**
- Full top-level application suite: **395/395 PASS**
- FastAPI/backend suite: **48/48 PASS**
- **Combined Python regression: 443/443 PASS**
- Package validation: **58/58 PASS**
- Adaptive package validation: **60/60 PASS**
- Business readiness: **69/69 PASS**
- Final release: **16/16 PASS**
- Required self-check: **45/45 PASS**
- Phase 1: **PASS (12/12)**
- Phase 2: **PASS (19/19)**
- Phase 3: **PASS (31/31)**
- Phase 4: **PASS (26/26)**
- Phase 5: **PASS (28/28)**
- Phase 6: **PASS (38/38)**
- Controlled 18-step end-to-end API simulation: **PASS**, `endToEndSuccess=true`, `blockedSteps=[]`
- FastAPI process smoke: `/api/health` 200, `/api/bootstrap` 200, `/api/system/status` 200, API catalog count 18.
- Python compilation: PASS.

## Boundary

No authenticated Dell/HIP mutation was executed during packaging. The next LIVE rerun is still required to prove the current private Dell services return the expected current Rule summary data and to confirm the external Account/Partner/System upstream routes have been restored or replaced.
