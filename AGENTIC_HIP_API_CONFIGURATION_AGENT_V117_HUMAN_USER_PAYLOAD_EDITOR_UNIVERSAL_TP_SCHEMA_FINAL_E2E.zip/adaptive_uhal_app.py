from __future__ import annotations

import io
import html
import json
import os
import re
import subprocess
import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st
from dotenv import dotenv_values, load_dotenv, set_key

from adaptive_engine import AdaptiveHipEngine
from api_execution_plan import (
    ApiExecutionPlan,
    clear_execution_plan,
    save_execution_plan,
)
from api_pdf_ingestion import PdfApiKnowledgeBase
from configuration_workspace import (
    FLOW_TP_PRESETS,
    INTERFACE_OPTIONS,
    INTERFACE_HELP,
    build_guided_input,
    clone_uhaul_template,
    default_flow_tp_references,
    guided_questions,
    infer_fields_from_payload_bundle,
)
from execution_flow import (
    ExecutionFlowConfig,
    STEP_DEFINITIONS,
    save_execution_flow,
)
from mcp_bridge import MCPBridge
from payload_overrides import PayloadOverrideStore, clear_all_overrides, clear_override, save_override
from uhal_mapper import UhalInputMapper
from ui_helpers import safe_table_rows
from production_guard import inspect_live_run, clear_stale_live_run, terminate_live_run
from payload_ui_helpers import json_change_paths, payload_status_row, safe_request_for_ui
from business_demo import prepare_uhal_business_demo, build_business_demo_summary, write_business_demo_report
from application_studio import (
    interface_options as studio_interface_options,
    interface_metadata as studio_interface_metadata,
    customer_options as studio_customer_options,
    customer_metadata as studio_customer_metadata,
    prepare_sftp_uhal_studio,
    request_inventory as studio_request_inventory,
    run_local_request_checks as studio_local_checks,
)
from transport_interface_react import TransportInterfaceReActAgent, interface_shared_profiles, validate_interface_only_request_override
from unified_studio_views import render_agentic_interface_studio, render_advanced_tools
from easy_studio import render_easy_studio
from run_agent import Runner
from learn_assistant import LearnAssistant
from scratch_flow_ui import render_scratch_flow_builder
from input_bundle_ui import render_input_bundle_workspace
from api_testing_area_ui import render_api_testing_area
from parallel_config_ui import render_parallel_configuration_workspace
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from streamlit_navigation import apply_pending_workspace, request_workspace_switch, hide_legacy_page_navigation
from runtime_payload_values import (
    has_runtime_payload_value,
    placeholder as runtime_payload_placeholder,
    runtime_payload_status,
    save_runtime_payload_values,
)

ROOT = Path(__file__).resolve().parent
INPUT_JSON = ROOT / "input.json"
CONFIG_JSON = ROOT / "config_overrides.json"
ENV_PATH = ROOT / ".env"
REPORTS = ROOT / "reports"
INPUT_FILES = ROOT / "input_files"
DEV_APPROVED_DIR = ROOT / "dev_approved"
BUILD_ID = "2026-08-12-live-only-all18-interactive-game-upload-v23"
DEFAULT_HIP_TOKEN_URL = "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token"

REPORTS.mkdir(exist_ok=True)
INPUT_FILES.mkdir(exist_ok=True)
load_dotenv(ENV_PATH, override=True)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def save_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    invalidate_connection_check()


def invalidate_connection_check() -> None:
    (REPORTS / "connection_check_latest.json").unlink(missing_ok=True)
    st.session_state.pop("connection_check", None)


def save_env(values: Dict[str, Any]) -> None:
    ENV_PATH.touch(exist_ok=True)
    for key, value in values.items():
        set_key(str(ENV_PATH), key, str(value or ""), quote_mode="always")
    load_dotenv(ENV_PATH, override=True)
    invalidate_connection_check()


def configured(key: str) -> bool:
    value = os.getenv(key, "")
    return bool(value and not value.startswith(("REPLACE_", "PASTE_")))


def render_table(data: Any, empty_message: str = "Nothing to show yet.") -> None:
    rows = safe_table_rows(data)
    if not rows:
        st.caption(empty_message)
        return
    st.dataframe(rows, width="stretch", hide_index=True)


def latest_report() -> Path | None:
    candidates = sorted(REPORTS.glob("UHAL_final_end_to_end_report_*.html"))
    if not candidates:
        candidates = sorted(REPORTS.glob("hip_aia_mcp_agent_report_*.html"))
    return candidates[-1] if candidates else None


def active_input_summary() -> Dict[str, str]:
    value = load_json(INPUT_JSON, {})
    objects = value.get("objects") or {}
    biz = objects.get("biz_flow") or {}
    return {
        "customer": str(value.get("customer") or "Not set"),
        "flow": str(value.get("profile_name") or (biz.get("flow_details") or {}).get("business_flow_name") or "Not set"),
        "direction": str(value.get("direction") or "Not set"),
        "transaction": " ".join(
            x for x in [str(value.get("tx_standard") or ""), str(value.get("tx_code") or ""), str(value.get("tx_name") or "")] if x
        ) or "Not set",
        "mode": str((value.get("_creation_source") or {}).get("mode") or "Existing package"),
    }


def apply_active_input(canonical: Dict[str, Any], reset_plan: bool = True) -> Dict[str, Any]:
    config = load_json(CONFIG_JSON, {})
    updated = engine.derive_config_updates(canonical, config)
    save_json(INPUT_JSON, canonical)
    save_json(CONFIG_JSON, updated)
    if reset_plan:
        clear_execution_plan(ROOT, INPUT_JSON)
        clear_all_overrides(ROOT)
    try:
        engine.record_mapping_graph(UhalInputMapper(canonical, updated, ROOT).execution_manifest())
    except Exception:
        pass
    return updated


def safe_customer_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9]+", "_", str(value or "").upper()).strip("_")
    return token or "CUSTOMER"


def smart_defaults(customer: str, tx_code: str, tx_name: str) -> Dict[str, str]:
    c = safe_customer_token(customer)
    code = re.sub(r"[^A-Za-z0-9]+", "", str(tx_code or "")) or "TX"
    return {
        "flow_name": f"{c}_{code}_FLOW",
        "source_doc_name": f"XML_DELL_{c}_{code}_IB",
        "target_doc_name": f"XML_{c}_{code}_OB",
        "map_identifier": f"DELL_{c}_{code}_MAP",
        "map_name": f"DELL_{c}_{code}",
        "map_class": f"Transform_DELL_{c}_{code}",
        "rule_name": f"DELL_{c}_{code}_RULE",
        "source_tp_profile": f"SFTP_{c}_{code}_SRC_IB",
        "target_tp_profile": f"SFTP_{c}_{code}_TGT_OB",
        "flow_description": f"{tx_name or code} integration for {customer or c}",
    }


def xml_root(uploaded: Any) -> str:
    if not uploaded:
        return ""
    try:
        root = ET.fromstring(uploaded.getvalue())
        return str(root.tag).split("}")[-1]
    except Exception:
        return ""


def json_object_or_empty(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def normalize_payload_bundle(value: Any) -> Dict[str, Dict[str, Any]]:
    if not isinstance(value, dict):
        raise ValueError("The payload file must contain a JSON object.")
    valid_keys = set(STEP_DEFINITIONS)
    out: Dict[str, Dict[str, Any]] = {}
    for key, raw in value.items():
        if key not in valid_keys:
            continue
        if isinstance(raw, dict) and isinstance(raw.get("value"), dict):
            out[key] = raw["value"]
        elif isinstance(raw, dict) and isinstance(raw.get("payload"), dict):
            out[key] = raw["payload"]
        elif isinstance(raw, dict) and isinstance(raw.get("params"), dict):
            out[key] = raw["params"]
        elif isinstance(raw, dict):
            out[key] = raw
    if not out:
        raise ValueError("I could not recognize any HIP API steps in that payload file.")
    return out


def agent_fallback(step: str, facts: Dict[str, Any]) -> Dict[str, Any]:
    next_action = facts.get("next_action") or "Complete the highlighted item and I will re-check the workspace."
    return {
        "message": facts.get("message") or "I can guide you through this step. You do not need to know the API details.",
        "nextActions": [next_action],
        "whatYouCanIgnore": facts.get("ignore") or "Technical payload fields can stay hidden unless validation says they need attention.",
    }


def ask_agent(step: str, facts: Dict[str, Any]) -> Dict[str, Any]:
    fallback = agent_fallback(step, facts)
    try:
        from run_agent import AIAJudge
        judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
        if not judge.available():
            return fallback
        judge.verify_connection()
        return judge.complete_json(
            system=(
                "You are the friendly guide inside a Dell HIP configuration application. "
                "The user may be non-technical. Explain only what they need to do next in plain business language. "
                "Do not expose secrets. Do not invent IDs or payload fields. Return JSON only with keys "
                "message, nextActions (array), whatYouCanIgnore. Keep it short and reassuring without being patronizing."
            ),
            user=json.dumps({"step": step, "workspaceFacts": facts}, indent=2, default=str)[:14000],
            temperature=0.1,
        )
    except Exception:
        return fallback


def coach(key: str, title: str, body: str, next_action: str, facts: Dict[str, Any] | None = None) -> None:
    st.markdown(
        f"""
        <div class="coach">
          <div class="coach-icon">✨</div>
          <div><div class="coach-title">{title}</div><div class="coach-body">{body}</div>
          <div class="coach-next"><b>Next:</b> {next_action}</div></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    if st.button("Ask the agent to guide me", key=f"coach_{key}", width="content"):
        payload = {"message": body, "next_action": next_action, **(facts or {})}
        st.session_state[f"coach_reply_{key}"] = ask_agent(key, payload)
    reply = st.session_state.get(f"coach_reply_{key}")
    if reply:
        with st.container(border=True):
            st.markdown(f"**Agent:** {reply.get('message', '')}")
            for item in reply.get("nextActions") or []:
                st.markdown(f"- {item}")
            if reply.get("whatYouCanIgnore"):
                st.caption(reply["whatYouCanIgnore"])


def readiness_state() -> Dict[str, Any]:
    input_data = load_json(INPUT_JSON, {})
    config = load_json(CONFIG_JSON, {})
    try:
        mapper_issues = [x.__dict__ for x in UhalInputMapper(input_data, config, ROOT).validate()]
    except Exception as exc:
        mapper_issues = [{"severity": "ERROR", "message": str(exc)}]
    try:
        mcp_validation = mcp.validate_uhal_input(input_data, config)
    except Exception as exc:
        mcp_validation = {"valid": False, "issues": [{"message": str(exc)}]}
    connection = load_json(REPORTS / "connection_check_latest.json", {})
    plan = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
    flow = ExecutionFlowConfig(ROOT).summary()
    payloads = PayloadOverrideStore(ROOT).summary()
    pdf_required = os.getenv("PDF_REQUIRE_DOCUMENTATION", "false").lower() in {"true", "1", "yes"}
    pdf_ready = (not pdf_required) or pdf_kb.has_documents()
    mapper_ok = not any(x.get("severity") == "ERROR" for x in mapper_issues)
    plan_ok = (not plan.get("confirmed")) or bool(plan.get("active"))
    state = {
        "input": input_data,
        "mapper_issues": mapper_issues,
        "mapper_ok": mapper_ok,
        "mcp": mcp_validation,
        "mcp_ok": bool(mcp_validation.get("valid")),
        "connection": connection,
        "connections_ok": connection.get("overall") == "OK",
        "plan": plan,
        "plan_ok": plan_ok,
        "flow": flow,
        "flow_ok": bool(flow.get("valid")),
        "payloads": payloads,
        "payloads_ok": bool(payloads.get("valid", True)),
        "pdf_ready": pdf_ready,
    }
    state["ready"] = all(
        [state["mapper_ok"], state["mcp_ok"], state["connections_ok"], state["plan_ok"], state["flow_ok"], state["payloads_ok"], state["pdf_ready"]]
    )
    return state


def next_recommendation(state: Dict[str, Any]) -> tuple[str, str]:
    if not load_json(INPUT_JSON, {}).get("customer"):
        return "Start", "Tell me who this configuration is for."
    if not state["connections_ok"]:
        return "Connect", "Connect the services needed for this run."
    if not state["mapper_ok"] or not state["mcp_ok"]:
        return "Configure", "Answer the agent's missing-information questions."
    if not state["plan_ok"] or not state["flow_ok"] or not state["payloads_ok"]:
        return "Configure", "Review what will run and fix the highlighted plan item."
    if not state["pdf_ready"]:
        return "Teach Agent", "Upload the API PDF because this workspace requires documentation before execution."
    return "Review & Run", "Everything is ready. Review the plan and run preflight."


def connection_card(title: str, component: Dict[str, Any], required: bool = True) -> None:
    status = str(component.get("status") or "NOT CHECKED").upper()
    if not required or status in {"NOT_REQUIRED", "SKIPPED"}:
        st.info(f"⏭️ **{title}** — not needed for this run")
    elif status == "OK":
        st.success(f"✅ **{title}** — connected")
    else:
        st.warning(f"○ **{title}** — needs connection")


def config_bundle_bytes() -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in ["input.json", "config_overrides.json", "api_execution_plan.json", "execution_flow.json", "payload_overrides.json"]:
            path = ROOT / name
            if path.exists():
                zf.writestr(name, path.read_bytes())
    return buffer.getvalue()



def render_learn_workspace() -> None:
    assistant = LearnAssistant(ROOT, pdf_kb)
    st.markdown(
        """
        <div class="studio-shell">
          <div class="demo-kicker">Multimodal API learning workspace</div>
          <div class="demo-title">Learn · API, payload, network & frontend copilot</div>
          <div class="demo-sub">Teach Learn with Dev-approved API text/PDFs, HAR/JSON/network logs and frontend screenshots. It correlates visible UI fields with backend payload/API evidence and clearly marks inference vs observed fact.</div>
        </div>
        """, unsafe_allow_html=True,
    )
    uploads = st.file_uploader(
        "Add evidence for Learn",
        type=["pdf", "har", "json", "txt", "log", "md", "xml", "csv", "yaml", "yml", "png", "jpg", "jpeg", "webp"],
        accept_multiple_files=True,
        help="Network logs are redacted for authorization/secrets before being stored in Learn's local evidence index.",
        key="learn_uploads",
    )
    image_question = st.text_input(
        "Optional instruction for screenshot analysis",
        placeholder="Example: This is the SFTP frontend. Map what you see to the likely backend API/payload fields.",
        key="learn_image_question",
    )
    if st.button("🧠 Learn from selected files", type="primary", disabled=not uploads, width="stretch", key="learn_ingest"):
        learned = []
        for upload in uploads or []:
            try:
                record = assistant.ingest(upload.name, upload.getvalue(), upload.type or "", image_question)
                learned.append(record)
                st.markdown(f'<span class="mini-done">✓ Learned {html.escape(upload.name)}</span>', unsafe_allow_html=True)
                if record.get("vision", {}).get("model"):
                    st.caption(f"Vision model: {record['vision']['model']}")
                for warning in record.get("warnings") or []:
                    st.warning(warning)
            except Exception as exc:
                st.error(f"Could not learn {upload.name}: {exc}")
        if learned:
            st.session_state["learn_last_ingest"] = [x.get("filename") for x in learned]

    records = assistant.list_records()
    if records:
        with st.expander(f"Learned evidence · {len(records)} file(s)", expanded=False):
            st.dataframe([
                {
                    "File": r.get("filename"), "Type": r.get("kind"),
                    "Learned": r.get("learnedAt"),
                    "Vision model": (r.get("vision") or {}).get("model") or "—",
                    "Summary": str(r.get("summary") or "")[:220],
                } for r in records
            ], width="stretch", hide_index=True)

    if "learn_chat" not in st.session_state:
        st.session_state["learn_chat"] = []
    for message in st.session_state["learn_chat"]:
        with st.chat_message(message.get("role", "assistant")):
            st.markdown(message.get("content", ""))
            if message.get("details"):
                with st.expander("Evidence / analysis details"):
                    st.json(message.get("details"))

    question = st.chat_input("Ask Learn about an API, payload, response, screenshot or network call")
    if question:
        st.session_state["learn_chat"].append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            try:
                answer = assistant.ask(question)
                text = str(answer.get("answer") or "I could not produce an evidence-grounded answer.")
                st.markdown(text)
                verdict = str(answer.get("verdict") or "").upper()
                if verdict:
                    chip = "mini-blocked" if "BLOCK" in verdict else "mini-done"
                    st.markdown(f'<span class="{chip}">{html.escape(verdict)}</span>', unsafe_allow_html=True)
                with st.expander("Evidence / frontend-backend analysis"):
                    st.json({
                        "evidenceUsed": answer.get("evidenceUsed"),
                        "frontendBackendRelationship": answer.get("frontendBackendRelationship"),
                        "payloadFindings": answer.get("payloadFindings"),
                        "confidence": answer.get("confidence"),
                        "nextChecks": answer.get("nextChecks"),
                    })
                st.session_state["learn_chat"].append({"role": "assistant", "content": text, "details": answer})
            except Exception as exc:
                msg = f"Learn could not call Dell AIA: {exc}"
                st.error(msg)
                st.session_state["learn_chat"].append({"role": "assistant", "content": msg})


engine = AdaptiveHipEngine(ROOT)
mcp = MCPBridge(ROOT, enabled=True, required=False)
pdf_kb = PdfApiKnowledgeBase(ROOT)

st.set_page_config(page_title="HIP Application Studio", page_icon="🧭", layout="wide", initial_sidebar_state="expanded")
hide_legacy_page_navigation(st)
apply_pending_workspace(st)

st.markdown(
    """
<style>
:root{--navy:#07213f;--blue:#0b5cab;--cyan:#0f8f98;--green:#148447;--ink:#182230;--muted:#66778b;--line:#d9e4ef;--bg:#f4f8fc}
.stApp{background:linear-gradient(180deg,#f8fbff 0%,#eef5fb 100%)}
.block-container{max-width:1500px;padding-top:1rem;padding-bottom:4rem}
.hero{background:radial-gradient(circle at 88% 0%,rgba(48,201,199,.46),transparent 29%),linear-gradient(135deg,#061b36,#0b5cab 64%,#0a7f89);color:white;padding:34px 38px;border-radius:24px;box-shadow:0 18px 46px rgba(9,48,84,.18);margin-bottom:18px}
.hero h1{margin:0;font-size:2.15rem}.hero p{margin:.55rem 0 0;color:#dceeff;font-size:1.03rem}.hero .small{font-size:.78rem;opacity:.78;margin-top:.8rem}
.coach{display:flex;gap:14px;align-items:flex-start;background:white;border:1px solid #cfe0ef;border-left:6px solid var(--cyan);padding:16px 18px;border-radius:16px;box-shadow:0 8px 24px rgba(12,48,82,.05);margin:8px 0 12px}.coach-icon{font-size:1.4rem}.coach-title{font-weight:800;color:var(--navy);font-size:1.02rem}.coach-body{color:#44566c;margin-top:3px}.coach-next{margin-top:8px;color:#1e5b83}
.choice{background:white;border:1px solid var(--line);border-radius:18px;padding:18px;min-height:130px;box-shadow:0 8px 22px rgba(13,44,77,.05)}
.step-pill{display:inline-block;background:#e9f4ff;color:#07558f;border-radius:999px;padding:5px 10px;font-size:.76rem;font-weight:800;margin-bottom:6px}
.plain-card{background:white;border:1px solid var(--line);border-radius:16px;padding:16px 18px;margin:8px 0;box-shadow:0 7px 20px rgba(14,43,77,.04)}
[data-testid="stMetric"]{background:white;border:1px solid var(--line);padding:13px;border-radius:15px;box-shadow:0 6px 18px rgba(14,43,77,.04)}
.stButton>button{border-radius:11px;font-weight:700;min-height:2.7rem}
div[data-testid="stExpander"]{background:rgba(255,255,255,.78);border-radius:13px}
.simple-tip{background:#eef8ff;border-left:5px solid var(--blue);padding:12px 14px;border-radius:10px;margin:8px 0 14px;color:#314a62}
.request-card{background:white;border:1px solid var(--line);border-radius:18px;padding:18px 20px;margin:10px 0;box-shadow:0 10px 25px rgba(14,43,77,.05)}
.request-title{font-size:1rem;font-weight:800;color:var(--navy)}
.request-sub{color:var(--muted);font-size:.86rem;margin-top:3px}
.badge-ok,.badge-edit,.badge-skip{display:inline-block;border-radius:999px;padding:4px 9px;font-size:.72rem;font-weight:800;margin-right:5px}.badge-ok{background:#e9f8ef;color:#116638}.badge-edit{background:#fff4d8;color:#8a5700}.badge-skip{background:#edf1f5;color:#596879}
.demo-shell{background:white;border:1px solid #d5e2ee;border-radius:24px;padding:26px 28px;box-shadow:0 16px 38px rgba(13,42,73,.08);margin:6px 0 18px}.demo-kicker{font-size:.78rem;font-weight:850;letter-spacing:.07em;color:#0b5cab;text-transform:uppercase}.demo-title{font-size:1.55rem;font-weight:850;color:#061c38;margin:4px 0}.demo-sub{color:#64748b;margin-bottom:14px}.demo-step{background:#f7fbff;border:1px solid #dce8f3;border-radius:15px;padding:14px 15px;min-height:96px}.demo-step b{color:#082b53}.demo-step span{display:block;color:#6a7a8c;font-size:.83rem;margin-top:4px}.demo-safe{background:#ecf9f1;border:1px solid #c6ead4;color:#17663a;padding:12px 14px;border-radius:12px;font-weight:650}.demo-result-ok{background:#ecf9f1;border-left:6px solid #148447;padding:18px;border-radius:14px}.demo-result-bad{background:#fff1f0;border-left:6px solid #b42318;padding:18px;border-radius:14px}
.studio-shell{background:white;border:1px solid #d5e2ee;border-radius:24px;padding:24px 26px;box-shadow:0 16px 38px rgba(13,42,73,.08);margin:6px 0 18px}.studio-stage{background:#fff;border:1px solid #dbe7f2;border-radius:18px;padding:18px;min-height:118px;box-shadow:0 7px 20px rgba(14,43,77,.04)}.studio-stage-num{display:inline-flex;width:28px;height:28px;border-radius:50%;background:#0b5cab;color:white;align-items:center;justify-content:center;font-weight:850;margin-right:7px}.studio-stage-title{font-weight:850;color:#082b53}.studio-stage-sub{color:#687a8d;font-size:.84rem;margin-top:8px}.studio-ready{background:#edf9f1;color:#17663a;border:1px solid #c8e9d5;border-radius:12px;padding:11px 13px;font-weight:700}.studio-live{background:#eaf4ff;color:#07558f}.studio-reuse{background:#f2f4f7;color:#536274}.studio-edit{background:#fff4dc;color:#8a5700}.studio-badge{display:inline-block;border-radius:999px;padding:4px 9px;font-size:.72rem;font-weight:850;margin-right:5px}
</style>
<div class="hero">
  <h1>🧭 HIP Configuration Studio</h1>
  <p>Select a connection, choose an existing configuration, review the generated API requests, let the agent validate everything, then execute the complete flow.</p>
  <div class="small">Build: V23 · HIP Application Studio · Live-only · New configuration upload · Interactive API game</div>
</div>
""",
    unsafe_allow_html=True,
)

st.markdown("### Start here")
qa1, qa2 = st.columns([1.25, 1])
if qa1.button("📦 Upload a NEW configuration · ZIP + input.json", type="primary", width="stretch", key="adaptive_quick_upload_new_config"):
    request_workspace_switch(st, "📦 Upload New Configuration")
if qa2.button("🎮 Open API Flow Game", width="stretch", key="adaptive_quick_open_game"):
    request_workspace_switch(st, "🎮 API Flow Game")
st.caption("Upload first for any new customer/interface package. The agent ingests, validates and prepares it for the same live execution path as U-HAUL.")

state = readiness_state()
summary = active_input_summary()
next_step, next_text = next_recommendation(state)
progress_checks = [bool(load_json(INPUT_JSON, {}).get("customer")), state["connections_ok"], state["mapper_ok"] and state["mcp_ok"], state["plan_ok"] and state["flow_ok"] and state["payloads_ok"], state["ready"]]
progress = sum(1 for x in progress_checks if x) / len(progress_checks)

with st.sidebar:
    st.markdown("## 🧭 HIP Application Studio")
    st.caption("One app · upload · validate · test · game · run LIVE")
    st.divider()
    st.markdown("### Your progress")
    st.progress(progress)
    st.caption(f"{int(progress*100)}% ready")
    st.markdown(f"**Next: {next_step}**")
    st.caption(next_text)
    st.divider()
    st.markdown("### Current configuration")
    st.caption(f"**Customer:** {summary['customer']}")
    st.caption(f"**Flow:** {summary['flow']}")
    st.caption(f"**Direction:** {summary['direction']}")
    st.caption(f"**Transaction:** {summary['transaction']}")
    st.divider()
    st.markdown("### Studio workspace")
    studio_workspace = st.radio(
        "Choose workspace",
        ["🚀 U-HAUL Live Configuration", "📦 Upload New Configuration", "🧪 API Testing Area", "🎮 API Flow Game", "⚡ Parallel Configurations", "🧠 Learn", "🤖 Agentic Interface Studio", "🛠️ Payload / MCP / Advanced"],
        label_visibility="collapsed",
        key="unified_studio_workspace",
    )
    st.caption("For a NEW package use 📦 Upload New Configuration: add the related files ZIP + input.json, let the agent validate it, then run it live like U-HAUL.")
    with st.expander("Agent tool health", expanded=False):
        mcp_status = mcp.status()
        st.caption(
            "MCP tools cover mapping, interface planning, API contracts, payload critique, "
            "execution policy, response interpretation, runtime IDs, Knowledge Graph and AgentQ memory."
        )
        st.json({
            "active": mcp_status.get("active"),
            "transport": mcp_status.get("transport"),
            "sdkAvailable": mcp_status.get("sdkAvailable"),
            "calls": mcp_status.get("calls"),
            "fallbackCalls": mcp_status.get("fallbackCalls"),
            "coverage": mcp_status.get("toolCoverage"),
        })

# ---------------------------------------------------------------------------
# SINGLE APPLICATION STUDIO WORKSPACES
# ---------------------------------------------------------------------------
if studio_workspace.startswith("📦"):
    render_input_bundle_workspace(ROOT, apply_active_input)
    st.stop()
if studio_workspace.startswith("🧪"):
    render_api_testing_area(ROOT, mcp)
    st.stop()
if studio_workspace.startswith("🎮"):
    render_scratch_flow_builder(ROOT, mcp)
    st.stop()
if studio_workspace.startswith("⚡"):
    render_parallel_configuration_workspace(ROOT)
    st.stop()
if studio_workspace.startswith("🧠"):
    render_learn_workspace()
    st.stop()
if studio_workspace.startswith("🤖"):
    render_agentic_interface_studio(ROOT, mcp, pdf_kb)
    st.stop()
if studio_workspace.startswith("🛠️"):
    render_advanced_tools(ROOT, mcp)
    st.stop()

# ---------------------------------------------------------------------------
# U-HAUL FULL LIVE API STUDIO — default end-to-end experience
# ---------------------------------------------------------------------------
if "show_guided_workspace" not in st.session_state:
    st.session_state["show_guided_workspace"] = False

if not st.session_state["show_guided_workspace"]:
    st.markdown(
        """
        <div class="studio-shell">
          <div class="demo-kicker">Full end-to-end studio</div>
          <div class="demo-title">Choose → Review payloads → Agent checks → Execute</div>
          <div class="demo-sub">For the Business demo, choose <b>SFTP</b>. The approved <b>U-HAUL</b> configuration is already available and the studio loads its complete 18-step HIP flow automatically.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ------------------------------------------------------------------
    # 1. SELECT INTERFACE + EXISTING CONFIGURATION
    # ------------------------------------------------------------------
    st.markdown("### 1 · Select what you want to run")
    select1, select2 = st.columns([1, 1.35], gap="large")
    with select1:
        studio_interface = st.selectbox(
            "Connection type",
            studio_interface_options(ROOT),
            index=0,
            help="SFTP is the U-HAUL Business-demo path. FTP, HTTPS and HTTPS-AS2 remain available for new/configuration-template workflows.",
            key="studio_interface",
        )
    with select2:
        studio_customers = studio_customer_options(studio_interface)
        studio_customer = st.selectbox(
            "Configuration / customer",
            studio_customers,
            index=0,
            key=f"studio_customer_{studio_interface}",
        )

    studio_meta = studio_customer_metadata(studio_interface, studio_customer)
    sm1, sm2, sm3, sm4 = st.columns(4)
    sm1.metric("Status", studio_meta.get("status") or "—")
    sm2.metric("Transaction", studio_meta.get("transaction") or "—")
    sm3.metric("Direction", studio_meta.get("direction") or "—")
    sm4.metric("Deployment group", studio_meta.get("deploymentGroup") or "hip-automation")

    studio_is_uhal = studio_interface == "SFTP" and studio_customer == "U-HAUL"
    if not studio_is_uhal:
        st.info(
            "This selection starts a new/adaptive configuration. For tomorrow's live Business demo, choose **SFTP → U-HAUL**. "
            "The full guided workspace below supports FTP, HTTPS and HTTPS-AS2, including U-HAUL-template cloning."
        )
        n1, n2 = st.columns(2)
        if n1.button("Open Agentic Interface Studio here", type="primary", width="stretch"):
            request_workspace_switch(st, "🤖 Agentic Interface Studio")
        if n2.button("Open guided configuration here", width="stretch"):
            st.session_state["show_guided_workspace"] = True
            st.session_state["studio_requested_interface"] = studio_interface
            st.rerun()
        st.stop()

    # Load the approved U-HAUL baseline once per Streamlit session. This gives
    # the user a clean known starting point but does not wipe payload edits on
    # every rerun after they start working in the Studio.
    studio_key = "SFTP::U-HAUL"
    if st.session_state.get("studio_loaded_key") != studio_key:
        prep = prepare_sftp_uhal_studio(ROOT)
        st.session_state["studio_loaded_key"] = studio_key
        st.session_state.pop("studio_agent_checks", None)
        st.session_state.pop("business_demo_result", None)
        st.session_state.pop("friendly_preflight", None)
    else:
        prep = {
            "customer": "U-HAUL",
            "interface": "SFTP HAFT",
            "deploymentGroup": "hip-automation",
            "logicalSteps": len(STEP_DEFINITIONS),
            "liveSteps": len(STEP_DEFINITIONS),
            "reuseSteps": 0,
        }

    st.markdown(
        """
        <div class="studio-ready">✓ U-HAUL is loaded from the approved SFTP / hip-automation deployment baseline in FULL LIVE API COVERAGE mode. Every configured API building block will be called; existing/duplicate responses are captured as evidence.</div>
        """,
        unsafe_allow_html=True,
    )

    baseline_input = load_json(INPUT_JSON, {})
    baseline_objects = baseline_input.get("objects") or {}
    baseline_source_tp = baseline_objects.get("source_transport_profile") or {}
    baseline_target_tp = baseline_objects.get("target_transport_profile") or {}
    b1, b2, b3, b4 = st.columns(4)
    b1.metric("Customer", baseline_input.get("customer") or "U-HAUL")
    b2.metric("Interface", "SFTP")
    b3.metric("Flow", baseline_input.get("profile_name") or "U-HAUL")
    b4.metric("Logical flow", "18 steps")

    with st.expander("U-HAUL configuration selected by the studio", expanded=False):
        uc1, uc2 = st.columns(2)
        with uc1:
            st.markdown("**Sender / Source**")
            st.write(f"Transport Profile: `{baseline_source_tp.get('profile_name')}`")
            st.write("Shared profile: `da-sender-sftphaft-dce-common`")
            st.write(f"Account: `{baseline_source_tp.get('existing_account_name')}`")
        with uc2:
            st.markdown("**Receiver / Target**")
            st.write(f"Transport Profile: `{baseline_target_tp.get('profile_name')}`")
            st.write("Shared profile: `pt-receiver-sftphaft-dce-common`")
            st.write(f"Partner: `{baseline_target_tp.get('partner_name')}`")
        st.caption(
            "U-HAUL already exists, but this Studio intentionally calls the full Account, Partner, System, Document Type, Map, Rule, Transport Profile, Flow, validation, deployment-history and audit API set. "
            "Duplicate/existing responses are recorded and downstream calls continue using the configured U-HAUL runtime IDs when needed."
        )

    # ------------------------------------------------------------------
    # 2. PAYLOAD STUDIO
    # ------------------------------------------------------------------
    st.markdown("### 2 · Review the generated U-HAUL API requests")
    st.caption(
        "The agent has generated the request for every logical HIP step. In this Full Live API Coverage run every request is intended for a live API call; nothing is reused or skipped because U-HAUL already exists."
    )

    try:
        studio_inventory = studio_request_inventory(ROOT)
    except Exception as exc:
        st.error(f"The Studio could not build the payload preview: {exc}")
        studio_inventory = {"cards": [], "total": 0, "live": 0, "reused": 0, "edited": 0}

    pi1, pi2, pi3, pi4 = st.columns(4)
    pi1.metric("Requests generated", studio_inventory.get("total", 0))
    pi2.metric("Live API requests", studio_inventory.get("live", 0))
    pi3.metric("Skipped / reused", studio_inventory.get("reused", 0))
    pi4.metric("User-edited requests", studio_inventory.get("edited", 0))

    filter_choice = st.radio(
        "Show",
        ["All live APIs", "All logical steps"],
        horizontal=True,
        key="studio_payload_filter",
    )
    cards = studio_inventory.get("cards") or []
    if filter_choice == "All live APIs":
        visible_cards = [row for row in cards if row.get("decision") == "LIVE API"]
    else:
        visible_cards = cards

    inventory_rows = []
    for row in visible_cards:
        inventory_rows.append({
            "#": row.get("order"),
            "HIP step": row.get("label"),
            "Area": row.get("group"),
            "Method": row.get("method"),
            "What happens": "LIVE CALL" if row.get("decision") == "LIVE API" else "UNEXPECTED SKIP",
            "Edited": "Yes" if row.get("edited") else "No",
        })
    render_table(inventory_rows)

    if visible_cards:
        label_map = {
            f"{row.get('order'):02d} · {row.get('label')}": row
            for row in visible_cards
        }
        selected_request_label = st.selectbox(
            "Choose a request to see its payload",
            list(label_map),
            key="studio_selected_request",
        )
        selected_card = label_map[selected_request_label]
        decision_badge = (
            '<span class="studio-badge studio-live">LIVE API</span>'
            if selected_card.get("decision") == "LIVE API"
            else '<span class="studio-badge studio-reuse">UNEXPECTED SKIP</span>'
        )
        edit_badge = (
            '<span class="studio-badge studio-edit">USER EDIT ACTIVE</span>'
            if selected_card.get("edited")
            else '<span class="studio-badge studio-live">AGENT GENERATED</span>'
        )
        st.markdown(
            f"""
            <div class="request-card">
              <div class="request-title">{html.escape(str(selected_card.get('label')))}</div>
              <div class="request-sub">{html.escape(str(selected_card.get('businessMeaning')))}</div>
              <div style="margin-top:10px">{decision_badge}{edit_badge}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        payload_tabs = st.tabs(["What the agent will use", "Original generated", "Edit payload"])
        with payload_tabs[0]:
            st.json(selected_card.get("effective") or {})
            if selected_card.get("changedPaths"):
                st.caption("User changes from the generated baseline:")
                for path in (selected_card.get("changedPaths") or [])[:30]:
                    st.markdown(f"- `{path}`")
            else:
                st.caption("No user edits are active for this request.")

        with payload_tabs[1]:
            st.json(selected_card.get("generated") or {})
            st.caption("This is the payload generated automatically from the approved U-HAUL configuration.")

        with payload_tabs[2]:
            if selected_card.get("decision") != "LIVE API":
                st.warning("This request is unexpectedly marked non-live. Re-run the U-HAUL Studio preparation before execution.")
            edit_text = st.text_area(
                "Request JSON",
                value=json.dumps(selected_card.get("effective") or {}, indent=2, ensure_ascii=False),
                height=430,
                key=f"studio_edit_{selected_card.get('stepKey')}",
            )
            parsed_edit = None
            try:
                parsed_edit = json.loads(edit_text)
                if not isinstance(parsed_edit, dict):
                    raise ValueError("Request must be a JSON object")
                st.success("JSON format is valid.")
            except Exception as exc:
                st.error(f"Fix the JSON before saving: {exc}")

            edit_mode_label = st.radio(
                "Apply edit as",
                ["Replace full request", "Change only entered fields"],
                horizontal=True,
                key=f"studio_edit_mode_{selected_card.get('stepKey')}",
            )
            edit_mode = "replace" if edit_mode_label.startswith("Replace") else "merge"
            edit_note = st.text_input(
                "Reason for edit (optional)",
                placeholder="Example: Dev team asked to change this field",
                key=f"studio_edit_note_{selected_card.get('stepKey')}",
            )
            pe1, pe2, pe3 = st.columns(3)
            if pe1.button(
                "Save payload edit",
                type="primary",
                disabled=parsed_edit is None,
                width="stretch",
                key=f"studio_save_edit_{selected_card.get('stepKey')}",
            ):
                mcp_critic = mcp.validate_payload_override(
                    selected_card.get("stepKey"),
                    selected_card.get("generated") or {},
                    safe_request_for_ui(parsed_edit or {}),
                    interface_only=False,
                )
                mcp_contract = mcp.validate_api_request(
                    api_key=selected_card.get("urlKey") or selected_card.get("stepKey"),
                    method=selected_card.get("method") or "GET",
                    url=selected_card.get("url") or "",
                    headers={"x-requester-id": "application-studio-preview"},
                    payload=(parsed_edit if (selected_card.get("requestKind") or "payload") == "payload" else None),
                    params=(parsed_edit if (selected_card.get("requestKind") or "payload") == "params" else None),
                )
                if not mcp_critic.get("valid", True):
                    st.error("The MCP payload critic blocked this edit.")
                    st.json(mcp_critic)
                elif not mcp_contract.get("valid", True):
                    st.error("The MCP/API-contract validator blocked this edit.")
                    st.json(mcp_contract)
                else:
                    save_override(
                        ROOT,
                        selected_card.get("stepKey"),
                        parsed_edit,
                        request_kind=selected_card.get("requestKind") or "payload",
                        mode=edit_mode,
                        note=edit_note or "Human user Business Application Studio edit validated by MCP",
                        edit_origin="USER",
                    )
                    st.session_state.pop("studio_agent_checks", None)
                    st.success("Saved after MCP payload critic + API-contract validation.")
                    st.rerun()
            if pe2.button(
                "Restore generated",
                width="stretch",
                key=f"studio_reset_edit_{selected_card.get('stepKey')}",
            ):
                clear_override(ROOT, selected_card.get("stepKey"))
                st.session_state.pop("studio_agent_checks", None)
                st.success("User edit removed; generated request restored.")
                st.rerun()
            if pe3.button(
                "Ask agent about this request",
                disabled=parsed_edit is None,
                width="stretch",
                key=f"studio_agent_edit_{selected_card.get('stepKey')}",
            ):
                st.session_state["studio_payload_agent_reply"] = ask_agent(
                    "studio-payload",
                    {
                        "message": f"Review the U-HAUL request for {selected_card.get('label')} in plain business language.",
                        "next_action": "Explain what this request does and highlight any risky user change before execution.",
                        "decision": selected_card.get("decision"),
                        "changedPaths": selected_card.get("changedPaths") or [],
                        "request": safe_request_for_ui(parsed_edit),
                    },
                )
            if st.session_state.get("studio_payload_agent_reply"):
                reply = st.session_state["studio_payload_agent_reply"]
                with st.container(border=True):
                    st.markdown(f"**Agent:** {reply.get('message', '')}")
                    for item in reply.get("nextActions") or []:
                        st.markdown(f"- {item}")

        with st.expander("Technical endpoint / authentication — project team only"):
            st.code(f"{selected_card.get('method')} {selected_card.get('url')}")
            st.write(f"OAuth profile: `{selected_card.get('tokenKind')}`")
            st.write(f"Request kind: `{selected_card.get('requestKind')}`")

    # ------------------------------------------------------------------
    # 3. AGENT CHECKS
    # ------------------------------------------------------------------
    st.markdown("### 3 · Let the agent check everything")
    st.caption(
        "This performs connection verification, mapping/dependency checks, MCP/PDF validation for all generated requests, an MCP supervisor readiness assessment, and the production safety preflight. No configuration mutation is performed here."
    )

    run_checks = st.button(
        "🤖 Run all Agent Checks",
        type="primary",
        width="stretch",
        key="studio_run_checks",
    )
    if run_checks:
        check_logs: List[str] = []
        with st.status("Agent is checking the complete U-HAUL flow...", expanded=True) as check_status:
            st.write("1/5 · Checking HIP OAuth, Dell AIA and MCP connectivity")
            conn = subprocess.run(
                [sys.executable, "connection_check.py"],
                cwd=ROOT,
                text=True,
                capture_output=True,
            )
            check_logs.append((conn.stdout or "") + ("\n" + conn.stderr if conn.stderr else ""))
            connection_result = load_json(REPORTS / "connection_check_latest.json", {})
            connection_ok = bool(connection_result.get("secureConnectionsOk", conn.returncode == 0 and connection_result.get("overall") == "OK"))

            st.write("2/5 · Validating mappings, dependencies and all generated requests")
            try:
                local_checks = studio_local_checks(ROOT)
                local_ok = bool(local_checks.get("ok"))
            except Exception as exc:
                local_checks = {"ok": False, "error": str(exc)}
                local_ok = False

            st.write("3/5 · MCP supervisor checks execution policy and interface readiness")
            mcp_readiness = mcp.assess_execution_readiness(
                load_json(INPUT_JSON, {}),
                load_json(CONFIG_JSON, {}),
            )
            mcp_supervisor_ok = bool(
                mcp_readiness.get("valid", True)
                and not mcp_readiness.get("liveRunBlocked")
            )

            st.write("4/5 · Running production safety preflight")
            preflight = subprocess.run(
                [sys.executable, "run_agent.py", "--preflight"],
                cwd=ROOT,
                text=True,
                capture_output=True,
            )
            check_logs.append((preflight.stdout or "") + ("\n" + preflight.stderr if preflight.stderr else ""))
            preflight_ok = preflight.returncode == 0

            st.write("5/5 · Dell AIA summarizes readiness for the Business run")
            agent_reply = ask_agent(
                "studio-readiness",
                {
                    "message": "Summarize whether the U-HAUL SFTP flow is ready to execute and explain any blocker in plain business language.",
                    "next_action": "If ready, tell the user they can execute the whole U-HAUL flow. If not, name only the action required before execution.",
                    "connectionsOk": connection_ok,
                    "localChecksOk": local_ok,
                    "mcpSupervisorOk": mcp_supervisor_ok,
                    "preflightOk": preflight_ok,
                    "requestChecks": (local_checks.get("requests") or {}) if isinstance(local_checks, dict) else {},
                    "mcpReadiness": mcp_readiness,
                },
            )
            all_ok = bool(connection_ok and local_ok and mcp_supervisor_ok and preflight_ok)
            check_status.update(
                label="All Agent Checks passed" if all_ok else "Agent found something that needs attention",
                state="complete" if all_ok else "error",
            )
            st.session_state["studio_agent_checks"] = {
                "ok": all_ok,
                "connectionsOk": connection_ok,
                "localChecksOk": local_ok,
                "mcpSupervisorOk": mcp_supervisor_ok,
                "preflightOk": preflight_ok,
                "connection": connection_result,
                "local": local_checks,
                "mcpReadiness": mcp_readiness,
                "mcpStatus": mcp.status(),
                "agent": agent_reply,
                "logs": "\n".join(check_logs),
            }

    studio_checks = st.session_state.get("studio_agent_checks") or {}
    if studio_checks:
        ac1, ac2, ac3, ac4, ac5 = st.columns(5)
        ac1.metric("Connections", "PASS" if studio_checks.get("connectionsOk") else "CHECK")
        ac2.metric("Payload + contracts", "PASS" if studio_checks.get("localChecksOk") else "CHECK")
        ac3.metric("MCP supervisor", "PASS" if studio_checks.get("mcpSupervisorOk") else "CHECK")
        ac4.metric("Safety preflight", "PASS" if studio_checks.get("preflightOk") else "CHECK")
        ac5.metric("Agent verdict", "READY" if studio_checks.get("ok") else "ATTENTION")

        agent_reply = studio_checks.get("agent") or {}
        with st.container(border=True):
            st.markdown(f"**Agent:** {agent_reply.get('message', 'Checks completed.')}")
            for item in agent_reply.get("nextActions") or []:
                st.markdown(f"- {item}")

        local_result = studio_checks.get("local") or {}
        request_result = local_result.get("requests") or {}
        if request_result:
            st.caption(
                f"Request validation: {request_result.get('validCount', 0)} / {request_result.get('total', 0)} generated requests passed MCP/PDF contract checks."
            )
        if not studio_checks.get("ok"):
            with st.expander("What needs attention"):
                st.json({
                    "connections": studio_checks.get("connection"),
                    "agentChecks": studio_checks.get("local"),
                    "mcpReadiness": studio_checks.get("mcpReadiness"),
                    "mcpStatus": studio_checks.get("mcpStatus"),
                })
        with st.expander("Agent-check technical logs — project team only"):
            st.code(studio_checks.get("logs") or "No log captured.")

    # ------------------------------------------------------------------
    # 4. EXECUTE COMPLETE FLOW
    # ------------------------------------------------------------------
    st.markdown("### 4 · Execute the complete U-HAUL flow")
    st.markdown(
        """
        <div class="simple-tip"><b>Full Live API Coverage means every configured HIP building-block API is called.</b> U-HAUL may already exist, but Account, Partner, System, Document Type, Map, Rule, Transport Profile, Flow create/deploy, validation, history and audit endpoints are still executed and their responses are captured. Duplicate/existing responses are evidence, not skipped steps.</div>
        """,
        unsafe_allow_html=True,
    )

    studio_lock = inspect_live_run(ROOT)
    if studio_lock.get("stale"):
        clear_stale_live_run(ROOT)
        studio_lock = inspect_live_run(ROOT)
    if studio_lock.get("active"):
        st.warning(f"Another HIP execution is still active (PID {studio_lock.get('pid')}).")
        lk1, lk2 = st.columns(2)
        if lk1.button("🛑 Stop old/running configuration", type="primary", width="stretch", key="studio_kill_old"):
            outcome = terminate_live_run(ROOT)
            if outcome.get("stopped"):
                st.success("Previous execution stopped. You can run the Studio flow now.")
                st.rerun()
            st.error(f"Could not stop safely: {outcome.get('reason')}")
        if lk2.button("Refresh run status", width="stretch", key="studio_refresh_lock"):
            st.rerun()

    if "studio_live_running" not in st.session_state:
        st.session_state["studio_live_running"] = False

    execution_ready = bool(
        studio_checks.get("ok")
        and not studio_lock.get("active")
        and not st.session_state["studio_live_running"]
    )
    if not studio_checks.get("ok"):
        st.info("Run **All Agent Checks** first. The live execution button unlocks only after every required check passes.")

    run_whole_flow = st.button(
        "▶ Execute Whole U-HAUL Flow",
        type="primary",
        width="stretch",
        disabled=not execution_ready,
        key="studio_execute_whole_flow",
    )

    if run_whole_flow:
        st.session_state["studio_live_running"] = True
        execution_logs: List[str] = []
        execution_error = ""
        try:
            clear_stale_live_run(ROOT)
            with st.status("Executing the complete U-HAUL HIP flow...", expanded=True) as live_status:
                live_progress = st.progress(0.0)
                live_message = st.empty()
                process = subprocess.Popen(
                    [sys.executable, "-u", "run_agent.py"],
                    cwd=ROOT,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    bufsize=1,
                )
                if process.stdout is not None:
                    for raw_line in process.stdout:
                        line = raw_line.rstrip()
                        execution_logs.append(line)
                        match = re.match(r"^\[(\d+)\]\s+.*?-\s+.*?-\s+([A-Za-z0-9_]+)(?:\s+.*)?$", line)
                        if match:
                            seq = int(match.group(1))
                            attempt = match.group(2)
                            logical_key = attempt
                            # Several attempts use different names; show the best
                            # business label we can without exposing technical noise.
                            label = STEP_DEFINITIONS.get(logical_key, {}).get("label") or attempt.replace("_", " ").title()
                            live_progress.progress(min(1.0, seq / max(1, len(STEP_DEFINITIONS))))
                            live_message.info(f"{seq}/18 · {label}")
                        elif "SKIPPED_EXISTING" in line:
                            live_message.info("Existing/duplicate API response received; continuing full coverage")
                        elif "-> HTTP" in line:
                            live_message.success("Live API response received")
                rc = process.wait()
                live_progress.progress(1.0)
                if rc != 0:
                    raise RuntimeError("The full U-HAUL API coverage run did not complete all configured calls. Complete evidence was preserved.")

                result_summary = build_business_demo_summary(ROOT)
                result_report = write_business_demo_report(ROOT, result_summary)
                if not result_summary.get("success"):
                    raise RuntimeError("The API coverage completed, but the coverage summary could not confirm all configured logical APIs.")

                live_status.update(label="Complete U-HAUL flow executed successfully", state="complete")
                st.session_state["business_demo_result"] = {
                    "summary": result_summary,
                    "report": str(result_report),
                    "logs": "\n".join(execution_logs),
                }
        except Exception as exc:
            execution_error = str(exc)
            result_summary = build_business_demo_summary(ROOT)
            result_report = write_business_demo_report(ROOT, result_summary)
            st.session_state["business_demo_result"] = {
                "summary": result_summary,
                "report": str(result_report),
                "logs": "\n".join(execution_logs),
                "error": execution_error,
            }
        finally:
            st.session_state["studio_live_running"] = False

    studio_result = st.session_state.get("business_demo_result")
    if studio_result:
        result_summary = studio_result.get("summary") or {}
        if result_summary.get("success"):
            verification_note = (
                "All configured API building blocks were called. Business/configuration verification also passed."
                if result_summary.get("businessSuccess")
                else "All configured API building blocks were called. One or more API responses still need review; this is shown in the report without hiding the live evidence."
            )
            st.markdown(
                f'<div class="demo-result-ok"><b>✓ Full U-HAUL live API coverage completed</b><br>{html.escape(verification_note)}</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f'<div class="demo-result-bad"><b>Execution needs attention</b><br>{html.escape(str(studio_result.get("error") or "One live verification did not pass."))}</div>',
                unsafe_allow_html=True,
            )

        rr1, rr2, rr3, rr4 = st.columns(4)
        rr1.metric("Logical APIs expected", result_summary.get("expectedLogicalApis", 18))
        rr2.metric("Live API attempts", result_summary.get("liveApiCalls", 0))
        rr3.metric("Skipped / reused", result_summary.get("skippedApiCalls", 0))
        rr4.metric("Business verification", "PASS" if result_summary.get("businessSuccess") else "ATTENTION")

        result_rows = []
        for check in result_summary.get("checks") or []:
            result_rows.append({
                "Execution / verification": check.get("label"),
                "Result": "✓ Passed" if check.get("ok") else "Needs attention",
                "Detail": check.get("classification"),
            })
        render_table(result_rows)

        with st.expander("API-by-API request / response summary", expanded=True):
            api_rows = []
            for item in result_summary.get("apiResults") or []:
                api_rows.append({
                    "#": item.get("sequence"),
                    "API": item.get("api"),
                    "Method": item.get("method"),
                    "HTTP": item.get("http"),
                    "Classification": item.get("classification"),
                    "Business success": "Yes" if item.get("businessSuccess") else "Check",
                })
            render_table(api_rows)

        report_value = Path(str(studio_result.get("report") or ""))
        if report_value.exists():
            st.download_button(
                "Download U-HAUL Business Execution Report",
                report_value.read_bytes(),
                file_name="UHAUL_Application_Studio_Live_Report.html",
                mime="text/html",
                width="stretch",
            )
        with st.expander("Full technical execution evidence — project team only"):
            st.code(studio_result.get("logs") or "No technical log captured.")

    st.divider()
    more1, more2 = st.columns(2)
    if more1.button("Configure another interface/customer", width="stretch"):
        request_workspace_switch(st, "🤖 Agentic Interface Studio")
    if more2.button("Open Payload / MCP / Advanced tools", width="stretch"):
        request_workspace_switch(st, "🛠️ Payload / MCP / Advanced")
    st.caption("All workflows now live inside one HIP Application Studio. The legacy separate Streamlit page links are no longer used.")

    st.stop()

# Small escape hatch when the project team enters the guided workspace.
back_demo, _ = st.columns([1, 4])
if back_demo.button("← Application Studio", width="stretch"):
    st.session_state["show_guided_workspace"] = False
    st.rerun()

# Friendly high-level navigation.
tabs = st.tabs([
    "🏁 1. Start",
    "🔐 2. Connect",
    "📚 3. Teach Agent",
    "🧭 4. Configure",
    "✅ 5. Review & Run",
])

# ---------------------------------------------------------------------------
# 1. START
# ---------------------------------------------------------------------------
with tabs[0]:
    coach(
        "start",
        "Tell me what you are trying to configure",
        "You can start from a few business details, an existing input JSON, or API payloads. You do not need to understand the HIP payload schema.",
        "Choose the starting option that matches what you already have.",
        {"currentCustomer": summary["customer"], "creationMode": summary["mode"]},
    )

    mode = st.radio(
        "What do you already have?",
        [
            "🔁 Everything stays the same — change only Transport Profile interface",
            "✨ I want to create a new configuration",
            "📄 I already have an input JSON",
            "🧩 I already have API payloads",
            "🧬 Copy U-HAUL template and change other business differences",
            "♻️ Use the current U-HAUL setup",
        ],
        horizontal=True,
        key="friendly_start_mode",
    )

    if mode.startswith("🔁"):
        coach(
            "interface-only-react",
            "ReAct agent: change only the Transport Profile interface",
            (
                "I will load the approved U-HAUL configuration as the frozen baseline. "
                "Document Types, Map, Rule, Account, Partner, System, Flow, routing, business values, names and IDs stay unchanged. The agent uses the Dev-confirmed dce-common shared profile for the selected interface. "
                "Only Source/Target Transport Profile interfaceDetails may change."
            ),
            "Choose the interface type. I will ask only for values that interface needs, build the proposal, and run a strict critic before you can apply it.",
        )

        baseline_input = load_json(
            DEV_APPROVED_DIR / "UHAL_input_dev_approved.json",
            load_json(INPUT_JSON, {}),
        )
        react_agent = TransportInterfaceReActAgent(ROOT, baseline_input)

        st.markdown(
            """
            <div class="plain-card">
              <div class="step-pill">STRICT TEMPLATE MODE</div>
              <b>Everything outside Transport Profile interface stays the same; the matching dce-common shared TP reference is selected automatically.</b><br>
              <span style="color:#66778b">The agent rejects its own proposal if a non-interface configuration path changes.</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

        ri1, ri2 = st.columns(2)
        source_interface = ri1.selectbox(
            "Dell / Sender interface",
            INTERFACE_OPTIONS,
            index=0,
            key="react_source_interface",
        )
        target_interface = ri2.selectbox(
            "Partner / Receiver interface",
            INTERFACE_OPTIONS,
            index=0,
            key="react_target_interface",
        )

        source_binding = interface_shared_profiles(source_interface)
        target_binding = interface_shared_profiles(target_interface)
        bind1, bind2 = st.columns(2)
        bind1.info(
            "Shared sender profile: " + (source_binding.get("source") or "Needs Dev/API contract confirmation")
        )
        bind2.info(
            "Shared receiver profile: " + (target_binding.get("target") or "Needs Dev/API contract confirmation")
        )

        source_params: Dict[str, Any] = {}
        target_params: Dict[str, Any] = {}
        react_source_secret = ""
        react_target_secret = ""

        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown("### Sender interface values")
            if source_interface == "SFTP":
                st.success("U-HAUL SFTP interfaceDetails are reused unchanged.")
            elif source_interface == "FTP":
                st.success("FTP reuses the same U-HAUL file/account/folder values; only interfaceType changes to FTP.")
            elif source_interface == "HTTPS":
                st.caption("Safe defaults come from the Dev-team HTTPS Sender example and remain editable.")
                source_params = {
                    "Protocol": st.text_input("Protocol", value="REST", key="react_src_protocol"),
                    "HIP URL": st.text_input("HIP URL", value="URL will be shared later after API Publish is successful.", key="react_src_hip_url"),
                    "Proxy URI": st.text_input("Proxy URI", value="dce-common-sv1", key="react_src_proxy"),
                    "Request Method": st.selectbox("Request Method", ["POST", "PUT", "GET", "PATCH"], index=0, key="react_src_method"),
                    "Request Format": st.text_input("Request Format", value="Request Body", key="react_src_format"),
                    "Sender Authentication Type": st.text_input("Authentication", value="OAuth2", key="react_src_auth"),
                    "Are Input Files Compressed?": st.selectbox("Input files compressed?", ["False", "True"], index=0, key="react_src_compress"),
                    "Sender Grant Type": st.text_input("Grant Type", value="client_credentials", key="react_src_grant"),
                }
                with st.expander("Optional Sender OAuth values"):
                    src_token = st.text_input("Sender Token Endpoint", key="react_src_token")
                    src_client = st.text_input("Sender Client ID", key="react_src_client")
                    react_source_secret = st.text_input(
                        "Sender Client Secret", type="password", key="react_src_secret",
                        placeholder="Partner/interface payload value — not an app credential",
                    )
                    if src_token:
                        source_params["Sender Token Endpoint"] = src_token
                    if src_client:
                        source_params["Sender Client Id"] = src_client
                    if react_source_secret:
                        save_runtime_payload_values(ROOT, {"source": {"sender_client_secret": react_source_secret}}, merge=True)
                    if react_source_secret or has_runtime_payload_value(ROOT, "source.sender_client_secret"):
                        source_params["Sender Client Secret"] = runtime_payload_placeholder("source.sender_client_secret")
            else:
                st.warning("HTTPS-AS2 fields are contract-driven. Paste the approved parameters or teach the agent with the API PDF.")
                src_as2 = st.text_area("Approved Sender HTTPS-AS2 parameters", height=230, key="react_src_as2", placeholder='{"approvedField": "value"}')
                source_params = json_object_or_empty(src_as2)

        with c2:
            st.markdown("### Receiver interface values")
            if target_interface == "SFTP":
                st.success("U-HAUL SFTP interfaceDetails are reused unchanged.")
            elif target_interface == "FTP":
                st.success("FTP reuses the same U-HAUL file/account/folder values; only interfaceType changes to FTP.")
            elif target_interface == "HTTPS":
                st.info("Partner must provide: Partner URL, Receiver Grant Type, Receiver Token Endpoint, Receiver Client ID and Receiver Client Secret. I will not invent or default these values.")
                st.caption("Certificate details are pending confirmation from the Dell team and are optional until that contract is confirmed.")
                target_params = {
                    "Protocol": "REST",
                    "Partner URL": st.text_input("Partner URL *", placeholder="https://partner-url.com", key="react_tgt_partner_url"),
                    "Request Method": st.selectbox("Request Method", ["POST", "PUT", "GET", "PATCH"], index=0, key="react_tgt_method"),
                    "Request Format": st.text_input("Request Format", value="Request Body", key="react_tgt_format"),
                    "Receiver Authentication Type": st.text_input("Authentication", value="OAuth2", key="react_tgt_auth"),
                    "Gateway URL": st.text_input("Gateway URL", value="URL will be shared later after API Publish is successful.", key="react_tgt_gateway"),
                    "Are Input Files Compressed?": st.selectbox("Input files compressed?", ["False", "True"], index=0, key="react_tgt_compress"),
                    "Receiver Grant Type": st.text_input("Receiver Grant Type *", placeholder="Get from Partner", key="react_tgt_grant"),
                    "Receiver Token Endpoint": st.text_input("Receiver Token Endpoint *", placeholder="https://.../oauth/token", key="react_tgt_token"),
                    "Receiver Client Id": st.text_input("Receiver Client ID *", key="react_tgt_client"),
                }
                react_target_secret = st.text_input(
                    "Receiver Client Secret *",
                    type="password",
                    key="react_tgt_secret",
                    placeholder="Partner-provided payload value — not an application credential",
                )
                if react_target_secret:
                    save_runtime_payload_values(ROOT, {"target": {"receiver_client_secret": react_target_secret}}, merge=True)
                if react_target_secret or has_runtime_payload_value(ROOT, "target.receiver_client_secret"):
                    target_params["Receiver Client Secret"] = runtime_payload_placeholder("target.receiver_client_secret")
            else:
                st.warning("HTTPS-AS2 fields are contract-driven. Paste the approved parameters or upload the API PDF in Teach Agent.")
                tgt_as2 = st.text_area("Approved Receiver HTTPS-AS2 parameters", height=230, key="react_tgt_as2", placeholder='{"approvedField": "value"}')
                target_params = json_object_or_empty(tgt_as2)

        react_analysis = react_agent.analyze(
            source_interface=source_interface,
            target_interface=target_interface,
            source_parameters=source_params,
            target_parameters=target_params,
        )

        st.subheader("Agent ReAct status")
        render_table([
            {
                "Phase": row.get("phase"),
                "Status": row.get("status"),
                "What the agent did": row.get("summary"),
            }
            for row in react_analysis.get("trace") or []
        ])

        if react_analysis.get("questions"):
            st.warning("I still need these interface-specific values before I can create a runnable proposal:")
            for q in react_analysis["questions"]:
                st.markdown(f"- **{q['question']}**  ")
                st.caption(q["why"])
            if st.button("🤖 Ask agent to explain what I need", width="stretch", key="react_explain_missing"):
                st.session_state["react_missing_help"] = ask_agent(
                    "interface-only-missing",
                    {
                        "message": "Explain these missing Transport Profile interface values to a non-technical user. Do not invent values.",
                        "questions": react_analysis["questions"],
                        "sourceInterface": source_interface,
                        "targetInterface": target_interface,
                    },
                )
            if st.session_state.get("react_missing_help"):
                st.info(st.session_state["react_missing_help"].get("message", ""))

        p1, p2 = st.columns(2)
        if p1.button(
            "🧠 ReAct: build + critic-check proposal",
            type="primary",
            disabled=not react_analysis.get("ready"),
            width="stretch",
        ):
            st.session_state["react_interface_proposal"] = react_agent.propose(
                source_interface=source_interface,
                target_interface=target_interface,
                source_parameters=source_params,
                target_parameters=target_params,
            )

        if p2.button("Reset interface proposal", width="stretch"):
            st.session_state.pop("react_interface_proposal", None)
            st.rerun()

        proposal = st.session_state.get("react_interface_proposal")
        if proposal:
            critic = proposal.get("critic") or {}
            st.subheader("Critic result")
            if critic.get("status") == "PASS":
                st.success("PASS — Everything outside the Transport Profile interface is unchanged.")
            else:
                st.error("REJECTED — The proposal attempted to change something outside Transport Profile interface.")
            render_table([
                {
                    "Phase": row.get("phase"),
                    "Status": row.get("status"),
                    "Summary": row.get("summary"),
                }
                for row in proposal.get("trace") or []
            ])
            with st.expander("Exactly what changes"):
                for path in proposal.get("changedPaths") or []:
                    st.markdown(f"- `{path}`")
            with st.expander("Preview interface-only canonical configuration"):
                st.json(proposal.get("proposal") or {})

            if proposal.get("valid") and st.button(
                "✅ Approve interface-only change",
                type="primary",
                width="stretch",
            ):
                # Interface credentials are Partner-provided payload values.
                # They were stored only in the transient runtime payload store,
                # never as new .env/application credential profiles.
                save_json(REPORTS / "react_interface_latest.json", {
                    "buildId": BUILD_ID,
                    "sourceInterface": proposal.get("sourceInterface"),
                    "targetInterface": proposal.get("targetInterface"),
                    "changedPaths": proposal.get("changedPaths") or [],
                    "critic": proposal.get("critic") or {},
                    "trace": proposal.get("trace") or [],
                })
                apply_active_input(proposal["proposal"], reset_plan=True)
                st.session_state.pop("react_interface_proposal", None)
                st.success("Approved. The U-HAUL baseline is active with only the Transport Profile interface change.")
                st.rerun()

    elif mode.startswith("✨"):
        st.subheader("Step 1 — The business basics")
        c1, c2, c3 = st.columns(3)
        customer = c1.text_input("Who is this configuration for?", value=st.session_state.get("f_customer", ""), placeholder="Example: U-HAUL")
        direction = c2.selectbox("Which way is the data moving?", ["Outbound — Dell sends", "Inbound — Dell receives"], index=0)
        tx_standard = c3.selectbox("Message standard", ["X12", "XML", "JSON", "Other"], index=0)
        c4, c5 = st.columns(2)
        tx_code = c4.text_input("Message / transaction code", value=st.session_state.get("f_tx_code", "856"), help="Example: X12 856 is Ship Notice.")
        tx_name = c5.text_input("What does this message represent?", value=st.session_state.get("f_tx_name", "Ship Notice"))

        defaults = smart_defaults(customer, tx_code, tx_name)
        if st.button("✨ Let the agent suggest safe names", width="stretch"):
            for key, value in defaults.items():
                st.session_state[f"draft_{key}"] = value
            st.success("I created draft names. You can change every one before saving.")

        st.subheader("Step 2 — What comes in and what goes out")
        source_xml, target_xml = st.columns(2)
        with source_xml:
            st.markdown("**Source message**")
            src_sample = st.file_uploader("Optional sample source XML", type=["xml"], key="friendly_src_xml")
            detected_src_root = xml_root(src_sample)
            source_doc_name = st.text_input("Source message name", value=st.session_state.get("draft_source_doc_name", defaults["source_doc_name"] if customer else ""))
            source_root = st.text_input("Source root name", value=detected_src_root, help="If you upload a sample XML, I detect this automatically.")
        with target_xml:
            st.markdown("**Target message**")
            tgt_sample = st.file_uploader("Optional sample target XML", type=["xml"], key="friendly_tgt_xml")
            detected_tgt_root = xml_root(tgt_sample)
            target_doc_name = st.text_input("Target message name", value=st.session_state.get("draft_target_doc_name", defaults["target_doc_name"] if customer else ""))
            target_root = st.text_input("Target root name", value=detected_tgt_root, help="If you upload a sample XML, I detect this automatically.")

        st.subheader("Step 3 — How Dell should connect")
        st.caption(
            "Choose the connection type for each side. SFTP and FTP use the same simple account/folder form. "
            "HTTPS shows the REST/OAuth fields supplied by your Dev team. HTTPS-AS2 stays contract-driven so the agent "
            "uses your API PDF or approved interfaceDetails instead of inventing fields."
        )

        it1, it2 = st.columns(2)
        source_interface_choice = it1.selectbox(
            "Dell / sender connection type",
            INTERFACE_OPTIONS,
            index=0,
            help="U-HAUL uses SFTP. You can change this per customer.",
        )
        target_interface_choice = it2.selectbox(
            "Partner / receiver connection type",
            INTERFACE_OPTIONS,
            index=0,
        )
        st.caption(
            f"Sender: {INTERFACE_HELP[source_interface_choice]}  •  "
            f"Receiver: {INTERFACE_HELP[target_interface_choice]}"
        )

        source_known_ref = default_flow_tp_references(source_interface_choice)["source"]
        target_known_ref = default_flow_tp_references(target_interface_choice)["target"]

        # Defaults shared by every interface.
        source_account = ""
        target_account = ""
        source_folder = ""
        target_folder = ""
        source_interface_parameters: Dict[str, Any] = {}
        target_interface_parameters: Dict[str, Any] = {}
        source_client_secret = ""
        target_client_secret = ""

        p1, p2 = st.columns(2)
        with p1:
            st.markdown("**Dell / sender side**")
            source_system = st.text_input("Dell source system", value="AIC - DCE")
            source_tp_profile = st.text_input(
                "Source connection name",
                value=st.session_state.get("draft_source_tp_profile", defaults["source_tp_profile"] if customer else ""),
            )
            source_flow_tp = st.text_input(
                "Source profile used by the flow",
                value=source_known_ref,
                placeholder="Enter the profile reference used by Flow",
            )

            if source_interface_choice in {"SFTP", "FTP"}:
                source_account = st.text_input("Source account name", placeholder="Example: haft account")
                source_folder = st.text_input("Source folder", placeholder="Example: /Outbound/ASN")
            elif source_interface_choice == "HTTPS":
                source_protocol = st.text_input("Protocol", value="REST", key="src_https_protocol")
                source_hip_url = st.text_input(
                    "HIP URL",
                    value="URL will be shared later after API Publish is successful.",
                    key="src_https_hip_url",
                )
                source_proxy_uri = st.text_input("Proxy URI", value="dce-common-sv1", key="src_https_proxy")
                srm, srf = st.columns(2)
                source_request_method = srm.selectbox("Request method", ["POST", "PUT", "GET", "PATCH"], index=0, key="src_https_method")
                source_request_format = srf.text_input("Request format", value="Request Body", key="src_https_format")
                source_authentication_type = st.text_input("Sender authentication type", value="OAuth2", key="src_https_auth")
                source_grant_type = st.text_input("Sender grant type", value="client_credentials", key="src_https_grant")
                source_are_input_files_compressed = st.selectbox("Input files compressed?", ["False", "True"], index=0, key="src_https_compressed")
                with st.expander("Optional sender OAuth details"):
                    source_token_endpoint = st.text_input("Sender token endpoint", key="src_https_token")
                    source_client_id = st.text_input("Sender client ID", key="src_https_client_id")
                    source_client_secret = st.text_input(
                        "Sender client secret",
                        type="password",
                        placeholder="Partner payload value; held transiently and injected only into the live API request",
                        key="src_https_client_secret",
                    )
            else:
                st.info("For HTTPS-AS2, paste only the interface parameters approved by your API contract.")
                source_as2_json = st.text_area(
                    "Sender HTTPS-AS2 interface parameters (JSON object)",
                    height=190,
                    key="src_as2_json",
                    placeholder='{"AS2 field": "approved value"}',
                )
                source_interface_parameters = json_object_or_empty(source_as2_json)

        with p2:
            st.markdown("**Partner / receiver side**")
            target_partner = st.text_input("Target partner", value=customer)
            target_tp_profile = st.text_input(
                "Target connection name",
                value=st.session_state.get("draft_target_tp_profile", defaults["target_tp_profile"] if customer else ""),
            )
            target_flow_tp = st.text_input(
                "Target profile used by the flow",
                value=target_known_ref,
                placeholder="Enter the profile reference used by Flow",
            )

            if target_interface_choice in {"SFTP", "FTP"}:
                target_account = st.text_input("Target account name", placeholder="Example: haft account")
                target_folder = st.text_input("Target folder", placeholder="Example: /Inbound/ASN")
            elif target_interface_choice == "HTTPS":
                st.info("Required from Partner: Partner URL, Receiver Grant Type, Receiver Token Endpoint, Receiver Client ID and Receiver Client Secret.")
                st.caption("Plain HTTPS Receiver SSL Certificate fields are ignored in the V117 Dev-validation candidate. HTTPS-AS2 certificate fields are separate and unchanged.")
                target_protocol = st.text_input("Protocol", value="REST", key="tgt_https_protocol")
                target_partner_url = st.text_input("Partner URL", placeholder="https://partner-url.com", key="tgt_https_partner_url")
                trm, trf = st.columns(2)
                target_request_method = trm.selectbox("Request method", ["POST", "PUT", "GET", "PATCH"], index=0, key="tgt_https_method")
                target_request_format = trf.text_input("Request format", value="Request Body", key="tgt_https_format")
                target_authentication_type = st.text_input("Receiver authentication type", value="OAuth2", key="tgt_https_auth")
                target_gateway_url = st.text_input(
                    "Gateway URL",
                    value="URL will be shared later after API Publish is successful.",
                    key="tgt_https_gateway",
                )
                target_grant_type = st.text_input("Receiver grant type", placeholder="Get from Partner", key="tgt_https_grant")
                target_token_endpoint = st.text_input("Receiver token endpoint", placeholder="https://.../oauth/token", key="tgt_https_token")
                target_client_id = st.text_input("Receiver client ID", key="tgt_https_client_id")
                target_client_secret = st.text_input(
                    "Receiver client secret",
                    type="password",
                    placeholder="Partner payload value; held transiently and injected only into the live API request",
                    key="tgt_https_client_secret",
                )
                target_are_input_files_compressed = st.selectbox("Input files compressed?", ["False", "True"], index=0, key="tgt_https_compressed")
            else:
                st.info("For HTTPS-AS2, upload the API PDF or paste the approved Receiver interface parameters.")
                target_as2_json = st.text_area(
                    "Receiver HTTPS-AS2 interface parameters (JSON object)",
                    height=190,
                    key="tgt_as2_json",
                    placeholder='{"AS2 field": "approved value"}',
                )
                target_interface_parameters = json_object_or_empty(target_as2_json)

        with st.expander("More details — mapping, routing, and field paths", expanded=False):
            st.caption("You can leave uncertain values blank. The agent will ask for them in Configure before the live run.")
            d1, d2, d3 = st.columns(3)
            flow_name = d1.text_input("Configuration / flow name", value=st.session_state.get("draft_flow_name", defaults["flow_name"] if customer else ""))
            map_identifier = d2.text_input("Map identifier", value=st.session_state.get("draft_map_identifier", defaults["map_identifier"] if customer else ""))
            map_name = d3.text_input("Map name", value=st.session_state.get("draft_map_name", defaults["map_name"] if customer else ""))
            d4, d5, d6 = st.columns(3)
            map_class = d4.text_input("Map class", value=st.session_state.get("draft_map_class", defaults["map_class"] if customer else ""))
            rule_name = d5.text_input("Mapping rule name", value=st.session_state.get("draft_rule_name", defaults["rule_name"] if customer else ""))
            receiver_value = d6.text_input("Receiver routing value", value=str(customer or "").lower())
            jar = st.file_uploader("Mapping JAR (if required)", type=["jar"], key="friendly_jar")
            xbm = st.file_uploader("XBM cross-reference file (optional)", type=["xbm"], key="friendly_xbm")
            e1, e2 = st.columns(2)
            source_receiver_expression = e1.text_input("Where is Receiver in the source message?", placeholder="XPath / expression")
            source_sender_expression = e2.text_input("Where is Sender in the source message?", placeholder="XPath / expression")
            e3, e4 = st.columns(2)
            target_receiver_expression = e3.text_input("Where is Receiver in the target message?", placeholder="XPath / expression")
            target_sender_expression = e4.text_input("Where is Sender in the target message?", placeholder="XPath / expression")
            flow_description = st.text_input("Description", value=st.session_state.get("draft_flow_description", defaults["flow_description"] if customer else ""))

        # Ensure values exist even if the advanced expander has not been interacted with.
        flow_name = locals().get("flow_name", st.session_state.get("draft_flow_name", defaults["flow_name"] if customer else ""))
        map_identifier = locals().get("map_identifier", st.session_state.get("draft_map_identifier", defaults["map_identifier"] if customer else ""))
        map_name = locals().get("map_name", st.session_state.get("draft_map_name", defaults["map_name"] if customer else ""))
        map_class = locals().get("map_class", st.session_state.get("draft_map_class", defaults["map_class"] if customer else ""))
        rule_name = locals().get("rule_name", st.session_state.get("draft_rule_name", defaults["rule_name"] if customer else ""))
        receiver_value = locals().get("receiver_value", str(customer or "").lower())
        flow_description = locals().get("flow_description", defaults["flow_description"] if customer else "")
        source_receiver_expression = locals().get("source_receiver_expression", "")
        source_sender_expression = locals().get("source_sender_expression", "")
        target_receiver_expression = locals().get("target_receiver_expression", "")
        target_sender_expression = locals().get("target_sender_expression", "")
        jar = locals().get("jar", None)
        xbm = locals().get("xbm", None)

        fields = {
            "customer": customer,
            "flow_name": flow_name,
            "flow_description": flow_description,
            "direction": "Outbound" if direction.startswith("Outbound") else "Inbound",
            "tx_standard": tx_standard if tx_standard != "Other" else "X12",
            "tx_code": tx_code,
            "tx_name": tx_name,
            "dell_app": "ANS",
            "version": "1",
            "data_format": "XML" if tx_standard in {"X12", "XML"} else tx_standard,
            "source_doc_name": source_doc_name,
            "source_root": source_root,
            "target_doc_name": target_doc_name,
            "target_root": target_root,
            "map_identifier": map_identifier,
            "map_name": map_name,
            "map_class": map_class,
            "map_data_file": jar.name if jar else "",
            "cross_reference_file": xbm.name if xbm else "",
            "rule_name": rule_name,
            "receiver_value": receiver_value,
            "receiver_operator": "Equals",
            "sender_value": "DELL",
            "sender_operator": "Contains",
            "source_system": source_system,
            "target_partner": target_partner,
            "source_tp_profile": source_tp_profile,
            "target_tp_profile": target_tp_profile,
            "source_flow_tp": source_flow_tp,
            "target_flow_tp": target_flow_tp,
            "source_account": source_account,
            "target_account": target_account,
            "source_folder": source_folder,
            "target_folder": target_folder,
            "source_deployment_group": "hip-automation",
            "target_deployment_group": "hip-automation",
            "source_receiver_expression": source_receiver_expression,
            "source_sender_expression": source_sender_expression,
            "target_receiver_expression": target_receiver_expression,
            "target_sender_expression": target_sender_expression,
            "source_business_expression": "",
            "source_alt_business_expression": "",
            "target_business_expression": "",
            "target_alt_business_expression": "",
            "source_interface_type": source_interface_choice,
            "target_interface_type": target_interface_choice,
            "source_interface_parameters": source_interface_parameters,
            "target_interface_parameters": target_interface_parameters,
            "source_protocol": locals().get("source_protocol", ""),
            "source_hip_url": locals().get("source_hip_url", ""),
            "source_proxy_uri": locals().get("source_proxy_uri", ""),
            "source_request_method": locals().get("source_request_method", ""),
            "source_request_format": locals().get("source_request_format", ""),
            "source_authentication_type": locals().get("source_authentication_type", ""),
            "source_are_input_files_compressed": locals().get("source_are_input_files_compressed", "False"),
            "source_grant_type": locals().get("source_grant_type", ""),
            "source_token_endpoint": locals().get("source_token_endpoint", ""),
            "source_client_id": locals().get("source_client_id", ""),
            "source_client_secret_configured": bool(
                source_client_secret or has_runtime_payload_value(ROOT, "source.sender_client_secret")
            ),
            "target_protocol": locals().get("target_protocol", ""),
            "target_partner_url": locals().get("target_partner_url", ""),
            "target_request_method": locals().get("target_request_method", ""),
            "target_request_format": locals().get("target_request_format", ""),
            "target_authentication_type": locals().get("target_authentication_type", ""),
            "target_gateway_url": locals().get("target_gateway_url", ""),
            "target_are_input_files_compressed": locals().get("target_are_input_files_compressed", "False"),
            "target_grant_type": locals().get("target_grant_type", ""),
            "target_token_endpoint": locals().get("target_token_endpoint", ""),
            "target_client_id": locals().get("target_client_id", ""),
            "target_client_secret_configured": bool(
                target_client_secret or has_runtime_payload_value(ROOT, "target.receiver_client_secret")
            ),
        }
        questions = guided_questions(fields)
        if questions:
            st.info(f"I can save this as a draft, but I still need {len(questions)} item(s) before execution.")
            with st.expander("What is still needed?", expanded=True):
                for idx, q in enumerate(questions, 1):
                    st.markdown(f"**{idx}. {q['question']}**  \n{q['why']}")
        else:
            st.success("The basic guided information is complete.")

        b1, b2 = st.columns(2)
        if b1.button("Save this configuration", type="primary", width="stretch"):
            if jar:
                (INPUT_FILES / jar.name).write_bytes(jar.getvalue())
            if xbm:
                (INPUT_FILES / xbm.name).write_bytes(xbm.getvalue())
            runtime_values: Dict[str, Any] = {"source": {}, "target": {}}
            if source_client_secret:
                runtime_values["source"]["sender_client_secret"] = source_client_secret
            if target_client_secret:
                runtime_values["target"]["receiver_client_secret"] = target_client_secret
            if runtime_values["source"] or runtime_values["target"]:
                save_runtime_payload_values(ROOT, runtime_values, merge=True)
            canonical = build_guided_input(fields)
            apply_active_input(canonical, reset_plan=True)
            st.success("Saved. Go to Connect next; the agent will keep checking for anything missing.")
            st.rerun()
        if b2.button("Ask agent to review my draft", width="stretch"):
            st.session_state["draft_agent_review"] = ask_agent("guided-draft", {
                "message": "Review this draft for a non-technical user. Explain missing business information, not API syntax.",
                "next_action": "Tell the user the most important missing item first.",
                "fields": {k: v for k, v in fields.items() if k not in {"source_receiver_expression", "source_sender_expression", "target_receiver_expression", "target_sender_expression"}},
                "missingQuestions": questions,
            })
        if st.session_state.get("draft_agent_review"):
            with st.container(border=True):
                st.markdown(f"**Agent review:** {st.session_state['draft_agent_review'].get('message','')}")
                for a in st.session_state["draft_agent_review"].get("nextActions") or []:
                    st.markdown(f"- {a}")

    elif mode.startswith("📄"):
        coach("input-json", "I will translate the JSON for you", "Upload your existing input file. I will map it into the HIP workspace and show questions instead of asking you to edit the schema.", "Upload the JSON and click Analyze.")
        uploaded = st.file_uploader("Choose input JSON", type=["json"], key="friendly_input_json")
        use_aia = st.checkbox("Let Dell AIA help understand unusual field names", value=True)
        if st.button("Analyze this file", type="primary", disabled=not uploaded, width="stretch"):
            try:
                raw = json.loads(uploaded.getvalue().decode("utf-8"))
                aia_callable = None
                if use_aia:
                    from run_agent import AIAJudge
                    judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
                    if judge.available():
                        judge.verify_connection(); aia_callable = judge.complete_json
                prepared = engine.prepare_canonical_input(raw, apply_safe=True, use_aia=bool(aia_callable), aia_complete_json=aia_callable)
                st.session_state["friendly_prepared_input"] = prepared
            except Exception as exc:
                st.error(str(exc))
        prepared = st.session_state.get("friendly_prepared_input")
        if prepared:
            unresolved = prepared.get("unresolvedQuestions") or []
            if unresolved:
                st.warning(f"I understood the file, but I still need {len(unresolved)} answer(s).")
                render_table(unresolved)
            else:
                st.success("I understood the file and it is ready to activate.")
            with st.expander("See what I understood"):
                st.json(prepared.get("canonicalInput") or {})
            if st.button("Use this as my active configuration", type="primary", disabled=bool(unresolved), width="stretch"):
                apply_active_input(prepared["canonicalInput"], reset_plan=True)
                st.success("Configuration activated.")
                st.rerun()

    elif mode.startswith("🧩"):
        coach("payload-first", "I can work backwards from API payloads", "Paste or upload payloads you already have. I will identify the objects, create a workspace draft, and ask only for the business information that cannot be inferred.", "Upload/paste the payload bundle.")
        payload_file = st.file_uploader("Payload bundle JSON", type=["json"], key="friendly_payload_bundle")
        payload_text = st.text_area("Or paste the payload bundle", height=220, placeholder='{"doctype_source": {...}, "source_tp": {...}, "flow_create": {...}}')
        if st.button("Understand these payloads", type="primary", disabled=not (payload_file or payload_text.strip()), width="stretch"):
            try:
                raw = json.loads(payload_file.getvalue().decode("utf-8")) if payload_file else json.loads(payload_text)
                bundle = normalize_payload_bundle(raw)
                inferred = infer_fields_from_payload_bundle(bundle)
                st.session_state["payload_inferred_fields"] = inferred
                st.session_state["payload_bundle_import"] = bundle
            except Exception as exc:
                st.error(str(exc))
        inferred = st.session_state.get("payload_inferred_fields")
        if inferred:
            st.success(f"I found {len(inferred)} configuration value(s) in the payloads.")
            render_table([{"What I found": k.replace("_", " ").title(), "Value": v} for k, v in inferred.items()])
            st.info("Use 'Create a new configuration' and the agent can use these values as a starting point, or import them as request overrides in Payload / MCP / Advanced.")
            if st.button("Use these as my guided draft", type="primary", width="stretch"):
                st.session_state.update({f"draft_{k}": v for k, v in inferred.items()})
                st.session_state["f_customer"] = inferred.get("customer", st.session_state.get("f_customer", ""))
                st.session_state["friendly_start_mode"] = "✨ I want to create a new configuration"
                st.rerun()

    elif mode.startswith("🧬"):
        coach(
            "clone-template",
            "Use U-HAUL as a working template",
            (
                "U-HAUL is an SFTP configuration and can be reused as a starting point. "
                "Tell me the new customer and only the values that change. I keep everything "
                "else from the approved U-HAUL template, then show you the changes before saving."
            ),
            "Enter the differences, preview them, then approve the cloned configuration.",
        )

        template_input = load_json(DEV_APPROVED_DIR / "UHAL_input_dev_approved.json", load_json(INPUT_JSON, {}))
        template_config = load_json(DEV_APPROVED_DIR / "UHAL_config_dev_approved.json", load_json(CONFIG_JSON, {}))

        st.info(
            "Template baseline: U-HAUL • SFTP • existing mapping/rule/document structure. "
            "Customer-specific names are automatically renamed when you enter a new customer."
        )

        t1, t2, t3 = st.columns(3)
        clone_customer = t1.text_input("New customer / partner", placeholder="Example: ACME")
        clone_tx_code = t2.text_input("Transaction code — leave blank to keep U-HAUL", placeholder="856")
        clone_tx_name = t3.text_input("Transaction name — leave blank to keep U-HAUL", placeholder="Ship Notice")

        ci1, ci2 = st.columns(2)
        clone_source_interface = ci1.selectbox("Sender connection type", INTERFACE_OPTIONS, index=0, key="clone_source_interface")
        clone_target_interface = ci2.selectbox("Receiver connection type", INTERFACE_OPTIONS, index=0, key="clone_target_interface")

        clone_source_ref_default = default_flow_tp_references(clone_source_interface)["source"]
        clone_target_ref_default = default_flow_tp_references(clone_target_interface)["target"]

        tc1, tc2 = st.columns(2)
        with tc1:
            st.markdown("**Sender differences**")
            clone_source_tp = st.text_input("Source Transport Profile name — optional", key="clone_src_tp")
            clone_source_flow_tp = st.text_input(
                "Source profile used by Flow",
                value=clone_source_ref_default,
                key="clone_src_flow_tp",
            )
            clone_source_account = ""
            clone_source_folder = ""
            clone_source_params: Dict[str, Any] = {}
            clone_source_secret = ""

            if clone_source_interface in {"SFTP", "FTP"}:
                clone_source_account = st.text_input("Source account — blank keeps template", key="clone_src_account")
                clone_source_folder = st.text_input("Source folder — blank keeps template", key="clone_src_folder")
            elif clone_source_interface == "HTTPS":
                csp = st.text_input("Proxy URI", value="dce-common-sv1", key="clone_src_proxy")
                cship = st.text_input(
                    "HIP URL",
                    value="URL will be shared later after API Publish is successful.",
                    key="clone_src_hip_url",
                )
                clone_source_params = {
                    "Protocol": "REST",
                    "HIP URL": cship,
                    "Proxy URI": csp,
                    "Request Method": "POST",
                    "Request Format": "Request Body",
                    "Sender Authentication Type": "OAuth2",
                    "Are Input Files Compressed?": "False",
                    "Sender Grant Type": "client_credentials",
                }
                with st.expander("Optional sender OAuth values"):
                    clone_src_token = st.text_input("Sender token endpoint", key="clone_src_token")
                    clone_src_client = st.text_input("Sender client ID", key="clone_src_client")
                    clone_source_secret = st.text_input(
                        "Sender client secret",
                        type="password",
                        key="clone_src_secret",
                        placeholder="Partner payload value — transient, not an app credential",
                    )
                    if clone_src_token:
                        clone_source_params["Sender Token Endpoint"] = clone_src_token
                    if clone_src_client:
                        clone_source_params["Sender Client Id"] = clone_src_client
                    if clone_source_secret:
                        save_runtime_payload_values(ROOT, {"source": {"sender_client_secret": clone_source_secret}}, merge=True)
                    if clone_source_secret or has_runtime_payload_value(ROOT, "source.sender_client_secret"):
                        clone_source_params["Sender Client Secret"] = runtime_payload_placeholder("source.sender_client_secret")
            else:
                clone_source_as2 = st.text_area(
                    "Approved sender HTTPS-AS2 parameters",
                    key="clone_src_as2",
                    height=170,
                    placeholder='{"field": "value"}',
                )
                clone_source_params = json_object_or_empty(clone_source_as2)

        with tc2:
            st.markdown("**Receiver differences**")
            clone_target_partner = st.text_input("Target Partner — blank uses new customer", key="clone_tgt_partner")
            clone_target_tp = st.text_input("Target Transport Profile name — optional", key="clone_tgt_tp")
            clone_target_flow_tp = st.text_input(
                "Target profile used by Flow",
                value=clone_target_ref_default,
                key="clone_tgt_flow_tp",
            )
            clone_target_account = ""
            clone_target_folder = ""
            clone_target_params: Dict[str, Any] = {}
            clone_target_secret = ""

            if clone_target_interface in {"SFTP", "FTP"}:
                clone_target_account = st.text_input("Target account — blank keeps template", key="clone_tgt_account")
                clone_target_folder = st.text_input("Target folder — blank keeps template", key="clone_tgt_folder")
            elif clone_target_interface == "HTTPS":
                clone_partner_url = st.text_input("Partner URL", placeholder="https://partner-url.com", key="clone_tgt_partner_url")
                clone_gateway_url = st.text_input(
                    "Gateway URL",
                    value="URL will be shared later after API Publish is successful.",
                    key="clone_tgt_gateway",
                )
                clone_token_endpoint = st.text_input("Receiver token endpoint", key="clone_tgt_token")
                clone_client_id = st.text_input("Receiver client ID", key="clone_tgt_client")
                clone_target_secret = st.text_input(
                    "Receiver client secret",
                    type="password",
                    key="clone_tgt_secret",
                    placeholder="Partner payload value — transient, not an app credential",
                )
                clone_target_params = {
                    "Protocol": "REST",
                    "Partner URL": clone_partner_url,
                    "Request Method": "POST",
                    "Request Format": "Request Body",
                    "Receiver Authentication Type": "OAuth2",
                    "Gateway URL": clone_gateway_url,
                    "Are Input Files Compressed?": "False",
                    "Receiver Grant Type": st.text_input("Receiver Grant Type", placeholder="Get from Partner", key="clone_tgt_grant"),
                    "Receiver Token Endpoint": clone_token_endpoint,
                    "Receiver Client Id": clone_client_id,
                }
                clone_target_params = {k: v for k, v in clone_target_params.items() if v not in ("", None)}
                if clone_target_secret:
                    save_runtime_payload_values(ROOT, {"target": {"receiver_client_secret": clone_target_secret}}, merge=True)
                if clone_target_secret or has_runtime_payload_value(ROOT, "target.receiver_client_secret"):
                    clone_target_params["Receiver Client Secret"] = runtime_payload_placeholder("target.receiver_client_secret")
            else:
                clone_target_as2 = st.text_area(
                    "Approved receiver HTTPS-AS2 parameters",
                    key="clone_tgt_as2",
                    height=170,
                    placeholder='{"field": "value"}',
                )
                clone_target_params = json_object_or_empty(clone_target_as2)

        clone_notes = st.text_area(
            "Tell the agent any other differences in normal language",
            height=130,
            placeholder=(
                "Example: Everything else is the same as U-HAUL. Change the receiver routing value to acme, "
                "use deployment group hip-automation, and change the flow name to ACME_PC_856_ANS_MAPPING_OB."
            ),
        )

        if st.button("Preview configuration cloned from U-HAUL", type="primary", width="stretch"):
            if not clone_customer.strip():
                st.error("Enter the new customer / partner first.")
            else:
                changes = {
                    "tx_code": clone_tx_code,
                    "tx_name": clone_tx_name,
                    "source_interface_type": clone_source_interface,
                    "target_interface_type": clone_target_interface,
                    "source_tp_profile": clone_source_tp,
                    "target_tp_profile": clone_target_tp,
                    "source_flow_tp": clone_source_flow_tp,
                    "target_flow_tp": clone_target_flow_tp,
                    "source_account": clone_source_account,
                    "target_account": clone_target_account,
                    "source_folder": clone_source_folder,
                    "target_folder": clone_target_folder,
                    "target_partner": clone_target_partner or clone_customer,
                    "source_interface_parameters": clone_source_params,
                    "target_interface_parameters": clone_target_params,
                }
                cloned = clone_uhaul_template(
                    template_input,
                    customer=clone_customer,
                    changes=changes,
                )

                proposal = None
                if clone_notes.strip():
                    aia_callable = None
                    try:
                        from run_agent import AIAJudge
                        judge = AIAJudge(template_config, enabled=True)
                        if judge.available():
                            judge.verify_connection()
                            aia_callable = judge.complete_json
                    except Exception:
                        aia_callable = None
                    proposal = engine.propose_change(
                        clone_notes,
                        cloned,
                        template_config,
                        use_aia=bool(aia_callable),
                        aia_complete_json=aia_callable,
                    )

                st.session_state["clone_preview"] = {
                    "input": cloned,
                    "config": template_config,
                    "proposal": proposal,
                    "sourceSecret": clone_source_secret,
                    "targetSecret": clone_target_secret,
                }

        clone_preview = st.session_state.get("clone_preview")
        if clone_preview:
            st.success("Template clone is ready for review. Nothing has been activated yet.")
            preview_input = clone_preview["input"]
            proposal = clone_preview.get("proposal")
            summary_rows = [
                {"Item": "Customer", "Value": preview_input.get("customer")},
                {"Item": "Flow", "Value": preview_input.get("profile_name")},
                {"Item": "Sender interface", "Value": (preview_input.get("objects") or {}).get("source_transport_profile", {}).get("interface_type")},
                {"Item": "Receiver interface", "Value": (preview_input.get("objects") or {}).get("target_transport_profile", {}).get("interface_type")},
                {"Item": "Target partner", "Value": (preview_input.get("objects") or {}).get("target_transport_profile", {}).get("partner_name")},
            ]
            render_table(summary_rows)
            if proposal:
                st.markdown("**Agent-proposed additional differences**")
                if proposal.get("patch"):
                    render_table(proposal.get("patch"))
                else:
                    st.warning("The free-text differences could not be mapped safely. Structured changes above are still available.")
                    for q in proposal.get("questions") or []:
                        st.markdown(f"- {q}")

            with st.expander("Preview full cloned canonical configuration"):
                st.json(preview_input)

            if st.button("Approve and use this cloned configuration", type="primary", width="stretch"):
                final_input = preview_input
                if proposal and proposal.get("patch"):
                    applied = engine.apply_change(
                        proposal,
                        preview_input,
                        clone_preview["config"],
                        approve=True,
                    )
                    final_input = applied.get("input") or preview_input

                runtime_values: Dict[str, Any] = {"source": {}, "target": {}}
                if clone_preview.get("sourceSecret"):
                    runtime_values["source"]["sender_client_secret"] = clone_preview["sourceSecret"]
                if clone_preview.get("targetSecret"):
                    runtime_values["target"]["receiver_client_secret"] = clone_preview["targetSecret"]
                if runtime_values["source"] or runtime_values["target"]:
                    save_runtime_payload_values(ROOT, runtime_values, merge=True)

                apply_active_input(final_input, reset_plan=True)
                st.session_state.pop("clone_preview", None)
                st.success("Cloned configuration activated. Continue to Connect.")
                st.rerun()

    else:
        coach("restore", "Use the known U-HAUL setup", "This restores the Dev-approved U-HAUL input and configuration. You can still change what runs, timing, payloads, and credentials afterward.", "Restore it, then go to Connect.")
        if st.button("Restore the approved U-HAUL setup", type="primary", width="stretch"):
            try:
                src = DEV_APPROVED_DIR / "UHAL_input_dev_approved.json"
                cfg = DEV_APPROVED_DIR / "UHAL_config_dev_approved.json"
                save_json(INPUT_JSON, load_json(src, {}))
                save_json(CONFIG_JSON, load_json(cfg, {}))
                st.success("U-HAUL configuration restored.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))

# ---------------------------------------------------------------------------
# 2. CONNECT
# ---------------------------------------------------------------------------
with tabs[1]:
    plan = ApiExecutionPlan(ROOT, INPUT_JSON)
    account_required = not (plan.is_skipped("account_source") and plan.is_skipped("account_target"))
    partner_required = not plan.is_skipped("partner_target")
    system_required = not plan.is_skipped("system_source")
    coach(
        "connect",
        "Connect only the services this run needs",
        "HIP Config and Dell AIA are always needed. Account, Partner, and System credentials are only needed when those APIs will actually run.",
        "Open each required connection card, enter Client ID + Client Secret, save, then run the connection check.",
        {"accountRequired": account_required, "partnerRequired": partner_required, "systemRequired": system_required},
    )

    connection = st.session_state.get("connection_check") or load_json(REPORTS / "connection_check_latest.json", {})
    components = connection.get("components") or {}
    cc = st.columns(5)
    with cc[0]: connection_card("HIP Config", components.get("hipOAuth", {}), True)
    with cc[1]: connection_card("Account", components.get("accountOAuth", {}), account_required)
    with cc[2]: connection_card("Partner", components.get("partnerOAuth", {}), partner_required)
    with cc[3]: connection_card("System", components.get("systemOAuth", {}), system_required)
    with cc[4]: connection_card("Dell AIA", components.get("dellAia", {}), True)

    env = {str(k): str(v or "") for k, v in dotenv_values(ENV_PATH).items()} if ENV_PATH.exists() else {}

    def credential_expander(label: str, prefix: str, required: bool, default_url: str, explanation: str) -> Dict[str, str]:
        state_label = "Required for this run" if required else "Optional — API is currently skipped"
        with st.expander(f"{'🔑' if required else '⏭️'} {label} — {state_label}", expanded=False):
            st.caption(explanation)
            u1, u2 = st.columns([2, 1])
            url = u1.text_input("Access token URL", env.get(f"{prefix}_TOKEN_URL", default_url), key=f"cred_url_{prefix}")
            scope = u2.text_input("Scope (usually blank)", env.get(f"{prefix}_SCOPE", ""), key=f"cred_scope_{prefix}")
            c1, c2 = st.columns(2)
            cid = c1.text_input("Client ID", env.get(f"{prefix}_CLIENT_ID", ""), key=f"cred_id_{prefix}")
            secret = c2.text_input("Client Secret", type="password", placeholder="Already saved — leave blank to keep" if configured(f"{prefix}_CLIENT_SECRET") else "Enter Client Secret", key=f"cred_secret_{prefix}")
            return {"url": url, "scope": scope, "id": cid, "secret": secret}

    hip = credential_expander("HIP Config + MAC Map", "HIP", True, DEFAULT_HIP_TOKEN_URL, "Used for Document Type, MAC Map, Rule, Transport Profile, Flow, deploy and history APIs.")
    acct = credential_expander("Account", "ACCOUNT", account_required, env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL), "Only needed if this run creates or calls Account APIs.")
    part = credential_expander("Partner", "PARTNER", partner_required, env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL), "Only needed if this run creates or calls Partner APIs.")
    syst = credential_expander("System", "SYSTEM", system_required, env.get("HIP_TOKEN_URL", DEFAULT_HIP_TOKEN_URL), "Only needed if this run creates or calls System APIs.")

    with st.expander("🌐 Account / Partner / System API endpoint overrides", expanded=False):
        st.caption(
            "Leave these blank to use the developer-approved packaged Dell gateway URLs. "
            "Only enter replacements supplied by the API team. These settings change the destination URL only; "
            "the approved request payloads are not mutated."
        )
        e1, e2, e3 = st.columns(3)
        account_api_url = e1.text_input(
            "Account API URL", env.get("HIP_ACCOUNT_API_URL", ""), key="endpoint_override_account"
        )
        partner_api_url = e2.text_input(
            "Partner API URL", env.get("HIP_PARTNER_API_URL", ""), key="endpoint_override_partner"
        )
        system_api_url = e3.text_input(
            "System API URL", env.get("HIP_SYSTEM_API_URL", ""), key="endpoint_override_system"
        )

    with st.expander("🤖 Dell AIA — the assistant that helps you", expanded=False):
        st.caption("Dell AIA explains missing values, reviews payloads, and helps interpret changes. It does not silently apply changes.")
        a1, a2 = st.columns(2)
        aia_base = a1.text_input("Dell AIA URL", env.get("DELL_AIA_BASE_URL", "https://aia.gateway.dell.com/genai/dev/v1"))
        aia_model = a2.text_input("Model", env.get("DELL_AIA_MODEL", "gpt-oss-120b"))
        a3, a4 = st.columns(2)
        aia_id = a3.text_input("Dell AIA Client ID", env.get("DELL_AIA_CLIENT_ID", ""))
        aia_secret = a4.text_input("Dell AIA Client Secret", type="password", placeholder="Already saved — leave blank to keep" if configured("DELL_AIA_CLIENT_SECRET") else "Enter Client Secret")

    save_col, check_col = st.columns(2)
    if save_col.button("Save connection details", type="primary", width="stretch"):
        values = {
            "HIP_TOKEN_URL": hip["url"].strip(), "HIP_CLIENT_ID": hip["id"].strip(), "HIP_SCOPE": hip["scope"].strip(),
            "ACCOUNT_TOKEN_URL": acct["url"].strip(), "ACCOUNT_CLIENT_ID": acct["id"].strip(), "ACCOUNT_SCOPE": acct["scope"].strip(),
            "PARTNER_TOKEN_URL": part["url"].strip(), "PARTNER_CLIENT_ID": part["id"].strip(), "PARTNER_SCOPE": part["scope"].strip(),
            "SYSTEM_TOKEN_URL": syst["url"].strip(), "SYSTEM_CLIENT_ID": syst["id"].strip(), "SYSTEM_SCOPE": syst["scope"].strip(),
            "HIP_ACCOUNT_API_URL": account_api_url.strip(),
            "HIP_PARTNER_API_URL": partner_api_url.strip(),
            "HIP_SYSTEM_API_URL": system_api_url.strip(),
            "DELL_AIA_BASE_URL": aia_base.strip(), "DELL_AIA_MODEL": aia_model.strip(), "DELL_AIA_CLIENT_ID": aia_id.strip(),
            "HIP_VERIFY_SSL": "true", "MCP_ENABLED": "true", "MCP_VALIDATE_EACH_REQUEST": "true",
        }
        for key, value in [("HIP_CLIENT_SECRET", hip["secret"]), ("ACCOUNT_CLIENT_SECRET", acct["secret"]), ("PARTNER_CLIENT_SECRET", part["secret"]), ("SYSTEM_CLIENT_SECRET", syst["secret"]), ("DELL_AIA_CLIENT_SECRET", aia_secret)]:
            if value:
                values[key] = value
        save_env(values)
        st.success("Saved locally. Secrets are not written to the execution report.")
    if check_col.button("Check my connections", width="stretch"):
        proc = subprocess.run([sys.executable, "connection_check.py"], cwd=ROOT, text=True, capture_output=True)
        st.session_state["connection_check"] = load_json(REPORTS / "connection_check_latest.json", {})
        if proc.returncode == 0:
            st.success("Everything required for this run is connected.")
        else:
            st.warning("One or more required connections still need attention.")
        st.rerun()

    if connection:
        with st.expander("Connection details — only if you need to troubleshoot"):
            st.json(connection)

# ---------------------------------------------------------------------------
# 3. TEACH AGENT
# ---------------------------------------------------------------------------
with tabs[2]:
    coach(
        "docs",
        "Teach the agent using your API documentation",
        "This step is optional unless your team requires documentation. Upload the API portal PDF and I will use it to check requests before they are sent.",
        "Upload one or more PDF files, then click Learn from these documents.",
        {"documentsAlreadyLoaded": len(pdf_kb.list_documents())},
    )
    uploads = st.file_uploader("Drop API documentation PDF(s) here", type=["pdf"], accept_multiple_files=True, key="friendly_pdf_upload")
    c1, c2 = st.columns(2)
    if c1.button("Learn from these documents", type="primary", disabled=not uploads, width="stretch"):
        learned = []
        for item in uploads or []:
            try:
                result = pdf_kb.ingest_bytes(item.name, item.getvalue())
                learned.append({"File": item.name, "Status": "Learned", "Sections": len(result.sections or []) if hasattr(result, "sections") else ""})
            except Exception as exc:
                learned.append({"File": item.name, "Status": f"Could not read: {exc}"})
        st.session_state["friendly_pdf_learned"] = learned
        st.success(f"Processed {len(learned)} document(s).")
    if c2.button("Build API checks from the documents", disabled=not pdf_kb.has_documents(), width="stretch"):
        try:
            from run_agent import AIAJudge
            judge = AIAJudge(load_json(CONFIG_JSON, {}), enabled=True)
            judge.verify_connection()
            result = pdf_kb.extract_contracts_with_aia(judge)
            st.success(f"Agent created/updated {len(result.get('contracts') or {})} API contract check(s).")
        except Exception as exc:
            st.error(str(exc))
    if st.session_state.get("friendly_pdf_learned"):
        render_table(st.session_state["friendly_pdf_learned"])
    docs = pdf_kb.list_documents()
    if docs:
        st.success(f"The agent currently knows {len(docs)} uploaded API document(s).")
        with st.expander("See learned documents"):
            render_table(docs)
    else:
        st.info("No PDF has been uploaded yet. You can continue if documentation is not mandatory.")

# ---------------------------------------------------------------------------
# 4. CONFIGURE
# ---------------------------------------------------------------------------
with tabs[3]:
    input_data = load_json(INPUT_JSON, {})
    config_data = load_json(CONFIG_JSON, {})
    try:
        analysis = engine.prepare_canonical_input(input_data, apply_safe=False)
        questions = analysis.get("unresolvedQuestions") or []
    except Exception as exc:
        questions = [{"field": "configuration", "question": str(exc), "why": "The configuration could not be fully checked."}]
    coach(
        "configure",
        "I will show only what needs your decision",
        "You do not need to inspect every API field. I will ask about missing business values, show which objects already exist, and keep the technical request editor in the Advanced workspace.",
        "Answer the open questions below. If you do not know an answer, ask the agent for a suggestion.",
        {"openQuestions": questions, "customer": input_data.get("customer")},
    )

    q1, q2, q3 = st.columns(3)
    q1.metric("Questions for you", len(questions))
    q2.metric("API documents", len(pdf_kb.list_documents()))
    q3.metric("Manual request edits", PayloadOverrideStore(ROOT).summary().get("count", 0))

    if questions:
        st.subheader("What I still need from you")
        for i, q in enumerate(questions, 1):
            with st.container(border=True):
                st.markdown(f"**{i}. {q.get('question') or q.get('field')}**")
                if q.get("why"):
                    st.caption(q["why"])
    else:
        st.success("I do not see any unresolved canonical-input questions.")

    st.subheader("Tell the agent in normal language")
    answer = st.text_area(
        "Your answer or correction",
        height=110,
        placeholder="Example: Use da-sender-sftphaft-dce-common for the sender and pt-receiver-sftphaft-dce-common for the receiver.",
        key="friendly_agent_answer",
    )
    a1, a2 = st.columns(2)
    if a1.button("Turn my answer into a change I can review", type="primary", disabled=not answer.strip(), width="stretch"):
        try:
            from run_agent import AIAJudge
            judge = AIAJudge(config_data, enabled=True)
            judge.verify_connection()
            st.session_state["friendly_patch"] = engine.propose_change(answer, input_data, config_data, use_aia=True, aia_complete_json=judge.complete_json)
        except Exception as exc:
            st.error(str(exc))
    if a2.button("Ask agent what I should answer first", width="stretch"):
        st.session_state["configure_guidance"] = ask_agent("questions", {"openQuestions": questions, "next_action": "Prioritize the single most important missing business value."})
    if st.session_state.get("configure_guidance"):
        st.info(st.session_state["configure_guidance"].get("message", ""))
        for x in st.session_state["configure_guidance"].get("nextActions") or []:
            st.markdown(f"- {x}")

    proposal = st.session_state.get("friendly_patch")
    if proposal:
        with st.expander("Review the agent's proposed change", expanded=True):
            st.json(proposal)
            approved = st.checkbox("I approve this proposed change", key="friendly_patch_approve")
            if st.button("Apply approved change", disabled=not approved, width="stretch"):
                try:
                    applied = engine.apply_change(proposal, input_data, config_data, approve=True)
                    save_json(INPUT_JSON, applied["input"]); save_json(CONFIG_JSON, applied["config"])
                    st.session_state.pop("friendly_patch", None)
                    st.success("Change applied. I will re-check the workspace.")
                    st.rerun()
                except Exception as exc:
                    st.error(str(exc))

    st.divider()
    st.subheader("Do any of these already exist?")
    st.caption("If an object already exists, I can skip its create API and continue with the remaining flow.")
    plan = ApiExecutionPlan(ROOT, INPUT_JSON)
    current_skips = set(plan.summary().get("skipSteps") or []) if plan.summary().get("active") else set()
    e1, e2, e3, e4 = st.columns(4)
    skip_source_account = e1.checkbox("Source account already exists", value="account_source" in current_skips)
    skip_target_account = e2.checkbox("Target account already exists", value="account_target" in current_skips)
    skip_partner = e3.checkbox("Partner already exists", value="partner_target" in current_skips)
    skip_system = e4.checkbox("System already exists", value="system_source" in current_skips)
    if st.button("Save these existing-object choices", width="stretch"):
        selected: List[str] = []
        if skip_source_account: selected.append("account_source")
        if skip_target_account: selected.append("account_target")
        if skip_partner: selected.append("partner_target")
        if skip_system: selected.append("system_source")
        try:
            existing = plan.summary().get("existingIds") or {}
            save_execution_plan(ROOT, INPUT_JSON, selected, existing, confirmed=bool(selected), reason="Existing objects confirmed by user in Guided Configuration Assistant")
            st.success("Saved. Skipped create APIs will not block the remaining flow.")
            invalidate_connection_check()
            st.rerun()
        except Exception as exc:
            st.error(str(exc))

    st.divider()
    st.subheader("How cautious should the timing be?")
    timing = st.radio("Timing preset", ["Recommended", "Fast", "Careful"], horizontal=True)
    if st.button("Apply timing preset", width="stretch"):
        base = ExecutionFlowConfig(ROOT).summary().get("steps") or []
        rows = []
        for row in base:
            wait = 0.0
            if timing == "Recommended":
                wait = 30.0 if row["stepKey"] in {"target_tp", "flow_deploy"} else 0.0
            elif timing == "Careful":
                wait = 10.0
                if row["stepKey"] in {"target_tp", "flow_deploy"}: wait = 30.0
            rows.append({"stepKey": row["stepKey"], "order": row["order"], "waitAfterSeconds": wait})
        try:
            save_execution_flow(ROOT, rows)
            st.success(f"{timing} timing applied.")
        except Exception as exc:
            st.error(str(exc))

    st.markdown("### What will happen")
    plan_summary = ApiExecutionPlan(ROOT, INPUT_JSON).summary()
    skip_keys = set(plan_summary.get("skipSteps") or []) if plan_summary.get("active") else set()
    flow = ExecutionFlowConfig(ROOT)
    simple_rows = []
    for idx, key in enumerate(flow.ordered_steps(), 1):
        simple_rows.append({
            "Step": idx,
            "What the agent will do": STEP_DEFINITIONS[key]["label"].replace("Orchestration", "").replace("Validate", "Check"),
            "Action": "Use existing — no create call" if key in skip_keys else "Run",
            "Wait after": f"{flow.wait_after(key):g} sec",
        })
    render_table(simple_rows)
    st.info("Need to edit raw payloads, exact order, individual waits, or IDs? Open Payload / MCP / Advanced from the sidebar.")

# ---------------------------------------------------------------------------
# 5. REVIEW & RUN
# ---------------------------------------------------------------------------
with tabs[4]:
    state = readiness_state()
    coach(
        "review",
        "Final check before anything changes",
        "I will not enable the live run until mapping, MCP validation, required connections, skip choices, timing, payload edits, and any required documentation all pass.",
        "Fix any red item below, then run Preflight. When preflight passes, execute the configuration.",
        {"ready": state["ready"], "mapperOk": state["mapper_ok"], "mcpOk": state["mcp_ok"], "connectionsOk": state["connections_ok"], "planOk": state["plan_ok"], "flowOk": state["flow_ok"]},
    )

    labels = [
        ("Configuration", state["mapper_ok"]),
        ("Agent checks", state["mcp_ok"]),
        ("Connections", state["connections_ok"]),
        ("Run plan", state["plan_ok"] and state["flow_ok"]),
        ("Request edits", state["payloads_ok"]),
        ("Documentation", state["pdf_ready"]),
    ]
    cols = st.columns(len(labels))
    for col, (label, ok) in zip(cols, labels):
        col.metric(label, "READY" if ok else "NEEDS HELP")

    if state["ready"]:
        st.success("Everything required is ready. You can run preflight now.")
    else:
        st.warning("A few things still need attention. The live run remains disabled.")
        blockers = []
        if not state["mapper_ok"]: blockers.append("Some configuration values are missing or invalid — go to Configure.")
        if not state["mcp_ok"]: blockers.append("The agent's input validation has unresolved items — go to Configure.")
        if not state["connections_ok"]: blockers.append("One or more required services are not connected — go to Connect.")
        if not state["plan_ok"]: blockers.append("The existing-object skip plan is stale or invalid — go to Configure or Advanced.")
        if not state["flow_ok"]: blockers.append("The execution order/timing has an invalid dependency — use Payload / MCP / Advanced.")
        if not state["payloads_ok"]: blockers.append("A manual request edit is invalid — use Payload / MCP / Advanced.")
        if not state["pdf_ready"]: blockers.append("Your settings require API documentation — upload it in Teach Agent.")
        for b in blockers:
            st.markdown(f"- {b}")
        if st.button("Ask agent to explain these blockers", width="stretch"):
            st.session_state["review_guidance"] = ask_agent("review-blockers", {"blockers": blockers, "next_action": "Explain the first blocker and where the user should go."})
        if st.session_state.get("review_guidance"):
            st.info(st.session_state["review_guidance"].get("message", ""))

    st.subheader("Simple run summary")
    plan_summary = state["plan"]
    skip_keys = set(plan_summary.get("skipSteps") or []) if plan_summary.get("active") else set()
    flow = ExecutionFlowConfig(ROOT)
    rows = []
    for idx, key in enumerate(flow.ordered_steps(), 1):
        rows.append({
            "#": idx,
            "Task": STEP_DEFINITIONS[key]["label"],
            "Will it call the API?": "No — use existing" if key in skip_keys else "Yes",
            "Pause afterward": f"{flow.wait_after(key):g} sec",
        })
    render_table(rows)

    st.subheader("Review what the agent will send")
    st.caption(
        "This is optional. The agent generates every API request for you. "
        "You can inspect or edit any request before the live run without changing Python code."
    )

    try:
        from run_agent import Runner

        request_runner = Runner(llm_enabled=False)
        active_input_for_requests = load_json(INPUT_JSON, {})
        strict_interface_mode = bool(
            isinstance(active_input_for_requests.get("_interface_only_mode"), dict)
            and active_input_for_requests.get("_interface_only_mode", {}).get("enabled")
        )
        request_steps = request_runner.execution_flow.ordered_steps()
        request_labels = {key: STEP_DEFINITIONS[key]["label"] for key in request_steps}
        override_summary = PayloadOverrideStore(ROOT).summary()
        active_override_keys = {
            row.get("stepKey")
            for row in (override_summary.get("overrides") or [])
            if row.get("enabled")
        }

        rq1, rq2, rq3 = st.columns(3)
        rq1.metric("Generated requests", len(request_steps))
        rq2.metric("User-edited requests", len(active_override_keys))
        rq3.metric("Using existing / skipped", len(skip_keys))

        with st.expander("✏️ Review or edit a generated request", expanded=False):
            selected_request_label = st.selectbox(
                "What would you like to review?",
                [request_labels[key] for key in request_steps],
                key="friendly_payload_step",
            )
            selected_request_key = next(
                key for key in request_steps
                if request_labels[key] == selected_request_label
            )
            request_preview = request_runner.preview_step_request(selected_request_key)
            request_kind = request_preview.get("requestKind") or "payload"
            generated_request = (
                request_preview.get("generatedParams")
                if request_kind == "params"
                else request_preview.get("generatedPayload")
            ) or {}
            effective_request = (
                request_preview.get("params")
                if request_kind == "params"
                else request_preview.get("payload")
            ) or {}

            generated_safe = safe_request_for_ui(generated_request)
            effective_safe = safe_request_for_ui(effective_request)
            existing_override = request_preview.get("override") or {}
            current_changes = json_change_paths(generated_safe, effective_safe)
            will_skip = request_runner.execution_plan.is_skipped(selected_request_key)
            # Agent interface-only proposal mode never removes HUMAN edit authority.
            # Human users may edit any existing canonical request value before LIVE.
            frozen_by_interface_mode = False

            badge = (
                '<span class="badge-skip">USE EXISTING — API NOT CALLED</span>'
                if will_skip
                else (
                    '<span class="badge-edit">USER EDIT ACTIVE</span>'
                    if existing_override.get("applied")
                    else '<span class="badge-ok">AGENT GENERATED</span>'
                )
            )
            st.markdown(
                f"""
                <div class="request-card">
                  <div class="request-title">{selected_request_label}</div>
                  <div class="request-sub">{request_preview.get('method')} · {request_preview.get('url')}</div>
                  <div style="margin-top:10px">{badge}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Method", request_preview.get("method") or "—")
            m2.metric("Request type", request_kind.upper())
            m3.metric("Changes", len(current_changes))
            m4.metric("Run decision", "SKIP" if will_skip else "EXECUTE")

            request_tabs = st.tabs([
                "What will be sent",
                "Original generated",
                "Edit request",
            ])

            with request_tabs[0]:
                st.json(effective_safe)
                if current_changes:
                    st.caption("Changed from the generated request:")
                    for path in current_changes[:20]:
                        st.markdown(f"- `{path}`")
                    if len(current_changes) > 20:
                        st.caption(f"+ {len(current_changes) - 20} more changes")
                else:
                    st.caption("No user edits are active for this request.")

            with request_tabs[1]:
                st.json(generated_safe)
                st.caption("This is the request produced automatically from your configuration.")

            with request_tabs[2]:
                st.info(
                    "Edit only if something must differ from the agent-generated request. "
                    "OAuth profile, endpoint, HTTP method and protected headers remain controlled by the application."
                )
                if strict_interface_mode:
                    st.info(
                        "Agent interface-only proposal mode is active, but the HUMAN payload editor is independent: "
                        "you may edit any existing canonical value before LIVE. Attribute names, nesting, method, URL "
                        "and protected headers remain locked."
                    )
                editor_key = f"friendly_payload_editor_{selected_request_key}"
                edited_text = st.text_area(
                    "Request JSON",
                    value=json.dumps(effective_safe, indent=2, ensure_ascii=False),
                    height=430,
                    key=editor_key,
                )

                parsed_request = None
                try:
                    parsed_request = json.loads(edited_text)
                    if not isinstance(parsed_request, dict):
                        raise ValueError("The request must be a JSON object.")
                    st.success("JSON format looks good.")
                except Exception as exc:
                    st.error(f"Please fix the JSON before saving: {exc}")

                mode_label = st.radio(
                    "How should this edit be applied?",
                    [
                        "Replace the full generated request",
                        "Change only the fields I entered",
                    ],
                    horizontal=True,
                    key=f"friendly_payload_mode_{selected_request_key}",
                )
                override_mode = "replace" if mode_label.startswith("Replace") else "merge"
                edit_note = st.text_input(
                    "Why are you changing it? (optional)",
                    value=str(existing_override.get("note") or ""),
                    key=f"friendly_payload_note_{selected_request_key}",
                    placeholder="Example: Dev team asked to use the new HTTPS Receiver fields",
                )

                if parsed_request is not None:
                    proposed_changes = json_change_paths(generated_safe, safe_request_for_ui(parsed_request))
                    if proposed_changes:
                        st.caption(f"This HUMAN edit changes {len(proposed_changes)} field/path(s) compared with the generated request.")
                # Human editor policy: any existing canonical value may change.
                # Exact request structure is still contract-validated before save/LIVE.
                save_edit_allowed = bool(parsed_request is not None)

                pb1, pb2, pb3, pb4 = st.columns(4)
                if pb1.button(
                    "Check my edit",
                    disabled=parsed_request is None,
                    width="stretch",
                    key=f"friendly_validate_payload_{selected_request_key}",
                ):
                    payload_arg = parsed_request if request_kind == "payload" else None
                    params_arg = parsed_request if request_kind == "params" else None
                    deterministic = request_runner.pdf_kb.validate_request(
                        api_key=request_preview.get("urlKey"),
                        method=request_preview.get("method"),
                        url=request_preview.get("url"),
                        headers={
                            "x-requester-id": request_runner.requester,
                            **(request_preview.get("extraHeaders") or {}),
                        },
                        payload=payload_arg,
                        params=params_arg,
                    )
                    mcp_result = mcp.validate_api_request(
                        api_key=request_preview.get("urlKey"),
                        method=request_preview.get("method"),
                        url=request_preview.get("url"),
                        headers={
                            "x-requester-id": request_runner.requester,
                            **(request_preview.get("extraHeaders") or {}),
                        },
                        payload=payload_arg,
                        params=params_arg,
                    )
                    st.session_state[f"friendly_payload_validation_{selected_request_key}"] = {
                        "deterministic": deterministic,
                        "mcp": mcp_result,
                    }

                if pb2.button(
                    "Ask agent to review",
                    disabled=parsed_request is None,
                    width="stretch",
                    key=f"friendly_agent_payload_{selected_request_key}",
                ):
                    st.session_state[f"friendly_payload_agent_{selected_request_key}"] = ask_agent(
                        "payload-edit",
                        {
                            "message": (
                                f"Review the user's edit for {selected_request_label}. "
                                "Explain in plain language what changed and what should be checked before saving."
                            ),
                            "next_action": "Tell the user whether the edit needs validation or documentation review before saving.",
                            "requestKind": request_kind,
                            "changedPaths": json_change_paths(
                                generated_safe,
                                safe_request_for_ui(parsed_request),
                            )[:40],
                            "request": safe_request_for_ui(parsed_request),
                        },
                    )

                if pb3.button(
                    "Save this edit",
                    type="primary",
                    disabled=not save_edit_allowed,
                    width="stretch",
                    key=f"friendly_save_payload_{selected_request_key}",
                ):
                    save_override(
                        ROOT,
                        selected_request_key,
                        parsed_request,
                        request_kind=request_kind,
                        mode=override_mode,
                        note=edit_note,
                        edit_origin="USER",
                    )
                    st.session_state.pop("friendly_preflight", None)
                    st.success("Saved. This edited request will be used during the live run.")
                    st.rerun()

                if pb4.button(
                    "Restore agent-generated",
                    width="stretch",
                    key=f"friendly_reset_payload_{selected_request_key}",
                ):
                    clear_override(ROOT, selected_request_key)
                    st.session_state.pop(editor_key, None)
                    st.session_state.pop("friendly_preflight", None)
                    st.success("The user edit was removed. The agent-generated request is active again.")
                    st.rerun()

                validation_result = st.session_state.get(
                    f"friendly_payload_validation_{selected_request_key}"
                )
                if validation_result:
                    with st.expander("Check result", expanded=True):
                        st.json(validation_result)

                agent_payload_reply = st.session_state.get(
                    f"friendly_payload_agent_{selected_request_key}"
                )
                if agent_payload_reply:
                    with st.container(border=True):
                        st.markdown(f"**Agent:** {agent_payload_reply.get('message', '')}")
                        for item in agent_payload_reply.get("nextActions") or []:
                            st.markdown(f"- {item}")

            st.caption(
                "Secure values are shown only as local environment references. "
                "Client secrets are injected immediately before the live API call and are not saved in the payload editor."
            )

    except Exception as exc:
        st.warning(
            "I cannot build the request preview yet. Complete the missing configuration values first."
        )
        with st.expander("Technical detail"):
            st.code(str(exc))

    r1, r2, r3 = st.columns(3)
    if r1.button("Run safe preflight", type="primary", width="stretch"):
        proc = subprocess.run([sys.executable, "run_agent.py", "--preflight"], cwd=ROOT, text=True, capture_output=True)
        st.session_state["friendly_preflight"] = {"rc": proc.returncode, "out": proc.stdout, "err": proc.stderr}
    r2.download_button("Download my configuration", config_bundle_bytes(), file_name="hip_configuration_bundle.zip", mime="application/zip", width="stretch")
    if r3.button("Re-check connections", width="stretch"):
        proc = subprocess.run([sys.executable, "connection_check.py"], cwd=ROOT, text=True, capture_output=True)
        st.session_state["connection_check"] = load_json(REPORTS / "connection_check_latest.json", {})
        st.rerun()

    preflight = st.session_state.get("friendly_preflight")
    preflight_passed = bool(preflight and preflight.get("rc") == 0)
    if preflight:
        if preflight_passed:
            st.success("Preflight passed. The application is ready for live execution.")
        else:
            st.error("Preflight found something that must be fixed before live execution.")
        with st.expander("Preflight details — only if you need them"):
            st.code((preflight.get("out") or "") + ("\n" + preflight.get("err") if preflight.get("err") else ""))

    # Runtime-process health is separate from API readiness. Stale locks are
    # automatically healed; a genuine older run can be stopped safely from UI.
    lock_state = inspect_live_run(ROOT)
    if lock_state.get("stale"):
        cleared = clear_stale_live_run(ROOT)
        if cleared.get("cleared"):
            st.info("I found a leftover run marker from an old process and cleared it automatically.")
        lock_state = inspect_live_run(ROOT)

    run_is_active = bool(lock_state.get("active"))
    if run_is_active:
        with st.container(border=True):
            st.warning(
                "Another HIP configuration is still running. "
                f"PID {lock_state.get('pid')} • started {lock_state.get('createdAt') or 'earlier'}."
            )
            kc1, kc2 = st.columns(2)
            if kc1.button("🛑 Stop old/running configuration", type="primary", width="stretch"):
                outcome = terminate_live_run(ROOT)
                if outcome.get("stopped"):
                    st.success("The previous HIP execution was stopped and its run lock was cleared.")
                    st.session_state["hip_run_in_progress"] = False
                    st.rerun()
                else:
                    st.error(
                        "I did not terminate the process because it could not be verified as the HIP runner. "
                        f"Reason: {outcome.get('reason')}"
                    )
            if kc2.button("Refresh run status", width="stretch"):
                st.rerun()

    if "hip_run_in_progress" not in st.session_state:
        st.session_state["hip_run_in_progress"] = False

    live_ready = bool(
        state["ready"]
        and preflight_passed
        and not run_is_active
        and not st.session_state["hip_run_in_progress"]
    )

    run_clicked = st.button(
        "🚀 Run the live HIP configuration",
        type="primary",
        disabled=not live_ready,
        width="stretch",
    )
    if run_clicked:
        # Re-check immediately before launching so a stale lock can never be the
        # reason this run fails.
        clear_stale_live_run(ROOT)
        st.session_state["hip_run_in_progress"] = True
        try:
            with st.status("The agent is configuring HIP...", expanded=True) as status:
                proc = subprocess.run(
                    [sys.executable, "run_agent.py"],
                    cwd=ROOT,
                    text=True,
                    capture_output=True,
                )
                combined_output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
                if proc.returncode == 0:
                    status.update(label="Configuration completed", state="complete")
                    st.success("The live configuration completed successfully.")
                elif "genuinely still running" in combined_output.lower() or "already running" in combined_output.lower():
                    status.update(label="Another run was detected", state="error")
                    st.warning(
                        "Another verified HIP runner owns the execution lock. "
                        "Use 'Stop old/running configuration' above, then retry."
                    )
                else:
                    status.update(label="Configuration stopped at a blocking API step", state="error")
                    st.error(
                        "The agent stopped because an API/configuration step needs attention. "
                        "The report contains the complete request, response and agent diagnosis."
                    )
                with st.expander("Execution details"):
                    st.code(combined_output)
        finally:
            st.session_state["hip_run_in_progress"] = False

        report = latest_report()
        if report and report.exists():
            st.download_button("Download the final report", report.read_bytes(), file_name=report.name, mime="text/html", width="stretch")

    report = latest_report()
    if report and report.exists():
        st.divider()
        st.subheader("Latest report")
        st.download_button("Download latest report", report.read_bytes(), file_name=report.name, mime="text/html", width="stretch", key="friendly_latest_report")
        with st.expander("Preview report"):
            st.components.v1.html(report.read_text(encoding="utf-8"), height=760, scrolling=True)
