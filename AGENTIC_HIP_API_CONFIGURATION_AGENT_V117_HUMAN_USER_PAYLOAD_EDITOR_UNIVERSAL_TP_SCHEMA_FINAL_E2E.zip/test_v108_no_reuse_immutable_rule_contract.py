from __future__ import annotations

import copy
import json

import execution_flow
import run_agent
from report_insights import reconcile_execution_analyses


def _result(response: str) -> run_agent.Result:
    return run_agent.Result(
        1, "Rule", "Create mapping rule", "v108-test", "POST",
        "https://mock/api", "HIP", "", 500,
        "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", False, 1, "", "{}",
        response, {}, "API_BACKEND_OR_ERROR_HANDLING", "",
        "API_BACKEND_OR_ERROR_HANDLING", "", "",
    )


def test_v108_build_id_keeps_strict_live_marker():
    value = run_agent.BUILD_ID.lower()
    assert "v117" in value
    assert "strict" in value
    assert "live" in value
    assert "no-reuse" in value


def test_v108_rule_payload_exact_dev_correction_omits_runtime_fk_ids():
    runner = run_agent.Runner(llm_enabled=False)
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert "flowDefinitionId" not in payload
    assert "mapId" not in payload["actions"][0]["params"]
    assert payload["documentTypeName"]
    assert payload["documentTypeVersion"] == 1.0
    assert payload["actions"][0]["params"]["mapIdentifier"]
    assert payload["actions"][0]["params"]["mapVersion"] == "1.0"


def test_v108_rule_contract_schema_matches_runtime_exactly():
    runner = run_agent.Runner(llm_enabled=False)
    schema = json.load(open(run_agent.CODE_ROOT / "schemas" / "uhal_canonical_18_request_shapes.json", encoding="utf-8"))
    assert set(runner.rule_payload()) == set(schema["steps"]["rule"]["schema"]["keys"])


def test_v108_flow_fk_response_never_triggers_id_injection_or_retry_mutation():
    runner = run_agent.Runner(llm_enabled=False)
    r = _result(
        '{"detail":"ORA-02291: integrity constraint (SHARED.FK_MAC_RULE_FLOW_DEF) violated - parent key not found"}'
    )
    assert runner.enforce_live_id_integrity("rule", r, require_dependency_ids=False) is False
    assert r.classification == "API_BACKEND_CONTRACT_MISMATCH"
    meta = r.extracted["backendContractMismatch"]
    assert meta["constraint"] == "FK_MAC_RULE_FLOW_DEF"
    assert meta["requestContainsFlowDefinitionId"] is False
    assert meta["runtimeIdMutationPerformed"] is False
    assert runner.is_non_retryable_completion_reason(r.classification) is True


def test_v108_downstream_success_cannot_rewrite_foundation_failure():
    rows = [
        {"status_code": 500, "classification": "BACKEND_ERROR_OR_UNHANDLED_PAYLOAD", "response_preview": "create failed", "extracted": {"logicalStepKey": "account_source"}},
        {"status_code": 201, "classification": "PASS_SUCCESS", "business_success": True, "response_preview": "created", "extracted": {"logicalStepKey": "source_tp"}},
    ]
    out = reconcile_execution_analyses(rows)
    assert out[0]["verdict"] == "FAIL"
    assert out[0]["outcome"] == "API_ERROR"
    assert out[1]["verdict"] == "PASS"


def test_v108_request_fingerprint_blocks_runtime_payload_mutation():
    runner = run_agent.Runner(llm_enabled=False)
    factory = {
        "method": "POST",
        "url_key": "rule",
        "payload": runner.rule_payload(),
        "extra_headers": {},
    }
    first = runner.lock_live_request_fingerprint("rule", factory)
    assert runner.lock_live_request_fingerprint("rule", copy.deepcopy(factory)) == first
    changed = copy.deepcopy(factory)
    changed["payload"]["name"] = changed["payload"]["name"] + "_MUTATED"
    try:
        runner.lock_live_request_fingerprint("rule", changed)
    except ValueError as exc:
        assert "IMMUTABLE_LIVE_REQUEST_CHANGED" in str(exc)
    else:
        raise AssertionError("Runtime request mutation was not blocked")


def test_v108_no_reuse_mode_is_default_and_map_id_is_not_preseeded():
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.no_reuse_live_mode is True
    assert runner.runtime_state["map_id"] is None
    assert runner.map_id() == 0


def test_v108_foundation_calls_remain_soft_for_tp_but_their_results_stay_independent():
    assert execution_flow.STEP_DEFINITIONS["partner_target"]["dependencies"] == []
    assert execution_flow.STEP_DEFINITIONS["source_tp"]["dependencies"] == ["doctype_source"]
    assert execution_flow.STEP_DEFINITIONS["target_tp"]["dependencies"] == ["doctype_target"]


def test_v108_dev_endpoint_correction_uses_hip_config_service_for_rule():
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.build_url("rule") == "https://apigtwtst.us.dell.com/hip-config-service/api/rule"
    assert "/hip-partners/" in runner.build_url("account")
    assert "/hip-systems/" in runner.build_url("system")
