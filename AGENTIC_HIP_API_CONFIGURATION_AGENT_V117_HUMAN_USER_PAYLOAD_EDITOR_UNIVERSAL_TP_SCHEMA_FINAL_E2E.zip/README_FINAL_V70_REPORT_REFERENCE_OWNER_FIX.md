# V70 — Customer Intake Report Reference-Owner Fix

- Corrects the intake report attribution of DUNS `12345666`.
- `12345666` belongs to the HIP partner object `dce-test-partner`; it is **not U-HAUL's DUNS**.
- U-HAUL remains the integration/customer context for the packaged reference flow.
- The report's generic comparison column is now **Reference example**, not **U-HAUL example**.
- Partner-owned identifiers show an explicit **Owner/context** field.
- `uhalReference` now stores the reference partner as a nested `partnerReference` object with owner, identifier type and value.
- No API payload behavior is changed by this report-only semantic correction.
