# V109 Final — Governed Skills + Expert Provenance + Context Budgeting

**Build ID:** `2026-08-30-agentic-hip-v109-business-final-strict-live-no-reuse-immutable-api-governed-skills-context-budget-deterministic-vetting`

V109 keeps all V108 no-reuse and immutable-request protections and strengthens the AI-agent layer using five production rules.

1. **The description is the trigger.** Skills are declarative `skills/*.skill.json` manifests. Each description starts with `Use when ...`; a deterministic router matches the task intent/mode to that description before AutoGen runs. Ambiguous or unmatched routing fails closed.
2. **Built from real expertise.** Every skill declares the approved project sources it is based on. Those files must exist and their SHA-256 hashes are combined into an `expertiseDigest` recorded with execution metadata.
3. **Spend context wisely.** The LLM receives only skill-approved task fields. Secret-like keys are redacted, unrelated/raw payload fields are excluded, and each skill has a hard context-character budget plus a context digest.
4. **Use deterministic scripts.** Validation, request construction, dependency scheduling, and HIP execution remain deterministic Python/application logic. The LLM does not construct requests. The skill's `deterministicEntrypoint` is an allowlisted identifier, never a dynamically imported user path.
5. **Vet a skill before it runs.** Startup preflight vets all manifests. Each LIVE AutoGen job selects and vets its skill again *before* the Dell AIA model client is created. Invalid schema, arbitrary entrypoints/tools, missing expertise sources, unsafe paths, or weak descriptions block execution.

## V108 protections retained

- Every applicable canonical LIVE API is executed and must produce its own evidence.
- Cross-step `EXISTING_REUSED` inference is forbidden.
- Standalone Mapping Rule omits `documentTypeId`, `actions.params.mapId`, and `flowDefinitionId`.
- Runtime request fingerprinting blocks payload/query/endpoint mutation between retries.
- MAP fallback payload mutation and Flow-name auto-rename are disabled.
- The default deployment group is `hip-automation`.

## Deterministic skill preflight

Run:

```bat
python VET_AGENT_SKILLS.py
```

Normal `SETUP_AGENTIC_HIP.bat` and `RUN_AGENTIC_HIP.bat` also invoke `runtime_preflight.py`, which now requires the governed-skill vetting check to pass.

## Boundary

Skill governance improves routing, provenance, context efficiency, and execution safety. It cannot make an unavailable Dell upstream service succeed. Authenticated Dell/HIP network, OAuth, service availability, and backend contract behavior remain external runtime dependencies and are reported truthfully.
