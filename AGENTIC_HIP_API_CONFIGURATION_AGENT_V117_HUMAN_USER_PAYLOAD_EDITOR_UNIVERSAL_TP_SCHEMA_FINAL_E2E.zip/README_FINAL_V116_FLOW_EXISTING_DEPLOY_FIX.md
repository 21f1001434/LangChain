# V116 — Flow EXISTING → Deploy Progression Fix

## Issue from latest LIVE run
Flow Orchestration Create was executed and HIP returned HTTP 400 with explicit current-LIVE evidence that the requested Flow name already exists. The report correctly rendered PASS / EXISTING, but the dependency engine still treated `flow_create` as unresolved under the old no-reuse special case. Flow Deploy and Flow Deployment History were therefore incorrectly skipped.

## Fix
V116 distinguishes historical reuse from explicit current-run EXISTING evidence. Strict LIVE still executes Flow Create. When that exact executed API response says the canonical Flow already exists, the response satisfies `flow_create`, allowing Flow Deploy to execute with the same canonical Flow name/version. No historical Flow ID is loaded or injected.

`Flow Name already exists` is also no longer labeled `FLOW_NAME_INVALID`. Genuine length/character/format validation failures remain terminal.

## Preserved protections
- Rule reference in Flow remains name + version only, no ruleId.
- Mapping Rule remains free of documentTypeId, flowDefinitionId and mapId.
- No skipped create API based on historical existence.
- No EXISTING_REUSED inference from another API.
- No post-error Flow rename.
- Immutable request fingerprinting remains enforced.
- Account/Partner/System canonical APIs remain executable.
- Generic <=40-character Flow-name normalization remains pre-LIVE.

## Dependency semantics
`Flow Create SUCCESS` → Deploy allowed.
`Flow Create EXISTING from its own executed HIP response` → Deploy allowed.
`Flow Create malformed/auth/backend/true invalid-name failure` → Deploy blocked.

