# MCP Tool Catalog — HIP Agentic Application Studio v11

Build: `2026-08-11-partner-payload-values-v12`

MCP is the control-plane/tool boundary for deterministic work that should not be left to free-form LLM reasoning. The application has **18 MCP tools** spanning the complete configuration lifecycle.

## 1. Input and mapping

| Tool | Purpose |
|---|---|
| `validate_uhal_input` | Validate the canonical HIP configuration input and required business structure. |
| `get_mapping_for_step` | Return exact input → API payload lineage for a logical execution step. |
| `suggest_missing_values` | Suggest safe, non-secret defaults and surface unresolved questions. |
| `analyze_new_input` | Discover arbitrary customer JSON structure/aliases. |
| `prepare_canonical_input` | Convert arbitrary input into the canonical HIP configuration shape. |

## 2. Interface and contract intelligence

| Tool | Purpose |
|---|---|
| `list_interface_profiles` | List SFTP, FTP, HTTPS, HTTPS-AS2 and registered custom interface profiles. |
| `plan_interface_configuration` | Build an interface-aware proposal, questions, critic result, impact analysis and execution recommendation. |
| `get_api_contract_summary` | Return the verified/PDF-enriched contract for a specific HIP API. |

## 3. Payload safety and validation

| Tool | Purpose |
|---|---|
| `validate_api_request` | Validate method, URL, required headers, payload/query fields and known contracts. |
| `validate_payload_override` | Critic for HUMAN-user-edited payloads; enforces secret handling and canonical contract structure. Agent interface-only proposal restrictions do not limit the human value editor. |

## 4. Execution governance

| Tool | Purpose |
|---|---|
| `validate_execution_policy` | Validate execute/skip plan, dependency ordering, waits, payload overrides and live-run health. |
| `assess_execution_readiness` | Supervisor that combines input, interface, execution-plan and policy readiness before live execution. |

## 5. Response and runtime state

| Tool | Purpose |
|---|---|
| `interpret_api_response` | Apply semantic response checks; HTTP 2xx alone is not considered success. |
| `resolve_response_ids` | Extract runtime Document Type / Map / Rule / Flow IDs and related metadata from API responses. |

## 6. User / Dev changes

| Tool | Purpose |
|---|---|
| `propose_change_patch` | Convert a user/Dev request into an approval-gated configuration patch. |
| `apply_change_patch` | Apply only an explicitly approved patch. |

## 7. Knowledge and learning

| Tool | Purpose |
|---|---|
| `query_knowledge_graph` | Query interface, mapping, dependency, change and API-result knowledge. |
| `agentq_memory_status` | Surface trajectory memory and ranked prior patch candidates. |

## Runtime modes

The package pins the stable MCP Python SDK line:

```text
mcp>=1.28,<2
```

Normal installation enables the stdio/FastMCP protocol server. The project also keeps the same tool functions available as a local-function fallback when `MCP_REQUIRED=false`; this protects the demo from an SDK/environment issue while preserving identical validation logic.

For strict protocol operation:

```env
MCP_ENABLED=true
MCP_REQUIRED=true
MCP_VALIDATE_EACH_REQUEST=true
```

Then the runner stops before live HIP calls if MCP protocol/tool invocation is unavailable.

## CLI checks

```powershell
python run_agent.py --mcp-status
python run_agent.py --mcp-self-test
python run_agent.py --mcp-contract tp_validate
```

`--mcp-self-test` exercises interface catalog, canonical input validation, execution policy, readiness supervisor, interface planning, Knowledge Graph and AgentQ status without calling live Dell APIs.
