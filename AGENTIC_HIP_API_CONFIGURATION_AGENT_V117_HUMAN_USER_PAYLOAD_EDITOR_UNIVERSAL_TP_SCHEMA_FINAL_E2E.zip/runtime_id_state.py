from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict

_SAFE_KEYS = {
    "source_document_type_id",
    "target_document_type_id",
    "map_id",
    "rule_id",
    "flow_id",
    "flow_version",
    "source_tp_name",
    "target_tp_name",
}


def input_sha256(workspace: Path) -> str:
    path = Path(workspace) / "input.json"
    if not path.exists():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def state_path(workspace: Path) -> Path:
    return Path(workspace) / "reports" / "live_runtime_ids_latest.json"


def load_runtime_ids(workspace: Path) -> Dict[str, Any]:
    """Load only IDs captured for the exact current input.json.

    This state is intentionally local to a configuration workspace and contains
    no OAuth secrets. Changing/rebuilding input.json invalidates it automatically.
    """
    path = state_path(workspace)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if str(data.get("inputSha256") or "") != input_sha256(workspace):
        return {}
    values = data.get("runtimeIds") if isinstance(data.get("runtimeIds"), dict) else {}
    return {k: v for k, v in values.items() if k in _SAFE_KEYS and v not in (None, "")}


def save_runtime_ids(workspace: Path, runtime_ids: Dict[str, Any]) -> Path:
    reports = Path(workspace) / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    path = state_path(workspace)
    payload = {
        "version": 1,
        "inputSha256": input_sha256(workspace),
        "runtimeIds": {k: v for k, v in dict(runtime_ids or {}).items() if k in _SAFE_KEYS and v not in (None, "")},
        "note": "HIP-owned runtime IDs captured from LIVE responses for this exact input.json. No credentials are stored.",
    }
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(reports))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False, default=str)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
        except OSError:
            pass
    return path
