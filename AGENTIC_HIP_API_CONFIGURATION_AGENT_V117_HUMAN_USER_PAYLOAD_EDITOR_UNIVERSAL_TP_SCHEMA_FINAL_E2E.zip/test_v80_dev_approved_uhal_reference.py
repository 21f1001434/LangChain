from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

import webapp.backend.app.main as main_module
from webapp.backend.app.parallel_manager import ParallelManager
from webapp.backend.app.storage import JsonStore


def _use_temp_runtime(monkeypatch, tmp_path):
    store = JsonStore(tmp_path / "runtime")
    manager = ParallelManager(store)
    monkeypatch.setattr(main_module, "STORE", store)
    monkeypatch.setattr(main_module, "PARALLEL", manager)
    return store, manager


def test_v80_uhal_is_first_immutable_dev_approved_configuration(monkeypatch, tmp_path):
    store, _manager = _use_temp_runtime(monkeypatch, tmp_path)
    rows = main_module.list_configurations()
    assert rows
    uhal = rows[0]
    assert uhal["managed_reference_source"] == "reference:uhal"
    assert uhal["approved_reference"] is True
    assert uhal["immutable_reference"] is True
    assert uhal["reference_approval_status"] == "DEV_APPROVED"
    assert uhal["test_ready"] is True
    assert uhal["status"] == "DEV_APPROVED"
    assert uhal["questions"] == []
    assert uhal["validation"]["ok"] is True
    assert uhal["validation"]["requests"]["validCount"] == 18
    assert uhal["validation"]["requests"]["total"] == 18
    assert (Path(uhal["workspace"]) / "input.json").exists()
    assert store.get_configuration(uhal["id"])["status"] == "DEV_APPROVED"


def test_v80_reference_mutations_are_rejected_but_clone_is_editable(monkeypatch, tmp_path):
    store, _manager = _use_temp_runtime(monkeypatch, tmp_path)
    client = TestClient(main_module.app)
    uhal = main_module.list_configurations()[0]
    uid = uhal["id"]

    patch = client.patch(f"/api/configurations/{uid}", json={"name": "should not change"})
    assert patch.status_code == 409
    assert "Create from U-HAUL" in patch.text or "Clone" in patch.text

    override = client.put(
        f"/api/configurations/{uid}/payload-overrides/account_source",
        headers={"X-HIP-User-Action":"payload-value-edit-v1","X-HIP-Actor":"Human User"},
        json={"mode":"merge", "value":{"description":"should-not-save"}},
    )
    assert override.status_code == 409

    deleted = client.delete(f"/api/configurations/{uid}")
    assert deleted.status_code == 409

    validated = client.post(f"/api/configurations/{uid}/validate")
    assert validated.status_code == 200
    v = validated.json()
    assert v["ok"] is True
    assert v["approval"]["status"] == "DEV_APPROVED"
    assert v["requests"]["validCount"] == v["requests"]["total"] == 18

    cloned = client.post(f"/api/configurations/{uid}/clone", json={"name":"Editable customer from U-HAUL"})
    assert cloned.status_code == 200
    clone = cloned.json()
    assert clone.get("approved_reference") is not True
    assert clone["cloned_from_approved_reference"] is True
    assert clone["starter_source"] == "reference:uhal"
    assert clone["status"] == "STARTER_READY"

    changed = client.patch(f"/api/configurations/{clone['id']}", json={"name":"Editable customer changed"})
    assert changed.status_code == 200
    assert changed.json()["name"] == "Editable customer changed"


def test_v80_runtime_validator_cannot_downgrade_dev_approval(monkeypatch, tmp_path):
    _store, _manager = _use_temp_runtime(monkeypatch, tmp_path)
    monkeypatch.setattr(
        main_module,
        "validate_configuration",
        lambda _workspace: {"ok": False, "requests": {"ok": False, "validCount": 0, "total": 18, "blockedCount": 18}},
    )
    client = TestClient(main_module.app)
    uhal = main_module.list_configurations()[0]
    response = client.post(f"/api/configurations/{uhal['id']}/validate")
    assert response.status_code == 200
    result = response.json()
    assert result["ok"] is True
    assert result["approval"]["status"] == "DEV_APPROVED"
    assert result["requests"]["validCount"] == result["requests"]["total"] == 18

    persisted = main_module.STORE.get_configuration(uhal["id"])
    assert persisted["status"] == "DEV_APPROVED"
    assert persisted["validation"]["ok"] is True


def test_v80_parallel_sources_have_one_approved_uhal_and_hide_stale_copy(monkeypatch, tmp_path):
    store, _manager = _use_temp_runtime(monkeypatch, tmp_path)
    stale = store.create_configuration({
        "name":"U-HAUL stale blocked copy", "customer":"U-HAUL", "direction":"Outbound",
        "transaction_code":"856", "flow_type":"Translation",
    })
    (Path(stale["workspace"]) / "input.json").write_text(
        (main_module.LEGACY_ROOT / "input.json").read_text(encoding="utf-8"), encoding="utf-8"
    )
    store.update_configuration(stale["id"], {"status":"NEEDS_INPUT", "questions":[{"id":"stale","informational":False}]})

    rows = main_module.parallel_sources()
    uhal_rows = [r for r in rows if "".join(ch for ch in str(r.get("customer") or "").upper() if ch.isalnum()) == "UHAUL"]
    assert len(uhal_rows) == 1
    uhal = uhal_rows[0]
    assert uhal["sourceId"] == "reference:uhal"
    assert uhal["sourceKind"] == "reference"
    assert uhal["approvedReference"] is True
    assert uhal["immutableReference"] is True
    assert uhal["approvalStatus"] == "DEV_APPROVED"
    assert uhal["validated"] is True
    assert uhal["testReady"] is True
    assert uhal["validCount"] == uhal["totalContracts"] == 18
    assert uhal["repairConfigurationId"] == ""
    assert uhal["blockerCount"] == 0


def test_v80_intentional_uhal_clone_remains_visible_as_customer_configuration(monkeypatch, tmp_path):
    _store, _manager = _use_temp_runtime(monkeypatch, tmp_path)
    client = TestClient(main_module.app)
    uhal = main_module.list_configurations()[0]
    clone = client.post(f"/api/configurations/{uhal['id']}/clone", json={"name":"Customer A from U-HAUL"}).json()
    assert clone["cloned_from_approved_reference"] is True
    # The original and the intentional clone are distinct lifecycle objects.
    configs = main_module.list_configurations()
    ids = {row["id"] for row in configs}
    assert uhal["id"] in ids
    assert clone["id"] in ids
    source = next(row for row in configs if row["id"] == clone["id"])
    assert source.get("approved_reference") is not True
    assert source.get("status") == "STARTER_READY"


def test_v80_frontend_explicitly_separates_approval_from_runtime():
    root = Path(__file__).resolve().parent
    workspace = (root / "webapp/frontend/src/pages/WorkspacePage.tsx").read_text(encoding="utf-8")
    builder = (root / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    testing = (root / "webapp/frontend/src/pages/ApiTestingPage.tsx").read_text(encoding="utf-8")
    parallel = (root / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    flow = (root / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")

    for content in (workspace, builder, testing, parallel, flow):
        assert "DEV APPROVED" in content
    assert "Create from U-HAUL" in workspace
    assert "not editable" in builder
    assert "Runtime" in testing or "runtime" in testing
    assert "RUNTIME PRE-LIVE" in parallel
    assert "Fix configuration" in flow  # retained for editable customer configurations
