from __future__ import annotations

import html
import io
import json
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


def _scalar(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def flatten_json(value: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    """Losslessly flatten dict/list config into dotted paths + list indexes."""
    out: List[Tuple[str, Any]] = []
    if isinstance(value, dict):
        for k, v in value.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            out.extend(flatten_json(v, p))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            out.extend(flatten_json(v, f"{prefix}[{i}]"))
    else:
        out.append((prefix, value))
    return out


def _relative_rows(section: Any) -> List[Tuple[str, Any]]:
    return flatten_json(section, "") if section is not None else []


def build_profile_runner_manual_bytes(config: Dict[str, Any]) -> bytes:
    """Generate the Profile Runner Ready Configuration Manual used by this project.

    Sheet names intentionally match the uploaded LEGRAND/ATEA v2 examples:
      Summary, Data_Map, Source_Doc_Type, Target_Doc_Type, Rule, Source_TP,
      Target_TP, Business_Flow, Review_Overrides, Full_JSON_Flattened.
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    except ImportError as exc:
        raise RuntimeError("openpyxl is required to generate the Configuration Manual") from exc

    wb = Workbook()
    default = wb.active
    wb.remove(default)

    navy = "0B2E59"; blue = "1261A0"; pale = "EAF2F8"; green = "E8F5E9"; amber = "FFF3CD"; white = "FFFFFF"; gray = "667085"
    thin = Side(style="thin", color="D0D5DD")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    def setup(ws, title: str, width_a: int = 55, width_b: int = 90):
        ws.sheet_view.showGridLines = False
        ws.freeze_panes = "A6"
        ws.column_dimensions["A"].width = width_a
        ws.column_dimensions["B"].width = width_b
        ws.merge_cells("A1:B1")
        ws["A1"] = title
        ws["A1"].font = Font(name="Aptos Display", size=16, bold=True, color=white)
        ws["A1"].fill = PatternFill("solid", fgColor=navy)
        ws["A1"].alignment = Alignment(vertical="center")
        ws.row_dimensions[1].height = 28
        ws.merge_cells("A4:B4")
        ws["A4"] = title
        ws["A4"].font = Font(bold=True, color=white)
        ws["A4"].fill = PatternFill("solid", fgColor=blue)
        ws["A5"] = "Field Path"; ws["B5"] = "Final Value"
        for c in (ws["A5"], ws["B5"]):
            c.font = Font(bold=True, color=white); c.fill = PatternFill("solid", fgColor=navy); c.border = border

    def add_section_sheet(name: str, title: str, section: Any):
        ws = wb.create_sheet(name)
        setup(ws, title)
        r = 6
        for path, value in _relative_rows(section):
            ws.cell(r, 1, path)
            ws.cell(r, 2, _scalar(value))
            for c in range(1, 3):
                cell = ws.cell(r, c); cell.border = border; cell.alignment = Alignment(vertical="top", wrap_text=True)
                if r % 2 == 0: cell.fill = PatternFill("solid", fgColor="F8FAFC")
            r += 1
        if r == 6:
            ws.cell(r, 1, "_note"); ws.cell(r, 2, "Not applicable for this flow")
        return ws

    objects = config.get("objects", {}) if isinstance(config.get("objects"), dict) else {}
    src_tp = objects.get("source_transport_profile", {})
    tgt_tp = objects.get("target_transport_profile", {})
    src_tp0 = src_tp[0] if isinstance(src_tp, list) and src_tp else src_tp if isinstance(src_tp, dict) else {}
    tgt_tp0 = tgt_tp[0] if isinstance(tgt_tp, list) and tgt_tp else tgt_tp if isinstance(tgt_tp, dict) else {}
    bf = objects.get("biz_flow", {}) if isinstance(objects.get("biz_flow"), dict) else {}

    # Summary
    ws = wb.create_sheet("Summary")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 48; ws.column_dimensions["B"].width = 90; ws.column_dimensions["C"].width = 22; ws.column_dimensions["D"].width = 20
    ws.merge_cells("A1:D1")
    customer = _scalar(config.get("customer")) or "CUSTOMER"
    ws["A1"] = f"{customer} - Generated Configuration Manual (Profile Runner Ready)"
    ws["A1"].font = Font(name="Aptos Display", size=18, bold=True, color=white); ws["A1"].fill = PatternFill("solid", fgColor=navy)
    ws.merge_cells("A2:D2"); ws["A2"] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}"; ws["A2"].font = Font(italic=True, color=gray)
    ws.merge_cells("A5:D5"); ws["A5"] = "Profile Details"; ws["A5"].font = Font(bold=True, color=white); ws["A5"].fill = PatternFill("solid", fgColor=blue)
    ws["A6"]="Field"; ws["B6"]="Value"
    for c in ws[6][:2]: c.font=Font(bold=True,color=white); c.fill=PatternFill("solid",fgColor=navy); c.border=border
    details = [
        ("Profile Name", config.get("profile_name", "")), ("Customer", config.get("customer", "")),
        ("Folder", config.get("folder", "")), ("Transaction Standard", config.get("tx_standard", "")),
        ("Transaction Code", config.get("tx_code", "")), ("Transaction Name", config.get("tx_name", "")),
        ("Source Format", config.get("source_format", "")), ("Direction", config.get("direction", "")),
        ("Flow Type", config.get("flow_type", "")), ("Requires Data Map", config.get("requires_data_map", False)),
        ("Deployment Group - Source", src_tp0.get("deployment_group", "")),
        ("Deployment Group - Target", tgt_tp0.get("deployment_group", "")),
    ]
    for i,(k,v) in enumerate(details,7):
        ws.cell(i,1,k); ws.cell(i,2,_scalar(v)); ws.cell(i,1).border=border; ws.cell(i,2).border=border
        if i % 2 == 1:
            ws.cell(i,1).fill=PatternFill("solid",fgColor="F8FAFC"); ws.cell(i,2).fill=PatternFill("solid",fgColor="F8FAFC")
    r=21
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); ws.cell(r,1,"Harish Feedback Fields"); ws.cell(r,1).font=Font(bold=True,color=white); ws.cell(r,1).fill=PatternFill("solid",fgColor=blue)
    r+=1
    for c,val in enumerate(["Field","Value","Requirement","Status"],1):
        ws.cell(r,c,val); ws.cell(r,c).font=Font(bold=True,color=white); ws.cell(r,c).fill=PatternFill("solid",fgColor=navy); ws.cell(r,c).border=border
    review = [
        ("Source Transport Profile document_type", src_tp0.get("document_type", "")),
        ("Target Transport Profile document_type", tgt_tp0.get("document_type", "")),
        ("Business Flow configure_source", bf.get("configure_source", {})),
        ("Business Flow configure_targets", bf.get("configure_targets", {})),
    ]
    for field,val in review:
        r+=1; ws.cell(r,1,field); ws.cell(r,2,_scalar(val)); ws.cell(r,3,"Required"); ws.cell(r,4,"Added" if _scalar(val) else "Review")
        for c in range(1,5): ws.cell(r,c).border=border; ws.cell(r,c).alignment=Alignment(wrap_text=True,vertical="top")
        ws.cell(r,4).fill=PatternFill("solid",fgColor=green if _scalar(val) else amber)

    add_section_sheet("Data_Map", "Data Map", objects.get("data_map", {}))
    add_section_sheet("Source_Doc_Type", "Source Document Type", objects.get("source_document_type", {}))
    add_section_sheet("Target_Doc_Type", "Target Document Type", objects.get("target_document_type", {}))
    add_section_sheet("Rule", "Rule Configuration", objects.get("rule", {}))
    add_section_sheet("Source_TP", "Source Transport Profile", objects.get("source_transport_profile", {}))
    add_section_sheet("Target_TP", "Target Transport Profile", objects.get("target_transport_profile", {}))
    add_section_sheet("Business_Flow", "Business Flow", objects.get("biz_flow", {}))

    # User override matrix, intentionally editable.
    ws = wb.create_sheet("Review_Overrides")
    ws.sheet_view.showGridLines = False; ws.freeze_panes="A6"
    widths=[58,62,42,62,22,20,45]
    for i,w in enumerate(widths,1): ws.column_dimensions[chr(64+i)].width=w
    ws.merge_cells("A1:G1"); ws["A1"]="User Review / Override Matrix"; ws["A1"].font=Font(size=16,bold=True,color=white); ws["A1"].fill=PatternFill("solid",fgColor=navy)
    ws.merge_cells("A4:G4"); ws["A4"]="Auto Value → User Override → Final Value"; ws["A4"].font=Font(bold=True,color=white); ws["A4"].fill=PatternFill("solid",fgColor=blue)
    headers=["Field Path","Auto Value","User Override","Final Value","Source Type","Review Required","Reviewer Notes"]
    for c,h in enumerate(headers,1): ws.cell(5,c,h); ws.cell(5,c).font=Font(bold=True,color=white); ws.cell(5,c).fill=PatternFill("solid",fgColor=navy); ws.cell(5,c).border=border
    flat = [(p,v) for p,v in flatten_json(config) if not p.startswith("_agent")]
    for r,(pth,val) in enumerate(flat,6):
        sval=_scalar(val); source="LLM_GAP_FILL" if pth.startswith("extracted.") and config.get("_agent",{}).get("llm_used") else "LOGIC_BUILT"
        review_required="Yes" if (not sval or "credential" in pth.lower() or "secret" in pth.lower()) else "No"
        vals=[pth,sval,"",sval,source,review_required,""]
        for c,v in enumerate(vals,1):
            ws.cell(r,c,v); ws.cell(r,c).border=border; ws.cell(r,c).alignment=Alignment(wrap_text=True,vertical="top")
        ws.cell(r,3).fill=PatternFill("solid",fgColor=amber); ws.cell(r,4).fill=PatternFill("solid",fgColor=green)

    # Lossless flattened canonical config. Do not include runtime AIA diagnostics;
    # this workbook is configuration, not an auth/session dump.
    ws = wb.create_sheet("Full_JSON_Flattened")
    setup(ws,"Full input.json Flattened")
    canonical = {k:v for k,v in config.items() if k != "_agent"}
    for r,(pth,val) in enumerate(flatten_json(canonical),6):
        ws.cell(r,1,pth); ws.cell(r,2,_scalar(val))
        for c in range(1,3): ws.cell(r,c).border=border; ws.cell(r,c).alignment=Alignment(wrap_text=True,vertical="top")

    out=io.BytesIO(); wb.save(out); return out.getvalue()


def build_audit_report_html(config: Dict[str, Any], source_files: Iterable[str] = ()) -> str:
    agent = config.get("_agent", {}) if isinstance(config.get("_agent"), dict) else {}
    missing = config.get("missing_fields", []) if isinstance(config.get("missing_fields"), list) else []
    files = list(source_files)
    def e(v: Any) -> str: return html.escape(_scalar(v))
    rows = "".join(f"<tr><td>{e(p)}</td><td>{e(v)}</td></tr>" for p,v in flatten_json({k:v for k,v in config.items() if k not in {"objects","_agent"}}))
    file_html = "".join(f"<li>{e(x)}</li>" for x in files) or "<li>No file manifest supplied</li>"
    missing_html = "".join(f"<li>{e(x)}</li>" for x in missing) or "<li>None reported by builder</li>"
    status = "Dell AIA used" if agent.get("llm_used") else ("Dell AIA available; deterministic evidence sufficient" if agent.get("ready") else "Deterministic-only for this run")
    json_preview = html.escape(json.dumps(config, indent=2, ensure_ascii=False))
    return f'''<!doctype html><html><head><meta charset="utf-8"><title>HIP Input Builder Audit</title>
<style>body{{font-family:Inter,Segoe UI,Arial;background:#f4f7fb;color:#172033;margin:0}}.hero{{padding:34px 42px;background:linear-gradient(135deg,#071f4d,#185adb,#08a7c5);color:#fff}}.wrap{{max-width:1200px;margin:0 auto;padding:24px}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}}.card{{background:#fff;border:1px solid #dce5f2;border-radius:14px;padding:16px;box-shadow:0 8px 18px #142b5012}}.k{{color:#66748a;font-size:12px;text-transform:uppercase;font-weight:700}}.v{{font-size:20px;font-weight:800;margin-top:6px}}table{{width:100%;border-collapse:collapse;background:#fff}}th,td{{padding:10px;border:1px solid #e1e7ef;text-align:left;vertical-align:top}}th{{background:#eef5ff}}pre{{white-space:pre-wrap;word-break:break-word;background:#0f172a;color:#d7e3ff;padding:16px;border-radius:12px;max-height:650px;overflow:auto}}.ok{{color:#0f8a5f}}.warn{{color:#b96a00}}</style></head>
<body><div class="hero"><h1>HIP Input Builder — Agent Audit Report</h1><p>Canonical configuration → input.json + Profile Runner Ready Configuration Manual.</p></div><div class="wrap">
<div class="cards"><div class="card"><div class="k">Customer</div><div class="v">{e(config.get('customer','—'))}</div></div><div class="card"><div class="k">Flow</div><div class="v">{e(config.get('flow_type','—'))}</div></div><div class="card"><div class="k">Direction</div><div class="v">{e(config.get('direction','—'))}</div></div><div class="card"><div class="k">Agent</div><div class="v">{e(status)}</div></div></div>
<h2>Dell AIA</h2><table><tr><th>Provider</th><th>Model</th><th>Mode</th><th>Ready</th><th>Invoked</th></tr><tr><td>{e(agent.get('provider','Dell AIA'))}</td><td>{e(agent.get('model','gpt-oss-120b'))}</td><td>{e(agent.get('mode',''))}</td><td>{e(agent.get('ready',False))}</td><td>{e(agent.get('llm_used',False))}</td></tr></table>
<h2>Input files</h2><ul>{file_html}</ul><h2>Unresolved / human review</h2><ul>{missing_html}</ul><h2>Top-level field audit</h2><table><tr><th>Field</th><th>Final Value</th></tr>{rows}</table><h2>Canonical input.json</h2><pre>{json_preview}</pre></div></body></html>'''


def build_bundle_bytes(config: Dict[str, Any], source_files: Iterable[str] = ()) -> bytes:
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("input.json", json.dumps(config, indent=2, ensure_ascii=False))
        zf.writestr("configuration_manual_profile_runner_ready.xlsx", build_profile_runner_manual_bytes(config))
        zf.writestr("input_builder_audit.html", build_audit_report_html(config, source_files))
    return buf.getvalue()
