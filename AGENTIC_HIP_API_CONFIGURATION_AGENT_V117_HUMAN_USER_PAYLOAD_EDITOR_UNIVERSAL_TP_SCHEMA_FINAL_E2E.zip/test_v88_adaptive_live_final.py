from pathlib import Path
ROOT=Path(__file__).resolve().parent

def test_v89_safe_capacity_and_adaptive_live_ui_are_replaced_by_direct_live():
    page=(ROOT/'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    api=(ROOT/'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    assert 'RUN LIVE EXECUTION' in page
    for retired in ('Readiness proven only','RUN ACTUAL LIVE AT PROVEN CONCURRENCY','ADAPTIVE_LIVE','What Advanced LIVE Stress proves'):
        assert retired not in page
    assert "confirm_live:true" in api

def test_v89_live_mode_keeps_payload_schema_lock_contract():
    runner=(ROOT/'run_agent.py').read_text(encoding='utf-8')
    lock=(ROOT/'payload_schema_lock.py').read_text(encoding='utf-8') if (ROOT/'payload_schema_lock.py').exists() else ''
    assert 'HIP_API_PARALLEL_ENABLED' in runner
    assert 'validate_request_contract' in runner
    assert 'CANONICAL' in lock.upper() or 'schema' in lock.lower() or 'canonical' in runner.lower()
