from __future__ import annotations

import json
import math
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class AgentQTrajectoryMemory:
    """AgentQ-inspired trajectory and preference memory.

    This implements bounded exploration, self-critique storage and preference
    ranking over successful/failed trajectories. It does not fine-tune the LLM
    or claim to reproduce the paper's DPO training pipeline.
    """

    def __init__(self, root: Path):
        self.root = Path(root)
        self.dir = self.root / "knowledge" / "agentq"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.dir / "agentq_memory.sqlite3"
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS trajectories (
                    trajectory_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_key TEXT NOT NULL,
                    state_json TEXT NOT NULL,
                    action_json TEXT NOT NULL,
                    outcome_json TEXT NOT NULL,
                    reward REAL NOT NULL,
                    critique TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS patch_candidates (
                    candidate_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_key TEXT NOT NULL,
                    patch_json TEXT NOT NULL,
                    rationale TEXT NOT NULL,
                    source TEXT NOT NULL,
                    trials INTEGER NOT NULL DEFAULT 0,
                    successes INTEGER NOT NULL DEFAULT 0,
                    total_reward REAL NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'CANDIDATE',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(task_key, patch_json)
                );
                """
            )

    def record_trajectory(self, task_key: str, state: Dict[str, Any], action: Dict[str, Any], outcome: Dict[str, Any], reward: float, critique: str = "") -> int:
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO trajectories(task_key,state_json,action_json,outcome_json,reward,critique,created_at) VALUES(?,?,?,?,?,?,?)",
                (task_key, json.dumps(state, default=str), json.dumps(action, default=str), json.dumps(outcome, default=str), float(reward), critique, utc_now()),
            )
            return int(cur.lastrowid)

    def add_patch_candidate(self, task_key: str, patch: List[Dict[str, Any]], rationale: str, source: str = "deterministic") -> int:
        patch_json = json.dumps(patch, sort_keys=True, default=str)
        now = utc_now()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO patch_candidates(task_key,patch_json,rationale,source,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(task_key,patch_json) DO UPDATE SET
                    rationale=excluded.rationale, source=excluded.source, updated_at=excluded.updated_at
                """,
                (task_key, patch_json, rationale, source, now, now),
            )
            row = conn.execute(
                "SELECT candidate_id FROM patch_candidates WHERE task_key=? AND patch_json=?",
                (task_key, patch_json),
            ).fetchone()
            return int(row["candidate_id"])

    def update_candidate_outcome(self, candidate_id: int, success: bool, reward: float) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                UPDATE patch_candidates SET
                    trials=trials+1,
                    successes=successes+?,
                    total_reward=total_reward+?,
                    status=CASE WHEN ? AND trials+1>=2 THEN 'PREFERRED' ELSE status END,
                    updated_at=?
                WHERE candidate_id=?
                """,
                (1 if success else 0, float(reward), 1 if success else 0, utc_now(), int(candidate_id)),
            )

    def ranked_candidates(self, task_key: str, limit: int = 10, exploration_weight: float = 1.2) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM patch_candidates WHERE task_key=? ORDER BY updated_at DESC",
                (task_key,),
            ).fetchall()
        total_trials = max(1, sum(int(row["trials"]) for row in rows))
        candidates: List[Dict[str, Any]] = []
        for row in rows:
            trials = int(row["trials"])
            average = float(row["total_reward"]) / trials if trials else 0.0
            exploration = exploration_weight * math.sqrt(math.log(total_trials + 1) / (trials + 1))
            score = average + exploration
            candidates.append({
                "candidateId": row["candidate_id"],
                "taskKey": row["task_key"],
                "patch": json.loads(row["patch_json"]),
                "rationale": row["rationale"],
                "source": row["source"],
                "trials": trials,
                "successes": int(row["successes"]),
                "averageReward": average,
                "explorationBonus": exploration,
                "agentQScore": score,
                "status": row["status"],
            })
        return sorted(candidates, key=lambda item: item["agentQScore"], reverse=True)[:limit]

    def recent_trajectories(self, task_key: str = "", limit: int = 50) -> List[Dict[str, Any]]:
        query = "SELECT * FROM trajectories"
        params: List[Any] = []
        if task_key:
            query += " WHERE task_key=?"
            params.append(task_key)
        query += " ORDER BY trajectory_id DESC LIMIT ?"
        params.append(int(limit))
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [
            {
                "trajectoryId": row["trajectory_id"],
                "taskKey": row["task_key"],
                "state": json.loads(row["state_json"]),
                "action": json.loads(row["action_json"]),
                "outcome": json.loads(row["outcome_json"]),
                "reward": row["reward"],
                "critique": row["critique"],
                "createdAt": row["created_at"],
            }
            for row in rows
        ]

    def stats(self) -> Dict[str, Any]:
        with self._connect() as conn:
            trajectory_count = conn.execute("SELECT COUNT(*) FROM trajectories").fetchone()[0]
            candidate_count = conn.execute("SELECT COUNT(*) FROM patch_candidates").fetchone()[0]
            preferred_count = conn.execute("SELECT COUNT(*) FROM patch_candidates WHERE status='PREFERRED'").fetchone()[0]
            average_reward = conn.execute("SELECT AVG(reward) FROM trajectories").fetchone()[0]
        return {
            "database": str(self.db_path),
            "trajectoryCount": trajectory_count,
            "candidateCount": candidate_count,
            "preferredCandidateCount": preferred_count,
            "averageReward": average_reward or 0.0,
            "implementation": "AgentQ-inspired trajectory preference memory; no DPO fine-tuning is performed.",
        }
