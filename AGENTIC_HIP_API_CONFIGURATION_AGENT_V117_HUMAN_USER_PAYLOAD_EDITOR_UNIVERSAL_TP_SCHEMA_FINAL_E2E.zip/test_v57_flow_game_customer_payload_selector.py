from pathlib import Path


def test_flow_game_can_materialize_approved_uhal_reference():
    from webapp.backend.app.main import (
        _UHAL_PARALLEL_SOURCE_ID,
        _materialize_flow_source,
        parallel_sources,
        STORE,
    )
    config = _materialize_flow_source(_UHAL_PARALLEL_SOURCE_ID)
    try:
        assert config["customer"] == "U-HAUL"
        assert config["direction"] == "Outbound"
        assert config["transaction_code"] == "856"
        assert config["flow_source_id"] == _UHAL_PARALLEL_SOURCE_ID
        assert config["managed_reference_source"] == _UHAL_PARALLEL_SOURCE_ID
        assert config["validation"]["ok"] is True
        assert config["input_json"]["partner_identifier_value"] == "12345666"
        workspace = Path(config["workspace"])
        assert (workspace / "input.json").is_file()
        assert (workspace / "input_files" / "UHAUL_4506868691_69D_ASN_VSHIP_20260410124029.xml").is_file()
        assert (workspace / "input_files" / "DELLCoXMLASNXX08C.xbm").is_file()
        assert (workspace / "input_files" / "Transform_DELLCoXMLASNXX08C.jar").is_file()
        uhal = [row for row in parallel_sources() if row.get("sourceId") == _UHAL_PARALLEL_SOURCE_ID]
        assert len(uhal) == 1
        assert uhal[0]["validated"] is True
    finally:
        STORE.delete_configuration(config["id"])


def test_flow_game_ui_exposes_validated_customer_payload_selector():
    root = Path(__file__).resolve().parent
    page = (root / "webapp/frontend/src/pages/FlowGamePage.tsx").read_text(encoding="utf-8")
    api = (root / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    app = (root / "webapp/frontend/src/App.tsx").read_text(encoding="utf-8")
    assert "CUSTOMER PAYLOAD" in page
    assert "Validated customer" in page
    assert "api.parallelSources()" in page
    assert "api.materializeFlowSource(sourceId)" in page
    assert "effective API payloads loaded" in page
    assert "materializeFlowSource" in api
    assert "onActive={updateActive}" in app
