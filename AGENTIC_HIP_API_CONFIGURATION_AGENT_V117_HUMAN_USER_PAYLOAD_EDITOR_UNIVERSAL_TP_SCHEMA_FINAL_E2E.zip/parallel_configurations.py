from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional

from production_guard import atomic_write_json, redact_sensitive
from runtime_payload_values import load_runtime_payload_values, save_runtime_payload_values

QUEUE_DIR = "configuration_queue"
RUNS_DIR = "parallel_runs"

_SNAPSHOT_FILES = [
    "input.json",
    "config_overrides.json",
    "payload_overrides.json",
    "api_execution_plan.json",
    "execution_flow.json",
    "scratch_flow.json",
    "interface_profiles.json",
    "request_validation_cache.json",
]
_SNAPSHOT_DIRS = ["input_files", "knowledge", "dev_approved"]



def _utf8_env(workspace: Path, **extra: str) -> Dict[str, str]:
    env = os.environ.copy()
    env["HIP_WORKSPACE_ROOT"] = str(Path(workspace).resolve())
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env.update({str(k): str(v) for k, v in extra.items()})
    return env

def _safe(value: Any, fallback: str = "CONFIG") -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip()).strip("_.-")
    return text[:80] or fallback


def _sha256(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _queue_secret_path(root: Path, job_id: str) -> Path:
    project_key = hashlib.sha256(str(Path(root).resolve()).lower().encode("utf-8")).hexdigest()[:20]
    base = Path(tempfile.gettempdir()) / "hip_parallel_queue_secrets" / project_key
    base.mkdir(parents=True, exist_ok=True)
    return base / f"{_safe(job_id, 'job')}.json"


def _capture_ephemeral_runtime_values(root: Path, job_id: str) -> bool:
    values = load_runtime_payload_values(root)
    if not values:
        return False
    path = _queue_secret_path(root, job_id)
    path.write_text(json.dumps(values, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return True


def _ephemeral_runtime_values_valid(root: Path, job_id: str, max_age_seconds: int = 4 * 60 * 60) -> bool:
    path = _queue_secret_path(root, job_id)
    if not path.exists():
        return False
    try:
        return (time.time() - path.stat().st_mtime) <= max_age_seconds
    except Exception:
        return False


def _hydrate_ephemeral_runtime_values(root: Path, job_id: str, workspace: Path) -> bool:
    path = _queue_secret_path(root, job_id)
    if not _ephemeral_runtime_values_valid(root, job_id):
        return False
    try:
        values = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(values, dict) or not values:
            return False
        save_runtime_payload_values(workspace, values, merge=False)
        return True
    except Exception:
        return False


def queue_root(root: Path) -> Path:
    path = Path(root) / QUEUE_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


def runs_root(root: Path) -> Path:
    path = Path(root) / RUNS_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


def _short_execution_root(root: Path) -> Path:
    """Short physical execution root for Windows/OneDrive path safety."""
    configured = str(os.environ.get("HIP_PARALLEL_EXEC_ROOT") or "").strip()
    base = Path(configured).expanduser() if configured else Path(tempfile.gettempdir()) / "hip_exec_legacy"
    key = hashlib.sha256(str(Path(root).resolve()).lower().encode("utf-8")).hexdigest()[:10]
    path = base / key
    path.mkdir(parents=True, exist_ok=True)
    return path


def _short_execution_workspace(root: Path, batch_id: str, job_id: str) -> Path:
    batch_key = hashlib.sha256(str(batch_id).encode("utf-8")).hexdigest()[:10]
    job_key = hashlib.sha256(str(job_id).encode("utf-8")).hexdigest()[:10]
    return _short_execution_root(root) / batch_key / job_key


def _copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


def _load_json(path: Path, default: Any = None) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except Exception:
        return {} if default is None else default


def snapshot_validated_configuration(
    root: Path,
    validation: Dict[str, Any],
    *,
    label: str = "",
) -> Dict[str, Any]:
    """Freeze the currently active *validated* configuration for later parallel execution."""
    root = Path(root).resolve()
    if not isinstance(validation, dict) or not validation.get("ok"):
        raise ValueError("Only an agent-validated configuration can be added to the parallel queue.")
    input_path = root / "input.json"
    if not input_path.exists():
        raise FileNotFoundError("input.json is missing.")
    input_data = _load_json(input_path, {})
    if not isinstance(input_data, dict):
        raise ValueError("input.json must contain an object.")

    customer = str(input_data.get("customer") or "CUSTOMER")
    flow = str(input_data.get("profile_name") or ((input_data.get("objects") or {}).get("biz_flow") or {}).get("flow_details", {}).get("business_flow_name") or "FLOW")
    job_id = "q" + uuid.uuid4().hex[:10]
    destination = queue_root(root) / job_id
    destination.mkdir(parents=True, exist_ok=False)

    for name in _SNAPSHOT_FILES:
        src = root / name
        if src.exists() and src.is_file():
            shutil.copy2(src, destination / name)
    for name in _SNAPSHOT_DIRS:
        _copy_tree(root / name, destination / name)

    runtime_values_captured = _capture_ephemeral_runtime_values(root, job_id)

    request_rows = list(((validation.get("requests") or {}).get("items") or []))
    if not request_rows:
        request_rows = list(validation.get("requestChecks") or [])
    manifest = {
        "jobId": job_id,
        "label": str(label or f"{customer} · {flow}"),
        "customer": customer,
        "flow": flow,
        "direction": input_data.get("direction"),
        "flowType": input_data.get("flow_type"),
        "createdAt": dt.datetime.now(dt.timezone.utc).isoformat(),
        "status": "READY",
        "validated": True,
        "validationOk": True,
        "inputSha256": _sha256(destination / "input.json"),
        "validation": redact_sensitive({
            "generatedAt": validation.get("generatedAt"),
            "ok": validation.get("ok"),
            "mapper": validation.get("mapper"),
            "mcpSupervisor": validation.get("mcpSupervisor"),
            "requestSummary": validation.get("requests"),
        }),
        "requestCount": len(request_rows),
        "runtimeValuesEphemeral": runtime_values_captured,
        "workspace": str(destination),
    }
    atomic_write_json(destination / "queue_manifest.json", manifest)
    return manifest


def snapshot_validated_configuration_instances(
    root: Path,
    validation: Dict[str, Any],
    count: int,
    *,
    label_prefix: str = "Parallel demo",
) -> List[Dict[str, Any]]:
    """Create N isolated queue snapshots from one already-validated active configuration."""
    instances = max(1, min(int(count), 8))
    queued: List[Dict[str, Any]] = []
    for index in range(1, instances + 1):
        manifest = snapshot_validated_configuration(
            root,
            validation,
            label=f"{label_prefix} #{index}",
        )
        manifest["demoInstance"] = index
        manifest["demoInstanceCount"] = instances
        manifest_path = Path(str(manifest.get("workspace") or "")) / "queue_manifest.json"
        if manifest_path.exists():
            stored = _load_json(manifest_path, {})
            if isinstance(stored, dict):
                stored["demoInstance"] = index
                stored["demoInstanceCount"] = instances
                stored["label"] = f"{label_prefix} #{index}"
                atomic_write_json(manifest_path, stored)
                manifest = stored
        queued.append(manifest)
    return queued


def list_queued_configurations(root: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for folder in sorted(queue_root(root).iterdir(), reverse=True):
        if not folder.is_dir():
            continue
        manifest = _load_json(folder / "queue_manifest.json", {})
        if not isinstance(manifest, dict) or not manifest:
            continue
        current_hash = _sha256(folder / "input.json")
        manifest = dict(manifest)
        manifest["workspace"] = str(folder)
        manifest["integrityOk"] = bool(current_hash and current_hash == manifest.get("inputSha256"))
        secret_required = bool(manifest.get("runtimeValuesEphemeral"))
        manifest["runtimeValuesReady"] = (not secret_required) or _ephemeral_runtime_values_valid(root, str(manifest.get("jobId") or folder.name))
        manifest["ready"] = bool(manifest.get("validated") and manifest.get("validationOk") and manifest["integrityOk"] and manifest["runtimeValuesReady"])
        rows.append(manifest)
    return rows


def delete_queued_configuration(root: Path, job_id: str) -> bool:
    target = (queue_root(root) / str(job_id)).resolve()
    if target.parent != queue_root(root).resolve() or not target.exists():
        return False
    shutil.rmtree(target)
    _queue_secret_path(root, str(job_id)).unlink(missing_ok=True)
    return True


def _prepare_run_workspace(root: Path, job: Dict[str, Any], batch_id: str) -> Path:
    source = Path(str(job.get("workspace") or "")).resolve()
    if not source.exists():
        raise FileNotFoundError(f"Queue workspace is missing: {source}")
    destination = _short_execution_workspace(root, batch_id, str(job.get("jobId") or "job"))
    if destination.exists():
        shutil.rmtree(destination, ignore_errors=True)
    destination.mkdir(parents=True, exist_ok=False)
    for name in _SNAPSHOT_FILES:
        src = source / name
        if src.exists() and src.is_file():
            shutil.copy2(src, destination / name)
    for name in _SNAPSHOT_DIRS:
        _copy_tree(source / name, destination / name)
    (destination / "payloads").mkdir(exist_ok=True)
    (destination / "reports").mkdir(exist_ok=True)
    if job.get("runtimeValuesEphemeral"):
        if not _hydrate_ephemeral_runtime_values(root, str(job.get("jobId") or ""), destination):
            raise RuntimeError("Ephemeral runtime payload values expired or are unavailable. Re-open the source configuration, re-enter the sensitive runtime values, and queue it again.")
    return destination


def _parse_json_stdout(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else {}
    except Exception:
        # Defensive fallback for tools that may print a short informational line
        # before the final JSON object.
        starts = [idx for idx, ch in enumerate(raw) if ch == "{"]
        for idx in reversed(starts):
            try:
                value = json.loads(raw[idx:])
                if isinstance(value, dict):
                    return value
            except Exception:
                continue
    return {}


def _run_final_pre_live_checks(
    root: Path,
    code_root: Path,
    workspace: Path,
    job: Dict[str, Any],
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> Dict[str, Any]:
    """Run a fresh staged-workspace validation + production preflight before LIVE.

    This is deliberately separate from queue-time validation.  A queued payload can
    become stale, runtime values can expire, or an edited effective payload can fail
    an approved business-value rule.  No mutating HIP call is started until both
    non-mutating gates pass in the exact workspace that will execute LIVE.
    """
    base_event = {
        "jobId": job.get("jobId"),
        "customer": job.get("customer"),
        "flow": job.get("flow"),
    }
    if progress_callback:
        progress_callback({**base_event, "event": "FINAL_CHECKS_STARTED", "stage": "contract-validation"})

    env = _utf8_env(workspace)
    worker = code_root / "webapp" / "backend" / "app" / "legacy_worker.py"
    validate_proc = subprocess.run(
        [sys.executable, "-u", str(worker), "validate", str(workspace)],
        cwd=str(code_root),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=300,
    )
    contract_result = _parse_json_stdout(validate_proc.stdout)
    requests = contract_result.get("requests") if isinstance(contract_result, dict) else {}
    contract_ok = bool(validate_proc.returncode == 0 and contract_result.get("ok"))
    if not contract_ok:
        details = {
            "stage": "contract-validation",
            "returnCode": validate_proc.returncode,
            "validCount": (requests or {}).get("validCount"),
            "total": (requests or {}).get("total"),
            "blocked": (requests or {}).get("blockedItems") or [],
            "stderr": (validate_proc.stderr or "")[-4000:],
        }
        atomic_write_json(workspace / "reports" / "final_pre_live_checks_latest.json", redact_sensitive({"ready": False, **details}))
        if progress_callback:
            progress_callback({**base_event, "event": "FINAL_CHECKS_BLOCKED", **redact_sensitive(details)})
        raise RuntimeError(
            "Final pre-LIVE API contract validation failed "
            f"({(requests or {}).get('validCount', 0)}/{(requests or {}).get('total', 18)} contracts ready). "
            "No LIVE HIP API call was made."
        )

    if progress_callback:
        progress_callback({**base_event, "event": "FINAL_CHECKS_PROGRESS", "stage": "production-preflight", "validCount": (requests or {}).get("validCount"), "total": (requests or {}).get("total")})

    preflight_proc = subprocess.run(
        [sys.executable, "-u", str(code_root / "run_agent.py"), "--preflight"],
        cwd=str(code_root),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=300,
    )
    preflight = _parse_json_stdout(preflight_proc.stdout)
    preflight_ok = bool(preflight_proc.returncode == 0 and preflight.get("ready"))
    evidence = {
        "ready": bool(contract_ok and preflight_ok),
        "contractValidation": {
            "ok": contract_ok,
            "validCount": (requests or {}).get("validCount"),
            "total": (requests or {}).get("total"),
            "applicableCount": (requests or {}).get("applicableCount"),
        },
        "productionPreflight": preflight,
    }
    atomic_write_json(workspace / "reports" / "final_pre_live_checks_latest.json", redact_sensitive(evidence))
    if not preflight_ok:
        if progress_callback:
            progress_callback({
                **base_event,
                "event": "FINAL_CHECKS_BLOCKED",
                "stage": "production-preflight",
                "errors": redact_sensitive(preflight.get("errors") or []),
            })
        raise RuntimeError(
            "Final production preflight failed. No LIVE HIP API call was made. "
            + json.dumps(redact_sensitive(preflight.get("errors") or []), default=str)[:3000]
        )

    if progress_callback:
        progress_callback({
            **base_event,
            "event": "FINAL_CHECKS_PASSED",
            "validCount": (requests or {}).get("validCount"),
            "total": (requests or {}).get("total"),
        })
    return evidence


def _load_step_timings(workspace: Path) -> List[Dict[str, Any]]:
    payload = _load_json(Path(workspace) / "reports" / "execution_timing_latest.json", {})
    events = payload.get("events") if isinstance(payload, dict) else []
    if not isinstance(events, list):
        return []
    rows: List[Dict[str, Any]] = []
    for event in events:
        if not isinstance(event, dict):
            continue
        rows.append({
            "stepKey": event.get("stepKey"),
            "label": event.get("label"),
            "sequence": event.get("sequence"),
            "classification": event.get("resultClassification"),
            "startedAt": event.get("startedAt"),
            "finishedAt": event.get("finishedAt"),
            "apiElapsedMs": event.get("apiElapsedMs", 0),
            "apiElapsedSeconds": event.get("apiElapsedSeconds", 0),
            "waitSeconds": event.get("actualWaitSeconds", 0),
            "totalStepSeconds": event.get("totalStepSeconds", 0),
        })
    return rows


def _run_one(
    root: Path,
    code_root: Path,
    job: Dict[str, Any],
    batch_id: str,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> Dict[str, Any]:
    started = dt.datetime.now(dt.timezone.utc)
    workspace = _prepare_run_workspace(root, job, batch_id)
    event = {"event": "STARTED", "jobId": job.get("jobId"), "customer": job.get("customer"), "flow": job.get("flow")}
    if progress_callback:
        progress_callback(dict(event))

    # Mandatory last-mile gate in the exact staged workspace.  This performs a
    # fresh 18-contract validation and production preflight before the mutating
    # runner process is even started.
    final_checks = _run_final_pre_live_checks(root, code_root, workspace, job, progress_callback)

    env = _utf8_env(
        workspace,
        HIP_PARALLEL_BATCH_ID=batch_id,
        HIP_PARALLEL_JOB_ID=str(job.get("jobId") or ""),
        HIP_LIVE_API_EXECUTION="1",
        HIP_STRICT_LIVE_PIPELINE="1",
        HIP_LIVE_AUTO_COMPLETE="1",
        HIP_LIVE_AUTO_COMPLETE_ROUNDS=str(os.environ.get("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "3") or "3"),
        HIP_STRICT_COVERAGE_ROUNDS=str(os.environ.get("HIP_STRICT_COVERAGE_ROUNDS", "3") or "3"),
        HIP_FULL_API_COVERAGE_MODE="0",
    )
    process = subprocess.Popen(
        [sys.executable, "-u", str(code_root / "run_agent.py")],
        cwd=str(code_root),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
    )
    lines: List[str] = []
    if process.stdout is not None:
        for raw in process.stdout:
            lines.append(raw.rstrip())
    rc = process.wait()
    finished = dt.datetime.now(dt.timezone.utc)
    step_timings = _load_step_timings(workspace)
    result = {
        "jobId": job.get("jobId"),
        "customer": job.get("customer"),
        "flow": job.get("flow"),
        "label": job.get("label"),
        "demoInstance": job.get("demoInstance"),
        "status": "PASS" if rc == 0 else "BLOCKED",
        "returnCode": rc,
        "workspace": str(workspace),
        "reportDirectory": str(workspace / "reports"),
        "startedAt": started.isoformat(),
        "finishedAt": finished.isoformat(),
        "elapsedSeconds": round((finished - started).total_seconds(), 3),
        "stepTimings": step_timings,
        "stepCount": len(step_timings),
        "finalPreLiveChecks": redact_sensitive(final_checks),
        "logs": "\n".join(lines),
    }
    atomic_write_json(workspace / "parallel_job_result.json", redact_sensitive(result))
    if progress_callback:
        progress_callback({k: v for k, v in result.items() if k != "logs"} | {"event": "FINISHED"})
    return result


def run_parallel_configurations(
    root: Path,
    job_ids: Iterable[str],
    *,
    max_workers: Optional[int] = None,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> Dict[str, Any]:
    """Run multiple validated configurations concurrently, one dependency-safe agent per config."""
    root = Path(root).resolve()
    code_root = Path(__file__).resolve().parent
    requested = {str(x) for x in job_ids if str(x).strip()}
    queue = {str(row.get("jobId")): row for row in list_queued_configurations(root)}
    jobs: List[Dict[str, Any]] = []
    for job_id in requested:
        job = queue.get(job_id)
        if not job:
            raise ValueError(f"Unknown queued configuration: {job_id}")
        if not job.get("ready"):
            raise ValueError(f"Configuration {job_id} is not validated/integrity-ready.")
        jobs.append(job)
    if not jobs:
        raise ValueError("Select at least one validated configuration.")

    configured_workers = int(os.getenv("HIP_PARALLEL_CONFIG_WORKERS", "3") or 3)
    workers = max_workers if max_workers is not None else configured_workers
    workers = max(1, min(int(workers), 8, len(jobs)))
    batch_id = dt.datetime.now().strftime("batch_%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
    batch_dir = runs_root(root) / batch_id
    batch_dir.mkdir(parents=True, exist_ok=True)
    started = dt.datetime.now(dt.timezone.utc)

    results: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="hip-config-agent") as executor:
        futures = {
            executor.submit(_run_one, root, code_root, job, batch_id, progress_callback): job
            for job in jobs
        }
        for future in as_completed(futures):
            job = futures[future]
            try:
                results.append(future.result())
            except Exception as exc:
                failed = {
                    "jobId": job.get("jobId"),
                    "customer": job.get("customer"),
                    "flow": job.get("flow"),
                    "status": "BLOCKED",
                    "returnCode": -1,
                    "error": f"{type(exc).__name__}: {exc}",
                }
                results.append(failed)
                if progress_callback:
                    progress_callback(dict(failed) | {"event": "FINISHED"})

    finished = dt.datetime.now(dt.timezone.utc)
    results.sort(key=lambda row: str(row.get("jobId") or ""))
    summary = {
        "batchId": batch_id,
        "mode": "PARALLEL_CONFIGURATIONS_LIVE_ONLY",
        "parallelWorkers": workers,
        "configurationCount": len(jobs),
        "passCount": sum(1 for row in results if row.get("status") == "PASS"),
        "blockedCount": sum(1 for row in results if row.get("status") != "PASS"),
        "startedAt": started.isoformat(),
        "finishedAt": finished.isoformat(),
        "elapsedSeconds": round((finished - started).total_seconds(), 3),
        "results": [{k: v for k, v in row.items() if k != "logs"} for row in results],
    }
    atomic_write_json(batch_dir / "parallel_batch_summary.json", redact_sensitive(summary))
    summary["batchDirectory"] = str(batch_dir)
    return summary
