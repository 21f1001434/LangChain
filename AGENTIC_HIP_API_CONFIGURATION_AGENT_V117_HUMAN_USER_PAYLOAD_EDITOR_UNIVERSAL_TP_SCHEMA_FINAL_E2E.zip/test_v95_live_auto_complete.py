from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from unittest.mock import patch

import run_agent
from report_insights import reconcile_execution_analyses


class _TokenResponse:
    status_code = 200
    ok = True
    text = json.dumps({"access_token": "v95.test.token"})
    url = "https://example.dell.com/oauth/token"
    headers = {"Content-Type": "application/json"}
    history = []
    def json(self):
        return {"access_token": "v95.test.token"}


class _CountingSession:
    calls = 0
    lock = threading.Lock()
    def __init__(self):
        self.trust_env = True
    def post(self, url, **kwargs):
        with self.lock:
            type(self).calls += 1
        time.sleep(0.02)
        return _TokenResponse()
    def close(self):
        return None


def _light_runner():
    runner = run_agent.Runner.__new__(run_agent.Runner)
    runner.hip_token_url = "https://example.dell.com/oauth/token"
    runner.hip_client_id = "client"
    runner.hip_client_secret = "secret"
    runner.hip_scope = ""
    runner.token_sources = {}
    return runner


def test_v95_oauth_singleflight_one_request_for_parallel_threads():
    run_agent.TOKEN_CACHE.clear()
    _CountingSession.calls = 0
    runner = _light_runner()
    values = []
    with patch.object(run_agent.requests, "Session", _CountingSession), patch.object(
        run_agent.requests.utils, "get_environ_proxies", return_value={}
    ), patch.object(run_agent, "_write_token_diagnostic_best_effort", return_value=None):
        threads = [threading.Thread(target=lambda: values.append(runner.get_token("HIP"))) for _ in range(8)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=5)
    assert len(values) == 8
    assert all(v == "v95.test.token" for v in values)
    assert _CountingSession.calls == 1


def test_v95_validation_network_failure_is_not_hidden_by_later_live_creation():
    rows = [
        {"classification":"EXECUTION_ERROR","error":"HIP OAuth network error","extracted":{"logicalStepKey":"validate_source"}},
        {"status_code":201,"classification":"PASS","business_success":True,"response_preview":"created","extracted":{"logicalStepKey":"source_tp"}},
    ]
    out = reconcile_execution_analyses(rows)
    assert out[0]["verdict"] == "FAIL"
    assert out[0]["outcome"] == "API_ERROR"
    assert out[1]["verdict"] == "PASS"


def test_v95_earlier_failed_attempt_is_recovered_by_successful_retry():
    rows = [
        {"classification":"EXECUTION_ERROR","error":"temporary network failure","extracted":{"logicalStepKey":"account_source"}},
        {"status_code":201,"classification":"PASS","business_success":True,"response_preview":"created","extracted":{"logicalStepKey":"account_source"}},
    ]
    out = reconcile_execution_analyses(rows)
    assert out[0]["verdict"] == "WARNING"
    assert out[0]["outcome"] == "RETRIED_SUCCESS"
    assert out[1]["verdict"] == "PASS"


def test_v95_react_live_button_and_backend_enable_real_auto_complete():
    root = Path(__file__).resolve().parent
    ui = (root / "webapp/frontend/src/pages/ParallelPage.tsx").read_text(encoding="utf-8")
    api = (root / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    manager = (root / "webapp/backend/app/parallel_manager.py").read_text(encoding="utf-8")
    runner = (root / "run_agent.py").read_text(encoding="utf-8")
    assert "confirm_live:true" in api
    assert 'HIP_LIVE_API_EXECUTION="1"' in manager
    assert 'HIP_LIVE_AUTO_COMPLETE="1"' in manager
    assert 'HIP_FULL_API_COVERAGE_MODE="0"' in manager
    assert "real HIP APIs" in ui
    assert "LIVE AUTO-COMPLETE" in runner
    assert '"autoCompletionRounds": completion_rounds' in runner


def test_v95_runner_retries_missing_prerequisite_and_finishes_flow(monkeypatch):
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    calls = {}

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        calls[api] = calls.get(api, 0) + 1
        if api == "Create source account" and calls[api] == 1:
            return run_agent.Result(
                seq, group, api, attempt, method, f"https://mock/{url_key}",
                str(kwargs.get("token_kind") or "HIP"), "", None,
                "EXECUTION_ERROR", False, None, "", "{}", "", {}, "", "", "",
                "temporary network failure", "retry", "temporary network failure",
            )
        return run_agent.Result(
            seq, group, api, attempt, method, f"https://mock/{url_key}",
            str(kwargs.get("token_kind") or "HIP"), "", 200,
            "PASS", True, 1, "", "{}", '{"success":true}', {}, "", "", "", "", "",
        )

    monkeypatch.setattr(runner, "call", fake_call)
    results = runner.run()
    assert runner.full_api_coverage_mode is False
    assert runner.final_state["success"] is True
    assert runner.final_state["unresolvedRequiredSteps"] == []
    # V108: downstream success cannot substitute for the Account API. The same
    # Account API is actually retried with the identical request.
    assert runner.final_state["autoCompletionRounds"]
    assert calls["Create source account"] == 2
    assert calls["Flow orchestration deploy ONLY"] == 1
    assert calls["Flow deployment history"] == 1
    assert len(results) == 19


def test_v95_oauth_endpoint_lock_serializes_parallel_holders():
    active = 0
    maximum = 0
    guard = threading.Lock()
    def worker():
        nonlocal active, maximum
        with run_agent._OAuthEndpointLock("https://example.dell.com/oauth/token"):
            with guard:
                active += 1
                maximum = max(maximum, active)
            time.sleep(0.02)
            with guard:
                active -= 1
    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=5)
    assert all(not t.is_alive() for t in threads)
    assert maximum == 1


def test_v95_explicit_runtime_dependency_mode_overrides_old_workspace_full_coverage(monkeypatch):
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    runner = run_agent.Runner(llm_enabled=False)
    assert runner.ov.get("fullApiCoverageMode") is True  # packaged U-HAUL legacy preference
    assert runner.full_api_coverage_mode is False         # React LIVE runtime wins
