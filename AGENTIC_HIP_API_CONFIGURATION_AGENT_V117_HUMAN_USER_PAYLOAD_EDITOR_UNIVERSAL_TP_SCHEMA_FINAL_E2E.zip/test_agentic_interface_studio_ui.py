from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    page = (ROOT / "legacy_pages" / "10_Agentic_Interface_Studio.py").read_text(encoding="utf-8")
    app = (ROOT / "adaptive_uhal_app.py").read_text(encoding="utf-8")
    runner = (ROOT / "run_agent.py").read_text(encoding="utf-8")

    required_page = [
        "Register another interface",
        "Upload API documentation PDF(s)",
        "Observe → Plan → Validate → Critic",
        "Affected API steps",
        "Execution strategy",
        "Safe validation",
        "Full configure",
        "Review generated API requests",
        "Run all checks",
        "Execute interface-aware HIP flow",
        "Stop old/running configuration",
        "reset_execution_flow(ROOT)",
        "Recent MCP tool activity",
    ]
    for token in required_page:
        assert token in page, token

    assert "Agentic Interface Studio" in app
    assert "studio_interface_options(ROOT)" in app
    assert "interface_type not in {\"SFTP HAFT\", \"FTP\"}" in runner
    assert "resolve_runtime_payload_placeholders" in runner

    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "dynamicInterfaceRegistry": True,
        "customInterfaceUi": True,
        "pdfContractGateUi": True,
        "agenticLifecycleUi": True,
        "executionStrategyUi": True,
        "fullConfigureRestoresSafeWaits": True,
        "mcpToolActivityUi": True,
        "genericRunner": True,
        "genericRuntimePayloadSecret": True,
    }
    path = ROOT / "examples" / "AGENTIC_INTERFACE_STUDIO_UI_VALIDATION.json"
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
