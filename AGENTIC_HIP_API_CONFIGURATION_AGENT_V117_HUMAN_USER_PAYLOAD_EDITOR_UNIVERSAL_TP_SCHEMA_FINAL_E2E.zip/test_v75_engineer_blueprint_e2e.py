from __future__ import annotations

import json
from pathlib import Path

from input_extraction_blueprint import apply_input_extraction_blueprint, BLUEPRINT_EXECUTION_REPORT
from input_builder_integration import apply_answers

ROOT = Path(__file__).resolve().parent


def _base() -> dict:
    return {
        "customer": "ACME",
        "direction": "Inbound",
        "flow_type": "translation",
        "requires_data_map": True,
        "objects": {
            "data_map": {},
            "source_document_type": {"version": "1.0"},
            "target_document_type": {"version": "1.0"},
            "rule": {},
            "source_transport_profile": {"interface_type": "SFTP HAFT"},
            "target_transport_profile": {"interface_type": "SFTP HAFT"},
            "biz_flow": {"flow_details": {}, "configure_source": {}, "configure_targets": {}, "configure_routing": {}},
        },
    }


def test_exact_file_mapping_fills_safe_blank_fields_and_persists_trace(tmp_path: Path):
    data = _base()
    data["_file_mapping"] = {"fieldMappings": [
        {"path": "tx_code", "value": "850", "sourceFile": "PO_850.edi", "rule": "X12 ST01", "confidence": "high"},
        {"path": "tx_standard", "value": "X12", "sourceFile": "PO_850.edi", "rule": "ISA/ST parser", "confidence": "high"},
        {"path": "objects.data_map.map_name", "value": "DELLCi85041EX99C", "sourceFile": "map.xbm", "rule": "XBM logicalName", "confidence": "high"},
        {"path": "objects.data_map.map_class", "value": "Transform_DELLCi85041EX99C", "sourceFile": "map.jar", "rule": "Transform_*.class", "confidence": "high"},
        {"path": "objects.data_map.map_data_file", "value": "map.jar", "sourceFile": "map.jar", "rule": "uploaded JAR", "confidence": "high"},
    ]}
    out = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP", manifest=["PO_850.edi", "map.xbm", "map.jar"], workspace=tmp_path)
    assert out["tx_code"] == "850"
    assert out["tx_standard"] == "X12"
    assert out["objects"]["data_map"]["map_name"] == "DELLCi85041EX99C"
    assert out["objects"]["data_map"]["map_class"] == "Transform_DELLCi85041EX99C"
    assert out["objects"]["data_map"]["map_data_file"] == "map.jar"
    bp = out["_input_extraction_blueprint"]
    assert bp["summary"]["extracted"] >= 5
    assert bp["fileAutoResolved"]
    report = tmp_path / "reports" / BLUEPRINT_EXECUTION_REPORT
    assert report.exists()
    saved = json.loads(report.read_text(encoding="utf-8"))
    assert saved["executionMode"] == "deterministic field-source resolution"
    assert saved["noSecretsPersisted"] is True


def test_conflicting_file_evidence_is_not_guessed():
    data = _base()
    data["_file_mapping"] = {"fieldMappings": [
        {"path": "tx_code", "value": "850", "sourceFile": "a.edi", "rule": "ST01", "confidence": "high"},
        {"path": "tx_code", "value": "856", "sourceFile": "b.edi", "rule": "ST01", "confidence": "high"},
    ]}
    out = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP")
    assert not out.get("tx_code")
    bp = out["_input_extraction_blueprint"]
    assert bp["summary"]["conflicts"] == 1
    assert bp["conflicts"][0]["path"] == "tx_code"
    row = next(x for x in bp["fields"] if x["path"] == "tx_code")
    assert row["status"] == "USER_REQUIRED"
    assert "Conflicting" in row["source"]


def test_existing_approved_value_wins_over_conflicting_or_different_file_evidence():
    data = _base()
    data["tx_code"] = "855"
    data["_file_mapping"] = {"fieldMappings": [
        {"path": "tx_code", "value": "850", "sourceFile": "a.edi", "rule": "ST01", "confidence": "high"},
    ]}
    out = apply_input_extraction_blueprint(data, source_interface="SFTP", target_interface="SFTP")
    assert out["tx_code"] == "855"


def test_human_answer_provenance_accumulates_across_multiple_answer_rounds():
    canonical = _base()
    canonical["tx_code"] = "850"
    q1 = [{"id": "q1", "path": "objects.source_transport_profile.subscription_folder", "label": "Source folder", "secret": False, "informational": False}]
    first, _ = apply_answers(ROOT, canonical, q1, {"q1": "/Inbound/850"}, "SFTP", "SFTP")
    q2 = [{"id": "q2", "path": "objects.target_transport_profile.subscription_folder", "label": "Target folder", "secret": False, "informational": False}]
    second, _ = apply_answers(ROOT, first, q2, {"q2": "/Outbound/850"}, "SFTP", "SFTP")
    paths = (second.get("_builder_audit") or {}).get("human_answers", {}).get("paths", [])
    assert "objects.source_transport_profile.subscription_folder" in paths
    assert "objects.target_transport_profile.subscription_folder" in paths
    assert len(paths) >= 2


def test_frontend_and_backend_expose_extraction_trace_download():
    api_src = (ROOT / "webapp/frontend/src/lib/api.ts").read_text(encoding="utf-8")
    page = (ROOT / "webapp/frontend/src/pages/BuilderPage.tsx").read_text(encoding="utf-8")
    backend = (ROOT / "webapp/backend/app/main.py").read_text(encoding="utf-8")
    assert "downloadExtractionBlueprint" in api_src
    assert "Download Extraction Trace JSON" in page
    assert '/extraction-blueprint/download' in backend
