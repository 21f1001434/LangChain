from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault(
    "HIP_TOKEN_URL",
    "https://www-sit-g2.dell.com/di/proxy/17/api/v3/oauth/token",
)
os.environ.setdefault("HIP_CLIENT_ID", "offline-test-client")
os.environ.setdefault("HIP_CLIENT_SECRET", "offline-test-secret")
os.environ.setdefault("DELL_AIA_CLIENT_ID", "offline-aia-client")
os.environ.setdefault("DELL_AIA_CLIENT_SECRET", "offline-aia-secret")
os.environ.setdefault(
    "DELL_AIA_BASE_URL",
    "https://aia.gateway.dell.com/genai/dev/v1",
)
os.environ.setdefault("DELL_AIA_MODEL", "gpt-oss-120b")
os.environ.setdefault("HIP_VERIFY_SSL", "true")
os.environ.setdefault("HTTP_RETRY_ATTEMPTS", "1")

import run_agent
from api_execution_plan import clear_execution_plan


class FakeResponse:
    def __init__(self, url: str, status_code: int, body: Any):
        self.url = url
        self.status_code = status_code
        self._body = body
        self.headers: Dict[str, str] = {
            "Content-Type": "application/json",
        }
        self.text = "" if body is None else json.dumps(body)

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> Any:
        if self._body is None:
            raise ValueError("No JSON body")
        return self._body


def fake_response(
    method: str,
    url: str,
    payload: Any,
    params: Any,
) -> FakeResponse:
    if "validate-unique-interface-detail" in url:
        return FakeResponse(url, 200, {"valid": True})
    if "flows/validate-name" in url:
        return FakeResponse(url, 200, "VALID")
    if "/authz/account" in url:
        if (payload or {}).get("accountName") == "haftatap10251593":
            return FakeResponse(
                url,
                409,
                {"message": "Account already exists"},
            )
        return FakeResponse(url, 201, {"id": 91001})
    if "/authz/partner" in url:
        return FakeResponse(url, 201, {"id": "partner-91002"})
    if "/hip-systems/" in url:
        return FakeResponse(url, 201, {"id": 91003})
    if url.endswith("/api/document-type"):
        name = (payload or {}).get("name", "")
        identifier = 92001 if "DellAutoASN" in name else 92002
        return FakeResponse(
            url,
            201,
            {"data": {"documentTypeId": identifier}},
        )
    if url.endswith("/api/mac-map"):
        return FakeResponse(url, 201, {"data": {"mapId": 93001}})
    if url.endswith("/api/rule"):
        assert "documentTypeId" not in (payload or {})
        assert "mapId" not in ((payload or {}).get("actions", [{}])[0].get("params", {}))
        assert (payload or {}).get("documentTypeName")
        assert (payload or {}).get("actions", [{}])[0].get("params", {}).get("mapIdentifier")
        return FakeResponse(url, 201, {"data": {"ruleId": 94001}})
    if "transport-profiles/orchestration/create" in url:
        return FakeResponse(
            url,
            200,
            {
                "success": True,
                "workOrderId": 95001,
                "taskId": 95002,
                "taskStatus": "COMPLETED",
                "tpCreateResponse": {"errorFlag": False},
            },
        )
    if "flows/orchestration/create" in url:
        definition = json.loads(
            (payload or {}).get("flowDefinition", "{}")
        )
        definition_text = json.dumps(definition)
        assert "documentTypeId" not in definition_text
        assert "targetDocumentTypeId" not in definition_text
        details = definition["targetDetails"]["targets"][0]["processSteps"][0]["configuration"]["defaultConfig"]["ruleRefs"]["ruleDetails"]
        assert details == {
            "name": "DELLCoXMLASNXX08C_U-HAUL_RULE",
            "version": "1.0",
        }
        assert "id" not in details
        return FakeResponse(
            url,
            200,
            {
                "success": True,
                "flowCreateResponse": {
                    "flowId": 96001,
                    "flowVersion": "1.0",
                },
            },
        )
    if "flows/orchestration/deploy" in url:
        assert "workType" not in (payload or {})
        return FakeResponse(
            url,
            200,
            {
                "success": True,
                "workOrderId": 97001,
                "taskId": 97002,
                "deployResponse": {"errorFlag": False},
            },
        )
    if "flows/deployment/history" in url:
        return FakeResponse(
            url,
            200,
            [{
                "deploymentId": 98001,
                "deploymentStatus": "DEPLOYED",
                "workOrderId": "97001",
            }],
        )
    if "transport-profiles/audits" in url:
        return FakeResponse(
            url,
            200,
            [{"status": "COMPLETED", "operation": "CREATE"}],
        )
    raise AssertionError(f"Unexpected request: {method} {url}")


def main() -> None:
    plan_path = ROOT / "api_execution_plan.json"
    original_plan = plan_path.read_bytes() if plan_path.exists() else None
    clear_execution_plan(ROOT, ROOT / "input.json")
    try:
        _main_full_create()
    finally:
        if original_plan is None:
            plan_path.unlink(missing_ok=True)
        else:
            plan_path.write_bytes(original_plan)


def _main_full_create() -> None:
    runner = run_agent.Runner(llm_enabled=False)
    runner.ov["tpProcessingWaitSeconds"] = 0
    runner.ov["flowProcessingWaitSeconds"] = 0

    runner.runtime_state.update({
        "source_document_type_id": None,
        "target_document_type_id": None,
        "map_id": None,
        "rule_id": None,
        "flow_id": None,
    })
    for key in (
        "source_document_type_id",
        "target_document_type_id",
        "map_id",
        "rule_id",
        "existing_flow_id",
    ):
        runner.ov[key] = None

    runner.get_token = lambda token_kind, scope: "offline-token"
    runner.judge.judge = lambda result: {}
    runner.judge.available = lambda: False

    def mocked_request(
        method: str,
        url: str,
        token_kind: str,
        scope: str,
        extra_headers: Any,
        payload: Any,
        params: Any,
    ) -> FakeResponse:
        return fake_response(method, url, payload, params)

    runner._request_with_retry = mocked_request

    with patch("run_agent.time.sleep", return_value=None), patch.object(
        runner.adaptive,
        "record_api_result",
        return_value=None,
    ), patch.object(
        runner.adaptive,
        "record_mapping_graph",
        return_value={"status": "mocked"},
    ):
        results = runner.run()

    assert runner.final_state["success"] is True, runner.final_state
    assert runner.runtime_state["source_document_type_id"] == 92001
    assert runner.runtime_state["target_document_type_id"] == 92002
    assert runner.runtime_state["map_id"] == 93001
    assert runner.runtime_state["rule_id"] == 94001
    assert runner.runtime_state["flow_id"] == 96001

    blocked = [
        item.api
        for item in results
        if item.classification in {
            "EXECUTION_ERROR",
            "CONTRACT_VALIDATION_BLOCKED",
            "SKIPPED_DEPENDENCY",
        }
    ]
    assert not blocked, blocked

    output = {
        "status": "PASS",
        "steps": len(results),
        "endToEndSuccess": True,
        "runtimeIds": runner.runtime_state,
        "blockedSteps": blocked,
    }
    path = ROOT / "examples" / "PRODUCTION_MOCK_INTEGRATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(
        json.dumps(output, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
