from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parent


def test_parallel_page_has_explicit_single_and_multiple_modes():
    text = (ROOT / 'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    assert "runMode" in text
    assert "Run one customer" in text
    assert "Run multiple customers" in text
    assert "RUN LIVE EXECUTION" in text


def test_flow_live_action_is_first_and_toolbar_no_longer_scrolls_horizontally():
    page = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    styles = (ROOT / 'webapp/frontend/src/styles.css').read_text(encoding='utf-8')
    action = page.split('flow-toolbar-actions', 1)[1][:1800]
    assert action.find('Run LIVE') < action.find('Agent preflight')
    assert 'overflow:visible!important' in styles
    assert 'flex-wrap:wrap!important' in styles


def test_payload_structure_is_immutable_and_only_human_user_can_edit_values():
    inspector = (ROOT / 'webapp/frontend/src/components/NodeInspector.tsx').read_text(encoding='utf-8')
    testing = (ROOT / 'webapp/frontend/src/pages/ApiTestingPage.tsx').read_text(encoding='utf-8')
    backend = (ROOT / 'webapp/backend/app/main.py').read_text(encoding='utf-8')
    policy = (ROOT / 'api_contract_policy.py').read_text(encoding='utf-8')
    assert 'Immutable API policy' in inspector
    assert 'Apply payload changes' not in inspector
    assert 'Human Payload Value Editor' in testing
    assert 'Only you can edit approved values before LIVE' in testing
    assert 'PAYLOAD_VALUE_EDIT_USER_ONLY' in (ROOT / 'payload_overrides.py').read_text(encoding='utf-8')
    assert 'Payload value editing is HUMAN USER ONLY' in backend
    assert 'AI/agent may inspect and validate but cannot edit payload values' in backend
    assert 'HUMAN_USER_VALUE_EDIT_ONLY' in policy

def test_reports_page_renders_and_downloads_html():
    page = (ROOT / 'webapp/frontend/src/pages/ReportsPage.tsx').read_text(encoding='utf-8')
    api = (ROOT / 'webapp/frontend/src/lib/api.ts').read_text(encoding='utf-8')
    assert 'html-report-frame' in page
    assert 'srcDoc' in page
    assert 'downloadReport' in api
    assert 'downloadParallelReport' in api


def test_react_execution_html_renderer_contains_requests_responses_and_status():
    import sys
    sys.path.insert(0, str(ROOT))
    from webapp.backend.app.report_renderer import render_react_execution_html
    record = {
        'id': 'exec1', 'status': 'PASS', 'elapsedMs': 1234,
        'flow': {'nodes': [{'id': 'n1', 'api_key': 'account_source', 'label': 'Source Account'}], 'edges': []},
        'events': [
            {'type': 'node.request', 'nodeId': 'n1', 'request': {'method': 'POST', 'url': 'https://example', 'payload': {'name': 'A'}}},
            {'type': 'node.completed', 'nodeId': 'n1', 'verdict': {'verdict': 'PASS', 'outcome': 'CREATED'}, 'result': {'status_code': 201, 'response_preview': {'id': 12}, 'classification': 'SUCCESS'}, 'output': {'id': 12}, 'timing': {'apiMs': 100, 'waitMs': 0, 'totalMs': 101}},
            {'type': 'execution.completed', 'status': 'PASS', 'elapsedMs': 1234},
        ],
    }
    html = render_react_execution_html(record, {'customer': 'Demo', 'direction': 'Inbound', 'transaction_code': '850'})
    assert 'Final LIVE Evidence' in html
    assert 'Source Account' in html
    assert 'Effective request' in html
    assert 'Response / verdict' in html
    assert 'CREATED' in html


def test_parallel_renderer_has_final_customer_summary():
    import sys
    sys.path.insert(0, str(ROOT))
    from webapp.backend.app.report_renderer import render_parallel_batch_html
    html = render_parallel_batch_html({'batchId': 'b1', 'parallelWorkers': 2, 'configurationCount': 2, 'passCount': 2, 'blockedCount': 0, 'elapsedSeconds': 3.2, 'results': [{'jobId': 'j1', 'customer': 'U-HAUL', 'status': 'PASS'}, {'jobId': 'j2', 'customer': 'LEGRAND', 'status': 'PASS'}]})
    assert 'LIVE Execution Report' in html
    assert 'U-HAUL' in html and 'LEGRAND' in html
