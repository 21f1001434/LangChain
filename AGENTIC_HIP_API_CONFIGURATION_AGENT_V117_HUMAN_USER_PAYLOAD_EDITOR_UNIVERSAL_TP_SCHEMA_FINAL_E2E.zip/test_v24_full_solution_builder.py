from __future__ import annotations

import gzip
import tempfile
import zipfile
from pathlib import Path

from hip_defaults import DEFAULT_DEPLOYMENT_GROUP, with_default_deployment_group
from input_builder_core import build_from_raw_files
from input_builder_integration import (
    apply_answers,
    apply_selected_interfaces,
    unresolved_questions,
)
from uhal_mapper import UhalInputMapper

ROOT = Path(__file__).resolve().parent


def _translation_fixture(direction: str):
    td = tempfile.TemporaryDirectory()
    root = Path(td.name)
    (root / "CUSTOMER_PO.xml").write_text(
        "<PurchaseOrderCollection><PurchaseOrderItem><BuyerParty><CompanyName>CUSTOMER</CompanyName>"
        "</BuyerParty><SellerParty><SupplierName>Dell</SupplierName></SellerParty>"
        "<PurchaseOrderNo>123</PurchaseOrderNo></PurchaseOrderItem></PurchaseOrderCollection>",
        encoding="utf-8",
    )
    xbm = (
        '<transformMap logicalName="MAP850" analystVersionLastSaved="6.7.2">'
        '<sources><schemaRoot logicalName="PurchaseOrderCollection"/></sources>'
        '<targets><schemaRoot logicalName="PurchaseOrder"/></targets></transformMap>'
    )
    (root / "MAP850.xbm").write_bytes(gzip.compress(xbm.encode("utf-8")))
    with zipfile.ZipFile(root / "Transform_MAP850.jar", "w") as zf:
        zf.writestr("com/dell/Transform_MAP850.class", b"class")
    data = build_from_raw_files(
        list(root.iterdir()), customer="CUSTOMER", direction=direction,
        flow_type="translation", use_dell_aia=False,
    )
    return td, data


def test_dev_deployment_group_overrides_any_uploaded_value():
    raw = {
        "objects": {
            "source_transport_profile": {"deployment_group": "legacy-sender"},
            "target_transport_profile": {"deployment_group": "legacy-receiver"},
        }
    }
    data, cfg = with_default_deployment_group(raw, {
        "source_deployment_group_name": "wrong",
        "target_deployment_group_name": "wrong",
    })
    assert DEFAULT_DEPLOYMENT_GROUP == "hip-automation"
    assert data["objects"]["source_transport_profile"]["deployment_group"] == DEFAULT_DEPLOYMENT_GROUP
    assert data["objects"]["target_transport_profile"]["deployment_group"] == DEFAULT_DEPLOYMENT_GROUP
    assert cfg["source_deployment_group_name"] == DEFAULT_DEPLOYMENT_GROUP
    assert cfg["target_deployment_group_name"] == DEFAULT_DEPLOYMENT_GROUP


def test_raw_builder_direction_places_dell_and_partner_on_correct_side():
    td, inbound = _translation_fixture("Inbound")
    try:
        src = inbound["objects"]["source_transport_profile"]
        tgt = inbound["objects"]["target_transport_profile"]
        assert src["system_type"] == "Partner"
        assert src.get("partner_name", "") == ""  # ask the user; do not invent customer partner app
        assert tgt["system_type"] == "Dell Application"
        assert tgt["partner_name"] == "AIC - DCE"
    finally:
        td.cleanup()

    td, outbound = _translation_fixture("Outbound")
    try:
        src = outbound["objects"]["source_transport_profile"]
        tgt = outbound["objects"]["target_transport_profile"]
        assert src["system_type"] == "Dell Application"
        assert src["partner_name"] == "AIC - DCE"
        assert tgt["system_type"] == "Partner"
        assert tgt.get("partner_name", "") == ""
    finally:
        td.cleanup()


def test_builder_questions_accounts_for_https_and_never_asks_deployment_group():
    td, data = _translation_fixture("Outbound")
    try:
        data = apply_selected_interfaces(ROOT, data, "HTTPS", "HTTPS")
        questions = unresolved_questions(ROOT, data, "HTTPS", "HTTPS")
        labels = [str(q.get("label") or "").lower() for q in questions]
        assert any("source hip account" in x for x in labels)
        assert any("target hip account" in x for x in labels)
        assert any("target partner identifier" in x for x in labels)
        assert not any("deployment group" in x for x in labels)
    finally:
        td.cleanup()


def test_partner_id_answer_updates_rule_and_flow_conditions():
    data = {
        "customer": "CUSTOMER", "direction": "Outbound", "flow_type": "translation",
        "requires_data_map": True, "partner_identifier_value": "DUNS-123",
        "objects": {
            "source_document_type": {"name": "SRC", "version": "1", "document_identifier": {"rows": [{"value": "SRC"}]}},
            "target_document_type": {"name": "TGT", "version": "1", "document_identifier": {"rows": [{"value": "TGT"}]}},
            "data_map": {"map_identifier": "MAP", "map_name": "MAP", "map_data_file": "Map.jar"},
            "rule": {"name": "RULE", "conditions": {"rows": [{"value": ""}]}},
            "source_transport_profile": {"system_type": "Dell Application", "partner_name": "AIC - DCE", "profile_name": "SRC_TP", "existing_account_name": "SRC_ACC"},
            "target_transport_profile": {"system_type": "Partner", "partner_name": "PARTNER", "profile_name": "TGT_TP", "existing_account_name": "TGT_ACC"},
            "biz_flow": {
                "flow_details": {"business_flow_name": "FLOW"},
                "configure_source": {"source_application": "AIC - DCE", "source_transport_profile": "SRC_TP"},
                "configure_targets": {"target_application": "PARTNER", "target_transport_profile": "TGT_TP"},
                "flow_identifiers": {"conditions": [{"value": ""}]},
                "configure_routing": {"conditions": {"rows": [{"value": ""}]}},
            },
        },
        "missing_fields": [{"field": "partner_id", "label": "Partner Identifier", "why": "routing"}],
    }
    questions = unresolved_questions(ROOT, data, "SFTP", "SFTP")
    q = next(x for x in questions if x.get("id") == "builder_partner_id")
    updated, _ = apply_answers(ROOT, data, questions, {q["id"]: "PARTNER-007"}, "SFTP", "SFTP")
    assert updated["objects"]["rule"]["conditions"]["rows"][0]["value"] == "PARTNER-007"
    assert updated["objects"]["biz_flow"]["flow_identifiers"]["conditions"][0]["value"] == "PARTNER-007"
    assert updated["objects"]["biz_flow"]["configure_routing"]["conditions"]["rows"][0]["value"] == "PARTNER-007"


def test_mapper_entity_roles_are_direction_aware():
    canonical = {
        "customer": "C", "direction": "Inbound", "profile_name": "FLOW", "partner_identifier_value": "DUNS",
        "flow_type": "passthrough", "requires_data_map": False,
        "objects": {
            "source_document_type": {"name": "DOC", "version": "1", "api_transaction_type": "INBOUND", "document_identifier": {"rows": [{"value": "Root"}]}},
            "target_document_type": {"name": "DOC_PT", "version": "1", "api_transaction_type": "OUTBOUND", "document_identifier": {"rows": [{"value": "Root"}]}},
            "source_transport_profile": {"system_type": "Partner", "partner_name": "CUSTOMER_PARTNER", "profile_name": "SRC_TP", "existing_account_name": "SRC_ACC", "deployment_group": "wrong"},
            "target_transport_profile": {"system_type": "Dell Application", "partner_name": "AIC - DCE", "profile_name": "TGT_TP", "existing_account_name": "TGT_ACC", "deployment_group": "wrong"},
            "biz_flow": {
                "flow_details": {"business_flow_name": "FLOW"},
                "configure_source": {"source_type": "Partner", "source_application": "CUSTOMER_PARTNER", "source_transport_profile": "SRC_TP"},
                "configure_targets": {"target_type": "Dell Application", "target_application": "AIC - DCE", "target_transport_profile": "TGT_TP"},
                "flow_identifiers": {"conditions": [{"attribute_name": "Receiver", "operator": "Equals", "value": "DELL"}]},
            },
        },
    }
    n = UhalInputMapper(canonical, {}, ROOT).normalized()
    assert n["sourceType"] == "Partner"
    assert n["targetType"] == "Dell Application"
    assert n["externalPartner"] == "CUSTOMER_PARTNER"
    assert n["dellSystem"] == "AIC - DCE"
    assert n["sourceDeploymentGroup"] == "hip-automation"
    assert n["targetDeploymentGroup"] == "hip-automation"


def test_runtime_python_has_no_legacy_deployment_group_literals():
    banned = ("dce-shared-sender", "dce-shared-receiver", "dce-default-sender", "dce-default-receiver")
    for path in ROOT.glob("*.py"):
        if path.name.startswith("test_") or path.name.startswith("validate_") or path.name == "final_self_check.py":
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for token in banned:
            assert token not in text, f"legacy deployment group {token} in {path.name}"


def test_full_solution_builder_ui_is_packaged():
    app = (ROOT / "hip_application_studio.py").read_text(encoding="utf-8")
    ui = (ROOT / "input_builder_ui.py").read_text(encoding="utf-8")
    assert "🧭 Build New Configuration" in app
    assert "Select interface" in ui
    assert "Upload customer artifacts" in ui
    assert "Agent ingest + generate input.json" in ui
    assert "Agent asks only for values it cannot determine" in ui
    assert "Map input.json to the 18 HIP APIs + validate" in ui
    assert "RUN FULL CONFIGURATION LIVE" in ui


def test_guided_engine_asks_for_partner_identifier_and_never_changes_deployment_group(tmp_path):
    from adaptive_engine import AdaptiveHipEngine

    engine = AdaptiveHipEngine(tmp_path)
    raw = {
        "customer": "CUSTOMER",
        "direction": "Outbound",
        "tx_code": "856",
        "profile_name": "FLOW",
        "objects": {
            "source_document_type": {
                "name": "SRC", "data_format_type": "XML", "api_transaction_type": "INBOUND",
                "root_element": "SRC", "attributes_to_configure": [{"name": "Receiver"}],
            },
            "target_document_type": {
                "name": "TGT", "data_format_type": "XML", "api_transaction_type": "OUTBOUND",
                "root_element": "TGT", "attributes_to_configure": [{"name": "Receiver"}],
            },
            "data_map": {"map_identifier": "MAP", "map_name": "MAP", "map_class": "Transform_MAP", "map_data_file": "Transform_MAP.jar"},
            "rule": {"name": "RULE", "conditions": {"rows": [{"attribute_name_unit": "Receiver", "operator": "Equals", "value": "CUST"}]}},
            "source_transport_profile": {"partner_name": "AIC - DCE", "profile_name": "SRC_TP", "profile_usage": "Sender", "interface_type": "SFTP HAFT", "existing_account_name": "SRC_ACC", "subscription_folder": "/src", "deployment_group": "wrong"},
            "target_transport_profile": {"partner_name": "CUSTOMER", "profile_name": "TGT_TP", "profile_usage": "Receiver", "interface_type": "SFTP HAFT", "existing_account_name": "TGT_ACC", "subscription_folder": "/tgt", "deployment_group": "wrong"},
        },
    }
    analysis = engine.prepare_canonical_input(raw, apply_safe=False)
    questions = analysis["unresolvedQuestions"]
    assert any(q.get("canonical_path") == "partner_identifier_value" for q in questions)

    proposal = engine.propose_change("Use deployment group legacy-sender and DUNS is DUNS-9988", raw, {}, use_aia=False)
    applied = engine.apply_change(proposal, raw, {}, approve=True)
    assert applied["input"]["partner_identifier_value"] == "DUNS-9988"
    assert applied["input"]["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    assert applied["input"]["objects"]["target_transport_profile"]["deployment_group"] == "hip-automation"
    assert applied["config"]["source_deployment_group_name"] == "hip-automation"
    assert applied["config"]["target_deployment_group_name"] == "hip-automation"


def test_plain_https_does_not_require_ssl_certificate_reference():
    # V117 Dev-validation candidate: plain HTTPS/REST omits SSL Certificate,
    # SSL Certificate CN - Expiry and SSL Certificate Id. HTTPS-AS2 remains separate.
    td, outbound = _translation_fixture("Outbound")
    try:
        outbound = apply_selected_interfaces(ROOT, outbound, "HTTPS", "HTTPS")
        qs = unresolved_questions(ROOT, outbound, "HTTPS", "HTTPS")
        certs = [q for q in qs if "certificate" in str(q.get("label") or "").lower()]
        assert certs == []
    finally:
        td.cleanup()

    td, inbound = _translation_fixture("Inbound")
    try:
        inbound = apply_selected_interfaces(ROOT, inbound, "HTTPS", "HTTPS")
        qs = unresolved_questions(ROOT, inbound, "HTTPS", "HTTPS")
        certs = [q for q in qs if "certificate" in str(q.get("label") or "").lower()]
        assert certs == []
    finally:
        td.cleanup()
