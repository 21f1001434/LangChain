# Agentic HIP API Configuration Agent — V33 Phase 1

## Goal

Begin the production UI migration from Streamlit to a smooth Bun/React frontend while preserving the proven V32 Python engine.

## User experience

- `Outbound` is the convenience default but **Direction is editable** and the selected value is authoritative.
- Inbound suggestions begin with `850`.
- Outbound suggestions include `832`, `855`, `856`, and the user can type any additional transaction code.
- Translation/Passthrough are separate paths; Auto remains available.
- Source/Target interfaces are editable.
- Customer files can arrive individually or in ZIPs.
- Supported onboarding paths: customer files only, CM + files, existing input.json + files.
- User business instructions participate in the audited input.json build.

## API Flow Game

- 18 reusable API blocks.
- Drag/drop from a block deck.
- Duplicate the same API block any number of times.
- Connect one-to-one, one-to-many and many-to-one.
- Graph cycles are rejected before execution.
- Load the agent-generated effective payloads into each node before running.
- Per-node inspector: Payload, Response, Agent, Output, Timing.
- Node states: READY, RUNNING, PASS, EXISTING, NEEDS_INPUT, BLOCKED.
- Live execution streams from Python to React over WebSocket.
- Saved flow templates can be reused for another customer/configuration.

## Starter templates

- Inbound 850 Translation
- Inbound 850 Passthrough
- Outbound 832 Translation / Passthrough
- Outbound 855 Translation / Passthrough
- Outbound 856 Translation / Passthrough

These are templates, not hard-coded business restrictions. Custom transaction codes and custom graphs are allowed.

## Validation performed in this release

- 104 Python tests PASS (legacy + Phase 1 tests).
- Standard legacy package validator 57/57 PASS.
- Adaptive validator 60/60 PASS.
- Legacy required self-check 43/43 PASS.
- Agentic Phase 1 self-check 12/12 PASS.
- FastAPI server boot + `/api/health` + `/api/bootstrap` verified.
- Bootstrap exposes 18 API blocks and 8 starter templates.
- TypeScript/TSX syntax transpilation: 14 files, 0 syntax errors.
- Bun itself is not installed in the build sandbox, so final visual browser acceptance must be run on a machine with Bun installed.

## Launch

First time:

```powershell
SETUP_AGENTIC_HIP.bat
```

Then:

```powershell
RUN_AGENTIC_HIP.bat
```

Frontend: `http://127.0.0.1:5173`
Backend API docs: `http://127.0.0.1:8765/docs`

The Streamlit launchers remain available during the phased migration.
