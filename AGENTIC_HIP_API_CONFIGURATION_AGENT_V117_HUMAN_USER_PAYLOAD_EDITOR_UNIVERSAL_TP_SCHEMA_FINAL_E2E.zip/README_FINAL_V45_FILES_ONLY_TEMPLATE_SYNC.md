# Agentic HIP API Configuration Agent V45

## What changed

### 1. Customer-files-only onboarding now truly requires no `input.json`
- The React and Streamlit Input Builder paths can build canonical `input.json` from customer files alone.
- If a recognizable Configuration Manual is received among the files, it is automatically consumed as structured customer evidence even when the UI is left on **Customer files only**.
- ZIP contents, nested files, XML/EDI/X12/CSV/JSON payloads, XBM and JAR mapping artifacts continue through the same deterministic extraction pipeline.
- Random React workspace ids / temp directory names are no longer allowed to become fake customer names.
- The builder asks only for values that cannot be proven from received evidence.

### 2. Received/extracted values take precedence over untouched card defaults
A new React card starts with convenience values such as `Outbound` and `850`. In files-only onboarding these are now fallback hints only. If customer evidence proves a different direction or transaction, the extracted value wins. This prevents an Inbound/856/etc. customer package from being silently rewritten by defaults.

### 3. Generated templates stay synchronized with the final canonical values
Every configuration gets a stable generated customer template (`generated-<configuration-id>`). It is created/updated after:
- Input Builder build
- Applying unresolved answers

The template tracks reusable final values including customer, direction, transaction, flow type, document types, map/rule names, transport profile names, interface types, accounts/folders, applications and partner identity. Passwords, secrets, access tokens, private-key/credential fields are not copied into reusable template defaults.

The React UI receives the refreshed template immediately after Build / Apply answers, so Templates and the API Flow Game can use the current configuration without an app restart. Template history versions only increase when reusable template content changes.

### 4. Regression coverage
Added `test_v45_files_only_template_sync.py` covering:
- Configuration Manual only, no `input.json`
- Raw XML + XBM + JAR only, no `input.json`
- Evidence overriding incorrect fresh-card defaults
- No random workspace id as customer
- Only true unresolved values are asked
- Generated template values and secret exclusion
- Template version/history behavior
- Backend template synchronization

Validation result: **165/165 non-live regression tests passed**.

The live OAuth/credential tests were intentionally excluded from the offline regression run because they require the target environment credentials/services.
