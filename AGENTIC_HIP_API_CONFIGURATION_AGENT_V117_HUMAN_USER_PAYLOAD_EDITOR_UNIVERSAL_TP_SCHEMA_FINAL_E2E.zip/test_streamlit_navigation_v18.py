from __future__ import annotations

from pathlib import Path

from streamlit_navigation import _page_slug


def test_streamlit_page_slug_strips_numeric_prefix():
    assert _page_slug("pages/10_Agentic_Interface_Studio.py") == "Agentic_Interface_Studio"
    assert _page_slug("pages/90_Advanced_Technical_Workspace.py") == "Advanced_Technical_Workspace"


def test_compatibility_pages_never_hardcode_root_page_link():
    root = Path(__file__).resolve().parent
    for rel in [
        "pages/10_Agentic_Interface_Studio.py",
        "pages/90_Advanced_Technical_Workspace.py",
        "legacy_pages/10_Agentic_Interface_Studio.py",
        "legacy_pages/90_Advanced_Technical_Workspace.py",
    ]:
        text = (root / rel).read_text(encoding="utf-8")
        assert 'st.page_link("hip_application_studio.py"' not in text
    for rel in [
        "pages/10_Agentic_Interface_Studio.py",
        "pages/90_Advanced_Technical_Workspace.py",
        "legacy_pages/10_Agentic_Interface_Studio.py",
    ]:
        text = (root / rel).read_text(encoding="utf-8")
        assert "render_app_home_link(st)" in text


def test_navigation_helper_has_non_crashing_relative_fallback():
    root = Path(__file__).resolve().parent
    text = (root / "streamlit_navigation.py").read_text(encoding="utf-8")
    assert 'st.markdown(f"[{text}](./)")' in text
    assert 'except Exception:' in text
    assert 'st.markdown(f"[{text}](./{slug})")' in text


def test_safe_page_link_falls_back_when_streamlit_rejects_page():
    from streamlit_navigation import safe_page_link

    class FakeStreamlit:
        def __init__(self):
            self.markdowns = []
        def page_link(self, *args, **kwargs):
            raise RuntimeError("StreamlitPageNotFoundError")
        def markdown(self, value):
            self.markdowns.append(value)

    fake = FakeStreamlit()
    safe_page_link(fake, "pages/90_Advanced_Technical_Workspace.py", label="Advanced", icon="🛠️")
    assert fake.markdowns == ["[🛠️ Advanced](./Advanced_Technical_Workspace)"]


def test_home_link_is_entrypoint_independent():
    from streamlit_navigation import render_app_home_link

    class FakeStreamlit:
        def __init__(self):
            self.markdowns = []
        def markdown(self, value):
            self.markdowns.append(value)

    fake = FakeStreamlit()
    render_app_home_link(fake)
    assert fake.markdowns == ["[🧭 ← Back to Application Studio](./)"]
