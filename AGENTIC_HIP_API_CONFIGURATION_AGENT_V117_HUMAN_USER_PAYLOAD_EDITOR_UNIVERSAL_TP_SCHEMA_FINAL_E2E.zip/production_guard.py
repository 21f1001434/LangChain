from __future__ import annotations

import json
import os
import re
import socket
import time
import uuid
import tempfile
import zipfile
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse
from xml.etree import ElementTree


try:
    import psutil
except Exception:  # optional but strongly recommended on Windows
    psutil = None



def env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def redact_sensitive(value: Any) -> Any:
    if isinstance(value, dict):
        output: Dict[str, Any] = {}
        for key, item in value.items():
            key_text = str(key)
            normalized_key = re.sub(r"[^a-z0-9]+", "", key_text.lower())
            sensitive_exact = {
                "authorization", "proxyauthorization",
                "clientsecret", "secret", "password", "passwd",
                "accesstoken", "refreshtoken", "idtoken",
                "apikey", "xapikey", "cookie", "setcookie",
            }
            if (
                normalized_key in sensitive_exact
                or "clientsecret" in normalized_key
                or "accesstoken" in normalized_key
                or "refreshtoken" in normalized_key
                or "password" in normalized_key
            ):
                output[key_text] = "<REDACTED>"
            else:
                output[key_text] = redact_sensitive(item)
        return output

    if isinstance(value, list):
        return [redact_sensitive(item) for item in value]

    if not isinstance(value, str):
        return value

    result = value
    for pattern, replacement in [
        (
            r"(?i)(authorization\s*[:=]\s*bearer\s+)"
            r"[A-Za-z0-9._~+\-/=]+",
            r"\1<REDACTED>",
        ),
        (
            r"(?i)(client[_ -]?secret\s*[\"']?\s*[:=]\s*[\"']?)"
            r"[^\"'\s,}]+",
            r"\1<REDACTED>",
        ),
        (
            r"(?i)(access[_ -]?token\s*[\"']?\s*[:=]\s*[\"']?)"
            r"[^\"'\s,}]+",
            r"\1<REDACTED>",
        ),
        (
            r"(?i)((?:refresh[_ -]?token|id[_ -]?token|api[_ -]?key)\s*[\"']?\s*[:=]\s*[\"']?)"
            r"[^\"'\s,}]+",
            r"\1<REDACTED>",
        ),
        (
            r"(?i)((?:cookie|set-cookie)\s*[:=]\s*)[^\r\n]+",
            r"\1<REDACTED>",
        ),
    ]:
        result = re.sub(pattern, replacement, result)
    return result


def atomic_write_text(
    path: Path,
    content: str,
    *,
    retries: int = 10,
    encoding: str = "utf-8",
) -> None:
    """Atomically persist text with Windows/endpoint-security resilience.

    Managed Windows laptops can briefly hold either the destination file or a
    just-created temporary file while Defender/indexing/OneDrive inspects it.
    A single ``os.replace`` therefore is not reliable enough for LIVE evidence
    writes.  Use a unique temp file for every attempt and retry transient
    PermissionError/OSError failures with bounded exponential backoff.

    The function intentionally still raises after the retry budget is exhausted;
    callers decide whether the artifact is mandatory or best-effort.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    attempts = max(1, int(retries))
    last_error: Exception | None = None

    for attempt in range(attempts):
        temporary = path.with_name(
            f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp"
        )
        try:
            with temporary.open("w", encoding=encoding, newline="") as handle:
                handle.write(content)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except OSError:
                    # Some virtual/enterprise filesystems do not support fsync.
                    pass
            os.replace(temporary, path)
            return
        except (PermissionError, OSError) as exc:
            last_error = exc
            try:
                temporary.unlink(missing_ok=True)
            except Exception:
                pass
            if attempt + 1 < attempts:
                time.sleep(min(0.75, 0.025 * (2 ** attempt)))

    if last_error is not None:
        raise last_error
    raise OSError(f"Could not write {path}")


def atomic_write_json(path: Path, value: Any, *, retries: int = 10) -> None:
    atomic_write_text(
        path,
        json.dumps(value, indent=2, ensure_ascii=False, default=str),
        retries=retries,
    )


def runtime_lock_path(project_root: Path) -> Path:
    """
    Put live-process locks outside the project/OneDrive reports directory.

    OneDrive can keep or restore project files after a process exits, which is
    exactly what caused the stale .live_execution.lock issue. Runtime locks are
    now stored in the local OS temp directory and scoped to the project path.
    """
    override = str(os.getenv("HIP_RUNTIME_LOCK_DIR") or "").strip()
    directory = Path(override) if override else Path(tempfile.gettempdir()) / "hip_agent_runtime_locks"
    directory.mkdir(parents=True, exist_ok=True)
    project_key = __import__("hashlib").sha256(
        str(Path(project_root).resolve()).lower().encode("utf-8")
    ).hexdigest()[:20]
    return directory / f"hip_live_{project_key}.lock"


def _process_identity(pid: int) -> Dict[str, Any]:
    """Return process state without assuming a PID still belongs to our old run."""
    if pid <= 0:
        return {"alive": False}

    if psutil is not None:
        try:
            process = psutil.Process(pid)
            return {
                "alive": bool(process.is_running()),
                "pid": pid,
                "name": process.name(),
                "createTime": process.create_time(),
                "cmdline": process.cmdline(),
            }
        except getattr(psutil, "NoSuchProcess", Exception):
            return {"alive": False, "pid": pid}
        except getattr(psutil, "AccessDenied", Exception):
            return {"alive": True, "pid": pid, "accessDenied": True}
        except Exception:
            pass

    try:
        os.kill(pid, 0)
        return {"alive": True, "pid": pid}
    except ProcessLookupError:
        return {"alive": False, "pid": pid}
    except PermissionError:
        return {"alive": True, "pid": pid, "accessDenied": True}
    except OSError:
        return {"alive": False, "pid": pid}


def inspect_live_run(project_root: Path) -> Dict[str, Any]:
    """
    Inspect the current live execution lock.

    A lock is stale when the recorded process no longer exists, the PID has
    been reused by a different process, or the lock contents are invalid.
    """
    path = runtime_lock_path(project_root)
    if not path.exists():
        return {
            "exists": False,
            "active": False,
            "stale": False,
            "lockPath": str(path),
        }

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}

    pid = int(data.get("pid") or 0)
    proc = _process_identity(pid)
    active = bool(proc.get("alive"))

    expected_create = data.get("processCreateTime")
    if active and expected_create not in (None, "") and proc.get("createTime") is not None:
        try:
            # Windows reuses PIDs. A different creation timestamp means this is
            # not the process that created the lock.
            if abs(float(proc["createTime"]) - float(expected_create)) > 2:
                active = False
        except Exception:
            pass

    if active and psutil is not None and proc.get("cmdline"):
        command = " ".join(str(x) for x in proc.get("cmdline") or []).lower()
        # Lock owners are run_agent.py processes. Do not treat an unrelated
        # application that inherited/reused the PID as an active HIP run.
        if "run_agent.py" not in command:
            active = False

    created_epoch = float(data.get("createdEpoch") or 0)
    age_seconds = max(0.0, time.time() - created_epoch) if created_epoch else None

    return {
        "exists": True,
        "active": active,
        "stale": not active,
        "lockPath": str(path),
        "pid": pid,
        "host": data.get("host"),
        "createdAt": data.get("createdAt"),
        "createdEpoch": created_epoch,
        "ageSeconds": age_seconds,
        "ownerId": data.get("ownerId"),
        "process": proc,
    }


def clear_stale_live_run(project_root: Path) -> Dict[str, Any]:
    """Remove the lock only when no real HIP execution process is alive."""
    state = inspect_live_run(project_root)
    if not state.get("exists"):
        return {"cleared": True, "reason": "NO_LOCK", **state}
    if state.get("active"):
        return {"cleared": False, "reason": "RUN_STILL_ACTIVE", **state}

    path = Path(state["lockPath"])
    path.unlink(missing_ok=True)
    return {"cleared": True, "reason": "STALE_LOCK_REMOVED", **state}


def terminate_live_run(project_root: Path, timeout_seconds: int = 8) -> Dict[str, Any]:
    """
    Safely stop the currently locked run_agent.py process.

    The UI exposes this as "Stop old/running configuration". It never kills the
    Streamlit UI itself and refuses to kill an unrelated PID.
    """
    state = inspect_live_run(project_root)
    if not state.get("exists"):
        return {"stopped": True, "reason": "NO_RUNNING_PROCESS", **state}

    if not state.get("active"):
        cleared = clear_stale_live_run(project_root)
        return {"stopped": True, "reason": "STALE_LOCK_REMOVED", **cleared}

    pid = int(state.get("pid") or 0)
    if pid <= 0:
        cleared = clear_stale_live_run(project_root)
        return {"stopped": True, "reason": "INVALID_PID_LOCK_REMOVED", **cleared}

    if psutil is None:
        return {
            "stopped": False,
            "reason": "PSUTIL_REQUIRED_TO_KILL_SAFELY",
            **state,
        }

    try:
        process = psutil.Process(pid)
        cmdline = " ".join(process.cmdline()).lower()
        if "run_agent.py" not in cmdline:
            return {
                "stopped": False,
                "reason": "REFUSED_UNRELATED_PROCESS",
                **state,
            }

        process.terminate()
        try:
            process.wait(timeout=max(1, int(timeout_seconds)))
        except psutil.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)

        Path(state["lockPath"]).unlink(missing_ok=True)
        return {
            "stopped": True,
            "reason": "RUN_TERMINATED",
            "pid": pid,
            "lockPath": state["lockPath"],
        }
    except psutil.NoSuchProcess:
        Path(state["lockPath"]).unlink(missing_ok=True)
        return {
            "stopped": True,
            "reason": "PROCESS_ALREADY_GONE_LOCK_REMOVED",
            "pid": pid,
            "lockPath": state["lockPath"],
        }
    except Exception as exc:
        return {
            "stopped": False,
            "reason": "TERMINATION_FAILED",
            "error": str(exc),
            **state,
        }


class LiveRunLock(AbstractContextManager):
    """Prevents duplicate live configuration runs while self-healing stale locks."""

    def __init__(
        self,
        lock_path: Path,
        stale_after_seconds: int = 6 * 60 * 60,
    ):
        self.lock_path = Path(lock_path)
        self.stale_after_seconds = stale_after_seconds
        self.acquired = False
        self.owner_id = str(uuid.uuid4())

    def __enter__(self):
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)

        # Try a few times because stale-lock cleanup and another browser click
        # can race each other.
        for _ in range(3):
            if self.lock_path.exists():
                # This class may also be used with an explicitly supplied path,
                # so inspect that path directly here.
                try:
                    data = json.loads(self.lock_path.read_text(encoding="utf-8"))
                except Exception:
                    data = {}
                pid = int(data.get("pid") or 0)
                proc = _process_identity(pid)
                active = bool(proc.get("alive"))
                expected_create = data.get("processCreateTime")
                if active and expected_create not in (None, "") and proc.get("createTime") is not None:
                    try:
                        if abs(float(proc["createTime"]) - float(expected_create)) > 2:
                            active = False
                    except Exception:
                        pass
                if active and psutil is not None and proc.get("cmdline"):
                    if "run_agent.py" not in " ".join(proc.get("cmdline") or []).lower():
                        active = False
                if not active:
                    self.lock_path.unlink(missing_ok=True)
                else:
                    raise RuntimeError(
                        "Another HIP configuration is genuinely still running. "
                        f"PID={pid}; started={data.get('createdAt')}; "
                        f"lock={self.lock_path}"
                    )

            payload = {
                "ownerId": self.owner_id,
                "pid": os.getpid(),
                "host": socket.gethostname(),
                "createdEpoch": time.time(),
                "createdAt": __import__("datetime").datetime.now().isoformat(),
                "processCreateTime": None,
            }
            if psutil is not None:
                try:
                    payload["processCreateTime"] = psutil.Process(os.getpid()).create_time()
                except Exception:
                    pass

            try:
                descriptor = os.open(
                    self.lock_path,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
            except FileExistsError:
                continue

            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)

            self.acquired = True
            return self

        raise RuntimeError(
            "Could not acquire the HIP execution lock after stale-lock recovery."
        )

    def __exit__(self, exc_type, exc, traceback):
        if self.acquired and self.lock_path.exists():
            try:
                data = json.loads(self.lock_path.read_text(encoding="utf-8"))
            except Exception:
                data = {}
            # Never delete a lock acquired by a different process after ours.
            if data.get("ownerId") in (None, self.owner_id):
                self.lock_path.unlink(missing_ok=True)
        self.acquired = False
        return False


def _placeholder(value: Any) -> bool:
    text = str(value or "").strip().upper()
    return (
        not text
        or text.startswith("REPLACE_")
        or text.startswith("PASTE_")
        or text.startswith("<")
    )


def _https(value: Any) -> bool:
    try:
        parsed = urlparse(str(value or ""))
        return parsed.scheme.lower() == "https" and bool(parsed.hostname)
    except Exception:
        return False


def validate_production_readiness(
    root: Path,
    input_data: Dict[str, Any],
    config: Dict[str, Any],
    urls: Dict[str, str],
    token_url: str,
    requester: str,
    verify_ssl: Any,
    effective_requests: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    errors: List[Dict[str, str]] = []
    warnings: List[Dict[str, str]] = []
    # Platform work-type metadata is self-healed from the approved v3 contract
    # before readiness checks. This keeps production preflight consistent with
    # request generation and avoids asking customers for known HIP constants.

    def add(target: List[Dict[str, str]], check: str, message: str) -> None:
        target.append({"check": check, "message": message})

    environment = str(
        config.get("hipEnvironment")
        or os.getenv("HIP_ENVIRONMENT")
        or "DEV"
    ).upper()

    if environment not in {"DEV", "TEST", "SIT", "UAT", "PROD"}:
        add(errors, "environment", f"Unsupported HIP environment: {environment}")

    if environment == "PROD":
        if os.getenv(
            "PRODUCTION_EXECUTION_CONFIRMATION",
            "",
        ).strip().upper() != "YES":
            add(
                errors,
                "production-confirmation",
                "Set PRODUCTION_EXECUTION_CONFIRMATION=YES for a PROD run.",
            )
        if not os.getenv("CHANGE_TICKET", "").strip():
            add(errors, "change-ticket", "CHANGE_TICKET is mandatory for PROD.")
        if verify_ssl is False:
            add(errors, "tls", "TLS verification cannot be disabled in PROD.")

    if verify_ssl is False:
        add(
            warnings,
            "tls",
            "TLS verification is disabled. Supply HIP_CA_BUNDLE instead.",
        )

    if not _https(token_url):
        add(errors, "token-url", f"Invalid HTTPS token URL: {token_url}")

    for key, url in urls.items():
        if not _https(url):
            add(errors, f"url:{key}", f"Invalid HTTPS endpoint: {url}")

    if "@" not in str(requester):
        add(errors, "requester", "Requester must be an email address.")

    for env_name in (
        "HIP_CLIENT_ID",
        "HIP_CLIENT_SECRET",
        "DELL_AIA_CLIENT_ID",
        "DELL_AIA_CLIENT_SECRET",
    ):
        if _placeholder(os.getenv(env_name, "")):
            add(
                errors,
                f"credential:{env_name}",
                f"{env_name} is missing or contains a placeholder.",
            )

    objects = input_data.get("objects") or {}
    source_doc = objects.get("source_document_type") or {}
    target_doc = objects.get("target_document_type") or {}
    data_map = objects.get("data_map") or {}
    translation = bool(input_data.get("requires_data_map")) or str(input_data.get("flow_type") or "").strip().lower() == "translation"
    input_dir = root / "input_files"

    if translation:
        jar_name = str(data_map.get("map_data_file") or "").strip()
        if not jar_name:
            add(errors, "input-file", "Translation flow requires an approved mapping JAR filename.")
        else:
            jar_path = input_dir / jar_name
            if not jar_path.exists() or jar_path.stat().st_size == 0:
                add(errors, "input-file", f"Missing or empty map JAR: {jar_name}")
            else:
                try:
                    with zipfile.ZipFile(jar_path, "r") as archive:
                        corrupt = archive.testzip()
                        if corrupt:
                            add(errors, "map-jar", f"Corrupt JAR member: {corrupt}")
                except Exception as exc:
                    add(errors, "map-jar", f"Invalid map JAR {jar_name}: {exc}")

        # Map Create needs representative source/target schemas. Do not bind
        # readiness to U-HAUL filenames; inspect the active customer files.
        def matching_samples(doc: Dict[str, Any]) -> list[Path]:
            if not input_dir.exists():
                return []
            fmt = str(doc.get("data_format_type") or "").upper()
            allowed = {".xml"} if "XML" in fmt else ({".edi", ".x12", ".txt"} if any(x in fmt for x in ("X12", "EDI", "EDIFACT")) else {".xml", ".edi", ".x12", ".txt", ".csv"})
            roots = [str(row.get("value")) for row in ((doc.get("document_identifier") or {}).get("rows") or []) if isinstance(row, dict) and row.get("value")]
            matches: list[Path] = []
            for path in input_dir.iterdir():
                if not path.is_file() or path.suffix.lower() not in allowed or path.stat().st_size == 0:
                    continue
                if not roots:
                    matches.append(path); continue
                try:
                    text = path.read_text(encoding="utf-8", errors="replace")[:250000]
                except Exception:
                    continue
                if any(root_value in text for root_value in roots):
                    matches.append(path)
            return matches

        for label, doc in (("source", source_doc), ("target", target_doc)):
            matches = matching_samples(doc)
            if not matches:
                add(errors, "input-file", f"Translation flow requires a representative {label} sample matching its Document Type.")
            for sample in matches:
                if sample.suffix.lower() == ".xml":
                    try:
                        ElementTree.parse(sample)
                    except Exception as exc:
                        add(errors, "xml", f"{sample.name} is invalid XML: {exc}")

    if input_data.get("customer") != "U-HAUL":
        configured_ids = [
            config.get("source_document_type_id"),
            config.get("target_document_type_id"),
            config.get("map_id"),
            config.get("rule_id"),
            config.get("existing_flow_id"),
        ]
        if any(value not in (None, "", 0) for value in configured_ids):
            add(
                errors,
                "stale-ids",
                "A new customer input cannot reuse U-HAUL IDs. "
                "Clear all configured IDs and resolve them from API responses.",
            )

    # Validate the exact effective requests that will be sent LIVE, not stale/raw
    # input.json helper fields. API Testing, Flow Game and Execute must agree on
    # the same persisted request after payload overrides and runner derivation.
    effective_requests = effective_requests or {}

    def effective_transaction_type(step_key: str, raw_doc: Dict[str, Any]) -> str:
        request = effective_requests.get(step_key) if isinstance(effective_requests, dict) else None
        if isinstance(request, dict):
            payload = request.get("payload")
            if isinstance(payload, dict) and payload.get("transactionType") not in (None, ""):
                return str(payload.get("transactionType") or "").strip().upper()
        return str(raw_doc.get("api_transaction_type") or "").strip().upper()

    source_transaction_type = effective_transaction_type("doctype_source", source_doc)
    target_transaction_type = effective_transaction_type("doctype_target", target_doc)

    if source_transaction_type and source_transaction_type != "INBOUND":
        add(
            errors,
            "source-transaction-type",
            f"Effective Source Document Type transactionType must be INBOUND; got {source_transaction_type!r}.",
        )
    elif not source_transaction_type:
        add(
            warnings,
            "source-transaction-type-derived",
            "Source Document Type transactionType is not stored in raw input.json; the runner will derive INBOUND in the effective request.",
        )

    if translation and target_transaction_type and target_transaction_type != "OUTBOUND":
        add(
            errors,
            "target-transaction-type",
            f"Effective Target Document Type transactionType must be OUTBOUND; got {target_transaction_type!r}.",
        )
    elif translation and not target_transaction_type:
        add(
            warnings,
            "target-transaction-type-derived",
            "Target Document Type transactionType is not stored in raw input.json; the runner will derive OUTBOUND in the effective request.",
        )

    # HIP derives the complete workType object internally. No workType values
    # are required from customer configuration.

    return {
        "generatedAt": __import__("datetime").datetime.now().isoformat(),
        "environment": environment,
        "ready": not errors,
        "errors": errors,
        "warnings": warnings,
        "checks": {
            "tlsVerification": verify_ssl,
            "tokenUrl": token_url,
            "endpointCount": len(urls),
            "requester": requester,
            "customer": input_data.get("customer"),
        },
    }
