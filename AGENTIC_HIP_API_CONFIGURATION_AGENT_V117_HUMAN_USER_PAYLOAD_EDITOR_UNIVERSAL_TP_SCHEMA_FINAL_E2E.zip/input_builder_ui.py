from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from application_studio import request_inventory, run_local_request_checks
from hip_defaults import DEFAULT_DEPLOYMENT_GROUP
from input_bundle import (
    backup_active_state, extract_input_zip, inspect_input_zip, inspect_individual_files,
    parse_input_json_bytes, replace_input_files_from_pairs, restore_active_state,
)
from input_builder_artifacts import build_audit_report_html, build_bundle_bytes, build_profile_runner_manual_bytes
from input_builder_core import (
    build_from_config_manual, build_from_config_manual_and_raw_files,
    build_from_raw_files, build_from_zip,
    combine_existing_input_with_artifact_evidence, normalize_input_json,
)
from input_builder_integration import (
    apply_answers, apply_selected_interfaces, apply_user_request_hints,
    load_answer_memory, save_answer_memory, unresolved_questions,
)
from input_mapping_learner import (
    clear_mapping_knowledge, load_mapping_knowledge, mapping_learning_summary,
    record_mapping_example,
)
from interface_registry import get_interface, interface_keys
from interactive_graphs import validation_figure
from production_guard import redact_sensitive
from scratch_flow import infer_flow_from_input, save_scratch_flow
from streamlit_navigation import request_workspace_switch
from parallel_configurations import snapshot_validated_configuration


def _safe_name(name: str) -> str:
    return Path(str(name or "file")).name or "file"


def _write_uploads(uploads: List[Any], folder: Path) -> List[Path]:
    out, seen = [], set()
    for uploaded in uploads:
        name = _safe_name(uploaded.name)
        if name.lower() in seen:
            raise ValueError(f"Duplicate uploaded file name: {name}")
        seen.add(name.lower())
        path = folder / name
        path.write_bytes(uploaded.getvalue())
        out.append(path)
    return out


def _activate_individual(root: Path, file_pairs: List[List[Any]]) -> int:
    dest = root / "input_files"
    stage = root / ".input_files_builder_staging"
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    try:
        for name, raw in file_pairs:
            (stage / _safe_name(name)).write_bytes(raw)
        dest.mkdir(parents=True, exist_ok=True)
        for child in dest.iterdir():
            shutil.rmtree(child) if child.is_dir() else child.unlink()
        for child in stage.iterdir():
            shutil.move(str(child), str(dest / child.name))
        return len(file_pairs)
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def _answer_widget(q: Dict[str, Any], remembered: Dict[str, Any]) -> Any:
    qid = str(q.get("id"))
    fallback = remembered.get(qid, q.get("current"))
    label, help_text = str(q.get("question") or q.get("label")), str(q.get("why") or "")
    kind = q.get("type")
    if kind == "select":
        options = list(q.get("options") or [])
        if fallback and fallback not in options:
            options.insert(0, str(fallback))
        return st.selectbox(label, options, index=options.index(fallback) if fallback in options else 0, key=f"ib_answer_{qid}", help=help_text)
    if kind == "password":
        return st.text_input(label, type="password", key=f"ib_answer_{qid}", help=help_text)
    if kind == "confirmation":
        return "Confirmed" if st.checkbox(label, key=f"ib_answer_{qid}", help=help_text) else ""
    if kind == "json":
        initial = "" if fallback in (None, "", {}, []) else (fallback if isinstance(fallback, str) else json.dumps(fallback, indent=2, ensure_ascii=False))
        text = st.text_area(label, value=initial, height=120, key=f"ib_answer_{qid}", help=help_text)
        if not text.strip():
            return ""
        try:
            return json.loads(text)
        except Exception:
            st.warning("This field requires valid JSON.")
            return ""
    return st.text_input(label, value=str(fallback or ""), key=f"ib_answer_{qid}", help=help_text)


def _summary_rows(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    objects = data.get("objects") or {}
    src = objects.get("source_transport_profile") or {}
    tgt = objects.get("target_transport_profile") or {}
    return [
        {"Field": "Customer", "Value": data.get("customer") or "—"},
        {"Field": "Source interface", "Value": src.get("interface_type") or "—"},
        {"Field": "Target interface", "Value": tgt.get("interface_type") or "—"},
        {"Field": "Direction", "Value": data.get("direction") or "—"},
        {"Field": "Transaction", "Value": " ".join(str(x or "") for x in [data.get("tx_standard"), data.get("tx_code"), data.get("tx_name")]).strip() or "—"},
        {"Field": "Flow type", "Value": data.get("flow_type") or "—"},
        {"Field": "Business flow", "Value": data.get("profile_name") or "—"},
        {"Field": "Deployment group", "Value": DEFAULT_DEPLOYMENT_GROUP},
    ]


def render_input_builder_workspace(root: Path, activate_input: Any) -> None:
    root = Path(root)
    st.markdown("## 🧭 New Configuration Builder")
    st.caption("Select interface → upload customer files → agent builds input.json → answer only unresolved values → validate 18 API payloads → run LIVE.")
    st.info("**Dev-team fixed deployment group:** `hip-automation` is used for every automation interface and is not editable. The Orchestration API performs the concrete mapping.")

    header = st.columns(6)
    for col, text in zip(header, ["1 · Interface", "2 · Upload", "3 · Agent build", "4 · Resolve", "5 · API validate", "6 · LIVE"]):
        col.markdown(f"**{text}**")

    keys = interface_keys(root)
    if not keys:
        st.error("No HIP interfaces are registered.")
        return
    idx = keys.index("SFTP") if "SFTP" in keys else 0
    st.markdown("### 1 · Select interface")
    c1, c2, c3 = st.columns(3)
    src_key = c1.selectbox("Source interface", keys, index=idx, key="ib_source_interface")
    same = c2.checkbox("Same interface for target", value=True, key="ib_same_interface")
    tgt_key = src_key if same else c3.selectbox("Target interface", keys, index=idx, key="ib_target_interface")
    src_def, tgt_def = get_interface(root, src_key), get_interface(root, tgt_key)
    m1, m2, m3 = st.columns(3)
    m1.metric("Source API interface", src_def.get("apiInterfaceType") or src_key)
    m2.metric("Target API interface", tgt_def.get("apiInterfaceType") or tgt_key)
    m3.metric("Deployment group", DEFAULT_DEPLOYMENT_GROUP)

    mapping_knowledge = load_mapping_knowledge(root)
    learning = mapping_learning_summary(mapping_knowledge)
    with st.expander("🧠 File → input.json mapping learner", expanded=learning.get("example_count", 0) < 3):
        l1, l2, l3 = st.columns(3)
        l1.metric("Reference pairs learned", learning.get("example_count", 0))
        l2.metric("Field mapping rules", learning.get("field_rule_count", 0))
        l3.metric("Learning target", "3+ pairs")
        st.caption("Each validated **existing input.json + customer files** pair teaches the agent reusable mapping structure: which physical file is source/target, file format → Document Type format, XML root → document identifier, JAR/XBM → Data Map. Customer-specific values and secrets are not copied between customers.")
        if learning.get("source_tokens") or learning.get("target_tokens"):
            st.json({"learnedSourceFilenameTokens": learning.get("source_tokens"), "learnedTargetFilenameTokens": learning.get("target_tokens"), "sourceFormatsSeen": learning.get("source_formats"), "targetFormatsSeen": learning.get("target_formats")})
        if st.button("Reset mapping-learning references", key="ib_reset_mapping_learning"):
            clear_mapping_knowledge(root)
            st.rerun()

    st.markdown("### 2 · Choose what you have · the output is always input.json + customer files")
    starting_point = st.radio(
        "Starting point",
        [
            "Customer files only — agent creates input.json",
            "Configuration Manual + customer files — agent creates input.json",
            "Existing input.json + supporting artifacts",
        ],
        key="ib_starting_point",
        help="All three paths converge to the same canonical input.json + customer-file bundle before 18-API mapping.",
    )
    artifact_mode = st.radio(
        "How do you want to provide the related files?",
        ["ZIP bundle", "Individual files"], horizontal=True, key="ib_artifact_mode",
        help="Both paths support XML/EDI/TXT/XBM/JAR and optional Configuration Manual files.",
    )
    zip_upload, existing_json, uploads = None, None, []
    prefer_cm = False

    if starting_point == "Existing input.json + supporting artifacts":
        existing_json = st.file_uploader(
            "Existing input.json", type=["json"], key="ib_existing_json",
            help="This JSON is authoritative for explicit business values. Uploaded artifacts are used to validate it and fill blanks only.",
        )
        if existing_json:
            try:
                parsed = parse_input_json_bytes(existing_json.getvalue())
                st.success("input.json is valid.")
                with st.expander("Preview uploaded input.json", expanded=False):
                    st.json(redact_sensitive(parsed))
            except Exception as exc:
                st.error(str(exc))

    if artifact_mode == "ZIP bundle":
        zip_upload = st.file_uploader(
            "Related customer files ZIP", type=["zip"], key="ib_zip",
            help="Upload XBM, mapping JAR, source/target/output XML, EDI/TXT and optional Configuration Manual files.",
        )
        if zip_upload:
            try:
                summary = inspect_input_zip(zip_upload.getvalue())
                st.success(f"Related-file ZIP ready · {summary['fileCount']} files · {summary['totalBytes']:,} bytes")
                if summary.get("containsInputJson") and existing_json:
                    st.warning("The ZIP contains input.json too. The separately uploaded input.json above remains authoritative.")
                st.dataframe(summary.get("files") or [], width="stretch", hide_index=True)
            except Exception as exc:
                st.error(str(exc))
        prefer_cm = starting_point.startswith("Configuration Manual")
        if prefer_cm:
            st.caption("✓ Configuration Manual is the primary structured source; customer files are still parsed and used for cross-validation/filling blanks.")
    else:
        uploads = st.file_uploader(
            "Related customer files", accept_multiple_files=True,
            type=["xml", "edi", "x12", "csv", "txt", "json", "jar", "xbm", "xlsx", "xlsm"],
            key="ib_files",
            help="Select files directly, for example XBM + mapping JAR + source XML + target XML + output/comparison XML.",
        ) or []
        if uploads:
            try:
                direct_summary = inspect_individual_files([(x.name, x.getvalue()) for x in uploads])
                st.success(f"Related files ready · {direct_summary['fileCount']} files · {direct_summary['totalBytes']:,} bytes")
                st.dataframe(direct_summary.get("files") or [], width="stretch", hide_index=True)
            except Exception as exc:
                st.error(str(exc))

    if starting_point == "Existing input.json + supporting artifacts":
        st.info("The agent reads **input.json and the related files together** (customer files/supporting artifacts). Explicit JSON values remain authoritative; artifacts fill blanks and validate JAR/XBM/XML evidence.")
    elif starting_point.startswith("Configuration Manual"):
        st.info("The agent reads the **Configuration Manual and customer files together**, learns the structured configuration, validates it against XML/EDI/XBM/JAR evidence, then generates input.json.")
    else:
        st.info("No input.json or Configuration Manual is required. The agent builds input.json from customer files, Dell AIA gap analysis, saved rules, and only then asks for unresolved values.")

    with st.expander("Optional hints + user request", expanded=True):
        h1, h2, h3 = st.columns(3)
        customer = h1.text_input("Customer name (if known)", key="ib_customer")
        direction_choice = h2.selectbox("Direction", ["Auto-detect", "Inbound", "Outbound"], key="ib_direction")
        flow_choice = h3.selectbox("Flow type", ["Auto-detect", "Translation", "Passthrough"], key="ib_flow_type")
        use_aia = st.checkbox("Use Dell AIA after deterministic extraction", value=True, key="ib_use_aia")
        user_request = st.text_area(
            "User request / business instructions for input.json",
            key="ib_user_request",
            placeholder="Example: This is an inbound passthrough flow for ATEA Norway. DUNS is ... Target account is ...",
            help="Explicit values in this request become an audited input source. The agent does not invent credentials, DUNS, certificates, folders or deployment groups.",
        )
        passthrough_target_exception = st.checkbox(
            "Passthrough exception: configure a separate Target Document Type",
            value=False, key="ib_passthrough_target_exception",
            help="Default is OFF. Normal Passthrough reuses the Source Document Type and does not call Target Document Type Create.",
        )

    artifacts_ready = bool(zip_upload) if artifact_mode == "ZIP bundle" else bool(uploads)
    can_build = bool(artifacts_ready and (starting_point != "Existing input.json + supporting artifacts" or existing_json))
    action_label = "🤖 3 · Agent ingest input.json + customer files" if starting_point.startswith("Existing") else "🤖 3 · Agent ingest + generate input.json · learn from files/request"
    if st.button(action_label, type="primary", width="stretch", disabled=not can_build, key="ib_generate"):
        try:
            direction = "" if direction_choice == "Auto-detect" else direction_choice
            flow_type = "" if flow_choice == "Auto-detect" else flow_choice.lower()
            manifest: List[str] = []
            input_raw = parse_input_json_bytes(existing_json.getvalue()) if existing_json else None
            if artifact_mode == "ZIP bundle":
                raw = zip_upload.getvalue()
                summary = inspect_input_zip(raw)
                manifest = [row["name"] for row in summary.get("files") or [] if row.get("name", "").lower() != "input.json"]
                has_manual = any(str(name).lower().endswith((".xlsx", ".xlsm")) for name in manifest)
                if starting_point.startswith("Configuration Manual") and not has_manual:
                    raise ValueError("Configuration Manual mode requires an .xlsx/.xlsm Configuration Manual in the ZIP.")
                evidence = build_from_zip(
                    raw, customer=customer, direction=direction, flow_type=flow_type,
                    prefer_config_manual=starting_point.startswith("Configuration Manual"),
                    use_dell_aia=use_aia, mapping_knowledge=mapping_knowledge,
                )
                st.session_state["ib_source_zip"] = raw
                st.session_state["ib_source_files"] = []
                st.session_state["ib_saved_artifact_mode"] = "ZIP bundle"
            else:
                with tempfile.TemporaryDirectory(prefix="hip_input_builder_") as td:
                    paths = _write_uploads(uploads, Path(td))
                    manuals = [p for p in paths if p.suffix.lower() in {".xlsx", ".xlsm"}]
                    raw_paths = [p for p in paths if p.suffix.lower() not in {".xlsx", ".xlsm"}]
                    if starting_point.startswith("Configuration Manual"):
                        if not manuals:
                            raise ValueError("Configuration Manual mode requires an .xlsx/.xlsm Configuration Manual.")
                        if not raw_paths:
                            raise ValueError("Add the related customer files too (XML/EDI/XBM/JAR/etc.); this mode learns from the manual and validates against customer evidence.")
                        evidence = build_from_config_manual_and_raw_files(
                            manuals[0], raw_paths, customer=customer, direction=direction,
                            flow_type=flow_type, use_dell_aia=use_aia, manual_primary=True,
                            mapping_knowledge=mapping_knowledge,
                        )
                    elif starting_point == "Existing input.json + supporting artifacts":
                        # Supporting evidence may itself include a Configuration Manual.
                        if manuals and raw_paths:
                            evidence = build_from_config_manual_and_raw_files(
                                manuals[0], raw_paths, customer=customer, direction=direction,
                                flow_type=flow_type, use_dell_aia=use_aia, manual_primary=True,
                                mapping_knowledge=mapping_knowledge,
                            )
                        elif manuals:
                            evidence = build_from_config_manual(
                                manuals[0], customer=customer, direction=direction, flow_type=flow_type
                            )
                        else:
                            evidence = build_from_raw_files(
                                raw_paths, customer=customer, direction=direction,
                                flow_type=flow_type, use_dell_aia=use_aia, mapping_knowledge=mapping_knowledge,
                            )
                    else:
                        # Customer-files-only really means no input.json is required.
                        # If the received package includes a recognizable Configuration
                        # Manual, use it automatically as structured customer evidence
                        # instead of ignoring values already supplied by the customer.
                        if manuals:
                            if raw_paths:
                                evidence = build_from_config_manual_and_raw_files(
                                    manuals[0], raw_paths, customer=customer, direction=direction,
                                    flow_type=flow_type, use_dell_aia=use_aia, manual_primary=True,
                                    mapping_knowledge=mapping_knowledge,
                                )
                            else:
                                evidence = build_from_config_manual(
                                    manuals[0], customer=customer, direction=direction, flow_type=flow_type
                                )
                            evidence.setdefault("_builder_audit", {})["automatic_configuration_manual"] = {
                                "filename": manuals[0].name,
                                "source": "received customer files",
                                "note": "No input.json was supplied; customer Configuration Manual was auto-detected and consumed.",
                            }
                        else:
                            evidence = build_from_raw_files(
                                raw_paths or paths, customer=customer, direction=direction,
                                flow_type=flow_type, use_dell_aia=use_aia, mapping_knowledge=mapping_knowledge,
                            )
                manifest = [x.name for x in uploads]
                st.session_state["ib_source_files"] = [[x.name, x.getvalue()] for x in uploads]
                st.session_state.pop("ib_source_zip", None)
                st.session_state["ib_saved_artifact_mode"] = "Individual files"

            if starting_point == "Existing input.json + supporting artifacts":
                canonical = combine_existing_input_with_artifact_evidence(
                    input_raw or {}, evidence, manifest=manifest, customer=customer,
                    direction=direction, flow_type=flow_type,
                )
                # A clean input.json + file pair is a supervised reference for the
                # reusable mapping learner. It learns structure/roles only, never
                # secrets or customer-specific values.
                if not list(((canonical.get("_artifact_validation") or {}).get("blockers") or [])):
                    learned = record_mapping_example(root, canonical, manifest, source_kind="validated_input_json_plus_customer_files")
                    st.session_state["ib_mapping_learning_summary"] = mapping_learning_summary(learned)
            else:
                canonical = evidence
            if canonical.get("_error"):
                raise ValueError(str(canonical["_error"]))

            # Explicit user request is a first-class input source. It can refine
            # flow type/direction/names/IDs but cannot change hip-automation or
            # invent secrets. The strict Passthrough policy is re-applied here.
            if user_request.strip():
                canonical, _ = apply_user_request_hints(
                    root, canonical, user_request, use_aia=use_aia,
                )
            if passthrough_target_exception:
                canonical["passthrough_target_document_type_required"] = True
                canonical = normalize_input_json(
                    canonical, customer=str(canonical.get("customer") or customer),
                    direction=str(canonical.get("direction") or direction),
                    flow_type=str(canonical.get("flow_type") or flow_type),
                )
            canonical = apply_selected_interfaces(root, canonical, src_key, tgt_key)
            st.session_state["ib_canonical"] = canonical
            st.session_state["ib_manifest"] = manifest
            st.session_state["ib_saved_mode"] = starting_point
            for key in ("ib_validation", "ib_inventory", "ib_live_result"):
                st.session_state.pop(key, None)
            st.rerun()
        except Exception as exc:
            st.error(f"Input Builder failed: {exc}")

    canonical = st.session_state.get("ib_canonical")
    if not isinstance(canonical, dict):
        st.caption("Upload customer artifacts, choose an interface, then click **Agent ingest + generate input.json**. The agent can learn from files and your request.")
        return
    canonical = apply_selected_interfaces(root, canonical, src_key, tgt_key)
    st.session_state["ib_canonical"] = canonical

    st.markdown("### 3 · Generated canonical input")
    st.dataframe(_summary_rows(canonical), width="stretch", hide_index=True)
    a1, a2, a3 = st.columns(3)
    a1.metric("Completeness", canonical.get("completeness") or "—")
    a2.metric("Accuracy", canonical.get("accuracy") or "—")
    a3.metric("Deployment", DEFAULT_DEPLOYMENT_GROUP)
    with st.expander("Preview input.json", expanded=False):
        st.json(redact_sensitive(canonical))
    st.download_button("⬇ Download generated input.json", json.dumps(canonical, indent=2, ensure_ascii=False), "input.json", "application/json", width="stretch", key="ib_download_early")

    file_mapping = canonical.get("_file_mapping") if isinstance(canonical.get("_file_mapping"), dict) else {}
    if file_mapping:
        st.markdown("#### 📎 How uploaded files mapped into input.json")
        fm1, fm2, fm3 = st.columns(3)
        fm1.metric("Source file", (file_mapping.get("source") or {}).get("filename") or "Unresolved")
        fm2.metric("Source format", (file_mapping.get("source") or {}).get("data_format_type") or "Unresolved")
        fm3.metric("Target format", (file_mapping.get("target") or {}).get("data_format_type") or "N/A / unresolved")
        rows = file_mapping.get("fieldMappings") or []
        if rows:
            st.dataframe(rows, width="stretch", hide_index=True)
        for warning in file_mapping.get("warnings") or []:
            st.warning(warning)

    user_request_audit = ((canonical.get("_builder_audit") or {}).get("user_request") or {}) if isinstance(canonical, dict) else {}
    if user_request_audit and user_request_audit.get("request"):
        st.markdown("#### 🧠 Learned from your request")
        ur1, ur2 = st.columns(2)
        ur1.metric("Request-derived values", len(user_request_audit.get("applied") or []))
        ur2.metric("Clarifications", len(user_request_audit.get("questions") or []))
        with st.expander("Show request → input.json audit", expanded=False):
            st.json(redact_sensitive(user_request_audit))

    artifact_validation = canonical.get("_artifact_validation") if isinstance(canonical.get("_artifact_validation"), dict) else {}
    if artifact_validation:
        st.markdown("#### 🔎 input.json ↔ supporting-artifact validation")
        av1, av2, av3, av4 = st.columns(4)
        av1.metric("Related files", artifact_validation.get("fileCount", 0))
        av2.metric("Matched", len(artifact_validation.get("matched") or []))
        av3.metric("Warnings", len(artifact_validation.get("warnings") or []))
        av4.metric("Blockers", len(artifact_validation.get("blockers") or []))
        if artifact_validation.get("blockers"):
            st.error("Supporting files conflict with or do not satisfy the active input.json. Re-upload the correct files or correct input.json before API mapping.")
        elif artifact_validation.get("warnings"):
            st.warning("The files were ingested with review warnings. Explicit input.json values remain authoritative.")
        else:
            st.success("✓ input.json and the uploaded supporting artifacts are consistent for the checked fields.")
        with st.expander("Artifact validation details", expanded=bool(artifact_validation.get("blockers"))):
            st.json(redact_sensitive(artifact_validation))

    st.markdown("### 4 · Agent asks only for values it cannot determine")
    questions = unresolved_questions(root, canonical, src_key, tgt_key)
    required = [q for q in questions if not q.get("informational")]
    review = [q for q in questions if q.get("informational")]
    remembered = load_answer_memory(root, canonical.get("customer") or "", src_key, tgt_key)
    if not questions:
        st.success("✓ No unresolved values remain.")
    else:
        st.info(f"{len(required)} required value(s) + {len(review)} business confirmation(s). Deployment group is never asked because it is fixed to `{DEFAULT_DEPLOYMENT_GROUP}`.")
        answers: Dict[str, Any] = {}
        for i, q in enumerate(questions, 1):
            with st.container(border=True):
                st.markdown(f"**{i}. {q.get('label')}**")
                st.caption(q.get("why") or "")
                answers[q["id"]] = _answer_widget(q, remembered)
        remember = st.checkbox("Remember non-secret answers for this customer + interface", value=True, key="ib_remember")
        if st.button("✓ Apply answers + agent re-check", type="primary", width="stretch", key="ib_apply_answers"):
            try:
                updated, applied = apply_answers(root, canonical, questions, answers, src_key, tgt_key)
                if remember:
                    save_answer_memory(root, updated.get("customer") or "", src_key, tgt_key, questions, answers)
                st.session_state["ib_canonical"] = updated
                st.session_state.pop("ib_validation", None)
                st.success(f"Applied {len(applied)} answer(s).")
                st.rerun()
            except Exception as exc:
                st.error(f"Could not apply answers: {exc}")

    canonical = st.session_state.get("ib_canonical") or canonical
    remaining = unresolved_questions(root, canonical, src_key, tgt_key)
    blockers = [q for q in remaining if not q.get("informational")]
    artifact_blockers = list(((canonical.get("_artifact_validation") or {}).get("blockers") or [])) if isinstance(canonical, dict) else []
    st.markdown("### 5 · Map input.json to the 18 HIP APIs + validate")
    st.caption("Validation constructs/criticizes requests without mutation. Every actual Run/Test/Launch action is LIVE-only.")
    if blockers:
        st.warning(f"Resolve {len(blockers)} required value(s) above before final API validation.")
    if artifact_blockers:
        st.error(f"Resolve {len(artifact_blockers)} supporting-artifact blocker(s) by correcting/re-uploading the related files before final API validation.")
    if st.button("🧩 Map to 18 APIs + agent validate", type="primary", width="stretch", disabled=bool(blockers or artifact_blockers), key="ib_map_validate"):
        try:
            with tempfile.TemporaryDirectory(prefix="hip_builder_backup_") as td:
                backup = Path(td)
                backup_active_state(root, backup)
                try:
                    saved_artifact_mode = st.session_state.get("ib_saved_artifact_mode")
                    if saved_artifact_mode == "ZIP bundle" and st.session_state.get("ib_source_zip"):
                        file_count = extract_input_zip(st.session_state["ib_source_zip"], root / "input_files").get("fileCount", 0)
                    elif saved_artifact_mode == "Individual files":
                        pairs = [(x[0], x[1]) for x in (st.session_state.get("ib_source_files") or [])]
                        file_count = replace_input_files_from_pairs(pairs, root / "input_files").get("fileCount", 0)
                    else:
                        file_count = 0
                    activate_input(canonical, True)
                    try:
                        from run_agent import Runner
                        runner = Runner(llm_enabled=False)
                    except Exception:
                        runner = None
                    flow, warnings = infer_flow_from_input(canonical, runner=runner)
                    save_scratch_flow(root, flow)
                    validation = run_local_request_checks(root)
                    inventory = request_inventory(root)
                except Exception:
                    restore_active_state(root, backup)
                    raise
            st.session_state["ib_validation"] = redact_sensitive(validation)
            st.session_state["ib_inventory"] = inventory
            st.session_state["ib_activation"] = {"fileCount": file_count, "warnings": warnings}
            st.rerun()
        except Exception as exc:
            st.error(f"API mapping/validation failed; the previous active configuration was restored. {exc}")

    validation = st.session_state.get("ib_validation")
    if not isinstance(validation, dict):
        return
    req = validation.get("requests") or {}
    v1, v2, v3, v4 = st.columns(4)
    v1.metric("Agent verdict", "PASS" if validation.get("ok") else "BLOCKED")
    v2.metric("Mapper", "PASS" if (validation.get("mapper") or {}).get("ok") else "BLOCKED")
    v3.metric("API contracts", f"{req.get('validCount', 0)}/{req.get('total', 0)}")
    v4.metric("Execution", "LIVE ONLY")
    try:
        st.plotly_chart(validation_figure(validation), use_container_width=True, config={"scrollZoom": True, "displaylogo": False, "responsive": True})
    except Exception as exc:
        st.caption(f"Interactive validation graph unavailable: {exc}")

    inventory = st.session_state.get("ib_inventory") or {}
    rows = [{"#": c.get("order"), "API": c.get("label"), "Group": c.get("group"), "Method": c.get("method"), "Decision": c.get("decision")} for c in inventory.get("cards") or []]
    if rows:
        st.dataframe(rows, width="stretch", hide_index=True)
    with st.expander("Inspect the 18 effective API requests", expanded=False):
        for card in inventory.get("cards") or []:
            with st.expander(f"{card.get('order')}. {card.get('label')}"):
                st.code(f"{card.get('method')} {card.get('url')}")
                st.json(card.get("effective") or {})

    manifest = st.session_state.get("ib_manifest") or []
    d1, d2, d3 = st.columns(3)
    d1.download_button("⬇ input.json", json.dumps(canonical, indent=2, ensure_ascii=False), "input.json", "application/json", width="stretch", key="ib_final_input")
    d2.download_button("⬇ Configuration Manual", build_profile_runner_manual_bytes(canonical), "configuration_manual_profile_runner_ready.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", width="stretch", key="ib_final_cm")
    d3.download_button("⬇ Builder bundle", build_bundle_bytes(canonical, manifest), "HIP_input_builder_bundle.zip", "application/zip", width="stretch", key="ib_final_bundle")
    st.download_button("⬇ Agent audit report", build_audit_report_html(canonical, manifest), "input_builder_audit.html", "text/html", width="stretch", key="ib_audit")

    n1, n2 = st.columns(2)
    if n1.button("🧪 Open API Testing Area", width="stretch", key="ib_to_testing"):
        request_workspace_switch(st, "🧪 API Testing Area")
    if n2.button("🎮 Open API Flow Game", width="stretch", key="ib_to_game"):
        request_workspace_switch(st, "🎮 API Flow Game")

    if validation.get("ok"):
        st.markdown("#### ⚡ Ready for parallel configuration agents")
        st.caption("Freeze this validated configuration so it can run concurrently with other validated customers. The snapshot contains no OAuth credentials; live agents use the normal local credential configuration.")
        queue_label = st.text_input("Queue label (optional)", value=str(canonical.get("customer") or "") + " · " + str(canonical.get("profile_name") or ""), key="ib_parallel_queue_label")
        q1, q2 = st.columns(2)
        if q1.button("➕ Add validated configuration to parallel queue", width="stretch", key="ib_add_parallel_queue"):
            try:
                queued = snapshot_validated_configuration(root, validation, label=queue_label)
                st.success(f"Queued {queued.get('customer')} · {queued.get('flow')} for parallel LIVE execution.")
            except Exception as exc:
                st.error(f"Could not queue validated configuration: {exc}")
        if q2.button("⚡ Open Parallel Configurations", width="stretch", key="ib_open_parallel"):
            request_workspace_switch(st, "⚡ Parallel Configurations")

    st.markdown("### 6 · Run generated configuration LIVE")
    if validation.get("ok"):
        st.success("✓ Agent validation passed. This uses the same dependency-aware live runner as U-HAUL.")
    else:
        st.error("⛔ Fix validation blockers before running live.")
    ack = st.checkbox("I confirm this generated configuration should call the configured LIVE HIP APIs", key="ib_live_ack")
    if st.button("🚀 RUN FULL CONFIGURATION LIVE", type="primary", width="stretch", disabled=not (validation.get("ok") and ack), key="ib_run_live"):
        logs: List[str] = []
        status = st.status("Running generated configuration LIVE...", expanded=True)
        proc = subprocess.Popen([sys.executable, "-u", "run_agent.py"], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1)
        if proc.stdout:
            for line in proc.stdout:
                text = line.rstrip(); logs.append(text); st.write(text)
        rc = proc.wait()
        st.session_state["ib_live_result"] = {"rc": rc, "logs": "\n".join(logs)}
        status.update(label="Live configuration completed" if rc == 0 else "Live configuration completed with blocker/error", state="complete" if rc == 0 else "error")
        st.rerun()
    live = st.session_state.get("ib_live_result")
    if live:
        st.success("✓ Live HIP configuration completed.") if live.get("rc") == 0 else st.error("⛔ Live runner returned a blocker/error. Review the agent report.")
        with st.expander("Live execution log", expanded=False):
            st.code(live.get("logs") or "")
