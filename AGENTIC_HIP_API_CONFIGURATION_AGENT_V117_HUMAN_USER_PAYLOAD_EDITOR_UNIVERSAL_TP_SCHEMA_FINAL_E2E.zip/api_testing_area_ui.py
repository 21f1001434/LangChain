from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict

import streamlit as st

from application_studio import request_inventory
from business_demo import agent_response_verdict
from payload_overrides import clear_override, save_override
from payload_ui_helpers import (
    apply_quick_field_change,
    display_json_value,
    json_field_paths,
    parse_json_value,
    safe_request_for_ui,
)
from production_guard import redact_sensitive
from run_agent import Runner


def _active_summary(root: Path) -> Dict[str, Any]:
    try:
        value = json.loads((root / "input.json").read_text(encoding="utf-8"))
    except Exception:
        value = {}
    objects = value.get("objects") if isinstance(value.get("objects"), dict) else {}
    flow = objects.get("biz_flow") if isinstance(objects.get("biz_flow"), dict) else {}
    details = flow.get("flow_details") if isinstance(flow.get("flow_details"), dict) else {}
    return {
        "customer": value.get("customer") or "—",
        "direction": value.get("direction") or "—",
        "transaction": " ".join(str(value.get(k) or "") for k in ("tx_standard", "tx_code", "tx_name")).strip() or "—",
        "flow": value.get("profile_name") or details.get("business_flow_name") or "—",
    }


def _effective_value(card: Dict[str, Any]) -> Dict[str, Any]:
    value = card.get("effective")
    return deepcopy(value) if isinstance(value, dict) else {}


def render_api_testing_area(root: Path, mcp: Any = None) -> None:
    root = Path(root)
    st.markdown("## 🧪 API Testing Area")
    st.caption("Test any of the 18 HIP APIs against the currently active uploaded/U-HAUL configuration. Payload edits are saved per API and the actual Run button always calls the LIVE endpoint.")

    summary = _active_summary(root)
    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Customer", summary["customer"])
    s2.metric("Transaction", summary["transaction"])
    s3.metric("Direction", summary["direction"])
    s4.metric("Flow", summary["flow"])

    inventory = request_inventory(root)
    cards = inventory.get("cards") or []
    if not cards:
        st.error("No API requests could be generated from the active input.json. Upload/activate a configuration first.")
        return

    st.success(f"{len(cards)}/18 API requests generated from the active configuration.")
    labels = {f"{row.get('order')}. {row.get('label')}": row for row in cards}
    selected_label = st.selectbox("Choose API", list(labels), key="generic_api_testing_selected")
    card = labels[selected_label]
    step_key = str(card.get("stepKey") or "")
    request_kind = str(card.get("requestKind") or "payload")
    effective = _effective_value(card)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Method", card.get("method") or "—")
    m2.metric("Request", request_kind.upper())
    m3.metric("Edited", "YES" if card.get("edited") else "NO")
    m4.metric("Execution", "LIVE ONLY")

    st.markdown(f"### {card.get('label')}")
    st.caption(card.get("businessMeaning") or "")
    tabs = st.tabs(["⚡ Easy field change", "🧾 Full JSON", "👀 Generated vs effective"])

    with tabs[0]:
        fields = json_field_paths(effective)
        if not fields:
            st.info("This request currently has no editable fields.")
        else:
            by_path = {row["path"]: row for row in fields}
            path = st.selectbox("Field", list(by_path), key=f"api_easy_path_{step_key}")
            row = by_path[path]
            value_text = st.text_area(
                f"New value · {row.get('type')}",
                value=display_json_value(row.get("value")),
                height=100,
                key=f"api_easy_value_{step_key}_{path}",
            )
            if st.button("✓ Apply this field change", type="primary", width="stretch", key=f"api_easy_apply_{step_key}"):
                try:
                    parsed = parse_json_value(value_text, str(row.get("type") or "string"))
                    updated = apply_quick_field_change(effective, path, parsed)
                    preview_runner = Runner(llm_enabled=False)
                    preview = preview_runner.preview_step_request(step_key)
                    if mcp is not None:
                        critic = mcp.validate_api_request(
                            api_key=preview.get("urlKey") or step_key,
                            method=preview.get("method") or "GET",
                            url=preview.get("url") or "",
                            headers=preview.get("extraHeaders") or {},
                            payload=updated if request_kind == "payload" else None,
                            params=updated if request_kind == "params" else None,
                        )
                        if not critic.get("valid", True):
                            st.error("MCP/API contract validation blocked this field change.")
                            st.json(critic)
                            return
                    save_override(root, step_key, updated, request_kind=request_kind, mode="replace", note=f"Easy field edit: {path}", edit_origin="USER")
                    st.success(f"Saved {path}. The next live request will use this value.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Could not apply the field change: {exc}")

    with tabs[1]:
        text = st.text_area(
            "Complete effective request JSON",
            value=json.dumps(effective, indent=2, ensure_ascii=False),
            height=430,
            key=f"api_full_json_{step_key}",
        )
        parsed = None
        try:
            parsed = json.loads(text)
            if not isinstance(parsed, dict):
                raise ValueError("Request must remain a JSON object")
            st.caption("✓ JSON valid")
        except Exception as exc:
            st.error(str(exc))
        a1, a2 = st.columns(2)
        if a1.button("Save full request", type="primary", disabled=parsed is None, width="stretch", key=f"api_full_save_{step_key}"):
            try:
                preview_runner = Runner(llm_enabled=False)
                preview = preview_runner.preview_step_request(step_key)
                if mcp is not None:
                    critic = mcp.validate_api_request(
                        api_key=preview.get("urlKey") or step_key,
                        method=preview.get("method") or "GET",
                        url=preview.get("url") or "",
                        headers=preview.get("extraHeaders") or {},
                        payload=parsed if request_kind == "payload" else None,
                        params=parsed if request_kind == "params" else None,
                    )
                    if not critic.get("valid", True):
                        st.error("MCP/API contract validation blocked this request.")
                        st.json(critic)
                        return
                save_override(root, step_key, parsed, request_kind=request_kind, mode="replace", note="API Testing Area full edit", edit_origin="USER")
                st.success("Saved.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))
        if a2.button("Restore generated request", width="stretch", key=f"api_reset_{step_key}"):
            clear_override(root, step_key)
            st.rerun()

    with tabs[2]:
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**Generated from active input.json**")
            st.json(safe_request_for_ui(card.get("generated") or {}))
        with c2:
            st.markdown("**Effective request used LIVE**")
            st.json(safe_request_for_ui(effective))

    st.divider()
    st.markdown("### 🚀 Live test selected API")
    ack = st.checkbox("I confirm this sends the selected request to the configured LIVE HIP endpoint", key=f"generic_api_live_ack_{step_key}")
    if st.button(f"🚀 RUN {card.get('label')} LIVE", type="primary", width="stretch", disabled=not ack, key=f"generic_api_live_{step_key}"):
        try:
            with st.status(f"Calling {card.get('label')} LIVE...", expanded=True) as status:
                runner = Runner(llm_enabled=True)
                result = runner.run_single_step(step_key)
                raw = asdict(result)
                verdict = agent_response_verdict(raw)
                payload = {"stepKey": step_key, "result": redact_sensitive(raw), "agentVerdict": verdict}
                (root / "reports").mkdir(exist_ok=True)
                (root / "reports" / "api_testing_area_latest.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
                st.session_state["generic_api_testing_result"] = payload
                status.update(label=f"{card.get('label')} · {verdict.get('verdict')}", state="complete" if verdict.get("verdict") == "PASS" else "error")
        except Exception as exc:
            st.session_state["generic_api_testing_result"] = {
                "stepKey": step_key,
                "result": {"error": str(exc)},
                "agentVerdict": {"verdict": "BLOCKED", "outcome": "CLIENT_ERROR", "reason": str(exc), "nextAction": "Correct the request/configuration and retry."},
            }
        st.rerun()

    latest = st.session_state.get("generic_api_testing_result") or {}
    if latest.get("stepKey") == step_key:
        verdict = latest.get("agentVerdict") or {}
        result = latest.get("result") or {}
        if verdict.get("verdict") == "PASS":
            st.success(f"✓ PASS · {verdict.get('outcome') or 'WORKED'}")
        else:
            st.error(f"⛔ BLOCKED · {verdict.get('outcome') or 'BLOCKER'}")
        elapsed_ms = result.get("elapsed_ms") if isinstance(result, dict) else None
        if elapsed_ms is not None:
            st.metric("Step completion time", f"{float(elapsed_ms) / 1000:.3f} s")
        st.markdown(f"**Agent response analysis:** {verdict.get('reason') or 'No explanation available.'}")
        st.caption(f"Next: {verdict.get('nextAction') or 'Review response evidence.'}")
        with st.expander("Live request/response evidence", expanded=False):
            st.json(safe_request_for_ui(result))
