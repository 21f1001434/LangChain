from __future__ import annotations

import asyncio
import json
from pathlib import Path

from webapp.backend.app.parallel_manager import ParallelManager

ROOT = Path(__file__).resolve().parent


def test_v40_responsive_overflow_hardening_is_present():
    css = (ROOT / 'webapp/frontend/src/styles.css').read_text(encoding='utf-8')
    assert 'min-width:1180px' not in css
    assert 'body{margin:0;min-width:0' in css
    assert '.sidebar nav{min-height:0;overflow-y:auto' in css
    assert '.flow-page{height:100vh;min-height:0' in css
    assert '.flow-shell{height:auto!important;flex:1 1 auto;min-height:0' in css
    assert '@media(max-width:1100px)' in css
    assert '@media(max-width:760px)' in css


def test_v40_flow_game_has_collapsible_panels_fit_and_automatic_preflight():
    flow = (ROOT / 'webapp/frontend/src/pages/FlowGamePage.tsx').read_text(encoding='utf-8')
    assert 'deckOpen' in flow and 'railOpen' in flow
    assert 'Hide blocks' in flow and 'Hide templates' in flow
    assert 'fitView({padding:.2,duration:300})' in flow
    assert 'if(!checked?.readyForLive)' in flow
    assert 'Automatic preflight PASS' in flow
    assert 'LIVE blocked by preflight' in flow


def test_v40_parallel_page_has_live_board_and_batch_recovery():
    page = (ROOT / 'webapp/frontend/src/pages/ParallelPage.tsx').read_text(encoding='utf-8')
    assert 'Select all ready' in page
    assert 'execution waves' in page
    assert 'LIVE EXECUTION BOARD' in page
    assert 'liveJobs' in page
    assert 'recovering the batch state from FastAPI' in page
    assert 'api.parallelBatch(b.batchId)' in page


def test_v40_app_restores_last_page_and_configuration():
    app = (ROOT / 'webapp/frontend/src/App.tsx').read_text(encoding='utf-8')
    assert "localStorage.getItem('hip.page')" in app
    assert "localStorage.setItem('hip.page'" in app
    assert "localStorage.getItem('hip.activeConfigurationId')" in app
    assert "localStorage.setItem('hip.activeConfigurationId'" in app


class _Store:
    def __init__(self, root: Path):
        self.root = root


def test_v40_parallel_manager_persists_live_job_state_for_reconnect(tmp_path: Path):
    manager = ParallelManager(_Store(tmp_path))
    batch = 'batch_test'
    folder = manager.run_root / batch
    folder.mkdir(parents=True)
    (folder / 'summary.json').write_text(json.dumps({
        'batchId': batch,
        'status': 'QUEUED',
        'events': [],
        'jobs': {'j1': {'jobId': 'j1', 'label': 'Customer A', 'customer': 'A', 'status': 'QUEUED'}},
    }), encoding='utf-8')
    loop = asyncio.new_event_loop()
    try:
        manager._publish(batch, {'type': 'batch.started', 'batchId': batch}, loop)
        manager._publish(batch, {'type': 'job.started', 'jobId': 'j1', 'label': 'Customer A', 'customer': 'A', 'startedAt': '2026-08-17T18:00:00+00:00'}, loop)
        manager._publish(batch, {'type': 'job.heartbeat', 'jobId': 'j1', 'lines': 25}, loop)
        row = manager.get_batch(batch)
        assert row['status'] == 'RUNNING'
        assert row['jobs']['j1']['status'] == 'RUNNING'
        assert row['jobs']['j1']['lines'] == 25
        manager._publish(batch, {'type': 'job.completed', 'jobId': 'j1', 'status': 'PASS', 'elapsedSeconds': 4.2}, loop)
        row = manager.get_batch(batch)
        assert row['jobs']['j1']['status'] == 'PASS'
        assert row['jobs']['j1']['elapsedSeconds'] == 4.2
    finally:
        loop.close()
