# START HERE — V117 Human-Only Payload Value Editor + Stable TP Contract + HTTPS Receiver Dev Candidate

**Current release:** V117 — only a HUMAN USER may edit approved payload/parameter leaf values pre-LIVE; the AI agent cannot edit values. The developer-approved structure remains locked. Source/Target TP identity edits synchronize canonical input. SFTP and HTTPS Transport Profile outer attributes are identical; only interfaceDetails changes. Plain HTTPS Receiver SSL-certificate fields are omitted from the Dev-validation candidate. V116 Flow EXISTING → Deploy and V115 Rule name+version corrections are retained.

## Current production rules

- Default deployment group is **`hip-automation`** everywhere. `deployment_group`, `deployment-group`, `deploymentGroup`, and `deploymentGroupName` spellings are normalized to the same value when present.
- The approved 18 HIP API **structures are immutable**. In API Testing, users may edit approved leaf **values** before LIVE; method, URL, protected headers, request kind, attribute names, nesting and array cardinality remain locked. Saved edits are audited and frozen by the LIVE request fingerprint.
- Customer-specific business values can be changed in **Build Configuration** or the schema-locked **Payload Value Editor**, then revalidated. Source/Target Transport Profile name edits are promoted to canonical input so validate/create/audit/dependent requests remain consistent. Runtime dependencies may populate only existing approved attributes.
- In LIVE no-reuse mode, the MAC Map API is executed like every other applicable canonical API. A same-call duplicate/uniqueness response may be recorded as that API's **EXISTING** evidence, but no packaged/historical Map ID is pre-seeded or allowed to substitute for the current run.
- Strict whole-pipeline LIVE execution still calls the approved HIP APIs needed for the configured flow and captures live request/response evidence; this policy prevents mutation of the API definition/payload contract, not the approved HIP object lifecycle itself.
- Normal Windows startup is stable and does not use repository-wide Uvicorn `--reload`.

See `README_FINAL_V117_PAYLOAD_VALUE_EDITOR_HTTPS_RECEIVER_DEV_CANDIDATE.md` for the current implementation and validation rules.

## Run

1. Extract into a fresh folder.
2. Run `SETUP_AGENTIC_HIP.bat` once.
3. Use `RUN_AGENTIC_HIP.bat` for normal startup.
4. Use Ctrl+F5 once after upgrading from an older extracted release.

## V96 strict whole-pipeline LIVE execution

For production LIVE behavior, see `README_FINAL_V96_STRICT_FULL_LIVE_PIPELINE.md`. RUN LIVE EXECUTION now ignores skip assumptions and requires a real HTTP result from every applicable canonical API (18/18 for the approved U-HAUL Translation flow), with per-API request/response evidence.


## V98 startup stability

- `RUN_AGENTIC_HIP.bat` uses stable Uvicorn mode with no WatchFiles reloader.
- `RUN_AGENTIC_HIP_DEV.bat` / `.ps1` also default to stable backend mode; the frontend still uses Bun/Vite HMR.
- Optional backend hot reload: set `HIP_BACKEND_HOT_RELOAD=1` before running the DEV launcher. Reload watching is then restricted to `webapp/backend/app`.
- This specifically prevents the repeated `WatchFiles detected changes ... Reloading...` loop on OneDrive-backed folders.
- A traceback ending in `KeyboardInterrupt` after repeated WatchFiles reloads is a consequence of the reloader being interrupted, not a FastAPI import failure.

## Business handoff certification

The final package has passed the non-mutating business-readiness suite and all packaged release validators. See `README_FINAL_V117_PAYLOAD_VALUE_EDITOR_HTTPS_RECEIVER_DEV_CANDIDATE.md` and `FINAL_CERTIFICATION_SUMMARY.json`.




## V117 human-user-only Payload Value Editor + stable Transport Profile contract + HTTPS Receiver candidate (2026-09-01)


- **Agent authority:** READ/ANALYZE/VALIDATE only. The AI/AutoGen/Dell-AIA layer cannot save, clear, or apply payload value edits.
- **Human authority:** an explicit user action may edit only values of existing canonical fields before LIVE. The edit is audited and then frozen by the immutable request fingerprint.
- **Transport Profile invariant:** FILE/SFTP and plain HTTPS use the exact same Transport Profile outer payload attributes/nesting. Only `interfaceDetails` (`interfaceType` + `parameters`) changes by interface family.
- **HTTPS Receiver candidate:** inside `interfaceDetails.parameters`, plain HTTPS omits `SSL Certificate`, `SSL Certificate CN - Expiry`, and `SSL Certificate Id`. HTTPS-AS2 is separate and unchanged.

- Every applicable canonical API payload/params object can be edited in API Testing before LIVE, but only existing leaf values may change.
- Method, URL, protected headers, request kind, attribute names, nesting and array cardinality are locked. The agent cannot add/remove API fields through this editor.
- Saved value edits are persisted with an audit trail and become immutable once the LIVE request is materialized/fingerprinted.
- Source and Target Transport Profile `transportProfileName` edits synchronize canonical customer input, so validation, create, audit/history and dependent requests use the same identity.
- Plain HTTPS Receiver candidate omits `SSL Certificate`, `SSL Certificate CN - Expiry`, and `SSL Certificate Id` pending Dev confirmation. HTTPS-AS2 certificate/encryption fields are unchanged.


## V116 Flow EXISTING → Deploy correction (2026-09-01)

- Flow Create remains mandatory and is executed in the current strict-LIVE run.
- If that exact HIP response says the canonical Flow name already exists, the result is PASS / EXISTING and satisfies the Flow Deploy dependency.
- Deploy uses the same canonical Flow name + version; no historical Flow ID is loaded or injected.
- The agent does not rename Flow after a duplicate response and does not change the request payload.
- Genuine Flow-name length/character/format errors remain FLOW_NAME_INVALID and block Deploy.
- Flow Deployment History is allowed after a valid Deploy execution/result.

## V115 Dev-team contract correction (2026-09-01)

- **Flow Rule reference:** `flowDefinition.targetDetails.targets[*].processSteps[*].configuration.defaultConfig.ruleRefs.ruleDetails` now contains only Mapping Rule `name` + `version`. Numeric `id` is omitted.
- **No Rule-ID blocker:** Rule PASS/EXISTING can progress directly to Flow Create based on the actual Rule API response; `LIVE_RULE_ID_UNRESOLVED` is no longer part of the canonical LIVE dependency path.
- **No Rule inventory workaround:** canonical LIVE execution does not perform a secondary Rule-ID lookup, because Dev confirmed the ID is not required in the Flow request.
- **Account/System/Partner:** the migration 404 incident was fixed by the Dev/API team. These APIs continue to execute normally with their approved payloads; no stale outage state is reused across runs.
- **Unchanged safety:** no packaged/historical IDs, no `EXISTING_REUSED`, no post-error payload mutation, no post-error Flow rename, and every applicable canonical API is still executed.


## V114 Windows worker / JSON boundary protections

- **Noisy stdout safe:** readiness, configuration validation, API preview, Flow preflight and production preflight extract the authoritative current worker JSON even when Windows/MCP/evidence warnings are emitted around it.
- **Machine-readable stdout discipline:** best-effort persistence warnings are written to stderr, so child-process JSON remains clean.
- **No false pre-LIVE JSONDecodeError:** the parallel safety gate no longer blocks at 0 ms merely because a benign diagnostic preceded the JSON result.
- **Effective Flow-name reporting:** an old queued manifest cannot display a stale >40-character Flow name after the staged input has already been canonically normalized.
- **Browser startup cleanliness:** `/favicon.ico` returns 204 instead of a misleading 404 terminal entry.
- All V113 future-customer Flow-name normalization, immutable request and no-reuse protections are retained. The V113 Rule-ID lookup workaround is superseded by the V115 Dev-approved name+version Flow contract.

## V113 generalized future-customer protections (Rule-ID lookup portion superseded by V115)

- **Generic Flow-name policy:** every customer, not only LEGRAND, is normalized to HIP's <=40-character rule before LIVE request materialization. Only structural flow tokens are abbreviated; customer/business terms are preserved. If still too long, a deterministic SHA-256-derived digest prevents naive truncation collisions.
- **Alias reconciliation:** `profile_name`, `flow_name`, `objects.biz_flow.flow_name`, and `objects.biz_flow.flow_details.business_flow_name` are reconciled to one value. Normalization is copy-based so queue/preflight/Runner can reliably persist a repaired staged input.
- **Historical V113 Rule-ID resolver (superseded):** V113 used current-LIVE GET evidence when Flow still appeared to require a Rule ID. V115 no longer invokes this resolver because Dev confirmed Flow uses Rule name + version only.
- **Accurate blocker reporting:** batch summaries prefer the actual blocked canonical API/dependency over the generic `Final pre-LIVE safety gate` fallback. `LIVE_RULE_ID_UNRESOLVED` is retained only for historical report interpretation and is not a V115 canonical dependency.
- **External route boundary:** Account/Partner/System missing-PCF-route responses remain Dell platform errors. V113 reports them accurately and accepts API-team replacement URLs through the existing endpoint overrides; it does not guess or mutate the approved requests.

## V112 latest 02:17 LIVE-run corrections (Rule-ID lookup portion superseded by V115)

- **LEGRAND persisted-name reconciliation:** both top-level `profile_name` and nested `business_flow_name` are reconciled to the same <=40-character canonical name before queue hashing, final pre-LIVE validation, and direct Runner request construction. This fixes the exact case where nested data was already `..._MAP_IB` but top-level data still held `..._MAPPING_IB`.
- **Historical V112 Rule ID lookup (superseded by V115):** no longer used in canonical LIVE execution.
- **Historical read-only resolution:** retained only as legacy diagnostic code; canonical V115 LIVE execution does not call it.
- `HIP_RULE_LOOKUP_MAX_PAGES` now defaults to 25, with repeat/empty/error response detection to stop unsupported pagination quickly.

## V111 latest LIVE-run corrections (Rule-ID lookup portion superseded by V115)

- **Historical V111 Rule identity lookup (superseded by V115):** no longer part of canonical execution.
- **U-HAUL TP audit:** CREATE-only orchestration is verified against CREATE audit history, so unrelated newer failed EDIT records do not create false retries.
- **LEGRAND Flow naming:** invalid >40-character flow names are deterministically compacted while building canonical input, before LIVE request materialization. `LEGRAND_NEDERLAND_PC_850_PREMIER_MAPPING_IB` becomes `LEGRAND_NEDERLAND_PC_850_PREMIER_MAP_IB`.
- **Terminal deterministic errors:** `FLOW_NAME_INVALID` is not blindly retried. `LIVE_RULE_ID_UNRESOLVED` is legacy-only after the V115 contract correction.
- Optional Rule read-endpoint replacements: `HIP_RULE_DETAILS_API_URL` and `HIP_RULE_SUMMARY_API_URL`.

## V109 governed AI-agent improvements

- **Description-triggered skills:** `skills/*.skill.json` descriptions explicitly begin with `Use when ...`; a deterministic router selects from that description plus execution mode.
- **Real expertise provenance:** every skill names approved project sources; the files are required to exist and are SHA-256 hashed into an execution-time expertise digest.
- **Context budgeting:** AutoGen receives only allowlisted task metadata; secret-like keys are redacted, raw/unrelated fields are omitted, and a hard per-skill context budget is enforced.
- **Deterministic execution:** the LLM never constructs HIP requests. It may invoke only the already-governed deterministic executor selected by an allowlisted skill entrypoint.
- **Pre-run vetting:** startup and each LIVE AgentChat run vet the selected skill before model execution. Arbitrary tools, paths, scripts, missing expertise sources, or ambiguous routing fail closed.
- Run `python VET_AGENT_SKILLS.py` for an explicit deterministic skill audit.

## V108 fixes for the 2026-08-29 LIVE reports

- Standalone Mapping Rule now omits `flowDefinitionId` completely. It also continues to omit `documentTypeId` and `actions.params.mapId`. No synthetic parent ID is injected.
- `FK_MAC_RULE_FLOW_DEF` / ORA-02291 is deterministic `API_BACKEND_CONTRACT_MISMATCH` evidence and is non-retriable; auto-completion no longer repeats the same permanent Rule failure.
- Account/Partner/System create APIs remain independently reported. Their route outage is not allowed to hard-block TP orchestration because the approved TP request uses names (`systemName`, `Existing Account Name`, partner name, `deploymentGroupName`) rather than IDs returned by those create calls.
- A TP call may therefore prove that the named foundation object already exists even while the corresponding create-service route is unavailable.
- `HIP_ACCOUNT_API_URL`, `HIP_PARTNER_API_URL`, and `HIP_SYSTEM_API_URL` remain the supported route-replacement controls.

## V106 API ownership and Document Type reuse fixes

- A Document Type create response that explicitly says the object already exists in DEV is **PASS / EXISTING**, even when HIP does not return `documentTypeId`. The approved downstream Mapping Rule and TP orchestration contracts use Document Type **name + version**, so no obsolete numeric-ID gate is applied.
- Mapping Rule still omits `documentTypeId`. A later `RULE_DOCUMENTTYPE` / `FK_RULE_DOCUMENTTYPE` backend error is classified as **API_BACKEND_CONTRACT_MISMATCH**; the runner never performs a fake Document Type ID repair/mutation cycle.
- Dell gateway HTTP 404 responses containing `Requested route (...pcf.dell.com) does not exist` are classified as **API_UPSTREAM_ROUTE_UNAVAILABLE**. They are reported as API/platform routing/deployment failures rather than customer-payload defects and are not repeatedly retried by auto-completion.
- Optional `.env` / UI overrides `HIP_ACCOUNT_API_URL`, `HIP_PARTNER_API_URL`, and `HIP_SYSTEM_API_URL` allow API-team replacement endpoints without changing code or approved payloads.
- V106 build metadata deliberately retains `strict-live` so historical strict-runtime release checks remain meaningful.

## V105 Dev-approved async orchestration rules

- Mapping Rule omits `documentTypeId` and `actions[].params.mapId` entirely. Zero placeholders are not sent.
- Source and Target TP creation are not considered complete at the create response. Their Audit API is polled every 60 seconds until terminal SUCCESS/FAILURE, for at most 3600 seconds.
- Flow Create starts only after both Source and Target TP audits are terminal SUCCESS.
- Flow deployment Audit/History is polled every 60 seconds until terminal SUCCESS/FAILURE, for at most 3600 seconds.
- Historical V105 behavior renamed a Flow after a collision. **This is superseded by V108+**: post-response Flow renaming is prohibited; V112 only normalizes canonical input before LIVE materialization.
- `hip-automation` remains the default deployment group.
- MAP create is always executed in LIVE. A duplicate response is recorded as explicit EXISTING evidence; no packaged `mapId` is injected into downstream requests.

## V108 no-reuse / immutable execution rules
- Every applicable canonical LIVE API is executed; persisted skip plans are ignored by default.
- No downstream API success can rewrite another API failure into `EXISTING_REUSED`.
- Validation failures remain visible even if later APIs succeed.
- Same-step retries are allowed only with the identical request fingerprint.
- Runtime MAP fallback payload mutation and Flow-name auto-rename mutation are removed.
- Persisted payload overrides remain disabled for LIVE execution.

- **LEGRAND stale snapshot upgrade:** queueing and the final staged pre-LIVE gate deterministically canonicalize an old >40-character Flow name before contract validation/request materialization, so configurations created under an earlier release do not need manual rebuilding solely for this naming correction.

## V117 Human payload editing and universal Transport Profile contract

- The AI/agent cannot save, apply or silently change an active API payload value. It may inspect, explain, preflight and report only.
- Only an explicit HUMAN USER action may edit an existing canonical payload/parameter value before LIVE execution.
- Human edits may change values in any applicable API request, including Source/Target Transport Profile names.
- Method, URL, request kind, protected headers, attribute names, nesting and array shape remain immutable.
- Source/Target Transport Profile orchestration uses one fixed outer payload schema for every interface type. SFTP, FTP, HTTPS, HTTPS-AS2 and future approved interfaces vary only inside `transportProfileDetails[0].interfaceDetails` (interface type/role/parameters).
- Plain HTTPS Receiver ignores `SSL Certificate`, `SSL Certificate CN - Expiry`, and `SSL Certificate Id`; HTTPS-AS2 certificate attributes are a separate contract and remain unchanged.
- Once a user-approved effective request is materialized for LIVE, the immutable request fingerprint prevents any retry-time or agent-time change.
