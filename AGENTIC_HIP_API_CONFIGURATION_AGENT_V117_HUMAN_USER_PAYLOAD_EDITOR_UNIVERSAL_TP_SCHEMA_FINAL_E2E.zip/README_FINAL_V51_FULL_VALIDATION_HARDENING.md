# V51 — Full Validation & Execution Hardening

## Scope

V51 is a hardening release on top of V50. It keeps the existing Input Builder, 18 API mapper, inline blocker repair, API Testing Area, Flow Game, templates, single/multi-customer execution and final HTML reports, while tightening correctness around stale validation, queued payload integrity and long-running parallel jobs.

## Correctness improvements

- Any configuration-changing action now invalidates the previous validation immediately: configuration edits, new uploads, Build, and Apply Answers return the customer to NOT VALIDATED until the new payload set is checked.
- API Testing Area no longer infers a per-API READY state from a global validation PASS when the exact contract row is absent. READY requires explicit contract evidence.
- Same-customer instance creation now revalidates the active configuration immediately before cloning it.
- U-HAUL validation/self-check logic is aligned with the current approved behavior: the external partner identity is derived from routing evidence instead of requiring a duplicate manually-entered Partner Identifier.
- Runtime build IDs are consistent across the primary Python entry points and release manifest.

## Single / multi-customer execution hardening

- Single-customer mode now enforces exactly one queued payload set all the way through the execution queue.
- Multi-customer mode requires at least two queued payload sets and exposes Select all ready only in multi mode.
- The final LIVE button follows the selected execution mode rather than silently changing mode based on checkbox count.
- Queue snapshots now hash every execution-critical copied file, including payload_overrides.json, config overrides, execution plans, input files, knowledge and approved reference files. A changed snapshot becomes NOT READY and must be re-queued.
- Ephemeral runtime values expire after four hours; an expired queue item becomes NOT READY instead of failing unexpectedly later.
- Parallel jobs emit heartbeats every two seconds even when the subprocess is quiet.
- Each customer job has a configurable wall-clock watchdog (`HIP_PARALLEL_JOB_TIMEOUT_SECONDS`, default 1800 seconds) so a hung process cannot leave the batch running forever.

## Payload-edit hardening

- Full request body/params editing remains available in API Testing Area and the Flow Game.
- Persistent Save for customer / Clear saved edit actions are now written to the application audit trail without storing the payload value in the audit metadata.
- Saved payload overrides continue to be revalidated immediately and are included in single/multi-customer snapshots.

## Reporting improvements

- The combined single/multi-customer final HTML report remains self-contained.
- When a customer run produced its detailed legacy HTML report, V51 embeds that full report inside the combined report in a collapsible section, preserving requests, responses and verdict evidence in one downloadable HTML file.
- Secrets remain redacted and the embedded customer report is rendered in a sandboxed iframe.

## UX improvements

- FastAPI error bodies are converted into human-readable messages instead of exposing raw `{"detail": ...}` JSON in the UI.
- The global Working spinner timing is corrected for overlapping API requests.
- Queue entries that fail snapshot integrity/runtime-value readiness expose a re-queue reason.

## Validation completed

- Pytest regression suite: **190/190 PASS**.
- `validate_package.py`: **57/57 PASS**.
- `FINAL_RELEASE_VALIDATION.py`: **16/16 PASS**.
- `final_self_check.py`: **43/43 required checks PASS** (Bun availability is advisory in the packaging environment).
- Python `compileall`: PASS.
- TypeScript/TSX syntax transpilation: **21 files, 0 errors**.
- Full npm/Bun dependency build could not be repeated in the packaging container because dependency installation timed out; the user-side V50 Bun build had already succeeded and no dependency versions were changed in V51.

## Manual run

```powershell
cd webapp\frontend
bun install
bun run build
cd ..\..
.\.venv\Scripts\Activate.ps1
python -m uvicorn webapp.backend.app.main:app --host 127.0.0.1 --port 8765
```

Open `http://127.0.0.1:8765` and use `Ctrl+Shift+R` once after replacing an older release.
