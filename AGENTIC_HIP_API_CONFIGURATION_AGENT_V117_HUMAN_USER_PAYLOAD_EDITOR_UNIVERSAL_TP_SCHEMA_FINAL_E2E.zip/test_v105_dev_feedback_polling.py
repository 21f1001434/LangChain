from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import run_agent
from execution_flow import DEFAULT_ORDER, STEP_DEFINITIONS, ExecutionFlowConfig

ROOT = Path(__file__).resolve().parent


def _result(seq, group, api, attempt, method, url_key, *, status=200, classification="PASS_SUCCESS", success=True, extracted=None, response='{"success":true}'):
    return run_agent.Result(
        seq, group, api, attempt, method, f"https://mock/{url_key}", "HIP", "",
        status, classification, success, 1, "", "{}", response,
        extracted or {}, "WORKING" if success else "NEEDS_REVIEW", "", "WORKING" if success else "NEEDS_REVIEW", "", "",
    )


def test_v105_rule_payload_removes_dev_rejected_zero_id_fields():
    runner = run_agent.Runner(llm_enabled=False)
    payload = runner.rule_payload()
    assert "documentTypeId" not in payload
    assert payload["documentTypeName"]
    params = payload["actions"][0]["params"]
    assert "mapId" not in params
    assert params["mapIdentifier"]
    assert params["mapVersion"]


def test_v105_execution_flow_waits_for_both_tp_audits_before_flow_create():
    cfg = ExecutionFlowConfig(ROOT)
    order = cfg.ordered_steps()
    assert order == DEFAULT_ORDER
    assert order.index("source_tp") < order.index("source_tp_audit") < order.index("flow_create")
    assert order.index("target_tp") < order.index("target_tp_audit") < order.index("flow_create")
    assert set(STEP_DEFINITIONS["flow_create"]["dependencies"]) >= {"source_tp_audit", "target_tp_audit"}
    assert STEP_DEFINITIONS["source_tp_audit"]["pollEverySeconds"] == 60
    assert STEP_DEFINITIONS["source_tp_audit"]["timeoutSeconds"] == 3600
    assert STEP_DEFINITIONS["flow_history"]["pollEverySeconds"] == 60
    assert STEP_DEFINITIONS["flow_history"]["timeoutSeconds"] == 3600


def test_v105_audit_response_classification_is_terminal_aware():
    runner = run_agent.Runner(llm_enabled=False)
    c, ok = runner.validate_step_business_result("tp_audits", [], "PASS_SUCCESS", True)
    assert (c, ok) == ("TP_AUDIT_PENDING", False)
    c, ok = runner.validate_step_business_result("tp_audits", [{"status": "IN_PROGRESS"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("TP_AUDIT_PENDING", False)
    c, ok = runner.validate_step_business_result("tp_audits", [{"status": "SUCCESS"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("PASS_SUCCESS", True)
    c, ok = runner.validate_step_business_result("tp_audits", [{"status": "FAILED"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("TP_AUDIT_FAILED", False)

    c, ok = runner.validate_step_business_result("flow_deploy_history", [{"deploymentStatus": "PROCESSING"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("FLOW_DEPLOYMENT_AUDIT_PENDING", False)
    c, ok = runner.validate_step_business_result("flow_deploy_history", [{"deploymentStatus": "DEPLOYED"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("PASS_SUCCESS", True)
    c, ok = runner.validate_step_business_result("flow_deploy_history", [{"deploymentStatus": "FAILED"}], "PASS_SUCCESS", True)
    assert (c, ok) == ("FLOW_DEPLOYMENT_AUDIT_FAILED", False)


def test_v105_strict_live_polls_tp_and_flow_audits_before_progress(monkeypatch):
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "2")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "2")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.001")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "0.2")
    monkeypatch.setenv("HIP_FLOW_AUDIT_POLL_INTERVAL_SECONDS", "0.001")
    monkeypatch.setenv("HIP_FLOW_AUDIT_POLL_TIMEOUT_SECONDS", "0.2")

    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    audit_counts = {"source": 0, "target": 0, "flow": 0}
    flow_create_seen = []

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        payload = kwargs.get("payload")
        params = kwargs.get("params") or {}
        if api == "Create source document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92011})
        if api == "Create target document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92012})
        if api == "Create/resolve MAC Map":
            return _result(seq, group, api, attempt, method, url_key, extracted={"mapId": 1670})
        if api == "Create mapping rule":
            assert "documentTypeId" not in payload
            assert "mapId" not in payload["actions"][0]["params"]
            return _result(seq, group, api, attempt, method, url_key, extracted={"ruleId": 33001})
        if api == "Source TP audit history":
            audit_counts["source"] += 1
            if audit_counts["source"] == 1:
                return _result(seq, group, api, attempt, method, url_key, classification="TP_AUDIT_PENDING", success=False, response='[{"status":"IN_PROGRESS"}]')
            return _result(seq, group, api, attempt, method, url_key, response='[{"status":"SUCCESS"}]')
        if api == "Target TP audit history":
            audit_counts["target"] += 1
            if audit_counts["target"] == 1:
                return _result(seq, group, api, attempt, method, url_key, classification="TP_AUDIT_PENDING", success=False, response='[{"status":"PROCESSING"}]')
            return _result(seq, group, api, attempt, method, url_key, response='[{"status":"SUCCESS"}]')
        if api == "Flow orchestration create ONLY":
            flow_create_seen.append((audit_counts["source"], audit_counts["target"]))
            assert audit_counts["source"] >= 2 and audit_counts["target"] >= 2
            inner = json.loads(payload["flowDefinition"])
            details = inner["targetDetails"]["targets"][0]["processSteps"][0]["configuration"]["defaultConfig"]["ruleRefs"]["ruleDetails"]
            assert details == {"name": runner.business["mappingRuleName"], "version": runner.business["mappingRuleVersion"]}
            assert "id" not in details
            return _result(seq, group, api, attempt, method, url_key, extracted={"flowId": 44001, "flowVersion": "1.0"})
        if api == "Flow deployment history":
            audit_counts["flow"] += 1
            if audit_counts["flow"] == 1:
                return _result(seq, group, api, attempt, method, url_key, classification="FLOW_DEPLOYMENT_AUDIT_PENDING", success=False, response='[{"deploymentStatus":"PROCESSING"}]')
            return _result(seq, group, api, attempt, method, url_key, response='[{"deploymentStatus":"DEPLOYED"}]')
        return _result(seq, group, api, attempt, method, url_key)

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(runner.adaptive, "record_mapping_graph", return_value={"status":"mocked"}):
        results = runner.run()

    assert flow_create_seen
    assert audit_counts == {"source": 2, "target": 2, "flow": 2}
    assert runner.final_state["success"] is True
    assert runner.final_state["coverageComplete"] is True
    assert runner.final_state["unresolvedRequiredSteps"] == []
    assert len({(r.extracted or {}).get("logicalStepKey") for r in results if r.status_code is not None}) == 18


def test_v105_tp_audit_timeout_blocks_flow_creation(monkeypatch):
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "1")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE_ROUNDS", "1")
    monkeypatch.setenv("HIP_STRICT_COVERAGE_ROUNDS", "1")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.001")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "0.005")

    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    flow_create_called = False

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        nonlocal flow_create_called
        if api == "Create source document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92011})
        if api == "Create target document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92012})
        if api == "Create/resolve MAC Map":
            return _result(seq, group, api, attempt, method, url_key, extracted={"mapId": 1670})
        if api == "Create mapping rule":
            return _result(seq, group, api, attempt, method, url_key, extracted={"ruleId": 33001})
        if api == "Source TP audit history":
            return _result(seq, group, api, attempt, method, url_key, classification="TP_AUDIT_PENDING", success=False, response='[{"status":"IN_PROGRESS"}]')
        if api == "Target TP audit history":
            return _result(seq, group, api, attempt, method, url_key, response='[{"status":"SUCCESS"}]')
        if api == "Flow orchestration create ONLY":
            flow_create_called = True
        return _result(seq, group, api, attempt, method, url_key)

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(runner.adaptive, "record_mapping_graph", return_value={"status":"mocked"}):
        runner.run()

    assert flow_create_called is False
    assert runner.final_state["success"] is False
    assert "source_tp_audit" in runner.final_state["unresolvedRequiredSteps"]
    assert "flow_create" in runner.final_state["coverageMissingSteps"]


def test_v105_flow_create_400_does_not_mutate_name_or_retry_with_changed_payload(monkeypatch):
    monkeypatch.setenv("HIP_STRICT_LIVE_PIPELINE", "1")
    monkeypatch.setenv("HIP_FULL_API_COVERAGE_MODE", "0")
    monkeypatch.setenv("HIP_API_PARALLEL_ENABLED", "0")
    monkeypatch.setenv("HIP_LIVE_AUTO_COMPLETE", "0")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_INTERVAL_SECONDS", "0.001")
    monkeypatch.setenv("HIP_TP_AUDIT_POLL_TIMEOUT_SECONDS", "0.1")
    monkeypatch.setenv("HIP_FLOW_AUDIT_POLL_INTERVAL_SECONDS", "0.001")
    monkeypatch.setenv("HIP_FLOW_AUDIT_POLL_TIMEOUT_SECONDS", "0.1")

    runner = run_agent.Runner(llm_enabled=False)
    monkeypatch.setattr(runner.execution_flow, "wait_after", lambda _key: 0.0)
    original = runner.flow_name()
    create_names = []

    def fake_call(seq, group, api, attempt, method, url_key, scope_key, *args, **kwargs):
        payload = kwargs.get("payload") or {}
        if api == "Create source document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92011})
        if api == "Create target document type":
            return _result(seq, group, api, attempt, method, url_key, extracted={"documentTypeId": 92012})
        if api == "Create/resolve MAC Map":
            return _result(seq, group, api, attempt, method, url_key, extracted={"mapId": 1670})
        if api == "Create mapping rule":
            return _result(seq, group, api, attempt, method, url_key, extracted={"ruleId": 33001})
        if api in {"Source TP audit history", "Target TP audit history"}:
            return _result(seq, group, api, attempt, method, url_key, response='[{"status":"SUCCESS"}]')
        if api == "Flow orchestration create ONLY":
            create_names.append(payload.get("flowName"))
            return _result(
                seq, group, api, attempt, method, url_key,
                status=400, classification="CLIENT_ERROR", success=False,
                response='{"message":"Flow name already exists. Please create flow with different name."}',
            )
        return _result(seq, group, api, attempt, method, url_key)

    monkeypatch.setattr(runner, "call", fake_call)
    with patch.object(runner.adaptive, "record_api_result", return_value=None), patch.object(runner.adaptive, "record_mapping_graph", return_value={"status":"mocked"}):
        runner.run()

    assert create_names == [original]
    assert runner.flow_name() == original
    # The purpose of this regression is request immutability: the runner must not
    # invent a new flowName or issue a second changed request. Exact same-call
    # EXISTING semantics are evaluated separately by the reporting/dependency policy.
    assert len(create_names) == 1
    # V116: the exact current-run Flow Create call returned explicit EXISTING
    # evidence. That satisfies the Deploy dependency without renaming the Flow
    # or injecting a historical Flow ID.
    assert "flow_create" not in runner.final_state["unresolvedRequiredSteps"]
