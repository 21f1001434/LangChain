from __future__ import annotations

import json
from pathlib import Path

from agentic_interface_orchestrator import AgenticInterfaceOrchestrator
from api_pdf_ingestion import PdfApiKnowledgeBase
from interface_registry import get_interface, save_custom_interface
from runtime_payload_values import placeholder, save_runtime_payload_values, clear_runtime_payload_values

ROOT = Path(__file__).resolve().parent


def _check_custom_registry_and_agent() -> dict:
    definition = save_custom_interface(
        ROOT,
        "MQ-DEMO",
        {
            "displayName": "MQ Demo",
            "apiInterfaceType": "MQ",
            "family": "MESSAGING",
            "description": "Validation-only custom messaging interface for package tests.",
            "deploymentGroup": "hip-automation",
            "sourceSharedProfile": "da-sender-mq-dce-common",
            "targetSharedProfile": "pt-receiver-mq-dce-common",
            "sourceDefaults": {"Queue Manager": "QM1"},
            "targetDefaults": {"Queue Manager": "QM2"},
            "sourceRequired": ["Queue Manager"],
            "targetRequired": ["Queue Manager", "Broker Client Secret"],
            "targetSensitiveFields": ["Broker Client Secret"],
            "requiresDocumentation": False,
        },
    )
    assert definition["apiInterfaceType"] == "MQ"
    assert get_interface(ROOT, "MQ-DEMO")["family"] == "MESSAGING"

    baseline = json.loads(
        (ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8")
    )
    pdf_kb = PdfApiKnowledgeBase(ROOT)
    agent = AgenticInterfaceOrchestrator(ROOT, baseline, pdf_kb=pdf_kb)

    blocked = agent.propose(
        source_interface="MQ-DEMO",
        target_interface="MQ-DEMO",
        source_parameters={"Queue Manager": "QM1"},
        target_parameters={"Queue Manager": "QM2"},
        source_shared_profile="da-sender-mq-dce-common",
        target_shared_profile="pt-receiver-mq-dce-common",
    )
    assert blocked["valid"] is False
    assert any(q["field"] == "Broker Client Secret" for q in blocked["questions"])

    ready = agent.propose(
        source_interface="MQ-DEMO",
        target_interface="MQ-DEMO",
        source_parameters={"Queue Manager": "QM1"},
        target_parameters={
            "Queue Manager": "QM2",
            "Broker Client Secret": placeholder("target.broker_client_secret"),
        },
        source_shared_profile="da-sender-mq-dce-common",
        target_shared_profile="pt-receiver-mq-dce-common",
    )
    assert ready["valid"] is True, ready
    assert ready["critic"]["status"] == "PASS"
    proposal = ready["proposal"]
    assert proposal["objects"]["source_transport_profile"]["interface_type"] == "MQ"
    assert proposal["objects"]["target_transport_profile"]["interface_type"] == "MQ"
    assert proposal["objects"]["source_transport_profile"]["interface_parameters"]["Queue Manager"] == "QM1"
    assert proposal["objects"]["target_transport_profile"]["interface_parameters"]["Broker Client Secret"] == placeholder("target.broker_client_secret")
    assert proposal["objects"]["biz_flow"]["configure_source"]["source_transport_profile"] == "da-sender-mq-dce-common"
    assert proposal["objects"]["biz_flow"]["configure_targets"]["target_transport_profile"] == "pt-receiver-mq-dce-common"
    assert proposal["objects"]["biz_flow"]["configure_routing"]["actions"]["target"] == "pt-receiver-mq-dce-common"
    assert proposal["objects"]["source_transport_profile"]["deployment_group"] == "hip-automation"
    return {
        "customInterfaceRegistered": True,
        "missingValueInterview": True,
        "criticPassed": True,
        "sharedFlowProfilesBound": True,
    }


def _check_generic_runner_payload() -> dict:
    import run_agent

    original = (ROOT / "input.json").read_text(encoding="utf-8")
    baseline = json.loads(
        (ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8")
    )
    agent = AgenticInterfaceOrchestrator(ROOT, baseline, pdf_kb=PdfApiKnowledgeBase(ROOT))
    proposal = agent.propose(
        source_interface="MQ-DEMO",
        target_interface="MQ-DEMO",
        source_parameters={"Queue Manager": "QM1"},
        target_parameters={
            "Queue Manager": "QM2",
            "Broker Client Secret": placeholder("target.broker_client_secret"),
        },
        source_shared_profile="da-sender-mq-dce-common",
        target_shared_profile="pt-receiver-mq-dce-common",
    )["proposal"]

    try:
        (ROOT / "input.json").write_text(json.dumps(proposal, indent=2), encoding="utf-8")
        runner = run_agent.Runner(llm_enabled=False)
        # V72: a custom interface can still be learned into input.json, but the
        # 18 LIVE API payload must not invent/project attributes for it. Until
        # the dev team registers its exact interfaceDetails template, preview/
        # preflight is blocked rather than sending FILE/HTTPS fields by guess.
        try:
            runner.preview_step_request("source_tp")
            raise AssertionError("unsupported custom interface should be blocked")
        except ValueError as exc:
            assert "no developer-approved LIVE payload template" in str(exc)

        flow = runner.preview_step_request("flow_create")
        flow_def = json.loads(flow["payload"]["flowDefinition"])
        assert flow_def["sourceDetails"]["sourceTransportProfile"] == ["da-sender-mq-dce-common"]
        assert flow_def["targetDetails"]["targets"][0]["targetTransportProfile"] == "pt-receiver-mq-dce-common"

        save_runtime_payload_values(ROOT, {"target": {"broker_client_secret": "TEST_ONLY_CUSTOM_SECRET"}}, merge=True)
        resolved = runner._resolve_runtime_payload_values(
            {"Broker Client Secret": placeholder("target.broker_client_secret")}
        )
        assert resolved == {"Broker Client Secret": "TEST_ONLY_CUSTOM_SECRET"}
        clear_runtime_payload_values(ROOT)
        return {
            "customInterfaceInputCanBeLearned": True,
            "unsupportedLivePayloadBlockedUntilDevTemplate": True,
            "genericPayloadSecretLateResolution": True,
            "flowBindingUsesRegistryProfiles": True,
        }
    finally:
        (ROOT / "input.json").write_text(original, encoding="utf-8")


def _check_documentation_gate() -> dict:
    definition = save_custom_interface(
        ROOT,
        "DOC-REQUIRED-DEMO",
        {
            "displayName": "Documentation Required Demo",
            "apiInterfaceType": "DOC-DEMO",
            "family": "CUSTOM",
            "deploymentGroup": "hip-automation",
            "sourceSharedProfile": "da-sender-doc-dce-common",
            "targetSharedProfile": "pt-receiver-doc-dce-common",
            "sourceDefaults": {"Mode": "A"},
            "targetDefaults": {"Mode": "B"},
            "sourceRequired": ["Mode"],
            "targetRequired": ["Mode"],
            "requiresDocumentation": True,
        },
    )
    assert definition["requiresDocumentation"] is True
    baseline = json.loads(
        (ROOT / "dev_approved" / "UHAL_input_dev_approved.json").read_text(encoding="utf-8")
    )

    class EmptyDocs:
        def has_documents(self):
            return False

    agent = AgenticInterfaceOrchestrator(ROOT, baseline, pdf_kb=EmptyDocs())
    result = agent.propose(
        source_interface="DOC-REQUIRED-DEMO",
        target_interface="DOC-REQUIRED-DEMO",
        source_parameters={"Mode": "A"},
        target_parameters={"Mode": "B"},
        source_shared_profile="da-sender-doc-dce-common",
        target_shared_profile="pt-receiver-doc-dce-common",
    )
    assert result["valid"] is False
    assert any(q["field"] == "apiDocumentation" for q in result["questions"])
    return {"documentationGate": True}


def test_custom_registry_and_agent() -> None:
    assert _check_custom_registry_and_agent()


def test_generic_runner_payload() -> None:
    assert _check_generic_runner_payload()


def test_documentation_gate() -> None:
    assert _check_documentation_gate()


def main() -> None:
    output = {
        "status": "PASS",
        "buildId": "2026-08-11-partner-payload-values-v12",
        "registry": _check_custom_registry_and_agent(),
        "runner": _check_generic_runner_payload(),
        "documentation": _check_documentation_gate(),
    }
    path = ROOT / "examples" / "ANY_INTERFACE_AGENTIC_STUDIO_VALIDATION.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
